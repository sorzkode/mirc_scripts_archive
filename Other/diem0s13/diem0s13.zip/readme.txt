To Get DiEM0s to work, place a mirc32.exe or a 
mirc.exe in the same directory as these .ini's 
and just run mirc
it will autoload
once you connect to a server
type /setup to setup your fserver
and then go thru the popups to configure 
your xdcc'er ( thier aren't that many! )
have fun!

