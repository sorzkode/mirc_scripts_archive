$$$$$$      s$$$$$$$$$$$$$$$$$$$$$$$$$s 
$$   $$                 $$ 
$$    $$  s$$$s s$$$$$  $$ $$ $$$   $$ s$  $$
$$    $$ $$  $$ $$      $$ $$ $$$$  $$ $$  $$
$$    $$ $$$$$$ $$$$$$s $$ $$ $$ $$ $$ $$  $$
$$    $$ $$          $$ $$ $$ $$  $$$$ $$  $$
$$    $$  $$$$   $$$$$s $$ $$ $$   $$$ s$$$$$
$$   $$                                    $$
$$$$$$       s$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$s



Pure Destiny *3.0* by EdgeWise
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Script For mirc version: 4.7
Bot: 4.6
[only because it's only a minor upgrade from
Destiny *3.0* for 4.6]
----------------------------------------
all of this gets loading into c:\destiny
add mirc.exe or mirc32.exe to this dir
AND add mirc32.exe to c:\destiny\bot
and in c:\destiny make a "logs" folder
also on c:\destiny make a "download" folder


thanx too.. JEEP_KID, Enforcer, ThunderCloud,
FrOsY, LiPgLoSs and Rally all helped me with
some *leet* coding
---------------------------------------
this edition is for everyone
---------------------------------------

enjoy!
---------------------------------------
Problems/Comments, Email
EdgeWise@bayside.net

Enjoy.. ***and no IRCing Drunk :P***
*You Drink, You IRC, You Die*
