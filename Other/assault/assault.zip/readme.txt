Assault v1.0 Installation Instructions
IMPORTANT:  Delete all previous copies of Assault 
before continuing.  Then extract and run install.exe
