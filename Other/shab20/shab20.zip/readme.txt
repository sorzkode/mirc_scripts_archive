README FOR SHADESBOT 2.0

Before you go installing it please at least skim through this file

I will try and keep it short

!!!!
Ok shadesbot contains a leech proove fserver which is written by a freind
of mine called hawkee (he gave me permission to use it)

Also shadesbot 2.0 contains a lot of addins and stuff which most other
scriptz do not contain

the only reason why i have released this scriptz is becuase i first wrote
shadesbot as a script for myself
but a few people were asking me where they could get a copy so
i decided to release it.

After the success if the original version I decided the had to be a sequel
and now with the release of mirc 4.7 I finally had it just were I wanted it
and after a slight face lift and a lot of major changes it is now
what you see before you.

INSTALLATION
just make a tempory dir dont matter what it is called

and unzip shab20.zip to thier
and then just run the file named install.bat
and it will do the rest for you

HAve FuN :->