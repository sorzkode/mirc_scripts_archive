
 ���� V1.0 �� ߢ��� ��mp��t��, � m��� 4.6 ����pt

Hello,
Thanx For Gettin This Script
i Would Like To Say Some Stuff,
This Script was Really Good, But not as Good as it was, Because a Command i put into Remote Messed it up At one point
but, V1.5 Is not Gonna Have Any Problems, Because I All Ready Started it, And it is not Near as Bad as this Script, This next Script is Very Very Poweful, it is Basicly a Takeover Script, and Major Protection, Please If You Don't Like this Script wait for xxx-��f�G�v��-xxx V1.5
Because it has no problems in it, it is a Very Exelent Script That Is Around Maybe 3 Megz,
Please Wait For That Script if You Don't Like this one,
This Script is a Exelent Script, But maybe a Few problems, and not to many Aliases,
Some Of The Feuters On This Script Are:
Partyline - Have Yer own Channel in a Dcc Chat window
User Levels, Master, Op,Voice,And About 10 different Shitlists - Auto Ops, And Auto Bans, Auto Voice
Floodz - Be Mr Mean Guy And Start Flooding The Heck Outta People, If ya wanna Be Real Mean Wait For V1.5
ICMP - IP Flood Someone, Put The Ip In, By Typing /Dns There nick, Then In The Status Window You'll See A Number, and Put Tha Number in The Icmp Program, then Hit Start, and You'll Wacth The Person Fry Off The Irc Server
There is Way To Much, There is About 150 Feuters, And Hack Protection, and Like 10 Flood Protections


About This Script

This Script is a mIRC 4.6 Script, It is a Exelent Channel Script - Unlike V1.5
This Script Well No Longer Be named ���� V1.0
Because a lamer Took It
If You see a Person Named Edson, Please Tell Him To Fuk off From Bcool.
This Guy Stole my Script name, and Said my Script Sux, So, this Version My Be Like That, But If He Says UnFerGiven Sux, He is A Lamer, Who Is Gonna Get it.
This Script Has Some Problems
But V1.5 Does not have 1 lil Problem in the Script.
Please If You don't like This Version, i know what you mean. But, It is a Channel Script, That Well Not Mess Up, Or make any harm to the channel
This Script Is not Gonna End Up Bein a channel Script in the next version
Because Edson UnDerEstimated The Power Of The Dark Side!
LOL
So If You don't like this Version, Please Please Please Get V1.5
Because That Version Well not Suk.
It Might be abit Screwie Because a Command i put in Messed it up at a point, so it is not as good as it should of been.
THIS SCRIPT IS MOSTLY A REMOTE SCRIPT.
And This Script Also Was Suppose To Have a .hlp File, But i did not get enough time to finish it.

Thanx To
Dejon - Was a Tester Of the Script
Codyak And Grizbear - for lettin me Test and Write the Script in there channel
Hiro101 - For Helpin me With Some of The Programs
WaVeGuY - For Helpin me with Some of The Remotes
^Smokin - For Helpin me Tell Edson off.

Thanx Everyone


And Thank You Very much For Tryin my Script.
Please if you don't like this Script get V1.5!
ALSO
UNZIP THIS SCRIPT TO THE C:\CoOl1.0 Directory, or it well not work