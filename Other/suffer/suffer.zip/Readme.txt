_________________________

��ff� Bot ��� 

By: Amigan
_________________________

This Bot Is Fairly Easy to Use.
So I will bring you through this
step by step.Ok if your reading this
you aviousily installed my bot.So now what
you do is copy mIRC 5.02 to c:\Suffer\
and double click on mIRC.It should All load up.
Once your connected to a server(with my bot)
Type /msg {Its Nick} suffer
It should there for msg you back with the commands.
This will turn the bot on. Then your ready.this
bot is really for begginers because its so
easy to use.Well have fun wit the bot.
I didnt include funky colors because
I think colors are worthless.They look like crap
to me an i never use them for multtiple reasons.
1.Dammit they just dont look good.....
2.They slow down mirc dammit......(I like sayin 
dammit...can ya tell.....lol)

Well Thats All from me now....
If ya need me e-mail me at Amigan@Usa.Net
Im usually on comicsrv1.microsoft.com:6667

-Amigan
