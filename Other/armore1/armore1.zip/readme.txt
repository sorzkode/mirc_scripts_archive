�Įm���ЦG��б 1.0beta
by black][ce and Dungeon_Master_
--------------------------------------------------------

    ** YOU NEED TO USE WIN95 TO RUN THE SETUP!!! **

All you have to do is make a directory called
ArmoredGuard. Then, extract all of the files to that dir
Add a copy of mIRC, then you are ready to go!

--------------------------------------------------------

If you find any bugs in this script, please email them
to kblalock@interconnect.net. Or, if you can find me
(black][ce) on DAL.net, tell me.

�Įm���ЦG��б 1.0beta
by black][ce and Dungeon_Master_