*****************************************************
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

WHEN YOU UNZIP THIS FILE,EXTRACT IT TO

     C:\totaldestruction

OR ELSE NOTHING WILL WORK...

E-mail me at whyitsme@wgn.net and I'll tell u if I make
anything else for TD that would help you.I'll answer any
questions u need =)


*Thank you for using tOtAl DeStRuCtIoN

                sKaTeR97

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
*****************************************************