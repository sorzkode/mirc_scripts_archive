# Readme.txt for Bizotch #1 #
A note on why Bizotch was made...
I made this script because generally, most of the
scripts made now and in the past are war, protection,
file offering, or any combination of those. It got
boring for me because everything was basically the same.
Although almost every decent script has at least one
thing which makes it unique, most really aren't much
different from all the others. The goal I am trying to
achieve with Bizotch is a script which is very complex,
configurable, contains all the normal script stuff, and
introduces a few new and useful items, yet remains easy
to use. Now let's get on to the info stuffs you need to
know to get yourself started.

First off, this script has NO floods or any type of irc
war stuff because that stuff is LAME AS SHIT. If you
want war stuff in it, put it in yourself.

#    All code in all sections of this script is   #
#  original. If you have seen it somewhere else,  #
#  then either a) it was in a previous script of  #
# mine, b) I gave someone else code examples and  #
#   that person ripped it, or c) it's just some   #
#   tiny routine which nearly all scripts have.   #

Thanx must go out to:
-Pulvidon for suggesting the global commands (the /g
 alias)
-|Dawd| for pointing out a few bugs which I was
 unaware of
-FreeJack2 for suggesting a confirmation on the /massop
 and /massdeop aliases after he accidentally massop'ed
 #madcrew <G>
-Datsun for supplying some of the actions associated
 with the /rme alias and helping me test
-WeBBeR and sPoNgE for helping me test
-My girl friend for being a pain in the arse

Finally, stuff to get you started:
-Bizotch is made for mIRC version 4.72. If you use
 it with any other version of mIRC, you will not
 be given any support if it is needed.
-unzip the main .zip file FROM c:\bizotch with the -d
 flag. Example: C:\Bizotch\> pkunzip -d bizotch.zip
-copy mirc32.exe into c:\bizotch
-run mirc32.exe
-the 'bhelp' alias will give you a general help file
 and an alias list. 'h <alias>' will give you help on
 any alias you list.

NOTICE
-If you wish to change the fonts mIRC uses with this
 scripts, certain messages you receive will not look
 as they are meant to. If you don't like this, then fix
 it. Please do not ask me how.

SECURITY NOTICE
-If you have users in your ops list, don't under ANY
 circumstances give out your vars.ini file!! That file
 contains all ops list users' passwords... and they're
 NOT encrypted.

Advertisement Stuff:
The Bizotch Homepage is
http://www.mindcryme.com/~spyke/bizotch.html
Please visit for new versions and/or update information.

Bizotch is sponsored by the mIRC Warehouse, mIRC
enhancement specialists. Located at
http://www.mindcryme.com/~spyke/mirc
(Still under construction at this point in time)

Other Notes
If you wish to receive support or help with this script,
you must be using it just like it came out of the zip
file. If you have changed any of the script code by
hand, support will not be given. Period. At all. Why?
Because this is a very complex script.. one little
mistake and the whole thing can 'blow up' on you.

-Spyke
 Feb. 17, 1997
