09/02/97 - Emploth for mIRC 4.72 - emploth@hotmail.com - Author: Wezz
--------------------------------
                ********************************
                             
                          Emploth v1.0
                      
                ********************************


   Thank you for downloading Emploth. Almost hundreds of hours scripting, coding and
   testing have made this script to what it is. 
   When I released the beta version of this script, one day in marsh, almost 30 persons
   download it the first week. That was quiet a lot more than I had expect. One week 
   later, when I checked my email for the first time that week (home from a one week 
   long holiday) had my email 60 emails from 40 different peoples that just loved my
   script and wondered when the full version of my script would release. I told them,
   soon, and here we are. Today is it one month from the beta versions release. 
   This is Emploth full version 1.0. Enjoy!
   
   *** Installtion ***
   1) Install mIRC 4.7 or later in a new directory. For example 
   c:\emploth\. Then copy all zipped files to the directory.
   If you allready have mIRC installed can you copy this files
   to that directory. 
   2) Open the exe file mIRC32.exe or mIRC.exe. Fill in the setup
   menu whish popups and type /setup in the status window.
   Follow the instructions and after that is the installtion done!
   ********************

   the original emploth files are able to download at
   http://home3.swipnet.se/~w-33865/emploth.htm
   
******** E * N * D * * * F * I * L * E ***********
