		7th Sphere v2.666 
	by Cashmere, Venum, and precursor
		Addons by Rhad


Install Instructions:

1. Delete any mIRC Files or older 7th Sphere files off your computer
   this means all the ini's. They can corrupt 7th Sphere's files and
   render it useless.

2. Run the setup.exe that was in the Zip with this readme.

3. Follow all the on screen instructions. It is HIGHLY
   RECOMENDED that you install it to c:\sphere

4. Icons will be created on the start menu.

5. Further help can be obtained by reading the Sphere.hlp file


Special Release Notes:

The copy the file called 'trace.bat' that was extracted from this
zip to your windows directory. This is necassary for ICMP Scan 3
to function properly. 


Known Bugs:

The only known bug is that when you switch to the War Menu it appears
that it does not switch. This is caused by mIRC. A Simple fix for this
is to Minimize and then Maximize mIRC.


Copyright Info:

The new 7th Sphere contains many programs and *.wav files that MAY NOT
be used with any other script. These were written for 7th Sphere ONLY.
This means that if you want to use our tools in your script too fucking
bad. 


7th Sphere � 1996 Cashmere, Venum and Precursor. 
Addons (Portscan, WanIRC, Portfuck, WaKo) � 1996 by Rhad
All *.wav files � 1996  Perran Lewis Davis III of Nonchalant Records
WWW Page: http://www.localnet.com/~marcraz
E-Mail: 7thsphere@geocities.com


All Rights Reserved To Their Respective Owners