���th��k for DALnet

Readme


Thank you for reading this....


*	Included in the zip file is orbs.dll...
	There are some nice icons in there...
*	The Guess the Number game was developed by
	baz`oo`ka..I did change a few things...
*	The Color Nice Stuff was given to me, by a user
	who still remains a blur in my mind..
*	The Magic 8-Ball was found on a fserve


I included this information so that you will know where i got
some of the stuff

I am certain everything in this works...If you find ne bugs,
email me at ngreene@hotmail.com and report it...

When I'm on IRC I usually am in #mirc_scripts, skripterz, and mirc_scripters_plus

After you have used my script, please email me w/ an opinion of it
and what you would like to see in an upcoming version...

Thank U for reading this, and enjoy ���th��k


Infinital

