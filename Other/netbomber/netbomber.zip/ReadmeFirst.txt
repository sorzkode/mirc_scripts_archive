ѣT��/\/\�� v1.0 Agreement:

	By Installing This Script Onto Your Computer or 
Disk You Agree To The Following Terms:

(1).  You Will Not Copy Anything From ѣT��/\/\�� v1.0
Into Any Other Script.

(2).  You Will Not Rename The Script.

(3).  You Will Not Take Credit For Making The Script By
Changing The Creaters Name To Yours Or In Any Other Way.

(4).  ^Pman^ Is Not Responsible For Any Of Things You
Use This Script For.

(5).  Have Fun And Enjoy The Script :)

	Please Send Any Questions Or Comments To:

		    drde@sisna.com

			Thanks!

--------------------------------------------------------

� Made By ^Pman^ � 1997

--------------------------------------------------------