---------------------------------------------------------
G��T��� Version 1.5 �y ]-[awk for mIRC 5.02 
---------------------------------------------------------
RELEASED: 17 May, 1997

-

INSTALLATION: To install Guillotine for mIRC simply extract the contents of
	the ZIP file to c:\Guillotine\ (prefered) or any other directory.

-

SETUP:  Setup of Guillotine is nearly completely 
	automatically.  When Guillotine is run for the first time you will
	be asked to fill in the channels you have Z access on and the
	password.  These will then be accessed by using a combination of
	SHIFT + F1,F2-F12  To list the channels Z access has been set on
	type: /z show  This will also display the password for the channel
	with access.

-

USAGE:	Usage of Guillotine is fairly simple to use and any problems
	can be answered at the Guillotine Homepage:
	http://student.uq.edu.au/~s340310/Guillotine
	If the problem is not answered please feal free to fill in the form
	and the	problem will be answered as soon as possible.


	SPYBOT:	To Use The Spy Bot type: /spy load or select it from the main
		Guillotine menu.  The Spy Bot will respond to all of mIRCs 
		command.  To use a command type: /spy command paramaters.  For
		example to connect to a different server type: /spy server 
		us.undernet.org 6666
-

THANKS: Many thanks goes to Topher, Darkness, Hyst3ria and whoever else
	helped me with the making of this script.

-

CONTACTS:

	Email: hawk@earthling.net
	Form Help: http://student.uq.edu.au/~s340310/Guillotine/help.html
	Home Page: http://student.uq.edu.au/~s340310/Guillotine

-

