==========�v� ���ipT Version 3.0=========Readme file!!!!!!!

Welcome �v� ���ipT !!!!!!!        RIGHT AWAY: you might want to read the HINTS file!!!! 

	THIS NEEDS TO GO IN C:\ESMIRC :)	
Hi, Welcome to �v� ���ipT by Limbeck777. I will 
continue working on this script to improve it always.
If you notice anything I need done to it, Please find me
on DALnet as Limbeck777 or something.
More better things are coming soon!!!!!!!
PLEASE Send ALL Suggestions to Limbeck@sprynet.com 
I will continue working my hardest on this, until
I get it to be the number 1 script out there! 
You will continue to find new versions!!!!!!!
You may also have any questions about mIRC or this script, then
contact me on DALnet as Limbeck777
I fixed a TON of bugs in this version!!!!!!!

Copy mirc32.exe into c:\esmirc and Click on mirc32.exe . And it should work!!!!!!!
If you have
any problems E-MAil me at Limbeck@sprynet.com
I ask one more thing of you....That you not steal things from this
and claim it is yours! Thank You!!!!!!!




PLEASE SEND ALL SUGGESTIONS/COMMENTS/COMPLAINTS, ETC. TO ME!!!!!!! Thank You!!!!!!!
E-Mail me at Limbeck@sprynet.com if you have any problems!!!!!!!





GET MIRC 4.72+ AT HTTP://WWW.MIRC.CO.UK   Although this script comes with it USUALLY!!!!!!!

I am NOT responsible for aything that this script does to your system. Or
if you get G:Lined, K:Lined, Kicked/Banned, ANYTHING!! I am NOT responsible! :)