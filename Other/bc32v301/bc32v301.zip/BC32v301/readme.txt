�� Blue-Chip� �� for DALnet 1997 Version 3.01

Please read the changes to 3.01 below.

If you did not accept the DEFAULT Directory c:\BCscript Please
re-install otherwise it will not work.

Thank you for using Blue-Chip� for DALnet 1997.

Introduction

My wife and I have been an OPs in Funfactory on DALnet for sometime
now. It became obvious very fast that the channel could not be 
controlled effectively without the use of Scripts.  It was also
evident that flood protection scripts were also required in 
Funfactory in order to retain our server connection.  Therefore 
I have been working slowly on Scripts to fill the needs of Funfactory.

Please pardon my french and spelling mistake.

Rights and Liability.

This Script package is the Property of Blue-Chip.  Please do not distribute
portions of it or alter my routines without my prior consent.  I have spent
a large amount of time designing and testing in order to please friends.
Feel Free however to distribute the entire package.. files called 
bc32v30.zip(win95) or bc16v30.zip(win3.1).  In using these Scripts, you are
agreeing to exampt me from any liability/responsibility for Damages or
virus or others which may occur with or by the use of these scripts. 

NOTE1: These Scripts are VIRUS FREE in its original installer.  I wrote the 
above, simply to protect myself against anything which could happen beyond
my knowledge or control.  I did not put any Flooding Scrits because
i do not want my scripts to be involved in Lame and Wrong doing to others. 

IMPORTANT:: READ THIS FILE SO THAT YOU KNOW HOW TO USE THESE SCRIPTS.

NOTE2: There are 2 Scripts which i did not write.... the /CT alias 
for the color text and the repeat kick which i got from someone.  I do
not remember from who so i appologize for not being able to give credit
where it is due.

NOTE3: Please be very carefull if you alter the content of the Alias or 
remotes.  Many things are dependant on others, therefore i cannot 
promise that every thing will work if you remove parts. If you do want to 
add Aliases... do so by adding at the bottom.  This will minimize the chance
of affecting the aliases used by the scripts.

NOTE4: Changing the setting on your DCC "Will Affect" how your scripts work.
You are well protected with the DCC's set to auto.  If you wish to receive
DCC's from some one... use the Allow CTCP(can still be kicked) or add him/her
to your friends list.

mIRC� v4.72 Internet Relay Chat Client
 Copyright � 1995-1997 Khaled Mardam-Bey and mIRC Co. Ltd.
 All rights reserved.

 mIRC is a Shareware program, which means that you can use it legally for 30
 days free of charge to evaluate it. If during, or at the end of, that period
 you decide that you would like to continue using it, please register your
 copy. Your registration will license you to use your copy of mIRC, will
 support work on future versions, new features, and bug fixes, and will
 provide you with technical support via email.

 Please see the Registration section to find out how you can register.

 mIRC may be freely distributed subject to, but not limited to, the following
 terms: mIRC may not be sold or resold, distributed as a part of any
 commercial package, used in a commercial environment, used or distributed in
 support of a commercial service, or used or distributed to support any kind
 of profit-generating activity, even if it is being distributed freely.



******* Latest change**********
***Version 3.01
Fixed a typo preventing friendlist to work with action and notices
when you are beat to a kick (using popup) it no longer kick the top OP
Updated all the 3.0 to 3.01

***Version 3.0
Updated this package with mIRC4.72 executable and help 13 Jan 97
Updated this package with mfaq.hlp version 30 help format 13 Jan 97
Fixed a bug in the Chanserv Register Popup
The /b and /ub now does a type 3 ban
The multiple clone now shows the address being filtered out
The time bans in the Nicklist menu.. all kicks are now all 30 Seconds
Removed the +i so that not everyone becomes +i auto.
Added a "Add Telnet (NOT CLONE)" menu selection under the User menu to allow adding addresses
Added a Line so that it will not kick an op who may have ghost or a second copy running
Changed the Ignore DCC .. Turn off so that it goes back to auto instead of ask
I have increased the single clone timer to 30 minutes to compensate for lag services


******* The General Scripts....
These scripts are not designed to kick ops while they are ops.  If you do 
run a channel which gives ops to everyone... remove all the statements
stating $nick isop $chan  NOTE: Do not attemp this if you are unsure.
These Scripts are also not affected by the Colors. (eg text lenght)

Running all these Scripts at once may seem harsh oping because you 
wont let too much go through but in some channel they are all 
required.

This Script uses the Internal Address List to load up all the user
for Speed.  It is a good idea to Press F3 on large channel (200+) 
temporarely turn off all your scripts until all the users are 
loaded up.  Then you can select which script to run or Press F3 again
to turn them all ON... then Press F5 to reload your original default settings.
I personnaly run all the scripts and only have a 486DX2 80 without much problems.
If you are starting to lag, just turn on the Lag mode to diseable the CPU 
intensive scripts or turn off the script which lags you the most.
 
Cuss Script:..............Kick for the word F*ck and Kick 30 sec for 
                          the rest.  This script will not kick for getting
                          cuss wav.

Repeat kick:..............Kick anyone who repeat the same thing twice..
                          within 5 lines and within 5 seconds

Advertisement kick:.......will kick anyone who uses the pound sign immediatly
                          followed by 2 letters or numbers.  It will not
                          kick if the name of the channel is part of the
                          advertizement.
                          
text Lenght Kick:.........will Kick anyone who put over 250 character on the
                          screen.

Caps Lock Detect:.........will warn the user if 16 caps are used the first
                          time.  If the user uses 16 Caps again within 10
                          minutes.. the user is then kicked.

Text Flood Detect:........will kick anyone who puts too many lines of text
                          in a short period of time. ie 4 within 5 second
                          interval

Nick Flood Detect:........Will kick anyone who changes nick too many time
                          and too fast. ie more than 3 times within 7 second
                          interval.  IMPORTANT: Kicking a user with this
                          Script will also automatically Shit list him in
                          the nick Flooder Category. 

Sound Flood Detect:.......will kick anyone who play more then 2 Wav sound
                          within 5 seconds.

Echo Flood Detect:........will kick anynone who Echo Flood you more than
                          and Au

Offensive Nick detect:....Will kick anyone using an offensive nick
                          which is preset in the user list or one
                          that you entered.

Offensive UserID detect:..Will kick anyone using an offensive User ID
                          which is preset in the user list or one 
                          that you entered.

Comprehensive Shit list:..Allows you to add, remove, in Categorise
                          users in defined shit list.  For example
                          nick Flooder, Echo Flooder, Plain Shit list
                          
Clone Detect:.............This clone detect will pick up any second
                          copy, ghost etc and tell them to Ghost.  If
                          they have not done so in 30 Minutes they 
                          will automatically be kicked/ban 30 sec.

                          In the event that 3 or more clones join the
                          channel, they will immediately be kicked.

                          One of the nice feature is that when a know
                          Telnet Client or CyberCafe user join the 
                          channel, the clone detection ignores them.
                          This should minimize the risk of kicking
                          innocent people.  This is done by checking
                          the address of known Telnet & CyberCafe 
                          users in a variable Called Telnetclient.
                          Special Thanks to Alleycat for providing
                          me with the list he had. You can add new
                          Address by using the User Level menu.

message Screening:........This is the Away System and msg Screening.
                          It will send a msg saying that you are 
                          busy to anyone who message you that is in
                          the same channel you are in.  Of course the
                          people on your friends list, Ops and the
                          ones you ADD will not be affected.  When 
                          you set yourself as away.... you will be
                          logging msgs which you can review when 
                          you return .. right in your active window.

autojoin:.................This Script is only Active on Start up.  If
                          you set a channel... it will auto-join you
                          to the channel of your choice.

CTCP logging:.............This Script will log.. on a file.. any CTCP
                          you receive.  Including Sounds, Sends, Gets
                          etc.....

auto OPing:...............This Script will OP automatically anyone 
                          who joins the channel you are on and that 
                          you have added as an op.  This Script can
                          be turned on and off.

Wav Play:.................This Script will permit you to Get and Send
                          wav files without having to add a user
                          to your friends list.

DALnet Services:..........This is a Popup i have written so that you 
                          can use any services from Nick/Chan/MemoServ

*******The Alias Section:

F1 will list all the Fkey assignment in the active window.

F2 will toggle the Bot mode ON and OFF.  The BOT mode will change your 
Nick to the first 4 letters of your nick then add |Bot.  For example:
Blue|Bot.  During this mode.. all msg's, CTCP's and Invites are ignored.
To return everything to normal.. press F2 again which will return to your
original nick ... and remove the ignore on msg/CTCP/Invites.

F3 will Toggle all your kicks ON and OFF. (all your kicking scripts are
turned OFF and ON.)

F4 will toggle the Lag Mode ON and OFF.  Lag Mode ON will turn off all the 
CPU intensive scripts. ie:Repeat Text, Caps Lock, Advertizing and Clone
Kick Scripts will be turned off. Pressing F4 again will turn the above
Scripts back on.

F5 will reload your default settings.  You have the option to change the 
configuration of your scripts on Load up (ie what Script will be ON or 
OFF when you connect to a server.) which will be explained later. Pressing
the F5 key will load to the configuration you have set as default 
regardless what you currently have ON or OFF. 

F6 will toggle between a random nick and your present nick.  The 
c:\bcscript\text\nickchan.txt contains 9 different nick alteration which
the F6 key will pick from.  Pressing it again will toggle back to your
original nick. 

F7 will echo the Script Status in the active window (Current Status). ie: 
what is ON and what is OFF.

F8 will start a Selective Mass kick.  You basically highlight the nicknames
you want kicked/banned 30 sec (in the names list) then when you press F8...
a User box will ask you to enter the reason for mass kicking.  Please 
be forewarned that mass kicking ALOT of people may get you disconnected
because the Server will think that you are flooding depending on your 
Flood Protection settings. 

F9 will kick/ban the selected user (one only) for 5 minutes.

F10 will kick/ban the selected user (one only) for 30 minutes.

F11 will kick/ban the selected user (one only) for 1 hour.

F12 will kick/ban the selected user (one only) Permanently.(until the ban
List is empty)

NOTE: About TELNET users and Cybercafe(hereafter refered to has Telnet clients).
I have encountered users that are using telnet clients or from cybercafe
with the exact same address.  This was a problem when searching for Clones.

I have incorporated a variable which has the hostand domain of the known
Telnet and Cybercafe clients so that no accidental clone detection occur.

/clone   This command will check the channel for clones.  I have excluded
         the Telnet clients.  When you run this Alias, it will tell you how
         many Telnet Clients are in the channel as well as any Ghost/Clone 

/k       To be used as follows  /k nickname comments ..  this alias will 
         Kick/ban for 30 seconds the nickname you specify.  If other clones
         or Ghost are present on the channel.. they will also be kicked out.
         If there is a Telnet Client Clone, only the mentionned nick will be
         kicked.  Again to avoid kicking innocent people.

/sk      To be used as follow /sk nickname comments .. this alias will Kick
         the user (does not filter clones or ban) and show as a warning kick. 

/ident   This command is a short cut to identify to nickserv.  Enter your 
         Password when requested.

/access  This command is a short cut to Add an addy to your access list with
         Nick serv.  When Prompted.. enter your addy in the following format
         userid@*.domain or userid@123.12.123.*

/ghost   This command is a short cut to Ghost your nick.  When prompted.. 
         Enter the nickname to ghost and your password for that nick.

/memos   This command is a short cut to send a memo thru memoserv.  for 
         ex:/memos Nickname type memo here

/memor   This command is a short cut to read a memo from another user thru
         memoserv.  for ex:/memor #   ie:/memor 1

/memod   This command is a short cut to delete a memo from another user 
         thru memoserv.  for ex:/memod # or all   ie:/memod 1 or /memod all

/ns      This command is a short cut to replace /msg nickserv

/ms      This command is a short cut to replace /msg memoserv

/cs      This command is a short cut to replace /msg chanserv

/os      This command is a short cut to replace /msg operserv(if you have
         Access of course)

/o       This is a short cut to the onotice command to be used as follows:
         /o message here

/pn      This is a short cut to send a notice to a user to be used as
         Follows:/pn nickname message here

/s       This is a short cut to play a wav. (you must have a sound card to
         hear it)  for example if the sound file is called hello.wav 
         The format is as follows: /s hello comments here

Warning and explaination section...

/eng     type /eng nickname   to tell the user to use english only.

/fre     type /fre nickname   to tell the user in french that only english
         is allowed on this channel.

/newops  type /newops nickname to explain how new ops are chosen.

/pg      type /pg nickname to remind a user that this is a pg channel

/caps    type /caps nickname to tell a user not to use caps

/sex     type /sex nickname to tell a user that it is not a sex channel

/reg     type /reg to explain how to register a nick on DALnet

Toys and other....

/colors  type /colors to show the channel what each color number is.

/cb      type /cb text here to put a multi-color bar on each side of the 
         text. (thanks for the idea Brujo)

/ct      type /ct text here to have multi-colored text, random bold and 
         random underline text.

/people  type /people to echo (you only) how many user/ops/total people
         are on the channel.        

*****The Popup menus:
There are 4 menus available for the Scripts...

1-The Blue-Chip menu
2-The Status window menu
3-The Chat and Query window menu
4-The channel window menu
5-The Nicknames List menu

****1-The Blue-Chip menu
�� Credits......  Just something to tell people who was involved

�� System Option... this is the main menu
Files maintenance... this sub-menu is to load/save your system/backup 
                     ini files

�� Default Scripts setting...This menu allow you to configure your scripts
                             on Startup (everytime you connect to a server)

�� Dalnet Services ... This is simply all the Dalnet Services available to 
                       you in a popup form so that you do not have to 
                       remember all the syntax to use them.

****2-The Status window menu

�� Scripts ... This is a main menu
Current Script Status:this Sub menu selection will give you the current 
                      status of your scripts.. ie. what is on and what
                      is off.  This is also available on the Fkeys

Default Script Status on Startup:This sub-menu selection will tell you what
                                 options you have selected to be ON or OFF
                                 everytime you startup or connect to a 
                                 server.  This is also available on the Fkeys

Reload Your Default Script Setting:This sub-menu selection will reset or load 
                                   the setting you have set as a default

All Kicks ON/OFF: allows you to turn off all your kicks or turn them all on
                  It is a good thing to have when you join a large channel.
                  i recommend you turn Off all your kicks until the large
                  channel has loaded up... then turn them all back, reload
                  your default settings or simply turn on the ones you 
                  wish.

Lag mode...: This mode Turns on/off the lag mode. The lag mode is a group 
             of scripts which are CPU intensive.  All this selection does
             is turn ON/OFF that group of scripts (Caps, Advertisement,
             Clone and repeat text.
Kicks...:This menu allows you to Turn ON/OFF idividual kicking scripts.
Other Goodies ... this turns off and on other scripts (non-kicking ones)
Message Screening ...:tell's people (ON the channel only) that you are too
                      busy to chat right now.  You can add People so that
                      they don't get that message.  you do not need to add
                      ppl on your friends list or ops

CTCP Logging ...:Turns it on/off.. self explainatory.  (you can view the 
                 ctcp log by using the edit menu.
Auto OPing ...:Turns it on/off... will auto-op anyone you have added as 
               an op in your users list
Wav Play...:Turns it on/off.  This mode allow you to exchange wav with ppl
            without having to add ppl to your allow ctcp/friends/op list.

�� User Levels ... this is one of the place where you give ppl priviledge
                   levels... Op/Friend/Allow CTCP... add a Telnet address
                   not to kick as clone

�� Shit lists...: this is where you add the special ppl :)
                  there are many Categories to pick from .. have fun
�� Offensive ID and Nick Options:this is where you can add offensive
                                 user id and nicks.  Beware that these
                                 two categories will require that you 
                                 remove them manually because the 
                                 level is not user specific but wild
                                 matched.

�� Self Modes and Server info... exactly what it says :)

�� Ignore Nick .... this is to ignore someone based on his address.... you 
                    can also remove someone (must be online)

�� Total Ignore Protection...: this function ignores everything.. an 
                               emergency kinda mode... 

�� Self Flood Protection...: this Menu allows you to ignore or un-ignore
                             certain things...ie:Messages,Invites,CTCP
                             DCC, Notices, Channels
�� Dalnet Services ...: Same as explained above

�� Edit ...: this main menu contains your notepads and CTCP log.

�� Message Control: this main menu contains Allow messages and Away
Allow Messages...: this is a sub-menu containing 3 things
Add user:will let you add a user so that he does not get your "i am too 
         busy to chat...."(not required from allow ctcp/friends/op level
         or ops on the channel

Remove user:will let you remove a specific user

Remove all:will remove all the users you have set to allowing msg

Away: this is a main menu

Set Away...:this will ask you for the reason you are away and display it
              in the channel every 5 minutes and log all your messages.

Set Back:this will stop your away and return to normal.

Read Away messages:This will allow you to read your logged messages in the
Active window.

Delete Away messages:This will delete all your logged messages.

****3-The Chat and Query window menu
NOTE: all the other menu options not listed here were covered above.

�� Rules and Explaination: this will permit you to show someone the rules
                           in a query or chat

****4-The channel window menu
�� My info ...: this menu allows you to echo (to yourself only) some info
                about your settings

�� Servers ...: this menu gives you a predifined list of server to chose
                from.

�� Ban List Option
Empty Ban List (SOP only chanserv):This option allows you to empty the 
                                   ban list on a registered channel
                                   if you are a sop and above

�� Channel rules:this is the main menu
List of Rules +m:This selection will moderate the channel.. play the rules
                 in c:\bcscript\text\rules.txt then un-moderate the channel
                 (thanks to papabear for that one)


****5-The Nicknames List menu
Add Ops:Add ops to your op levels
-
�� chanserv controls ...: This selection allows you to op and deop ppl with
                          chanserv.  PS: you cannot deop someone higher than
                          yourself.  ie. an aop cannot deop a founder or sop.
                          This Akick option is only available to SOP's and
                          above.

�� Potential Ops (voice): This menu allows you to voice users whom you want
                          to be sub-OP

�� All Kicks...: this menu contains some pre-defined kick.
 
30 seconds Custom Kick:this selection will ask you the reason for kicking
then kick.
