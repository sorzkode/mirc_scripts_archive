/.rlevel -r 2,500
//.auser 500 $me
//.guser 500 $me 3
/unsetall
/ReadDefaultSettings
/livestats
/ajoin
