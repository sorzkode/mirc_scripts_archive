[apex] 1.5 by stryfe (stryfe@stryfe.org)
Second release of apex 
1.0 Features:
1. Time Fix (duh who don't have that)
2. ircii chat (idea from meat)
3. relm (relay last msg) relsm (relay last msg sent) 
   reln (relay last notice) relsn (relay last notice sent)
   relj (relay last join) relp (relay last part)
4. All the other basic alias kb,op,deop, etc etc
5. Advanced msg logging systems
6. Friend list + shitlist (both have toggles for auto-op and kick on ban)
7. NO popups (i intended this to be an ircii based script)
New Features:
changed the minutes online to say hours minutes and seconds
added a pager


Fixed:
1. that damned time bug
2. shitlist reader (seems it didn't want to read)
3. and any other know bugs i found 
added:
1. forgot
2. forgot
3. forgot
Comments? Complaints? email me (stryfe@stryfe.org) or http://www.stryfe.org
apex is a Copyright (c) stryfe productions inc.
NOTE: NO CODE WAS STOLEN FROM STATIC ORANGE BY WEBBA
NOTE: I LIKED THE WAY IT WAS LAYED OUT SO I DECIDED TO MAKE IT LIKE THAT
GODDAMNIT@!#$%#@!
If you would like to see more version of apex, its up to you..
I made this script for YOU the user..

+---------------------------+
| stryfe is a member of the |
|        -=Evil krew=-      |
+---------------------------+
