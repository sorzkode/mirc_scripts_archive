All you have to do is move this file to C:\KeviScript 
so that all the files shall work correctly. Then move
you're mIRC 32 program into C:\KeviScript\ and yer all set.
                                  - KeviNash