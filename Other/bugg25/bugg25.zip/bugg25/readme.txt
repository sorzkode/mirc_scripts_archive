[B�GG�D] v2.5 bY FukNGrvN - [Revision 1 [03/01/97]

==============[readme.txt v2.5]===================

This is the most stable release of [B�GG�D] out
there right now.  The earlier versions had major
bugs in them and as far as i can tell most are
fixed.  If you do happen upon a bug please feel
free to email me at fukn@usa.net

thanks!

===================================================