�H����T by south_Florida (south_Florida@hotmail.com)
Use Mirc 4.7 Or Better

****************************************
*please do not use any parts of the bot* 
*in any scripts/bots (violation will   *
*result  in a lawsuit)                 *
****************************************

�H����T WAS only scripted by south_florida

***************�H����T instruction's*******************
1: /set %master <your nick> (no <>)                 
2: i have included NO flood prot...please use your own.
3: have fun.
*******************************************************

**********where can u find me??????????*******************
you can find me on dalnet (/server irc.dal.net 7000) 
when there type /join #teen13-21 my nick is south_florida
**********************************************************

**************************************************
�H����T is 1 out of about 20 bots i have scripted.
i do not release my better bots. (as of yet)
so this is obviously this is not my top bot.
�H����T is a channel bot and is made for DALNET!
**************************************************

**********BUGS***************************
REPORT ALL TO SOUTH_fLORIDA@HOTMAIL.COM *
*****************************************

*************WANT ANYTHING SCRIPTED???*********
EMAIL ALL IDEAS TO SOUTH_fLORIDA@HOTMAIL.COM **
***********************************************

**************CREDITS**************************
i would like to thank �1997 DARKFIRE PRODUCTIONS
members of �1997 DARKFIRE PRODUCTIONS:
TheTaz, Mysidia, Brian2059, The_Helper, SkiPanther.
___________________________________________________________________
CJB for hosting this bot. CHECK OUT. http://www.tera-byte.com/mirc/ 
TOOLMAN for all his help.
*************************************************

�H����T by South_Florida (south_Florida@hotmail.com)

*************commands***************************
this bot has been set up for the prefix of tb...all commands must be tb <command>
************************************************
         �H����T BASIC
******************************
level1: basic level: tb help *
******************************
         �H����T AOP
******************************************************************************************************
level10: aop level: tb help, tb kick <nick>, tb ban <nick>, tb opme, tb deop <nick> tb say <text>    *
******************************************************************************************************
         �H����T SOP
**********************************************************************************************************************
level11: sop level: tb help, tb kick <nick>, tb ban <nick>, tb opme, tb deop <nick> tb say <text>  tb add aop <nick> *
**********************************************************************************************************************
         �H����T FOUNDER
***************************************************************************************************************************************************************************************************
level13: founder level: tb help, tb kick <nick>, tb ban <nick>, tb opme, tb deop <nick> tb say <text>  tb add aop <nick> tb add sop <nick> tb shitlist <nick> tb join <channel> tb part <channel> *
***************************************************************************************************************************************************************************************************

�H����T by South_Florida (south_Florida@hotmail.com) enjoy.

�1997 DARKFIRE PRODUCTIONS
scripted by south_florida of DARKFIRE PRODUCTIONS
I will NOT be held reliable for any damage this bot may cause.
use it at your own discretion. thanks.
�1997 DARKFIRE PRODUCTIONS


/server irc.dal.net 7000 and /join #teen13-21
/server irc.dal.net 7000 and /join #teen13-21
/server irc.dal.net 7000 and /join #teen13-21
/server irc.dal.net 7000 and /join #teen13-21
/server irc.dal.net 7000 and /join #teen13-21
/server irc.dal.net 7000 and /join #teen13-21
/server irc.dal.net 7000 and /join #teen13-21
/server irc.dal.net 7000 and /join #teen13-21
/server irc.dal.net 7000 and /join #teen13-21
/server irc.dal.net 7000 and /join #teen13-21
/server irc.dal.net 7000 and /join #teen13-21
/server irc.dal.net 7000 and /join #teen13-21
/server irc.dal.net 7000 and /join #teen13-21
/server irc.dal.net 7000 and /join #teen13-21
/server irc.dal.net 7000 and /join #teen13-21
/server irc.dal.net 7000 and /join #teen13-21
/server irc.dal.net 7000 and /join #teen13-21
/server irc.dal.net 7000 and /join #teen13-21
/server irc.dal.net 7000 and /join #teen13-21
/server irc.dal.net 7000 and /join #teen13-21
/server irc.dal.net 7000 and /join #teen13-21
/server irc.dal.net 7000 and /join #teen13-21
/server irc.dal.net 7000 and /join #teen13-21
/server irc.dal.net 7000 and /join #teen13-21

