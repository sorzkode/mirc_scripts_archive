Welcome to [�Ras�] Ver�ion 7.5� �y m00n for mIRC v5.0

For change�, �ee versions.txt

Thi� i� my �econd �cript i have ever made. Fir�t off, you can ju�t
in�tall it into ANY directory or drive you choo�e. I will NOT take
up �pace in your C:\ :). Ju�t copy your mIRC32.exe file into that
directory and you're all �et!. �o anyway, here i� �ome �tuff about
the �cript. Thi� i� a protect �cript but ha� alot of other feature�.
It Ha� CTCP Protection, DCC Protction, TEXT Protection and channel
protection. If you look in the alia�e�, you will find alot of neat
command� �uch a� random color�, a�cii, etc.. it al�o contain� Dalnet
command�, Undernet X and W command� and IRCop control�. The type�
of �can� it include� are clone and IRCop and chan �tat�. Well, 
that� all i have to �ay, and thank you for u�ing my �cript.

PRoP�

K.M. Bey who made it all possible. m3rk is cool.
[bush] helping me with identifiers and the raw stuff
Hawkee for having a cool page
saB3r for telling me about screw bans
[Chron] for telling me about silent timers
Li0nHeart - the e-mail check is modded by me from Li0n 3.1
DaRKn for letting me use some of the quotes from -=�p����p�� ��\\'=-
Hiro101 for letting me know of some of the bugs
webba for giving me the idea of the chanstats.
MisFiTS for giving me the kilobyte converter
YuNGji for letting me know $vnick existed
#miRCScriptS on undernet for n0t giving me any help, but beinG a
 co0l plaCe to hanG out
And all the otha peepz i forgot to mention(though i dont think i
 left anyone out....)

If you ever need anything that ha� to do with m3rk, these are pages
that i think deserve some recognition:

http://www.m3rk.home.ml.org -> Muh er33t Add0n PaGE :)
http://www.hawkee.com -> Hawkees mIRC Script and MiDi Page
http://home.earthlink.net/~topdog -> SoNiKs mIRC Scripts Page
http://msc.simplenet.com -> mIRC Scripting Central
http://www.mircx.com -> miRC-X
http://www.scripterz.com -> SCriPtErZ
http://www.xcalibre.com -> Xcalibres mIRC Scripts Page
http://home.earthlink.net/~empirec -> Sharon's miRC Help Page
http://www.geocities.com/SiliconValley/Heights/1246/ -> Scripters Guild
http://www.addons.home.ml.org -> RatDog's mErK aDd0n PaGe

If any of the above links are wrong, please let me know. Thanks

This script is provided "AS IS" without warranty of any kind, either 
express or implied, including but not limited to the implied 
warranties of merchantability and fitness for a particular purpose.
In no event shall m00n be liable for any damages whatsoever 
including direct, indirect, incidental, consequential, loss of 
business profits or special damages, even if m00n has been
advised of the possibility of such damages.

The above line is from Li0n, i guess i was just too lazy to write my
own "use at own risk" thingamajigr. So thanks Li0nHeart

m00n on undernet m0on or mo0n on dalnet
knight@bc.sympatico.ca <---Que�tion� or comment� directed here. If
you need any help, then e-mail me or come to undernet on #nintendo64
or #bonethugs-n-harmony and a�k me! Al�o, if you e-mail me, don't
expect a reply until �aturday.

p.s. if you take anything from thi� �cript, i would like to be given
credit for it.
p.p.s if there are any bug, it might be cuz i converted it to 5.0
and didnt write all the code in 5.0 format, but let me know. Thanks
