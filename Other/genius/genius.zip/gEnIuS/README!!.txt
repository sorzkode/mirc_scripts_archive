 *********************************************************************************
 *********************************************************************************
 *****************************     THANKS FOR TRYING     *************************
 *****************************    �V�-�G���ﵧ    *************************
 *********************************************************************************
 *********************************************************************************


 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 !!!!!!! PLEASE READ THIS WHOLE FILE !!!!!!!
 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 !!!!!!!!!!(you'll be better off)!!!!!!!!!!!
 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

OK, this is my attempt at a readme file.  Now that this script is in version 2, i guess
it's time to give it a readme file to fully explain the script.  There *SHOULD* be
no problems with installing the script. So, now where do we start ??

OK, GOOD things to remember ...

## Make Use of the user lists ...  much of the protection will not effect your friends
   or people on the �V�-�G���ﵧ list.

## RUN THE "LOAD SETUP" IN THE �V�-�G���ﵧ menu.  It takes certain information for
   some of the script's variables.

Well, first off, let me tell you what �V�-�G���ﵧ has to offer.  I was (am) writing
this to be a mainly a War/Protection script.  There are a bunch of protection features
in �V�-�G���ﵧ for control of channels:

	Text Flood Protection
	Action Flood Protection
	Nick Flood Protection
	Offensive Nick Protection
	Offensive Username Protection
	Clone Checking
	Curse Kicker
	Ad Kicker
	Op Begging Kicker
	Revolving Door Ban
	Server Op protection 
	and others ...

There are also personal protection features which apply either if you're an op and
some if you're not. Among those are ....

	Personal CTCP flood protection
	Personal Notice flood protection
	personal Invite Flood protection
	Personal Msg Flood protection
	Ban Protection
	Kick Protection
	Deop Protection

In the Channel popups you will find all of those commands, plus most of the ChanServ,
NickServ, and MemoServ commands for DALnet.

Many of the functions that are in the popups are also available in the Function keys.
The function keys and the Control-Function keys are defined as follows ( you may
find out how they are defined in the script by pressing F1 and Control-F1) ...

	F1 List Function keys
	F3 War Mode
	F3 Peace Mode
	F4 List Channel Options
	--
	F5 Enable/Disable Text Flood Protection
	F6 Enable/Disable Action Flood Protection
	F7 Enable/Disable Nick Flood Protection
	F8 List Friends
	--
	F9 List Notify
	F10 List Arch-Enemies
	F11 PANIC !!
	F12 Auto Quit
	
And the Control-Function keys ...

	 Control-F1  List Control-Function keys
	 Control-F2  List Protection Options
	 Control-F3  Enable/Disable Kick Protection
	 Control-F4  Enable/Disable Ban Protecion
	 Control-F5  Enable/Disable Message Flood Protection
	 Control-F6  Enable/Disable Notice Flood Protection
	 Control-F7  Enable/Disable CTCP Flood Protection
	 Control-F8  Enable/Disable Invite Flood Protection
	 Control-F9  Enable/Disable Deop Protection
	 Control-F10  Turn On/Off Away System
	 Control-F11  Enable/Disable Wave Grabber
	 Control-F12  Yet to be Decided

And only one Shift-Function Key has been defined ...

	 Shift-F2  Reset Lag Monitor

A couple of the items may not be initially understood. For one thing, PAINIC !! in the
function keys is for if you are getting attacked by surprise.  If you are in War Mode
when you get flooded, you should not be affected badly ...  but if you are in trouble,
the PANIC system halts the processing of all remotes, and ignores all users. And in
the �V�-�G���ﵧ in war mode, there is Choke !! ( which is the same thing ), and 
BAIL OUT, which is what the name would imply, exiting   �V�-�G���ﵧ  . Hopefully
that is about all of the ambiguous stuff in the script.

Now for the war features ...  most is self explanitory.  You can load up to 8 flood clones.
( Although it says 10 ).  there are a variety of floods you can use.  All of the ctcp 
floods, invite flood, msg flood, nick flood, notice flood, and a combo flood or two.
There is also a "Desynch Channel" option which just makes a mess if you manage to get ops
in a channel.

Well, that's about it for now ...  If you ever have questions on the script or whatever,
i can be easily found on DAlnet in #fivestyle.  take it easy and have fun !!


						fIvEsTyLe
						briese@cs.uiuc.edu