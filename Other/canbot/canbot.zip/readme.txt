**************Directions for setting up -=((-CaNBoT-))=-****************

***This bot is for Mirc v4.7+
***This Bot is for EXPERTS ONLY

--------------------------------------------------------------------------

1.   Unzip canbot.zip anywhere you want.  Then copy the mirc32.exe file to the
   directory you unzipped ozzbot too. 

--------------------------------------------------------------------------

2. Copy everything here into your Main mIRC Client in Popups/Status or Channel

&CaNBoT 
.&Start CaNBoT:/run %canbotcl $+ mirc32.exe %canbotcl $+ bot.ini
.-
.&Setup:/.writeini %canbotcl $+ bot.ini botchannels autojoin $?="Auto-Join Channels; Separate by Commas" |  .writeini %canbotcl $+ bot.ini botchannels hourschannel $$?="Hours Channel?"
.&Set Join Channels:/.writeini %canbotcl $+ bot.ini botchannels autojoin $?="Channels; Separate by Commas, no spaces"
.&Set Chan for Hours:/.writeini %canbotcl $+ bot.ini botchannels hourschannel $$?="Channel?"
.-
.&Join Current Channel:/dde mircbot command "" /join #
.&Set Command Line:/echo 4 ex. If your command line for CaNbot's mirc32.exe is c:\canbot\mirc32.exe enter c:\canbot\.  It can be anywhere is the computer, just remember to put \ at the end of it. | /set %canbotcl $$?="Where is Ozzbot (ex. c:\canbot\ )?"
.&Bot Disconnect:/dde mircbot command "" /rlevel 500 | /dde mircbot command "" /quit
.&Bot Die:/dde mircbot command "" /rlevel 500 | /dde mircbot command "" /exit

--------------------------------------------------------------------------

3. Copy everything here into your Main mIRC Client in Popups/Query|Chat

&CaNBoT 
.&Start CaNBoT:/run %canbotcl $+ mirc32.exe %canbotcl $+ bot.ini
.-
.&Setup:/.writeini %canbotcl $+ bot.ini botchannels autojoin $?="Auto-Join Channels; Separate by Commas" |  .writeini %canbotcl $+ bot.ini botchannels hourschannel $$?="Hours Channel?"
.&Set Join Channels:/.writeini %canbotcl $+ bot.ini botchannels autojoin $?="Channels; Separate by Commas, no spaces"
.&Set Chan for Hours:/.writeini %canbotcl $+ bot.ini botchannels hourschannel $$?="Channel?"
.-
.&Join Current Channel:/dde mircbot command "" /join #
.&Set Command Line:/echo 4 ex. If your command line for CaNbot's mirc32.exe is c:\canbot\mirc32.exe enter c:\canbot\.  It can be anywhere is the computer, just remember to put \ at the end of it. | /set %canbotcl $$?="Where is CaNbot (ex. c:\canbot\ )?"
.&Bot Disconnect:/dde mircbot command "" /rlevel 500 | /dde mircbot command "" /quit
.&Bot Die:/dde mircbot command "" /rlevel 500 | /dde mircbot command "" /exit
-
&CaNBoT CoMMaNDS
.&OWNeR CoMMaNDS
..Flood Protection
...Text
....Configure:/say .configtext $$?="How many text lines?" $$?="In how many seconds?"
....-
....ON:/say .textprot
....OFF:/say .rtextprot
...Action
....Configure:/say .configaction $$?="How many action lines?" $$?="In how many seconds?"
....-
....ON:/say .actionpro
....OFF:/say .actionpro
...Mass Deop
....Configure:/say .configmd $$?="How many deops?" $$?="In how many seconds?"
....-
....ON:/say .mdpro
....OFF:/say .rmdpro
...Clone/Join
....Configure:/say .configcj $$?="How many Joins?" $$?="In how many seconds?"
....-
....ON:/say .cjpro
....OFF:/say .rcjpro
...AutoGreet
....Configure:/say .protautogreet $$?="Number of Joins?" $$?="In how many seconds?" $$?="Seconds to disable autogreet?"
....-
....Fun Ignore:/say .funig $$?="1 fun command in how many sec?" $$?="Ignore for how long?" $$?="After fun commands exceed?"
....-
....ON:/say .agpro
....OFF:/say .ragpro
...Nick
....Configure:/say .confignick $$?="How many nick changes?" $$?="In how many seconds?"
....-
....ON:/say .nckpro
....OFF:/say .rnckpro
...ServerOp
....ON:/say .hackpro
....OFF:/say .rhackpro
...DCC Text
....Configure:/say .configdcct $$?="How many text lines?" $$?="In how many seconds?"
....-
....ON:/say .dcctpro
....OFF:/say .rdcctpro
..Toggles
...Seen
....ON:/say .seen
....OFF:/say .rseen
...NoOp
....ON:/say .noop
....OFF:/say .rnoop
...AutoGreet
....Reset Counter:/say .fsreset
....-
....ON:/say .autogreet
....OFF:/say .dautogreet
...ChanGuard
....ON:/say .changuard
....OFF:/say .rchanguard
...Ping Reply
....ON:/say .onping
....OFF:/say .offping
...Beg For Ops
....ON:/say .begon
....OFF:/say .begoff
...Login
....Password:/say .setpassword $$?="Password for login?"
....-
....ON:/say .login
....OFF:/say .rlogin
..Voting Poll
...Total Setup {
  say .pollreset
  say .vptopic $$?="Voting Poll Topic?"
  set %choice1 $$?="First Choice?" | %choice2 = $$?="Second Choice?" | %choice3 = $$?="Third Choice?" | if ($left(1,%choice1) != !) { %choice1 = ! $+ %choice1 } | if ($left(1,%choice2) != !) { %choice2 = ! $+ %choice2 } | if ($left(1,%choice3) != !) { %choice3 = ! $+ %choice3 } | say .choices %choice1 %choice2 %choice3
}
...-
...Topic:/say .vptopic $$?="Voting Poll Topic?"
...Choices:/set %choice1 $$?="First Choice?" | %choice2 = $$?="Second Choice?" | %choice3 = $$?="Third Choice?" | if ($left(1,%choice1) != !) { %choice1 = ! $+ %choice1 } | if ($left(1,%choice2) != !) { %choice2 = ! $+ %choice2 } | if ($left(1,%choice3) != !) { %choice3 = ! $+ %choice3 } | say .choices %choice1 %choice2 %choice3
...-
...Reset:/say .pollreset
...-
...Find Nonvoters:/say .nonvoters $$?="Channel?"
..Join Counter
...Set Channel:/say .setchanc $$?="Channel?"
...-
...Reset Chan Counter:/say .resetc
...Reset Total Counter:/say .resett
..Stats
...Misc:/say .toggles
...Flood Prot:/say .floodprot
..Set Messages
...AutoGreet:/say .agmsg $$?="Enter AutoGreet Message?"
...Partyline:/say .motd $$?="Enter Partyline Join Message?"
..Partyline
...Linking
....Link Bots:/say .link $$?="Bot to Link Partyline to?"
....Wait for Link:/say .wait $$?="Bot to wait for connection from?"
....-
....UnLink Bots:/say .unlink $$?="Bot to UnLink From?"
...-
...Set MOTD:/say .motd $?="MOTD???"
...-
...Shutdown:/say .shutdown
..Number Game
...Setup:/say .su#game $$?="Picks number between 1 and ????" $$?="How many guesses does everyone get?"
...-
...Reset Game:/say .reset#game
...Reset ScoreBoard:/say .reset#sb
..Bot Specifics
...Nick:/say .nick $$?="Bot's Nick?"
...Add500:/say .add500 $$?="Nick to give 500 access?"
...Hours Channel:/say .hours $$?="Channel to play hours to?"
...Idle Time:/say .idtime $$?="Seconds between each anti-idle?"
...Ignore:/say .ignore $$?="Enter Mask?"
...Remove Shitlist/say .rshit
...Server:/say .server $$?="Server?" $?="Port?"
...DIE:/say .die
.-
.LeVeL &500 CoMMaNDS
..Controls
...Channel
....MassOp:/say .massop $$?="Channel?" $$?="Up to 6 Nicks (sep by spaces)"
....MassDeop:/say .massdeop $$?="Channel?" $$?="Up to 6 Nicks (sep by spaces)"
....MassBan:/say .massban $$?="Channel?" $$?="Up to 6 Masks (sep by spaces)"
....-
....Kickban:/say .kickban $$?="Channel?" $$?="Nick" $$?="Message?"
....-
....ClearMode:/say .clearmode $$?="Channel?"
...PaRTYLiNe
....Ban:/say .banpl $$?="Nick"
....Kick:/say .boot $$?="Nick" $$?="Message?"
..AddUsers
...Add200:/say .add200 $$?="Channel?" 
...Add300:/say .add300 $$?="Nick" 
...Add400:/say .add400 $$?="Nick"
...-
...Remove:/say .ruser $$?="Enter nick to be removed?"
...-
...Shitlist:/say .shit $$?="Nick" 
..Stats
...BotStats:/say .botstats
...FunStuff Counter:/say .fscounter
...LagStats:/say .lagstats
...Counter:/say .counter
...Number that Voted:/say .howmany
..Advertise
...Advertise in Topic:/say .atopic $$?="Channel?" 
...Stats in Topic/say .stopic $$?="Channel?" 
...FunStuff:/say .funstuff $$?="Channel?" 
..Join/Part
...Join:/say .join $$?="Channel?" 
...Part:/say .part $$?="Channel?" 
..Misc
...MSG:/say .msg $$?="Nick to msg?" $$?="Message?"
...Scan:/say .scan $$?="Channel?"
.-
.LeVeL &400 CoMMaNDS
..User@Host Ban:/say .ban $$?="Channel?" $$?="Nick"
..SiteBan:/say .hostban $$?="Channel?" $$?="Nick"
..-
..Kick:/say .kick $$?="Channel?" $$?="Nick" $?="Message"
..-
..Unban:/say .unban $$?="Channel?" $$?="Mask"
.-
.LeVeL &300 CoMMaNDS
..Deop:/say .deop $$?="Channel?" $$?="Nick"
..Say:/say .say $$?="Channel?" $$?="Message"
..Invite:/say .invite $$?="Nick" $$?="Channel?"
.-
.LeVeL &200 CoMMaNDS
..Access:/say .access $$?="Nick" 
..Op:/say .op $$?="Channel?" $$?="Nick" 
..Topic:/say .topic $$?="Channel?" $$?="Topic?"
.-
.&HeLP
..Menu of Commands:/say .menu
..Help on Commands:/say .help $?="What Command?"

--------------------------------------------------------------------------

4.   Then click on CaNbot then Set Command Line in you main mIRC Client in popups/status or Channel.
   Fill that out correctly or the log and some other stuff won't run.  An example is if your command 
   line for mirc32.exe is d:\mirc\CaNbot\mirc32.exe then you would fill in Set Command Line with 
   d:\mirc\CaNbot\.  Don't forget the "\" at the end, you need that there.

--------------------------------------------------------------------------

5.   Go into the popups I gave you for the Main mIRC client and click on CaNbot and then Setup. Fill
   in the info it asks you for.

--------------------------------------------------------------------------

6.   Then run both the mirc32.exe and bot.ini together. Make sure to
   Do this or there will not be anything in the ini's or if you did everything correct above,
   Just click on Start CaNbot in the main mIRC Client's popups and it should load up correctly.

   *** Example of running w/o popups: in main client of mIRC type /run c:\CaNbot\mirc32.exe c:\CaNbot\bot.ini

--------------------------------------------------------------------------

7.   After you've done all this the bot should join the channels you specified.  Then you can have all the fun you want with it. I know I will.

--------------------------------------------------------------------------

* All the commands are done through DCC CHAT so DCC the bot when you get it started.
  And there is online help in there so look at it.