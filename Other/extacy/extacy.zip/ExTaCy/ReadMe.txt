�`�����=��.,�_ ---===|��t�ǥv2.2 by kurtc|===--- _�,.��=椺��`�//   

  		      !!!!!!!!ReadMe!!!!!!!!!


1:) Installation

.1) Unzip all this stuff to c:\ (when you extract, it should place 
it in c:\extacy)
.2) copy mircv4.7 and put it in c:\extacy (name it mirc...(not mirc32))
.3) be NICE to tha ppl




______________________________________________________


This script...if you know what you are doing...can be very powerfull..
Take my wrd, i have been klined from many a nets with this script( and i dont even nuke)
i will let you know the best way to take a channel in another .txt...




mail me at : kurtc@geocities.com  or  nirvana.freak@juno.com

my nick iz kurtc...(duh!)
and you can find me on MTVnet or DALnet...

c yah!!!


read the FAX..:)   and coming s00n




p.s......BluGhst14 wrote the pro...all eye did was fix the replies
and precursor wrote the ircop find