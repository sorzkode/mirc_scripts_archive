�THe KiNG� v1.0 by ^allen. For mIRC v 4.72

;hi i have 3 scripts tied in to one so far thet are
;betaflood, asytum, retro12 so i dont know what all works it should all work  
;so i dont no what i got double of so 
;These scripts protect against all floods I know of has some cool
;things. 
;
;If you are being flooded badly, hit the F12 key. This will engage
;ultra flood protection. Hitting the F12 key a second time will
;change your nickname to a random nickname. Each time after this you hit
;the F12 key, it will change your nickname to another random one. This is 
;one of the best methods to avoid a very bad flood. When ultra flood 
;protection is on, you will be ignoring all input from other users, except 
;for channel actions, notices and text.
;To disable emergency flood protection, and restore your original 
;nickname, hit the F11 key,
;
;If your mIRC or computer locks up, hit the "F11" key when you restart
;mIRC. This will clear the Ultra flood protection mask. If you feel you
;are still unwantingly ignoring users, when you are not being flooded,
;you may have to clear the ignore list manually. To do this, from the 
;main menu bar, click "Files", then "Setup" then the "Control" tab. Click
;on "Ignore". Delete all the entries.
;
;If you have any custom ctcp commands, you must put them inside the #floodctcp
;group, inside the brackets, right where the �CoUrTjEsTeR� version command is. 
;All must be in the form, if $parm1 == <ctcp command> <mIRC command>. If you
;do not add them like this, those ctcp commands will not be protected 
;against floods. Custom ctcp replies must go inside the #floodctcpreply group,
;inside the brackets, or they will not be protected against floods either.
;********************credits****************************
;toolman=for leting me use betaflood
;dark_phantom=for leting me use
;zeusgod=for leting me use retro
;^allen
;these are all real good scripterz and good friends