
RRRRRRRRRRAABBBBBBBBBBBDDDDDDDDD
RRR     RRRAAAABBBBBBBBBBBBDDDDDDDDDD
RRR      RRRAAAAAABBB       BBBDDD     DDD
RRR      RRRAAA  AAABBB       BBBDDD      DDD
RRR     RRRAAA    AAABBB      BBBDDD       DDD
RRR    RRRAAA    AAABBBBBBBBBBBiiiiDDD        DDD
RRRRRRRRRAAAAAAAAAABBBBBBBBBBBiiiiDDD        DDD
RRRRRRRRRRAAAAAAAAAABBB      BBBDDD       DDD
RRR     RRRAAA    AAABBB       BBBiiiiDDD      DDD
RRR      RRRAAA    AAABBB       BBBiiiiDDD     DDD
RRR      RRRAAA    AAABBBBBBBBBBBBiiiiDDDDDDDDDD
RRR      RRRAAA    AAABBBBBBBBBBBiiiiDDDDDDDDD
 

Contents:

 1 ................ Setup
 2 ................ Running For the First Time
 3 ................ Any Questions?
 4 ................ Copyright Info and Disclamer
 5 ................ Thanks



1. - Setup

	Now that you have the file unziped to a temp directory, run the Setup.exe file, it will install the script (you must install it to c:\rabid, if you place it in another directory it will not work).  After setup is done you should either continue reading this file or start the help file up.

	Now copy your old mIRC32.exe file to C:\RABiD and C:\RABiD\clones  After you do that read section 2.


2 - Running For The First Time

	Start RABiD up by clicking on the iCON.  When it starts up, it will connect to the server (if the server is up and working).  After it connects you need to set all your settings.  This will set all your default stuff for the script to use.

	A menu should come up asking for settings, and telling you how to do them, if it doesn't come up, type /settings.


	Now.. continue Reading :)


3 - Any Questions?

	Now you are done setting up RABiD.  If you have anymore quesions about the script or if you want to know some of the commands.. type /rhelp or click on the iCON for the RABiD Help file.

	Any other quesions that you can't find in the Help file, mail them to anti@netdoor.com.

4 - Copyright and Disclamer

	If this script causes you to loose your life/mind/eyesight/compter or causes any other damage the writer of this script (AnTiExE) is not to be held responsable for what happens.

	This script and all it's parts including this file and the RABiD ascii at the top of this file are all copyright AnTiExE 1996 all rights 
reserved.


5 - Thanks

	A special thanks goes to DonDon, Bink, The_Viper, Uniform, Alura, Hexadec, and the rest of the #mIRC-Scripts crew.  If it wasn't for them I would have gone insane trying to figure some of this stuff out for this script.

- #Virii

	Well, some of these people didn't help me write this script, but, they inspired me to write one, because if you don't have a good script on this channel, you will not survive very long.

Senior Members - FA-Q, Axehandle, Calldan, LwnmorMan, AnTiExE

Members        - ki||er5, trustno1, theLURK3R, _ReFluX_, iCBM, U-PhoRiA,                  oXSmAsHXo, Wrd

Honary Members - TiePilot, Phloyd, Cyranix, n

Bots           - Backstab, QuackerZ, Heaven, PaGeN, Lame, Lamer


		I love those bots.. they are so l33t :)




