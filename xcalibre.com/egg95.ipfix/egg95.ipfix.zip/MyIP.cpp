/* 
 * Title: MyIP
 * Author: David Gravereaux <davygrvy@snet.net> 2/26/97
 * Purpose: This routine will get the corrected TCP/IP hostname.
 *          MS Dail-Up Networking is stupid.
 * Caveats: its just a Win32 console app that prints to the stdout.
 *          nothing fancy.
 */

/* note: link with "wsock32.lib" */

#include <stdio.h>
#include <windows.h>

int main( int argc, char *argv[] ) {
  int x; char MeHost[256];
  WORD wVersionRequested; WSADATA WSAData;
  LPHOSTENT lphp; struct in_addr in_addrIP;

  wVersionRequested = MAKEWORD(1,1);
  
  if ((x = WSAStartup(wVersionRequested,&WSAData)) != 0) {
    printf("error %d starting winsock\n",WSAGetLastError());
    return EXIT_FAILURE;
  }
  
  if ((x=gethostname(MeHost,255))!=0){  //this returns the network setup name
    printf("error %d running GetHostName()\n",WSAGetLastError());
    return EXIT_FAILURE;
  }

  lphp = gethostbyname(MeHost);
  in_addrIP = *(struct in_addr far *)(lphp->h_addr);  //
  
  if (in_addrIP.s_addr==0x100007F)  //check for loop-back
    printf("%s\n%s)",MeHost,inet_ntoa(in_addrIP));
  else {        
    // if not loopback, then do a reverse look-up to get the 
    // !correct! TCP/IP hostname. MS DUN is dumb.
    lphp = gethostbyaddr((char far *)&in_addrIP,4,PF_INET);
    strcpy(MeHost,lphp->h_name);
    printf("%s\n%s",MeHost,inet_ntoa(in_addrIP));
  }
  
  if ((x=WSACleanup())!=0) {
    printf("error %d running Cleanup()\n",WSAGetLastError());
    return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}
