Be sure to read this file completly to make sure that you
install bacon correctly. -flizzo
--------Tips
1) added flags: +g=god(auto reop),+i(instant op)
   +v(auto voice)
2)try out .setup in dcc chat
--------Installation--------
1) First edit the bacon.tcl file and make sure that the
   first line matches the directory when the bacon.tcl
   script is.
2) edit the bacon.cfg file and set everything to the
   desired setting.
   *1=on 0=off
   *this is assuming your command character is !
   >chan-mode  - this is for public commands such as !op
                 !kick !ban !idlekick
   >chan-fun   - this is for alot of stuff including !ping
                 !binfo !chan !char. No mode changes at all!
   >bot-chans  - for public commands such as !addchan
                 !delchan
   >bot-users  - for public commands such as !adduser
                 !deluser !chattr
   >chan-master- public commands such as !save !servers
                 !jump
   >kick-msg   - this is default kick message used with
                 !kick if you dont give a kick message
   >cmd-char   - this is what your public command character
                 will be, in this case it is !. can be 
                 changes using !char(public) or .char(dcc)
   >show-url   - if a user has a url set, using !url, bot
                 will show thier url when they join a chan
   >banned-words-list of words seperated by a list for when
                 someoone says one of these words in a chan
                 they will be kicked if there not +m. Words
                 can be added,deld using !addword !delword
                 (public) or .addword .delword(dcc). Use
                 !words or .words to see current banned words
   >everything else doesn't need to be messed with
3) add this line to the bottom of your eggdrop config file
   source dir_where_bacon.tcl_is/bacon.tcl
4) then run your eggdrop! Be sure to check out '.setup' in DCC Chat!
5) if you got comments or suggestions mail me at vince@fishnet.net
   also check out http://www.fishnet.net/~vince
6) if your NOT running eggdrop1.0m+ AND tcl7.5+ and you get tcl 
   errors, dont comoe bugging me for help.
7) Down to every last . and ) in this script was coded by ME. I did not rip
   anyones code. If you think I stole your code then you can talk to me and
   you will find out I do know tcl. If you wanna be realy leet and steal my
   code i wish you the best. Anyways, have fun with my script.
                      -flizzo@EFnet