Light Doorscan
Version 1.0
Author: ENNE
Realase: 16. February 2006
For info: lds@enne.skystorm.net
Based on: mIRC 6.16

---- Addon's typical installation
1) Unzip the file lightdoorscan.zip in the mIRC's folder (for example C:\mIRC\lightdoorscan\).
2) Start mIRC.
3) Write this command:
   /.load -rs lightdoorscan\lightdoorscan.mrc
---------------------------

---- Description
This addon is use to control open doors on your system.
You can also save in a file results and automatically open a sock connection with the open doors detected.
To use this addon you can click on the main menubar of mIRC "Light Doorscan" or use the alias:
/lightdoorscan
if you specify a start and end port in this way:
/lightdoorscan 1 1000
the scan start automatically.
---------------------------