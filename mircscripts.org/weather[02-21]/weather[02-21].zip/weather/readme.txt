    /********************************\
    * Weather Bar for mIRC by Jrfuzz *
    \________________________________/

********************************************
*                 How-to                   *
********************************************
|					   |
|--------------How To Install:-------------|
|				           |
|1. Unrar the downloaded file.             |
|2. Run mIRC			           |
|3. Copy-paste in your mirc the following: |
|					   |
|   //load -rs " $+ $sfile($mircdir) $+ "  |
|					   |
|4. In the opened dialog, find weather.mrc |
|   (it should be in folder where you      |
|    unrared downloaded file)              |
|6. On "Script warning" dialog, click yes  |
|					   |
|Notice: it is highly reccomended that you |
| delete all the previous weather scripts  |
| to avoid name conflicts.		   |
|					   |
|----------------How To Use----------------|
|					   |
|Right-click in the Status Window and 	   |
| select "Weather" -> "Enable weather bar" |
|					   |
|All the options are available via 	   |
| right-click on the weather bar.          |
|					   |
|-------------How to Uninstall-------------|
|					   |
|Right-click in the Status Window and 	   |
| select "Weather" -> "Unload script".     |
|					   |
********************************************


********************************************
*                  Credits                 *
********************************************
|					   |
| dohcan, for his excellent tbwin.dll	   |
|					   |
|					   |
| sax, for his brilliant xml.dll	   |
|					   |
|					   |
| FiberOPtics, for his almighty $download  |
|				     alias |
|					   |
| Weather.com for the most occurate info   |
|					   |
|					   |
********************************************


-
Contact: Jrfuzz@30gigs.com