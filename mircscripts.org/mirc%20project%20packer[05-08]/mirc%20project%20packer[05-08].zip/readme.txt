;#######################;
;# mIRC Project Packer #;
;# Version 1.1         #;
;# By IceShaman        #;
;#######################;

1. About
2. Changelog
3. Usage
3. Contact

About
-----

mIRC Project Packer is designed to turn a selection of mIRC script files into a single 
script that when loaded unpacks all the files (including directory trees). Think of it
as a simplified version of the WinZip self extractor. The script also provides support 
for validating packed files to check they have not been corrupted, compressing the packed 
file to save space and only unpacking if the mIRC version is above a specified value.

Please note if compression is enabled the minimum mIRC version required to unpack the
script will be automatically set to 6.1 and the files will not be packed if a value less
than that is used. This is because the compression option uses the $compress/$decompress 
aliases that were only added in mIRC 6.1.

Also note the packing method uses /bread to read the files as opposed to fopen as custom
file-handling commands were only introduced in version 6.1. This means the packed file
should unpack itself correctly on all versions of mIRC prior to 5.9 if compression isn't
enabled.

The packer also provides an option to save the packing settings so you can repack files 
easily by loading the settings file.

Please note in 1.1 the self extracting code has changed as well as the specification for
saved files. This means any settings saved with version 1.0 cannot be used with 1.1.


Changelog
---------

Version 1.1:

 - added checking for saving/packing so if subdirectory begins with a \ remove it or if it
   doesn't end in \ add one.

 - added readme to about menu (it would /run the readme file or give an error it the file
   doesn't exist in $scriptdir).

 - changed cRC checking in self extrating script so it doesn't give errors when checking
   folders (which have a CRC of 00000000 anyway)

 - empty directories are now added with the 'Directory' button. Tweaked self extracting 
   code to differentiate between files and folders so empty directories can be created
   without too much hassle.

 - fixed issue with saving some directory trees.

 - added subdirectory option with regex checking for invalid subdirectory names. This 
   replaces the basedir option which was mostly useless anyway.

 - added 2 invisible listboxs for action type (run or load) and full pathnames, which
   allows files from different directories to be added while still only showing the 
   filename in the main listbox. It also has the advantage of not having to have a hash
   table to store action info in anymore.


Usage
-----

To load the script unzip it to your mIRC directory and in mIRC type in
/load -rs packer.mrc 
(No messages are given to indicate the load)

Once loaded you can launch the dialog by typing in /packer in mIRC.

In the dialog you can use the 'Add' and 'Directory' buttons on the 'Files' tab to add the 
files you want to be packed. If 'Add' is used you may only select files in the same 
directory and they will be unpacked to the $scriptdir of the unpack file when it is loaded. 
'Directory' allows you to add all files in a directory INCLUDING all the files in the 
directory tree (subdirectories). 'Add' and 'Directory' CAN be used in conjunction with each
other. The 'Del' button will remove the selected file and it will not be packed. The 'Clear' 
button will remove all files from the pack list.

For every file to be packed you can select it and set the option of either trying to load
it into mIRC after it has been unpacked (scripts only) or run the file if it has an .exe
or .com extension. Note: no options are available to empty folders.

The options tab provides useful options for the packed file:

 - File Validation (CRC) will make the packed script check the CRC of the unpacked files
   against the CRC values of the original files. If they do not match it will warn you
   that the file is corrupt. This will work even if compression is enabled.

 - Compression will compress all of the packed files individually before writing them to
   the packed files. You can specify which compression level to use (1 being the lowest
   level of compression and 6 being the highest). Please note compression works best with
   large files and the higher the level you choose the longer it will take to compress/
   decompress the files.

 - mIRC Version check lets you specify a minimum version of mIRC. If the packed script is
   loaded on a lower version than the minimum the packed script will warn the user and
   unload itself. If you enable compression the minium version will be automatically set
   to 6.1 as that's the version $compress was first added to. You will not be able to
   pack the files if you set the minimum version to anything below 6.1 when compression is
   enabled.

 - Subdirector lets you specify a directory or set of directories that all files will be
   unpacked to from $mircdir. For example if you set it to test\ing\ all the files would
   be unpacked to $mircdir\test\ing\<files>. 

To pack the files simply press the 'Pack' button on the files tab and then select the
directory to save the packed script to. Any errors will be given to you via message boxes 
which may or may not halt the packing process depending on the severity of the error. 

To make life easier you can save your settings. This will save all the files and their 
individual loading/running preferences as well as the selected options to a file (which 
can be reloaded at any time). You can access save/load from the 'File' menu. The 'File' 
menu also contains an unload option. This will clear all the files to pack and your 
options.


Contact
-------

You can contact me using the email: iceshaman@gmail.com