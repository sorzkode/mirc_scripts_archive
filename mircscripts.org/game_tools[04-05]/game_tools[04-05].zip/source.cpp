#include <windows.h>
typedef struct {
    DWORD  mVersion;
    HWND   mHwnd;
    BOOL   mKeep;
} LOADINFO;
extern "C" _declspec(dllexport) int __stdcall splay(HWND mWnd,HWND aWnd,char *data,char*,BOOL,BOOL)
{	
	PlaySound(data, NULL, SND_FILENAME | SND_ASYNC);
    lstrcpy(data,"S_OK");
	return 3;
}
extern "C" _declspec(dllexport) int __stdcall ticks(HWND mWnd,HWND aWnd,char *data,char*,BOOL,BOOL)
{
	LARGE_INTEGER microtime;
	LARGE_INTEGER freq;
	QueryPerformanceCounter(&microtime);	
	QueryPerformanceFrequency(&freq);
    wsprintf(data,"%d",microtime.QuadPart * 1000 / freq.QuadPart);
	return 3;
}
extern "C" _declspec(dllexport) int __stdcall UnloadDll(int timeout)
{
   if (!timeout) return 1;
   else return 0;
}
extern "C" _declspec(dllexport) void __stdcall LoadDll(LOADINFO*) {
   return;
}

  


