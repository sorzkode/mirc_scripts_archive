==============================
========= Game Tools v1.0 ====
==============================
========== by  Epsilon =======
==============================
==============================

For mIRC games, demos, GUI and tutorials about picwin, 
visit --> www.PicWin.tk <--



	Game Tools DLL
	��������������

This DLL offers various commands related to mIRC game dev.


Commands:
���������

	1] ticks
	   �����
Returns the current ticks in milliseconds.
This is an accurate version of $ticks, wich is incremented only by steps of 10ms.
So if you need an accuracy smaller than 10ms (e.g: frame synchronisation in games,
or for accurate alias benchmarking) you can use this command. 
It queries the high resolution timer of your CPU to return the exact ticks.

The accuracy of the ticks returned is smaller than 1ms.


Usage: $dll(game_tools.dll,ticks,.)

____________________

	
	2] splay
	   ����� 
Play a .wav file.
This command is faster than /splay, and does not alter the speed of mIRC. 
This is very important in games, to play sounds FX without any delay, 
and without consuming FPS.

If a .wav file is already playing when using this command, it will be stopped
and the new wav will be played directly.

You cannot play mp3 or midi with this command.


Usage: /dll game_tools.dll splay <filename.wav>

____________________


By Epsilon - www.picwin.tk



