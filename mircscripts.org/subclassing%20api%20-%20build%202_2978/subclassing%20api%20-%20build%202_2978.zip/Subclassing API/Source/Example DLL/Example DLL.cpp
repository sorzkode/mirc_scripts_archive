#include "Example DLL.h"
#include <string.h>

HINSTANCE	hInstance = NULL;
HWND		hApp = NULL;
LPSTR		mData = NULL;
HANDLE		hMap = NULL;

LRESULT CALLBACK signalProc(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam);
BOOL CALLBACK EnumSubs(HINSTANCE hInstDLL, HWND hwnd, WNDPROC WndProc, LPARAM lParam);

// DLL Statup, Happens at time of LoadLibrary()
extern "C" int WINAPI _DllMainCRTStartup(HANDLE hInstDLL, DWORD, void*)
{
	hInstance = (HINSTANCE)hInstDLL;
	return 1;
}

extern "C" void WINAPI LoadDll(LOADINFO *load)
{
	hMap = CreateFileMapping(INVALID_HANDLE_VALUE,0,PAGE_READWRITE,0,4096,"mIRC");
	mData = (LPSTR)MapViewOfFile(hMap,FILE_MAP_ALL_ACCESS,0,0,0);
	// Let's save mIRC's HWND in a global variable
	hApp = load->mHwnd;
	// Let's set mKeep to TRUE so this DLL says loaded
	load->mKeep = TRUE;
	
	wsprintf(mData, "//echo -s InjectMonitor Returns: %ld", InjectMonitor(hInstance, hApp, mData));
	mCmd(NULL);
}

extern "C" int WINAPI UnloadDll(int timeout)
{
	if (!timeout) {
		// Close communications withs mIRC
		UnmapViewOfFile(mData);
		CloseHandle(hMap);
		return 1;
	}
	return 0;
}

// mIRC functions for subclassing, each function is only passed a window handle
extern "C" int WINAPI SafeSubclassWindow(HWND mWnd,HWND aWnd,char *data,char *parms,BOOL show,BOOL nopause)
{
	HWND	hwnd = (HWND)atoi(data);
	if (!hwnd) hwnd = hApp;
	wsprintf(mData, "//echo -s SafeSubclass(%ld, %ld, %ld) returned %ld", hInstance, hwnd, signalProc,
		SafeSubclassWindow(hInstance, hwnd, signalProc));
	mCmd(NULL);
	strcpy(data, "OK"); return 3;
}

extern "C" int WINAPI UnSubclassWindow(HWND mWnd,HWND aWnd,char *data,char *parms,BOOL show,BOOL nopause)
{
	HWND	hwnd = (HWND)atoi(data);
	if (!hwnd) hwnd = hApp;
	UnSubclassWindow(hInstance, hwnd);
	strcpy(data, "OK"); return 3;
}

extern "C" int WINAPI mEnumSubclassing(HWND mWnd,HWND aWnd,char *data,char *parms,BOOL show,BOOL nopause)
{
	HWND	hwnd = (HWND)atoi(data);
	if (!hwnd) hwnd = hApp;
	EnumSubclassing(hInstance, hwnd, EnumSubs, NULL);
	strcpy(data, "OK"); return 3;
}

LRESULT CALLBACK signalProc(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	if (uMsg < 200) {
		// Sends an mIRC signal
		wsprintf(mData, "//.signal WNDPROC %ld 0x $+ $base(%ld, 10, 16) %ld %ld", hwnd, uMsg, wParam, lParam);
		SendMessage(hApp, WM_USER + 200,0,0);
	}
	switch (uMsg) {
		case SCWM_PRECLOSE:
			mCmd("//echo -s SCWM_PRECLOSE");
			break;
		case SCWM_CLOSECANCELED:
			mCmd("//echo -s SCWM_CLOSECANCELED");
			break;
		case WM_DESTROY:
			UnSubclassWindow(hInstance, hwnd);
			PostMessage(hwnd, uMsg, wParam, lParam);
			return 0L;
		default:
			break;
	}
	return NextWndProc(hInstance, hwnd, uMsg, wParam, lParam);
}

BOOL CALLBACK EnumSubs(HINSTANCE hInstDLL, HWND hwnd, WNDPROC WndProc, LPARAM lParam)
{
	wsprintf(mData, "//.signal ENUMSC %ld %ld %ld %ld", hInstDLL, hwnd, WndProc, lParam);
	SendMessage(hApp, WM_USER + 200,0,0);

	return TRUE;
}

VOID mEval(LPTSTR destString, LPTSTR evalString)
{
	if (evalString)
		wsprintf(mData, evalString);
	SendMessage(hApp, WM_USER + 201,0,0);
	if (destString)
		strcpy(destString, mData);
}

VOID mCmd(LPTSTR cmdString)
{
	if (cmdString)
		wsprintf(mData, cmdString);
	SendMessage(hApp, WM_USER + 200,0,0);
}


