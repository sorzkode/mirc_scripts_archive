#pragma check_stack(off)
#pragma comment(linker,"/OPT:NOWIN98")

#define WIN32_LEAN_AND_MEAN
#define WINVER 0x0500
#define _X86_
#define _WIN32_WINNT 0x0501
#include <Windows.h>	//No proplem Windows.h will work file...
#include <WindowsX.h>	//Has the #define for SubclassWindow()
#include <stdlib.h>
#include "../../MonitorAccess.h"

typedef struct {
	DWORD  mVersion;
	HWND   mHwnd;
	BOOL   mKeep;
} LOADINFO;

VOID		mCmd(LPTSTR cmdString);
VOID		mEval(LPTSTR destString, LPTSTR evalString);

