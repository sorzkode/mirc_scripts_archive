#include "SafeSubclass.h"

HWND		HwndApp = NULL;

// Use this function to load the subclass monitor, the monitor can only be loaded
// once, so call this function ALWAYS and BEFORE and subclassing takes place
HMODULE InjectMonitor(HINSTANCE hInstDLL, HWND hAppIn, LPSTR mData)
{
	BOOL	bVal = false;
	FARPROC hProc;
	HMODULE	hLoadLib;
	char	dllPath[900];
	UINT	bufsize = 900;

	if (!HwndApp)
		HwndApp = hAppIn;

	// Check if DLL is already loaded
	hLoadLib = (HMODULE)GetProp(HwndApp, pPropName);
	if (hLoadLib) return hLoadLib;

	strcpy(mData, "$mircdir $+ SubclassMonitor.dll");
	SendMessage(HwndApp, WM_USER + 201,0,0);
	strcpy(&dllPath[0], mData);

	// Load the DLL
	DWORD		hLibModule;
	HANDLE		hThread;
	VOID		*pLibRemote;
	HINSTANCE	hProcess = (HINSTANCE)GetCurrentProcess();
	HMODULE		hKernel32 = GetModuleHandle("Kernel32");

	pLibRemote = VirtualAllocEx(hProcess, NULL, bufsize, MEM_COMMIT, PAGE_READWRITE);
	WriteProcessMemory(hProcess, pLibRemote, (void *)dllPath, bufsize, NULL);
	hThread = CreateRemoteThread(hProcess, NULL, 0, 
		(LPTHREAD_START_ROUTINE) GetProcAddress( hKernel32, "LoadLibraryA" ),
            pLibRemote, 0, NULL);
	WaitForSingleObject(hThread, INFINITE );
	GetExitCodeThread(hThread, &hLibModule);

	// CALL A DLL INIT ROUTINE
	hProc = GetProcAddress((HINSTANCE)hLibModule, "MonitorEnable");
	DLLINIT MonitorEnable = (DLLINIT)hProc;
	if (MonitorEnable)
		bVal = MonitorEnable(HwndApp);
	hLoadLib = (HINSTANCE)hLibModule;
	SetProp(HwndApp, pPropName, (HANDLE)hLoadLib);
	
	//hLoadLib = (HINSTANCE)SendMessage(HwndApp, SCWM_ISLOADED, 0L, (LPARAM)hInstDLL);

	return hLoadLib;
}

// Use this function to subclass a window
BOOL SafeSubclassWindow(HINSTANCE hInstDLL, HWND hWndSubclass, WNDPROC WndProc)
{
	SAFESUBCLASS	ssw;
	HINSTANCE		hInstMonitor = (HINSTANCE)GetModuleHandle("SubclassMonitor");
	ssw = (SAFESUBCLASS) GetProcAddress(hInstMonitor, "SafeSubclassWindow");
	if (ssw)
		return ssw(hInstDLL, hWndSubclass,WndProc);
	return FALSE;
}

// Use this function to remove a subclassing
BOOL UnSubclassWindow(HINSTANCE hInstDLL, HWND hWndSubclass)
{
	UNSUBCLASS		usw;
	HINSTANCE		hInstMonitor = (HINSTANCE)GetModuleHandle("SubclassMonitor");
	usw = (UNSUBCLASS) GetProcAddress(hInstMonitor, "UnSubclassWindow");
	if (usw)
		return usw(hInstDLL, hWndSubclass);
	return FALSE;
}

// Use this function in subclased WNDPROC's to maintain the message chain
LRESULT NextWndProc(HINSTANCE hInstDLL, HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	NEXTPROC		nwp;
	HINSTANCE		hInstMonitor = (HINSTANCE)GetModuleHandle("SubclassMonitor");
	nwp = (NEXTPROC) GetProcAddress(hInstMonitor, "NextWndProc");
	if (nwp)
		return nwp(hInstDLL, hwnd, uMsg, wParam, lParam);
	return FALSE;
}

// Use this function to subclass a window
INT EnumSubclassing(HINSTANCE hInstDLL, HWND hwnd, ENUMSC enumfunc, LPARAM lParam)
{
	ENUMSUBCLASS	es;
	HINSTANCE		hInstMonitor = (HINSTANCE)GetModuleHandle("SubclassMonitor");
	es = (ENUMSUBCLASS) GetProcAddress(hInstMonitor, "EnumSubclassing");
	if (es)
		return es(hInstDLL, hwnd, enumfunc, lParam);
	return -1;
}
