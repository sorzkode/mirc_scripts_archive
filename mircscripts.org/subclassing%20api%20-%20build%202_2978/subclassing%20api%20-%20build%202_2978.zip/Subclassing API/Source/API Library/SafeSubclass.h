//
//	Safe Subclassing Version 2 (Written By: NaquadaBomb)
//
#pragma check_stack(off)
#pragma comment(linker,"/OPT:NOWIN98")

#define WIN32_LEAN_AND_MEAN
#define WINVER 0x0500
#define _X86_
#define _WIN32_WINNT 0x0500
#include <Windows.h>	//No proplem Windows.h will work file...
#include <WindowsX.h>	//Has the #define for SubclassWindow()

// Window Prop name, used to get the monitor module handle, if monitor is already loaded
#define pPropName "SubclassFix"

#define SCWM_PRECLOSE			(WM_USER + 800)
#define SCWM_CLOSECANCELED		(WM_USER + 801)
#define SCWM_ISLOADED			(WM_USER + 802)
#define SCWM_DEBUG				(WM_USER + 803)

// Function typedefs, used to call functions in the Monitor DLL
typedef BOOL (CALLBACK *DLLINIT)(HWND);
typedef bool (CALLBACK *SAFESUBCLASS)(HINSTANCE,HWND,WNDPROC);
typedef bool (CALLBACK *UNSUBCLASS)(HINSTANCE,HWND);
typedef LRESULT (CALLBACK *NEXTPROC)(HINSTANCE,HWND,UINT,WPARAM,LPARAM);
typedef BOOL (CALLBACK *ENUMSC)(HINSTANCE,HWND,WNDPROC,LPARAM);
typedef BOOL (CALLBACK *ENUMSUBCLASS)(HINSTANCE,HWND,ENUMSC,LPARAM);
