#include "Monitor.h"

// This procedure uses the correct values to CallWindowProc() and returns result
__declspec(dllexport) LRESULT CALLBACK NextWndProc(HINSTANCE hInst, HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	SUBCLASS	subClass;
	subClass = FindSubclass(hInst, hwnd);
	if ((subClass) && (subClass->nextProc))
		return CallWindowProc(subClass->nextProc, hwnd, uMsg, wParam, lParam);
	return 0L;
}

