#include "Monitor.h"

// This is an initializing routine, set
__declspec(dllexport) BOOL CALLBACK MonitorEnable(HWND hAppInit)
{
	if (IsWindow(hApp)) return FALSE;
	hApp = hAppInit;
	SafeSubclassWindow(hInstance, hApp, MessageHandler);

	return TRUE;
}
