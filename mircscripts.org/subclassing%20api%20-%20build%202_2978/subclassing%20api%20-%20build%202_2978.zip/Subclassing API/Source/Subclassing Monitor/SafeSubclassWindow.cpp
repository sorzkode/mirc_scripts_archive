#include "Monitor.h"

// Use this function to setup subclassing on a window
__declspec(dllexport) BOOL CALLBACK SafeSubclassWindow(HINSTANCE hInst, HWND hwnd, WNDPROC lpfn)
{
	SUBCLASS	newSubClass, subClass;

	// Checks
	if (!hApp)
		return false;
	if (FindSubclass(hInst, hwnd) != NULL)
		return false;
	if (!IsWindow(hwnd))
		return false;
	
	// Else, Add a record of this subclassing

	// Create and Initialize a new SubClassStruct
	newSubClass = NewSubclass(hInst, hwnd);

	subClass = GetFirstSubclass(hwnd);
	if ((subClass) && (hwnd == hApp))
		return InsertSubclassAfter(subClass, newSubClass, lpfn);
	else 
		return SetFirstSubclass(hwnd, newSubClass, lpfn);
}
