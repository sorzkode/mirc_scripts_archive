#include "Monitor.h"

__declspec(dllexport) INT CALLBACK EnumSubclassing(HINSTANCE hInstDLL, HWND hwnd, ENUMSC enumfunc, LPARAM lParam)
{
	SUBCLASS	subClass;
	int			index = 1;		
	
	if (!enumfunc) return 0;
	subClass = GetFirstSubclass(hwnd);
	while (subClass)
	{
		if (!enumfunc(subClass->hInstance, subClass->hWnd, subClass->nextProc, lParam))
			return index;
		index++;
		subClass = GetNextSubclass(subClass);	// Get Next Subclass Struct
	}
	return index;
}
