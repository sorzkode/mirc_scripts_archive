#include "Monitor.h"

BOOL CALLBACK EnumSuspend(HWND hwnd, LPARAM lp)
{
	WNDPROC		FirstWndProc, LastWndProc;
	SUBCLASS	subClass;
	int			index = 1;
	HWND		hParent = (HWND)lp;

	// Only need to handle windows associated with this task.., Can't just EnumChildWindows
	// since destop windows are children of the desktop not mIRC
	if (GetWindowThreadProcessId(hwnd, NULL) != GetWindowThreadProcessId(hParent, NULL))
		return TRUE;
	if (GetProp(hwnd, DPROPNAME))
		return TRUE;

	// Check here if this window has any subclassing, it it does disable it

	// With hApp, we want to leave the monitor DLL subclassed
	// It's going to be the "eye's and ears" while the mIRC DLL's are not subclassed
	if (hwnd == hApp) {
		subClass = GetFirstSubclass(hwnd);
		if (subClass) {
			LastWndProc = GetLastWndProc(hwnd);
	
			// Patching up the WndProc's, SetWindowLong() is not needed
			SetProp(hwnd, DWNDPROC, subClass->nextProc);
			subClass->nextProc = LastWndProc;

			// Preseve the remaining linked list in a DPROPNAME prop
			if (subClass->nextStruct) {
				SetProp(hwnd, DPROPNAME, subClass->nextStruct);
				subClass->nextStruct = NULL;
			}
		}
	}
	else {
		// Find the last page so we can find mIRC's proc
		LastWndProc = GetLastWndProc(hwnd);
		if (LastWndProc) {
			FirstWndProc = (WNDPROC)SetWindowLong(hwnd, GWL_WNDPROC, (LONG)LastWndProc);
			// Preseve the linked list in a DPROPNAME prop
			SetProp(hwnd, DWNDPROC, (HANDLE)FirstWndProc);
			SetProp(hwnd, DPROPNAME, (HANDLE)GetFirstSubclass(hwnd));
			RemoveProp(hwnd, PROPNAME);
		}
	}
	return TRUE;
}


inline VOID SubclassSuspend(VOID)
{
	HWND	hMDI = FindWindowEx(hApp,NULL,"MDIClient",NULL);

	// Enumerate all of this task's windows
	EnumChildWindows(0, (WNDENUMPROC)EnumSuspend, (LPARAM)hApp);
	EnumChildWindows(hApp, (WNDENUMPROC)EnumSuspend, (LPARAM)hApp);
	EnumChildWindows(hMDI, (WNDENUMPROC)EnumSuspend, (LPARAM)hApp);
	EnumSuspend(hApp, (LPARAM)hApp);
}