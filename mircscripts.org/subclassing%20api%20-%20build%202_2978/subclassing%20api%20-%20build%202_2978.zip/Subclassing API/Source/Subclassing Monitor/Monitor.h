#pragma check_stack(off)
#pragma comment(linker,"/OPT:NOWIN98")

#define WIN32_LEAN_AND_MEAN
#define WINVER 0x0500
#define _X86_
#define _WIN32_WINNT 0x0501
#include <Windows.h>	//No proplem Windows.h will work file...
#include <WindowsX.h>	//Has the #define for SubclassWindow()

// Message for communications to/from the subclass monitor
#define SCWM_PRECLOSE			(WM_USER + 800)
#define SCWM_CLOSECANCELED		(WM_USER + 801)
#define SCWM_ISLOADED			(WM_USER + 802)
#define SCWM_DEBUG				(WM_USER + 803)

// The first node of the linked list equals (SUBCLASS)GetProp(hwnd, "SubclassingInfo")
#define PROPNAME "SubclassingInfo"
#define DPROPNAME "DisabledSubclassing"
#define DWNDPROC "DisabledWndProc"

//
typedef BOOL (CALLBACK *ENUMSC)(HINSTANCE,HWND,WNDPROC,LPARAM);

typedef struct ParameterPair {
	LPARAM lParam;
	WPARAM wParam;
} PARMPAIR, *PPARMPAIR;

// I use a linked list to maintain all of the subclassing procedures
typedef struct SubClassStruct SubClassRecord;
typedef SubClassRecord *SUBCLASS;
struct SubClassStruct {
	HINSTANCE	hInstance;		// The hInstance of the DLL that setup the subclassing
	HWND		hWnd;			// The handle of the window being subclassed
	WNDPROC		nextProc;		// Is the nextProc that needs to be called
	SUBCLASS	nextStruct;		// Is the address of the next structure in the linked list
};

extern	HWND		hApp;
extern	HINSTANCE	hInstance;
extern	LPVOID		heap;

extern inline SUBCLASS	FindSubclass(HINSTANCE hInst, HWND hwnd);
extern inline WNDPROC	GetLastWndProc(HWND hwnd);
extern inline VOID		SubclassResume(VOID);
extern inline VOID		SubclassSuspend(VOID);
extern inline WNDPROC	GetMircProc(HWND hwnd);
extern inline SUBCLASS	GetFirstSubclass(HWND hwnd);
extern inline SUBCLASS	GetNextSubclass(SUBCLASS subClass);
extern inline BOOL		SetFirstSubclass(HWND hwnd, SUBCLASS subClass, WNDPROC newproc);
extern inline SUBCLASS	NewSubclass(HINSTANCE hInst, HWND hwnd);
extern inline BOOL		InsertSubclassAfter(SUBCLASS subInAfter, SUBCLASS subClass, WNDPROC newproc);
extern inline BOOL		RemoveSubclass(SUBCLASS subClass);
extern inline BOOL		DeleteSubclass(SUBCLASS subClass);

__declspec(dllexport) BOOL	  CALLBACK	SafeSubclassWindow(HINSTANCE hInst, HWND hwnd, WNDPROC lpfn);
__declspec(dllexport) BOOL    CALLBACK	UnSubclassWindow(HINSTANCE hInst, HWND hwnd);
__declspec(dllexport) LRESULT CALLBACK	NextWndProc(HINSTANCE hInst, HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
__declspec(dllexport) BOOL    CALLBACK	MonitorEnable(HWND hAppInit);
__declspec(dllexport) INT     CALLBACK	EnumSubclassing(HINSTANCE hInstDLL, HWND hwnd, ENUMSC enumfunc, LPARAM lParam);

extern LRESULT CALLBACK MessageHandler(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
