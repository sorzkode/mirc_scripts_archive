#include "Monitor.h"

BOOL InClose = FALSE;

// Handles hApp Messages
LRESULT CALLBACK MessageHandler(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	LRESULT		lRes;
	switch (uMsg) {
		case WM_CLOSE:
			// First handler for WM_CLOSE, this handler unsubclass all the mIRC DLL's and
			// sends a SCWM_PRECLOSE message, than it's canceled and WM_CLOSE is reposted.
			// This get all mIRC DLL's subclassing out of the call stack
			if (!InClose) {
				InClose = true;
				// Pre-WM_CLOSE notification
				SendMessage(hApp, SCWM_PRECLOSE, wParam, lParam);
				SubclassSuspend();
				PostMessage(hApp, WM_CLOSE, wParam, lParam);
				return 0L;
			}
			// Second handler for WM_CLOSE
			// ALL OTHER SUBCLASSING SHOULD BE DISABLED WHEN HERE
			InClose = false;
			lRes = NextWndProc(hInstance, hwnd, uMsg, wParam, lParam);
			// If (!lRes) than WM_CLOSE was canceled
			if (!lRes) { 
				// Resume all subclassing, WM_CLOSE was canceled
				SubclassResume();
				// Message all DLL's (via WNDPROC) that this has happened
				PostMessage(hApp, SCWM_CLOSECANCELED, wParam, lParam);
			}
			// This DLL does it UnSubclassWindow() in WM_QUIT
			return lRes;
		case SCWM_ISLOADED:
			return (LRESULT)hInstance;
		case WM_QUIT:
			UnSubclassWindow(hInstance, hwnd);
			PostMessage(hwnd, uMsg, wParam, lParam);
			return 0L;
		default:
			break;
	}
	return NextWndProc(hInstance, hwnd, uMsg, wParam, lParam);
}
