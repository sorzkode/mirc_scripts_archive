#include "Monitor.h"

void StartDLL(void)
{
	return;
}

// DLL Statup, Happens at time of LoadLibrary()
extern "C" int WINAPI _DllMainCRTStartup(HANDLE hInstDLL, DWORD, void*)
{
	hInstance = (HINSTANCE)hInstDLL;
	heap = GetProcessHeap();
	//InitCommonControls();
	StartDLL();
	return 1;
}
