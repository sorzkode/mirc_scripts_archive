#include "Monitor.h"

// Use this function to remove subclassing on a window
__declspec(dllexport) BOOL CALLBACK UnSubclassWindow(HINSTANCE hInst, HWND hwnd)
{
	// Remove the record of this subclassing
	SUBCLASS	scIndex;

	if (!hInst || !hApp || !IsWindow(hwnd)) return false;

	// Lookup the Page (structure) for the page being removed
	scIndex = FindSubclass(hInst, hwnd);
	if (!scIndex) return false;

	return RemoveSubclass(scIndex);
}
