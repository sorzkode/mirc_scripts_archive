#include "Monitor.h"

inline SUBCLASS GetFirstSubclass(HWND hwnd)
{
	if (!IsWindow(hwnd)) return NULL;
	return (SUBCLASS)GetProp(hwnd, PROPNAME); // First Subclass
}

inline SUBCLASS GetNextSubclass(SUBCLASS subClass)
{
	if (!subClass) return NULL;
	return subClass->nextStruct;
}

// Creates a New Subclass structure
// A new SUBCLASS must be passed to either SetFirstSubclass() or InsertSubclassAfter()
inline SUBCLASS NewSubclass(HINSTANCE hInst, HWND hwnd)
{
	SUBCLASS	subClass;

	if (!IsWindow(hwnd) || !hInst)
		return NULL;

	subClass = new SubClassRecord;
	subClass->hInstance = hInst;
	subClass->hWnd = hwnd;
	subClass->nextProc = NULL;
	subClass->nextStruct = NULL;

	return subClass;
}

inline BOOL SetFirstSubclass(HWND hwnd, SUBCLASS subClass, WNDPROC newproc)
{
	SUBCLASS	existing;
	WNDPROC		proc;

	if (!IsWindow(hwnd) || !newproc) return false;

	// If !subClass, only restore mIRC's proc
	if (!subClass) {
		// Remove the old window prop
		RemoveProp(hwnd, PROPNAME);
		// Restore the mIRC proc
		proc = (WNDPROC)SetWindowLong(hwnd, GWL_WNDPROC, (LONG)newproc);

		return true;
	}

	// subClass != NULL
	existing = GetFirstSubclass(hwnd);
	
	// Restore mIRC's proc if not already using
	proc = GetMircProc(hwnd);
	if (proc != (WNDPROC)GetWindowLong(hwnd, GWL_WNDPROC))
		proc = (WNDPROC)SetWindowLong(hwnd, GWL_WNDPROC, (LONG)proc);
	
	// Remove the old window prop
	RemoveProp(hwnd, PROPNAME);

	// Update the window prop
	SetProp(hwnd, PROPNAME, (HANDLE)subClass); // First Subclass
	subClass->nextProc = proc;
	if (existing)
		subClass->nextStruct = existing;
	SetWindowLong(hwnd, GWL_WNDPROC, (LONG)newproc);
	return true;
}

inline BOOL InsertSubclassAfter(SUBCLASS subInAfter, SUBCLASS subClass, WNDPROC newproc)
{
	if (!subInAfter || !subClass || !newproc)
		return FALSE;

	subClass->nextProc = subInAfter->nextProc;
	subClass->nextStruct = subInAfter->nextStruct;
	subInAfter->nextProc = newproc;
	subInAfter->nextStruct = subClass;
	return TRUE;
}

inline BOOL DeleteSubclass(SUBCLASS subClass)
{
	SUBCLASS	subPrev;
	if ((!subClass) || (!subClass->hWnd)) return false;
	// Will need to scan all subclassing since there is no reverse direction pointer
	subPrev = GetFirstSubclass(subClass->hWnd);
	if (subPrev == subClass) {
			SetFirstSubclass(subClass->hWnd, subClass->nextStruct, subClass->nextProc);
	}
	else {
		while (subPrev) {
			if (subPrev->nextStruct == subClass) {
				subPrev->nextStruct = subClass->nextStruct;
				subPrev->nextProc = subClass->nextProc;
				delete subClass;
				return true;
			}
			subPrev = GetNextSubclass(subPrev);
		}
	}
	return false;
}

inline BOOL RemoveSubclass(SUBCLASS subClass)
{
	SUBCLASS	subFirst = GetFirstSubclass(subClass->hWnd);

	if (subClass == subFirst) {
		SetFirstSubclass(subClass->hWnd, subClass->nextStruct, subClass->nextProc);
	}
	DeleteSubclass(subClass);
	return true;
}

inline WNDPROC GetLastWndProc(HWND hwnd)
{
	SUBCLASS subClass = GetFirstSubclass(hwnd);

	while (subClass) {
		if (!subClass->nextStruct)
			return subClass->nextProc;
		subClass = GetNextSubclass(subClass);
	}
	return NULL;
}

// Unlike GetLastProc(), this function return mIRC's proc even if no subclassing exists
inline WNDPROC GetMircProc(HWND hwnd)
{
	SUBCLASS	subClass = GetFirstSubclass(hwnd);

	if (!subClass)
		return (WNDPROC)GetWindowLong(hwnd, GWL_WNDPROC);

	return GetLastWndProc(hwnd);
}

inline SUBCLASS FindSubclass(HINSTANCE hInst, HWND hwnd)
{
	SUBCLASS	subClass = GetFirstSubclass(hwnd);

	// Finds the Subclass Record from hInstance and window
	while (subClass) {
		if (subClass->hInstance == hInst) return subClass;
		subClass = GetNextSubclass(subClass);	// Get Next Subclass Struct
	}
	return NULL;
}
