#include "Monitor.h"

BOOL CALLBACK EnumResume(HWND hwnd, LPARAM lp)
{
	WNDPROC		suspendProc;
	SUBCLASS	subClass;
	int			index = 1;
	HWND		hParent = (HWND)lp;

	// Only need to handle windows associated with this task.., Can't just EnumChildWindows
	// since destop windows are children of the desktop not mIRC
	if (GetWindowThreadProcessId(hwnd, NULL) != GetWindowThreadProcessId(hParent, NULL))
		return TRUE;

	// Check here if this window has any disabled subclassing, if it does enable it
	subClass = (SUBCLASS)GetProp(hwnd, DPROPNAME);
	if (!subClass) return TRUE;
	suspendProc = (WNDPROC)GetProp(hwnd, DWNDPROC);

	// hApp may have a PROPNAME and DPROPNAME both, so we need to handle separate
	if (hwnd == hApp) {
		SUBCLASS	subFirst;

		// Get the first linked item (only one at this point, this DLL)
		subFirst = GetFirstSubclass(hwnd);
			
		// Add back the disabled items
		subFirst->nextStruct = subClass;
		subFirst->nextProc = suspendProc;
	}
	else {
		suspendProc = (WNDPROC)GetProp(hwnd, DWNDPROC);
		SetProp(hwnd, PROPNAME, (HANDLE)subClass);
		SetWindowLong(hwnd, GWL_WNDPROC, (LONG)suspendProc);
	}

	// Remove the diasbled props
	RemoveProp(hwnd, DPROPNAME);
	RemoveProp(hwnd, DWNDPROC);
	
	return TRUE;
}

inline VOID SubclassResume(VOID)
{
	HWND	hMDI = FindWindowEx(hApp,NULL,"MDIClient",NULL);

	// Enumerate all of this task's windows
	EnumChildWindows(0, (WNDENUMPROC)EnumResume, (LPARAM)hApp);
	EnumChildWindows(hApp, (WNDENUMPROC)EnumResume, (LPARAM)hApp);
	EnumChildWindows(hMDI, (WNDENUMPROC)EnumResume, (LPARAM)hApp);
	EnumResume(hApp, (LPARAM)hApp);
}
