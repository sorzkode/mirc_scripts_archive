#include <Windows.h>

HWND		hApp = NULL;
HINSTANCE	hInstance = NULL;
LPVOID		heap = NULL;
