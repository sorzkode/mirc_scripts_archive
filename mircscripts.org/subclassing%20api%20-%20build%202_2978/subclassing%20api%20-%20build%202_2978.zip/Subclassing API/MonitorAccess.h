// You can comment-out these includes if already included

#include <Windows.h>
#include <WindowsX.h>
#include <stdlib.h>

// Message for communications to/from the subclass monitor (hApp WndProc)
#define SCWM_PRECLOSE			(WM_USER + 800)
#define SCWM_CLOSECANCELED		(WM_USER + 801)
#define SCWM_ISLOADED			(WM_USER + 802)

typedef BOOL (CALLBACK *ENUMSC)(HINSTANCE,HWND,WNDPROC,LPARAM);

extern BOOL	SafeSubclassWindow(HINSTANCE hInstDLL, HWND hWndSubclass, WNDPROC WndProc);
extern BOOL	UnSubclassWindow(HINSTANCE hInstDLL, HWND hWndSubclass);
extern LRESULT	NextWndProc(HINSTANCE hInstDLL, HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
extern HMODULE	InjectMonitor(HINSTANCE hInstDLL, HWND hApp, LPSTR mData);
extern INT	EnumSubclassing(HINSTANCE hInstDLL, HWND hwnd, ENUMSC enumfunc, LPARAM lParam);


