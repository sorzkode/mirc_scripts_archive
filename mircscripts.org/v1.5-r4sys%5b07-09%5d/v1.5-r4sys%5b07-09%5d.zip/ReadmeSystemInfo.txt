To load the script, extract the files in the archive to your mIRC directory and type this in a mIRC window:

/load -rs SystemInfo.mrc

For mIRC 5.9 and above, may work on earlier versions but don't expect miracles :)