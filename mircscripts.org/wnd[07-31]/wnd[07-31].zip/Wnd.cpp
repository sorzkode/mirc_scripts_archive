#include <windows.h>

HANDLE hFileMap;
LPSTR mData;
HWND mWnd;
HWND hooked_hwnds[100];
WNDPROC hooked_old_procs[100];
int hooked_count = 0;

extern "C" int WINAPI _DllMainCRTStartup(HANDLE,DWORD,void*) { return 1; }
extern "C" {

	typedef struct {
		DWORD  mVersion;
		HWND   mHwnd;
		BOOL   mKeep;
	} LOADINFO;

void WINAPI LoadDll(LOADINFO *li)
{
	mWnd = li->mHwnd;
	hFileMap = CreateFileMapping(INVALID_HANDLE_VALUE,0,PAGE_READWRITE,0,4096,"mIRC");	
	mData = (LPSTR)MapViewOfFile(hFileMap,FILE_MAP_ALL_ACCESS,0,0,0);
}

int WINAPI UnloadDll(int timeout)
{
	if (!timeout)
	{
		for (int i=0;i<hooked_count;i++) {
			SetWindowLong(hooked_hwnds[i],GWL_WNDPROC,(LONG)hooked_old_procs[i]);
		}
		UnmapViewOfFile(mData);
		CloseHandle(hFileMap);
	}
	return 0;
}

bool is_hooked(HWND hwnd) 
{
	for (int i=0;i<hooked_count;i++) {
		if (hooked_hwnds[i] == hwnd)
			return true;
	}
	return false;
}
WNDPROC find_old_proc(HWND hwnd) 
{
	for (int i=0;i<hooked_count;i++) {
		if (hooked_hwnds[i] == hwnd)
			return hooked_old_procs[i];
	}
	return NULL;
}

void release_window(HWND hwnd) 
{
	SetWindowLong(hwnd,GWL_WNDPROC,(LONG)find_old_proc(hwnd));
}
LRESULT CALLBACK WndProc(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	long x, y, w, h, cx, cy;
	RECT wrect,mrect;
	GetWindowRect(hwnd,&wrect);
	GetWindowRect(GetDlgItem(mWnd,0),&mrect);
	WNDPROC old_proc = find_old_proc(hwnd);
	switch (uMsg) {
		case (WM_MOUSEMOVE):
			wsprintf(mData,"/.signal Wnd mouse_move %d %d %d",hwnd,LOWORD(lParam),HIWORD(lParam));
			SendMessage(mWnd,WM_USER + 200,0,0);
			break;
		case (WM_MOUSELEAVE):
			wsprintf(mData,"/.signal Wnd mouse_leave %d",hwnd);
			SendMessage(mWnd,WM_USER + 200,0,0);
			break;
		case (WM_RBUTTONDOWN):
			wsprintf(mData,"/.signal Wnd mouse_rdown %d",hwnd);
			SendMessage(mWnd,WM_USER + 200,0,0);
			break;
		case (WM_RBUTTONUP):
			wsprintf(mData,"/.signal Wnd mouse_rup %d",hwnd);
			SendMessage(mWnd,WM_USER + 200,0,0);
			break;
		case (WM_RBUTTONDBLCLK):
			wsprintf(mData,"/.signal Wnd mouse_rdclick %d",hwnd);
			SendMessage(mWnd,WM_USER + 200,0,0);
			break;
		case (WM_LBUTTONDOWN):
			wsprintf(mData,"/.signal Wnd mouse_ldown %d",hwnd);
			SendMessage(mWnd,WM_USER + 200,0,0);
			break;
		case (WM_LBUTTONUP):
			wsprintf(mData,"/.signal Wnd mouse_lup %d",hwnd);
			SendMessage(mWnd,WM_USER + 200,0,0);
			break;
		case (WM_LBUTTONDBLCLK):
			wsprintf(mData,"/.signal Wnd mouse_ldclick %d",hwnd);
			SendMessage(mWnd,WM_USER + 200,0,0);
			break;
		case (WM_MBUTTONDOWN):
			wsprintf(mData,"/.signal Wnd mouse_mdown %d",hwnd);
			SendMessage(mWnd,WM_USER + 200,0,0);
			break;
		case (WM_MBUTTONUP):
			wsprintf(mData,"/.signal Wnd mouse_mup %d",hwnd);
			SendMessage(mWnd,WM_USER + 200,0,0);
			break;
		case (WM_MBUTTONDBLCLK):
			wsprintf(mData,"/.signal Wnd mouse_mdclick %d",hwnd);
			SendMessage(mWnd,WM_USER + 200,0,0);
			break;
		case (WM_CHAR):
			wsprintf(mData,"/.signal Wnd key %d %d",hwnd,wParam);
			SendMessage(mWnd,WM_USER + 200,0,0);
			break;
		case (WM_ACTIVATE):
			if ((HWND)lParam == hwnd)
				wsprintf(mData,"/.signal Wnd activate %d",hwnd);
			else
				wsprintf(mData,"/.signal Wnd deactivate %d",hwnd);
			SendMessage(mWnd,WM_USER + 200,0,0);
			break;
		case (WM_MDIACTIVATE):
			if ((HWND)lParam == hwnd)
				wsprintf(mData,"/.signal Wnd activate %d",hwnd);
			else
				wsprintf(mData,"/.signal Wnd deactivate %d",hwnd);
			SendMessage(mWnd,WM_USER + 200,0,0);
			break;
		case (WM_SIZING):
			x = wrect.left; y = wrect.top; w = wrect.right-wrect.left; h = wrect.bottom-wrect.top;
			cx = x-mrect.left; cy = y-mrect.top;
			wsprintf(mData,"/.signal Wnd sizing %d %d %d %d %d %d %d",hwnd,x,y,w,h,cx,cy);
			SendMessage(mWnd,WM_USER + 200,0,0);
			break;
		case (WM_SIZE):
			x = wrect.left; y = wrect.top; w = wrect.right-wrect.left; h = wrect.bottom-wrect.top;
			cx = x-mrect.left; cy = y-mrect.top;
			switch (wParam) {
			case (SIZE_MAXIMIZED):
				wsprintf(mData,"/.signal Wnd maximized %d %d %d %d %d %d %d",hwnd,x,y,w,h,cx,cy);
				SendMessage(mWnd,WM_USER + 200,0,0);
				break;
			case (SIZE_MINIMIZED):
				wsprintf(mData,"/.signal Wnd minimized %d %d %d %d %d %d %d",hwnd,x,y,w,h,cx,cy);
				SendMessage(mWnd,WM_USER + 200,0,0);
				break;
			default:
				wsprintf(mData,"/.signal Wnd size %d %d %d %d %d %d %d",hwnd,x,y,w,h,cx,cy);
				SendMessage(mWnd,WM_USER + 200,0,0);
				break;
			}
			break;
		case (WM_MOVING):
			x = wrect.left; y = wrect.top; w = wrect.right-wrect.left; h = wrect.bottom-wrect.top;
			cx = x-mrect.left; cy = y-mrect.top;
			wsprintf(mData,"/.signal Wnd moving %d %d %d %d %d %d %d",hwnd,x,y,w,h,cx,cy);
			SendMessage(mWnd,WM_USER + 200,0,0);
			break;
		case (WM_MOVE):
			x = wrect.left; y = wrect.top; w = wrect.right-wrect.left; h = wrect.bottom-wrect.top;
			cx = x-mrect.left; cy = y-mrect.top;
			wsprintf(mData,"/.signal Wnd move %d %d %d %d %d %d %d",hwnd,x,y,w,h,cx,cy);
			SendMessage(mWnd,WM_USER + 200,0,0);
			break;
		case (WM_CLOSE):
			wsprintf(mData,"/.signal Wnd tryclose %d",hwnd);
			SendMessage(mWnd,WM_USER + 200,0,0);
			return 0;
		case (WM_DESTROY):
			wsprintf(mData,"/.signal Wnd destroyed %d",hwnd);
			SendMessage(mWnd,WM_USER + 200,0,0);
			release_window(hwnd);
			break;
	}
	return CallWindowProc(old_proc,hwnd,uMsg,wParam,lParam);
}

int WINAPI hook(HWND mWnd,HWND aWnd,char *data,char*,BOOL,BOOL) {
	HWND hwnd = (HWND)atol(data);
	if (is_hooked(hwnd)) {
		lstrcpy(data,"E_ALREADY_HOOKED");
		return 3;
	}
	hooked_hwnds[hooked_count] = hwnd;
	hooked_old_procs[hooked_count] = (WNDPROC)GetWindowLong(hwnd,GWL_WNDPROC);
	hooked_count++;
	SetWindowLong(hwnd,GWL_WNDPROC,(LONG)WndProc);

	lstrcpy(data,"S_OK");
	return 3;
}
int WINAPI release(HWND mWnd,HWND aWnd,char *data,char*,BOOL,BOOL) {
	HWND hwnd = (HWND)atol(data);
	if (!IsWindow(hwnd)) { lstrcpy(data,"E_INVALID_WINDOW"); return 3; }
	if (!is_hooked(hwnd)) {
		lstrcpy(data,"E_NOT_HOOKED");
		return 3;
	}
	release_window(hwnd);
	lstrcpy(data,"S_OK");
	return 3;
}

int WINAPI close(HWND mWnd,HWND aWnd,char *data,char*,BOOL,BOOL) 
{
	HWND hwnd = (HWND)atol(data);
	if (!IsWindow(hwnd)) { lstrcpy(data,"E_INVALID_WINDOW"); return 3; }
	if (!is_hooked(hwnd)) { lstrcpy(data,"E_NOT_HOOKED"); return 3; }
	CallWindowProc(find_old_proc(hwnd),hwnd,WM_CLOSE,NULL,NULL);
	lstrcpy(data,"S_OK");
	return 3;
}
int WINAPI getsize(HWND mWnd,HWND aWnd,char *data,char*,BOOL,BOOL) 
{
	HWND hwnd = (HWND)atol(data);
	int x, y, w, h;
	if (!IsWindow(hwnd)) { lstrcpy(data,"E_INVALID_WINDOW"); return 3; }
	RECT wrect;
	GetWindowRect(hwnd,&wrect);
	x = wrect.left; y = wrect.top; w = wrect.right-wrect.left; h = wrect.bottom-wrect.top;
	wsprintf(data,"%d %d %d %d",x,y,w,h);
	return 3;
}
int WINAPI getHWND(HWND mWnd,HWND aWnd,char *data,char*,BOOL,BOOL)
{
	HWND hwnd = FindWindow(data,NULL);
	if (!IsWindow(hwnd)) { lstrcpy(data,"E_INVALID_WINDOW"); return 3; }
	wsprintf(data,"%d",hwnd);
	return 3;
}
int WINAPI getHWND2(HWND mWnd,HWND aWnd,char *data,char*,BOOL,BOOL)
{
	HWND hwnd = FindWindow(NULL,data);
	if (!IsWindow(hwnd)) { lstrcpy(data,"E_INVALID_WINDOW"); return 3; }
	wsprintf(data,"%d",hwnd);
	return 3;
}
int WINAPI getcaption(HWND mWnd,HWND aWnd,char *data,char*,BOOL,BOOL)
{
	HWND hwnd  = (HWND)atol(data);
	if (!IsWindow(hwnd)) { lstrcpy(data,"E_INVALID_WINDOW"); return 3; }
	GetWindowText(hwnd,data,200);
	return 3;
}
int WINAPI version(HWND mWnd,HWND aWnd,char *data,char*,BOOL,BOOL)
{
	lstrcpy(data,"Wnd.dll v1.0 by FoLKeN^ - folken@bitchmessenger.com.ar - http://www.bitchmessenger.com.ar");
	return 3;
}

}
