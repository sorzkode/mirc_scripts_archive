Wnd dll 1.0 by FoLKeN^
E-Mail: folken@bitchmessenger.com.ar
Website: http://www.bitchmessenger.com.ar

Special Thanks: Narusegawa-Naru :D

DLL description: useful functions for managing your windows, even if they are mirc windows or not (since you can specify any HWND on any function)

Functions:

- hook -

Description: Catches most important window events and when they are fired, they are sent to mirc by a signal.

Syntax	: 	//dll Wnd.dll hook <HWND> | $dll(Wnd.dll,hook,<HWND>)
Example	: 	//dll Wnd.dll hook $window(@my_hooked_window).hwnd
Returns	: 	S_OK - the window exists/is not being hooked
		E_INVALID_WINDOW - window does not exist
		E_ALREADY_HOOKED - window is already hooked

When an event its executed, 'Wnd' signal its executed:

on 1:SIGNAL:Wnd: {
...
}

$1 is the event name, $2 is the HWND of the window that is executing the event, and $3, $4 ... are event-specific parameters

events could be:

mouse_move		- The mouse is being moved inside the window
			- $3 and $3 are the mouse coordinates in the window area (not the desktop area!)

mouse_leave		- The mouse leaved the window area

mouse_rdown		- The right/left/middle mouse button has been pressed
mouse_ldown
mouse_mdown

mouse_rup		- The right/left/middle mouse button has been released
mouse_lup
mouse_mup

mouse_rdclick		- The right/left/middle mouse button has been double-clicked
mouse_ldclick
mouse_mdclick

key			- The user pressed a key (this does not apply for mirc editbox!)
			- $3 is the keychar being pressed

activate		- The window has been activated

deactivate		- The window has been deactivated

sizing			- The window is being sized
			- $3, $4, $5, $6 are the x, y, w and h values for the window - $7 and $8 are the w and h
			  values according to mirc's client area

size			- The window has changed its size
			- $3, $4, $5, $6 are the x, y, w and h values for the window - $7 and $8 are the w and h
			  values according to mirc's client area
			- Note: This event will execute always after a 'sizing' event if you have "Show window contents
			  while dragging" windows appearance option on

maximized/minimized	- The window was maximized/minimized
			- $3, $4, $5, $6 are the x, y, w and h values for the window - $7 and $8 are the w and h
			  values according to mirc's client area
			- Note: there isn't a 'restored' event - 'size' event is returned instead

moving			- The window is being moved
			- $3, $4, $5, $6 are the x, y, w and h values for the window - $7 and $8 are the w and h
			  values according to mirc's client area

move			- The window has changed its position
			- $3, $4, $5, $6 are the x, y, w and h values for the window - $7 and $8 are the w and h
			  values according to mirc's client area
			- Note: This event will execute always after a 'moving' event if you have "Show window contents
			  while dragging" windows appearance option on

tryclose		- The user attempted to close the window - the window won't close, this 
			  event is more precise than on CLOSE/EXIT mirc events and works for any window.
			  To close the window, use 'close' dll function.

destroyed		- The window has been destroyed





- release -

Description: Stops catching window events

Syntax	: 	//dll Wnd.dll release <HWND> | $dll(Wnd.dll,release,<HWND>)
Example	: 	//dll Wnd.dll release $window(@my_hooked_window).hwnd
Returns	: 	S_OK - the window was released
		E_INVALID_WINDOW - window does not exist
		E_NOT_HOOKED - window isn't hooked


- close -

Description: Closes a hooked window

Syntax	: 	//dll Wnd.dll close <HWND> | $dll(Wnd.dll,close,<HWND>)
Example	: 	//dll Wnd.dll close $window(@my_hooked_window).hwnd
Returns	: 	S_OK - the window was closed
		E_INVALID_WINDOW - window does not exist
		E_NOT_HOOKED - window isn't hooked


- getsize -

Description: Gets the x, y, w, h values for any window relative to the desktop

Syntax	: 	$dll(Wnd.dll,getsize,<HWND>)
Example	: 	//echo -a $dll(Wnd.dll,close,$window(@my_hooked_window).hwnd)
Returns	: 	S_OK - the window coordinates were returned
		E_INVALID_WINDOW - window does not exist


- getHWND -

Description: Gets the HWND of any window by specifying its class name

Syntax	: 	$dll(Wnd.dll,getHWND,<class name>)
Example	: 	//echo -a $dll(Wnd.dll,getHWND,Shell_TrayWnd) << will return the Windows TaskBar HWND
Returns	: 	S_OK - the window HWND was returned
		E_INVALID_WINDOW - window does not exist



- getHWND2 -

Description: Gets the HWND of any window by specifying its title

Syntax	: 	$dll(Wnd.dll,getHWND2,<window title>)
Example	: 	//echo -a $dll(Wnd.dll,getHWND2,Wnd readme.txt - Notepad)
Returns	: 	S_OK - the window HWND was returned
		E_INVALID_WINDOW - window does not exist


- getcaption -

Description: Gets the caption (or title) of a given HWND

Syntax	: 	$dll(Wnd.dll,getcaption,<HWND>)
Example	: 	//echo -a $dll(Wnd.dll,getcaption,$window(-2).hwnd) << will return mIRC's titlebar
Returns	: 	S_OK - the window caption was returned
		E_INVALID_WINDOW - window does not exist


- version -

Description: Returns information about the dll and the author

Example	: 	//echo -a $dll(Wnd.dll,version,.)
Returns: Wnd.dll v1.0 by FoLKeN^ - folken@bitchmessenger.com.ar - http://www.bitchmessenger.com.ar


end of file ;)