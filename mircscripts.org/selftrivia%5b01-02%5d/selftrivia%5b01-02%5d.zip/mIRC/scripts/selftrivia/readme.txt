------------------------------

   Self-Trivia by ^Spiked^

==============================

Self-Trivia is a trivia game to play by yourself. Although it is a simple script, it provides fun on hose rainy days, or if you bored. Enjoy.

==============================

- You can make new trivia files by yourself, as long as they are text documents (.txt).

- Adding trivia is simple, just add a questions, follwed by a *, then add your answer. If you want to add more trivia, just start on a new line. [Everytime you make new trivia, or add trivia files, you MUST click the 'Mix Files' button in the trivia dialog. THIS IS ESSENTIAL...]

- Everything else it pretty much self-explanatory.