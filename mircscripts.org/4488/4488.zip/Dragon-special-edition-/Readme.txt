DScript v1.0

	it's an mIRC script that ease the life of IRC users out there. It manages almost everything
in the life of IRC such as channel management and user nicknames management. It support connecting to
more than one server simultaneously. It has a nice theme that changes the look of mIRC to a better one.
you only have to use it and DScript will prove itself. It provided in two native languages, English
and Arabic. It accepts adding more languages that those two native languages. Also, for those who suffer
from botnet attacks this script provide a great protection against floods. The name DScript refers to
						Dragon Script

Regards,
Dragon
