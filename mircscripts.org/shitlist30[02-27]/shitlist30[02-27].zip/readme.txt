
  .��� Shitlist 3.0 - by diffusi0n             (d)
  '---- - - - --------- --- - -- -------- -- --- -


  (?) English:
  ------------

    (1) About..
    (2) Installation
    (3) Versions
    (4) Credits


 `�-> 1. About..
         -------

  Author: diffusi0n (diffusi0n@brasnet.org)
  Released: 27/03/2003

  Files: shitlist30.mrc
         mdx.dll
         views.mdx
         fechar.ico
         idioma.icl
         readme.txt


 `�-> 2. Installation
         ------------

  Copy the paste "shitlist30" for the directory of the mIRC    
   Ex.: C:\mIRC\shilist30    
  
  ..And executes the file "shitlist30.mrc"  
   Ex.: /load -rs shitlist30\shitlist30.mrc    
    
  Ready! Now type /shitlist to configure.


 `�-> 3. Versions
         --------
  - 3.0 (27/03/2003)
    + added option for choose one channel for enable the shitlist (optional)
    + added support the multi-language: portuguese or english
    + new dialog design  

  - 2.0 (04/01/2002)
    + added option for kick or kick/ban

  - 1.0
    + first public version


 `�-> 4. Credits
         -------

  Credits to DragonZap for the: mdx.dll
                                views.mdx

  ===================================================================

  (?) Portugu�s:
  --------------

    (1) Sobre..
    (2) Instala��o
    (3) Vers�es
    (4) Cr�ditos


 `�-> 1. Sobre..
         -------

  Autor: diffusi0n (diffusi0n@brasnet.org)
  Lan�ado: 27/03/2003

  Arquivos: shitlist30.mrc
            mdx.dll
            views.mdx
            fechar.ico
            idioma.icl
            readme.txt


 `�-> 2. Instala��o
         ----------

  Copie a pasta "shitlist30" para o diret�rio do mIRC  
   Ex.: C:\mIRC\shilist30  

  ..E execute o arquivo "shitlist30.mrc"  
   Ex.: /load -rs shitlist30\shitlist30.mrc  
  
  Pronto! Agora digite /shitlist para configurar.


 `�-> 2. Vers�es
         -------

  - 3.0 (27/03/2003)
    + adicionado op��o pra escolher um canal pra habilitar a shitlist (opcional)
    + adicionado suporte a multi-linguagem: portugu�s ou ingl�s
    + novo design da dialog

  - 2.0 (04/01/2002)
    + adicionado op��o pra kick ou kick/ban

  - 1.0
    + primeira vers�o p�blica


 `�-> 4. Cr�ditos
         --------

  Cr�ditos ao DragonZap pela: mdx.dll
                              views.mdx






 -�� (c) copyright 2003, diffusi0n. all rights reserved.
                                 (diffusi0n@brasnet.org)