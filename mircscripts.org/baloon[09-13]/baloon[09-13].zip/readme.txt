
             -= Baloon Shooter v1.0 =-

  Hello, and thanks for trying this humble effort
  of mine out. =) Baloon Shooter is a simple game
  that you probably have seen before. But not for
  mIRC!
    The mission  is simple,  just  shoot  as many
  baloons as you can before there are too many of
  them for you to handle.  If you miss to shoot a
  baloon, and the baloon flies out of the screen,
  you loose one of your precious lives.

  Please send  comments/suggestions  or your view
  on life to my nick BeteL on  mircscripts.org or
  e-mail me: invaluable@hotmail.com

  Thank you for playing this game, enjoy!

  Tommy "BeteLgeuZe" L�fstedt

  -----------------------------------------------
  Installation: 

      Type: /load -rs file.path\baloon.game
      'file.path' is the full path to the file.

      To play, type: /baloon

      If you want to add Baloon Shooter to your
      popups, append this  line to your desired
      popup section:
      Baloon Shooter:baloon

      Note  that  Baloon Shooter  requres  mIRC
      6.02 or higher to work properly.

  Uninstallation:

      Type: /unload -rs file.path\baloon.game
      'file.path' is the full path to the file.
      Then remove all files  relating to Baloon
      Shooter. The files are:

      baloon.game         - Game script file
      gfx.png             - Grafix for the game
      gunclick.mp3        - No more shots sound
      gunload.mp3         - Loading gun sound
      gunshot.mp3         - Shooting gun sound
      readme.txt          - This file

  -----------------------------------------------
  System requirements (for best performance):
  ===================

  Space       - 19kb of  free hard drive space.
  Processor   - At least a  Pentium 3 processor
                or equivalent.
  Memory      - Dunno,  perhaps 64Mb of RAM for
                smooth play.
  Grafix      - At least 256 Colors.
  Sound       - Any general  Sound card  should
                work     (Sound   Blaster    or
                equivalent).

  Note that these  are  requirements for  BEST
  performance.  You will be  able to  play the
  game with less than these hardwares. But you
  will then be experiencing some serious lag!

  -----------------------------------------------

  Baloon Shooter v1.0  for  mIRC 6.02 or  higher.
  Copyright (c)  1996-2002  invaluable.  corp. =)
  Please,  use as you like,  just give me credit!

  eof