My!Whois v.1.00
--------------------------------------------------------------------

This is a little addon for your mIRC Client, you can search for 
the owner of a domain. You can select from about 40 TLDs and you'll
find what you want.

The Installation:
- - - - - - - - -
Simply put all files from the archive to your mIRC home folder (e.g.: C:\mIRC) 
and use '/load -rs mywhois.mrc' to load it (wihout the ').


How to use:
- - - - - -
It's very easy. You only have to use /mywhois and a dialog will open.


I'll hope you have fun with this script.
commx.