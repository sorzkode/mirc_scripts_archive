mIRC Web Server

Introduction
------------
Eww a web server scripted in mIRC? That's stupid... Why don't I just stick with Apache?
Well, here's why: MWS includes the concept of MHTML.  With MHTML, you can use mirc
scripting inside your HTML documents.  Take a look at index.mhtml in the mws folder to
see what I mean.  But this file only shows integrating mirc scripts.  You can also
create aliases that will only be able to be called within your MHTML documents.  These
are done simply by typing:

<!--mircalias foo
  inc %i
  print Bar %i
-->

You can then call this alias whenever you want in mirc scripts or other aliases like this:
<!--mirc
  call foo
-->

Installation
------------
If you haven't already, unzip to your *mIRC* directory. (MUST be mIRC).
MWS will be the folder where you should put your files you want to be displayed on your
web server.
Then type:
/load -rs mws.mrc
To start the server, type:
/mws 80
80 is the port number.  So if you want it to be on say port 12094, you'd type:
/mws 12094
If you did that, people would have to include the port number in your address, for example:
http://127.0.0.1:12094/

If everything works, when you access http://localhost/ you should see the default index.mhtml

MHTML Help
----------
As it is in this version, there are four special blocks of code you can create.  Each block
has to be on it's OWN line.

Bad example:
Uptime: <!--mirc
  print $uptime(system,1)
--><br>

Good example:
Uptime:
<!--mirc
  print $uptime(system,1)
-->
<br>

The <!--mircalias block simply creates a temporary mirc alias you can call from your mhtml
mirc scripts.  An example of this is available in the introduction.

In this version of MWS, you can use basic CGI values, using $isset and $getform.  Say for
instance a user accessed http://yourip/test.mhtml?hello&value=1
and you had the following MHTML file:
<!--mirc
  if ($isset(value)) print Value: $+($getform(value),<br>)
  if ($isset(bob)) print Bob: $+($getform(bob),<br>)
  if ($isset(hello)) print Hello, $+($getform(hello),!<br>)
-->
The output would be:
Value: 1
Hello, !

The last special block is <!--include filename-->.  "filename" will be evaluated as an 
mirc string, then that filename will be parsed for the client to see.  The file will be
parsed as an MHTML file.  Any aliases you created in the main file will be available in
the included file, and any aliases created in the included file will be available in the
main file.

If you want to include a file without it being parsed as an MHTML file, use
<!--includeraw filename-->.

A limit of 100 files can be included recursively.

A log of all page requests can be found in mws_log.txt

Devlopment
----------
I created this in Microsoft Visual C++ .NET, so if you're using MSVC6, you'll have to create
your own project.  In order to build mws.dll using the MSVC.NET solution included, you will
need to modify the path of newbuild in the Pre-Build and Post-Build project options.  The
purpose of newbuild is two automatically generate a DEF file from mws_funcs.txt and to
automatically update the Build number for version info.

Vulnerabilities
---------------
This server has a crude sort of safety against attacks.  It will allow only 20 page requests
in one minute.  If more than 20 pages have been requested, a message will appear to the user
trying to access the website.

------------------------------
FAQ - (I can only think of one question so far)
Q: Why is it that when somebody goes to one of my webpages, the Pages Served mark goes up by
more than one?
A: You probably have pictures on your webpage.  A request for a picture counts as a page
served.
------------------------------

Contact
-------
MHTML was realized by rkzad (rkzad@hotmail.com)
I don't want to limit this by being hiding the source from everybody, so it's open source.
I figure this way people can learn more and adjust it to their needs.  But please at least
give me some credit for the base of it. You may as well give me something ;)

I have greatly improved the source code since first mention of MWS, but it does have a lot of
things to be done, still.  Here are some things that should be added:

A settings dialog:
  Anti-spam: modify the number of connections as specified (connections/[minute/hour/day])
  Banned IPs/Allowed IPs
Access to headers sent by client
Username/Password protected websites (via headers)