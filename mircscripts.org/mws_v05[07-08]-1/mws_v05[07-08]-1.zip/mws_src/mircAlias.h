#pragma once

#include "mwsFileBase.h"

class mircAliases : public mwsFileBase
{
private:
    class mhtmlParse *pParse;
    TCHAR szDestination[128];
    bool bInAlias;

    // You shouldn't use these outside of the class
    virtual void Close() { mwsFileBase::Close(); };
    virtual void Reopen() { mwsFileBase::Reopen(); };

public:
    mircAliases();
    virtual ~mircAliases();

    virtual void New(mhtmlParse *pParse);
    virtual void NewAlias(LPCSTR szName);
    virtual void EndAlias();
};