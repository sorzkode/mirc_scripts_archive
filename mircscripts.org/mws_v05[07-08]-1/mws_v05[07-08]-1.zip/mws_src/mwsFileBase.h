#pragma once

#include <windows.h>

class mwsFileBase
{
protected:
    HANDLE hFile;
    TCHAR szFilename[128];

public:
    mwsFileBase() : hFile(INVALID_HANDLE_VALUE) { szFilename[0] = 0; };
    virtual ~mwsFileBase() { Close(); };

    inline int operator!() const { return (hFile == INVALID_HANDLE_VALUE); };
    operator void *() const { return (hFile != INVALID_HANDLE_VALUE ? (void*)this : 0); };

    virtual void Close() { if (hFile != INVALID_HANDLE_VALUE) { CloseHandle(hFile); hFile = INVALID_HANDLE_VALUE; } };
    virtual void Reopen() { if (hFile == INVALID_HANDLE_VALUE) { hFile = AppendExistingFile(szFilename); }
                            if (hFile == INVALID_HANDLE_VALUE) { New(); } };
    virtual void New() { if (hFile == INVALID_HANDLE_VALUE) { hFile = WriteNewFile(szFilename); } };

    mwsFileBase& mwsFileBase::operator << (LPCSTR szText)
    {
        if (hFile != INVALID_HANDLE_VALUE)
        {
            DWORD dwWritten;
            WriteFile(hFile, szText, lstrlen(szText), &dwWritten, NULL);
        }
        return *this;
    }

    inline LPCSTR GetFilename() const { return szFilename; };
    inline HANDLE GetHandle() const { return hFile; };
};
