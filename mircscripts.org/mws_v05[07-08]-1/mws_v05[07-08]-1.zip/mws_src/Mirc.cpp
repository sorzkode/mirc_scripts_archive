/* mIRC General Utilities
 * Copyright (c) 2002 rkzad
 *
 * mirc.cpp - Implementation for the mIRC Class.
 */

#include <windows.h>
#include <stdarg.h>
#include <stdio.h>
#include "Mirc.h"

CMirc::CMirc(HWND hWnd)
{
    m_hFileMap = CreateFileMapping(INVALID_HANDLE_VALUE, 0, PAGE_READWRITE, 0, 1024, "mIRC");
    m_lpstrData = (LPSTR)MapViewOfFile(m_hFileMap, FILE_MAP_ALL_ACCESS, 0, 0, 0);
    this->m_hWnd = hWnd;
}

CMirc::~CMirc()
{
    UnmapViewOfFile(m_lpstrData);
    CloseHandle(m_hFileMap);
}

void CMirc::Send(const char *fmt, ...)
{
    char buffer[512];
    va_list(args);

    va_start(args, fmt);
    _vsnprintf(buffer, 512, fmt, args);
    va_end(args);

    strncpy(m_lpstrData, buffer, 512);
    SendMessage(m_hWnd, WM_MCOMMAND, 0, 0L);
}

const char* CMirc::Evaluate(const char *fmt, ...)
{
    char buffer[512];
    va_list(args);

    va_start(args, fmt);
    _vsnprintf(buffer, 512, fmt, args);
    va_end(args);

    strncpy(m_lpstrData, buffer, 512);
    SendMessage(m_hWnd, WM_MEVALUATE, 0, 0L);
    return m_lpstrData;
}

HWND CMirc::GetWnd()
{
    return m_hWnd;
}
