#include <windows.h>
#include "FileUtils.h"
#include "mircAlias.h"
#include "mircScript.h"
#include "Mirc.h"

extern CMirc *pMirc;

mircScript::mircScript(mhtmlParse *pParse)
: mwsFileBase(), pParse(pParse)
{
    lstrcpy(szDestination, pParse->GetFilename());
    wsprintf(szFilename, "%smwstemp\\script%d.mrc", pMirc->Evaluate("$mircdir"), pParse->GetID());
}

mircScript::~mircScript()
{
    Close();
}

// Called when mIRC Script created
void mircScript::New()
{
    TCHAR szLine[128];

    if (hFile == INVALID_HANDLE_VALUE && (hFile = WriteNewFile(szFilename)))
    {
        // Write special MWS aliases
        *this << "alias -l print { write \"" << szDestination << "\" $1- }\r\n";
        wsprintf(szLine, "alias -l call { var %%a = mwsa%d $+ $1 | if ($isalias(%%a)) %%a $2- }\r\n", pParse->GetID());
        *this << szLine;
        wsprintf(szLine, "alias -l getform { return $readini($mircdirmwstemp\\%dcgi.dat,_,$1) }\r\n", pParse->GetID());
        *this << szLine;
        wsprintf(szLine, "alias -l isset { return $ini($mircdirmwstemp\\%dcgi.dat,_,$1) }\r\n", pParse->GetID());
        *this << szLine;
        *this << "alias -l clsock { return " << pParse->GetSockname() << " }\r\n";
        wsprintf(szLine, "alias mws_script%d {\r\n", pParse->GetID());
        *this << szLine;
    }
}

// Close file, close temp output for parsing (script might write to it),
// Load the script, run the script, unload the script, reopen the file for parsing,
// Delete the script
void mircScript::Execute()
{
    if (hFile != INVALID_HANDLE_VALUE)
    {
        *this << "}";
        CloseHandle(hFile);

        pParse->Close();
        pMirc->Send("/!.load -rs \"%s\"", szFilename);
        pMirc->Send("/mws_script%d", pParse->GetID());
        pMirc->Send("/!.unload -rs \"%s\"", szFilename);
        pParse->Reopen();

        DeleteFile(szFilename);

        hFile = INVALID_HANDLE_VALUE;
    }
}