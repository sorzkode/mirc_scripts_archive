#include <windows.h>
#include "FileUtils.h"
#include "mircAlias.h"
#include "mhtmlParse.h"
#include "Mirc.h"

extern CMirc *pMirc;

mircAliases::mircAliases()
: mwsFileBase(), bInAlias(false), pParse(NULL)
{

}

mircAliases::~mircAliases()
{
    // Make sure that the file is unloaded and deleted after we got rid of this class
    if (hFile || FileExists(szFilename))
    {
        Close();
        pMirc->Send("/!.unload -rs \"%s\"", szFilename);
        DeleteFile(szFilename);
    }
}

void mircAliases::New(mhtmlParse *pParse)
{
    TCHAR szLine[128];

    this->pParse = pParse;
    lstrcpy(szDestination, pParse->GetFilename());
    wsprintf(szFilename, "%smwstemp\\aliases%d.mrc", pMirc->Evaluate("$mircdir"), pParse->GetID());

    // Create aliases file to be used throughout all the parsing in this parse ID
    if (hFile == INVALID_HANDLE_VALUE && (hFile = WriteNewFile(szFilename)) != INVALID_HANDLE_VALUE)
    {
        // Set up special MWS aliases
        *this << "alias -l print { write \"" << szDestination << "\" $1- }\r\n";
        wsprintf(szLine, "alias -l call { var %%a = mwsa%d $+ $1 | if ($isalias(%%a)) %%a $2- }\r\n", pParse->GetID());
        *this << szLine;
        wsprintf(szLine, "alias -l getform { return $readini($mircdirmwstemp\\%dcgi.dat,_,$1) }\r\n", pParse->GetID());
        *this << szLine;
        wsprintf(szLine, "alias -l isset { return $ini($mircdirmwstemp\\%dcgi.dat,_,$1) }\r\n", pParse->GetID());
        *this << szLine;
        *this << "alias -l clsock { return " << pParse->GetSockname() << " }\r\n";
    }
}

// Create a new alias definition in the file, ending the previous one if it wasn't finished
void mircAliases::NewAlias(LPCSTR szName)
{
    TCHAR szLine[128];
    if (bInAlias)
        EndAlias();
    Reopen();
    bInAlias = true;
    wsprintf(szLine, "alias mwsa%d%s {\r\n", pParse->GetID(), szName);
    *this << szLine;
}

// Simply add a } to end the alias, close the file, and reload the script
void mircAliases::EndAlias()
{
    if (bInAlias)
    {
        *this << "}\r\n";
        bInAlias = false;
    }
    Close();
    pMirc->Send("/!.reload -rs \"%s\"", szFilename);
}