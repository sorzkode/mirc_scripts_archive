#pragma once

#include "mwsFileBase.h"
#include "mhtmlParse.h"

class mircScript : public mwsFileBase
{
private:
    mhtmlParse *pParse;
    TCHAR szDestination[128];

public:
    mircScript(mhtmlParse *pParse);
    virtual ~mircScript();

    virtual void New();
    virtual void Reopen() { };
    void Execute();
};