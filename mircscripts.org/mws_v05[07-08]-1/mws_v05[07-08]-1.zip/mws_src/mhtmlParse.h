#pragma once

#include "mircAlias.h"

class mhtmlParse : public mwsFileBase
{
private:
    int iParseId;
    int iRecursion;
    mircAliases ma;
    TCHAR szSockname[64];

public:
    mhtmlParse(LPCSTR szFilename, LPCSTR szSockname);
    virtual ~mhtmlParse();

    virtual void New() { };
    void Parse(LPCSTR szFilename);

    inline int GetID() const { return iParseId; };
    inline LPCSTR GetSockname() const { return szSockname; };
};