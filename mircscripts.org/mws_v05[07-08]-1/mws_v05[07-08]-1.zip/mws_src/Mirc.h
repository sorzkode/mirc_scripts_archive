/* mIRC General Utilities by rkzad
 * 
 * mirc.h - Definition for the mIRC Class and other assorted mIRC bits.
 */

#pragma once

// Use this macro to declare functions to be called from mIRC, apart from LoadDll and UnloadDll
// so for instance to be able to do //echo -a $dll(my.dll,hello,world)
// you would type:
// MIRCFUNC(hello)
// {
//     int length = lstrlen(lpstrData) - 1;
//     for (int i = 0; i <= length; i++)
//     {
//         int temp = lpstrData[i];
//         lpstrData[i] = lpstrData[length-i];
//         lpstrData[length-i] = temp;
//     }
//     return 3;
// }
#define MIRCFUNC(procname)  int __stdcall procname(HWND hwndMirc, HWND hwndActive, LPSTR lpstrData, LPSTR lpstrParms, BOOL bShow, BOOL bNoPause)

// These are defined outside of CMirc in case you do not want to take advantage of that class
// These messages are used for SendMessage.  WM_MCOMMAND for CMirc::Send.
// WM_MEVALUATE for CMirc::Evaluate
#define WM_MCOMMAND         (WM_USER + 200)
#define WM_MEVALUATE        (WM_USER + 201)

// This is the structure that is sent in LoadDll.  By this, you can only use it as a pointer,
// which is all you need.  Example of LoadDll:
//
// CMirc *pMirc;
// void __stdcall LoadDll(PLOADINFO pLoadInfo)
// {
//     pMirc = new CMirc(pLoadInfo->m_hWnd);
// }
typedef struct
{
    DWORD m_dwVersion;
    HWND m_hWnd;
    BOOL m_bKeep;
} *PLOADINFO;

// Useful CMirc class that let's you use WM_MCOMMAND and WM_MEVALUATE which is similar
// to printf
class CMirc
{
private:
    HANDLE m_hFileMap;
    LPSTR m_lpstrData;
    HWND m_hWnd;

public:
    CMirc(HWND Wnd);
    ~CMirc();
    void Send(const char *fmt, ...);
    const char *Evaluate(const char *fmt, ...);
    HWND GetWnd();
};