#include <windows.h>
#include "FileUtils.h"

// This function is actually a string utility, but oh well
// It finds all cases of '%' in the string and adds another '%' beside it.
LPCSTR FixForPrintf(LPSTR lpstrDest, LPCSTR lpcstrText)
{
    int offset = 0;
    for (int i = 0; i <= lstrlen(lpcstrText); i++)
    {
        if (lpcstrText[i] == '%')
            lpstrDest[i+offset++] = '%';
        lpstrDest[i+offset] = lpcstrText[i];
    }
    return lpstrDest;
}

// This function copies lpcstrFile to lpstrDest, takes out the path and
// cgi values out of lpstrDest, and returns it.
LPCSTR GetFilename(LPSTR lpstrDest, LPCSTR lpcstrFile)
{
    unsigned int i(lstrlen(lpcstrFile));
    unsigned int question = 0;
    strcpy(lpstrDest, lpcstrFile);
    for (; i >= 0 && lpcstrFile[i] != '\\'; i--)
        if (lpcstrFile[i] == '?')
            question = i;
    strcpy(lpstrDest, lpcstrFile + i + 1);
    if (question)
        lpstrDest[question - i - 1] = 0;
    return lpstrDest;
}

// When converting special characters in CGI to their real values, we must
// first convert a 2-digit hexadecimal number in a string to a real integer
// So we use a look-up table to figure out the numeric value of a character
char hex2dec[256] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 0, 0, 0, 0, 0,         // 0, 1, 2, 3, 4, 5, 6, 7, 8, 9
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 10, 11, 12, 13, 14, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0,   // A, B, C, D, E, F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 10, 11, 12, 13, 14, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0,   // a, b, c, d, e, f
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};
// Fixes all the special CGI characters (+, %hexadecimal)
void FixCGI(LPSTR lpstrFile)
{
    unsigned int i = 0;
    int amperstep = 0;          // This has nothing to do with &, but yeah
    int specials = 0;
    char chr = 0;

    for (; i < (unsigned int)lstrlen(lpstrFile); i++)
    {
        if (amperstep)                          // Convert hexadecimal character into number
        {
            chr = chr * 16 + hex2dec[lpstrFile[i]];
            if (++amperstep >= 3)
            {
                amperstep = 0;
                lpstrFile[i - (++specials)*2] = chr;
                chr = 0;
            }
        }
        else if (lpstrFile[i] == '%')           // Expect two hexadecimal characters next
            amperstep = 1;
        else if (lpstrFile[i] == '+')           // Replace '+' with spaces
            lpstrFile[i - specials*2] = ' ';
        else if (specials)
            lpstrFile[i - specials*2] = lpstrFile[i];
    }
    lpstrFile[i - specials*2] = 0;
}

// Hides CGI values from lpstrFile, and returns them
LPSTR TakeCGI(LPSTR lpstrFile)
{
    unsigned int i(lstrlen(lpstrFile));
    for (; i >= 0 && lpstrFile[i] != '\\' && lpstrFile[i] != '?'; i--);
    if (lpstrFile[i] == '?')
    {
        lpstrFile[i] = 0;
        if (lpstrFile[i+1])
            return lpstrFile + i + 1;
    }
    return 0;
}

// Puts path of lpcstrFile into lpstrDest and returns it
LPCSTR GetPath(LPSTR lpstrDest, LPCSTR lpcstrFile)
{
    unsigned int i(lstrlen(lpcstrFile));
    strcpy(lpstrDest, lpcstrFile);
    for (i = lstrlen(lpstrDest) - 1; i >= 0 && lpstrDest[i] != '\\'; i--);
    lpstrDest[i] = 0;

    return lpstrDest;
}

// Get a line from hFile into lpstrDest, returning FALSE if we didn't read anything
// If read a whole line, take out '\r\n'
BOOL GetLine(HANDLE hFile, LPSTR lpstrDest)
{
    DWORD dwRead = -1;
    int iTotal = 0;

    while (dwRead)
    {
        ReadFile(hFile, lpstrDest + iTotal, 1, &dwRead, NULL);
        iTotal += (int)dwRead;
        if (iTotal > 1 && !strncmp(lpstrDest + iTotal - 2, "\r\n", 2))
        {
            lpstrDest[iTotal - 2] = 0;
            return TRUE;
        }
    }

    if (iTotal)
    {
        lpstrDest[iTotal] = 0;
        return TRUE;
    }
    return FALSE;
}

HANDLE ReadExistingFile(LPCSTR lpcstrFile)
{
    return CreateFile(lpcstrFile,
                      GENERIC_READ,
                      0,
                      NULL,
                      OPEN_EXISTING,
                      FILE_ATTRIBUTE_NORMAL,
                      NULL);
}

HANDLE WriteNewFile(LPCSTR lpcstrFile)
{
    return CreateFile(lpcstrFile,
                      GENERIC_WRITE,
                      0,
                      NULL,
                      CREATE_ALWAYS,
                      FILE_ATTRIBUTE_NORMAL,
                      NULL);
}

// Open file. If successful, set file pointer to end.
HANDLE AppendExistingFile(LPCSTR lpcstrFile)
{
    HANDLE hFile = CreateFile(lpcstrFile,
                              GENERIC_WRITE,
                              0,
                              NULL,
                              OPEN_ALWAYS,
                              FILE_ATTRIBUTE_NORMAL,
                              NULL);

    if (hFile != INVALID_HANDLE_VALUE)
        SetFilePointer(hFile, 0, 0, FILE_END);

    return hFile;
}

// If can't open file, file doesn't exist (or is already open, heh)
BOOL FileExists(LPCSTR lpcstrFile)
{
    HANDLE hFile = ReadExistingFile(lpcstrFile);

    if (hFile != INVALID_HANDLE_VALUE)
    {
        CloseHandle(hFile);
        return TRUE;
    }

    return FALSE;
}