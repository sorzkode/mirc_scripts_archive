#pragma once

#include "mwsFileBase.h"
#include "mhtmlParse.h"

extern CMirc *pMirc;

class mwsTempOutFile : public mwsFileBase
{
protected:
    mhtmlParse *pParse;

public:
    mwsTempOutFile(const char *szFilename, mhtmlParse *pParse) : pParse(pParse)
    {
        wsprintf(this->szFilename, "%smwstemp\\%d%s", pMirc->Evaluate("$mircdir"), pParse->GetID(), szFilename);
        New();
    }
    virtual ~mwsTempOutFile() { Close(); DeleteFile(szFilename); };
};