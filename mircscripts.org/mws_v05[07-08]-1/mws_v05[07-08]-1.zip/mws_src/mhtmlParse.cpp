#include <windows.h>
#include "FileUtils.h"
#include "mircAlias.h"
#include "mircScript.h"
#include "mwsError.h"
#include "Mirc.h"

extern CMirc *pMirc;

// Easier way to tell what we're parsing right now.
enum mhtmlParsingType
{
    PARSING_HTML = 0,
    PARSING_SCRIPT,
    PARSING_ALIAS
};

mhtmlParse::mhtmlParse(LPCSTR szFile, LPCSTR szSockname)
: mwsFileBase(), iRecursion(0), iParseId(rand()%900000 + 10000)
{                                        // The odds of having the same parse id at the same time are pretty much impossible
    lstrcpy(this->szSockname, szSockname);
    // Example of szFilename if parsing index.mhtml: C:\mirc\mwstemp\index.mhtml892174.dat
    wsprintf(szFilename, "%smwstemp\\%s%d.dat", pMirc->Evaluate("$mircdir"), szFile, iParseId);
    hFile = WriteNewFile(szFilename);
    ma.New(this);   // Keep one aliases file for EVERY file parsed (even from included files)
}

mhtmlParse::~mhtmlParse()
{
    Close();                        // when mhtmlParse is out of scope (or deleted), close the file
}

void mhtmlParse::Parse(LPCSTR szInFile)
{                                   // Introducing the only comments:
    HANDLE hInFile;                 // Handle to file
    TCHAR szPath[128];              // Path of file in local directory
    TCHAR szLine[8192];             // Files parsed by line. Reason: easier for me
    mhtmlParsingType typeParse = PARSING_HTML;
    mircScript ms(this);

    // Do not include over 100 files
    if (iRecursion+1 >= 100)
        throw mwsError(MWS_RECURSION, "Include recursion limit reached");
    
    GetPath(szPath, szInFile);

    hInFile = ReadExistingFile(szInFile);
    if (hInFile == INVALID_HANDLE_VALUE)
        throw mwsError(MWS_404, "Could not locate page");

    ++iRecursion;

    // Read lines until end of file
    while (GetLine(hInFile, szLine))
    {
        TCHAR szTemp[128];
        switch (typeParse)
        {
        case PARSING_HTML:
            if (!stricmp(szLine, "<!--mirc"))
            {
                ms.New();                       // Create new mirc script file
                typeParse = PARSING_SCRIPT;
            }
            else if (!strnicmp(szLine, "<!--mircalias ", 13) && strlen(szLine) > 13)
            {
                ma.NewAlias(szLine + 14);       // Create new mirc alias in our alias file
                typeParse = PARSING_ALIAS;
            }
            else if (!strnicmp(szLine, "<!--include ", 11) && !strcmp(szLine + lstrlen(szLine) - 3, "-->"))
            {
                // Evaluate file to be evaluated, and include it, attempting for MHTML
                TCHAR szFileInc[128];
                DWORD dwLastPlace = SetFilePointer(hInFile, 0, NULL, FILE_CURRENT);
                szLine[lstrlen(szLine) - 3] = 0;
                wsprintf(szFileInc, "%s\\%s", szPath, FixForPrintf(szTemp, pMirc->Evaluate(FixForPrintf(szTemp, szLine + 12))));
                CloseHandle(hInFile);
                try
                {
                    Parse(szFileInc);
                }
                catch (...)
                {
                    // Catch error silently
                }
                hInFile = ReadExistingFile(szInFile);
                SetFilePointer(hInFile, dwLastPlace, 0, FILE_BEGIN);
            }
            else if (!strnicmp(szLine, "<!--includeraw ", 14) && !strcmp(szLine + lstrlen(szLine) - 3, "-->"))
            {
                // Evaluate filename, and include without parsing it.
                TCHAR szFileInc[128];
                DWORD dwLastPlace = SetFilePointer(hInFile, 0, NULL, FILE_CURRENT);
                szLine[lstrlen(szLine) - 3] = 0;
                wsprintf(szFileInc, "%s\\%s", szPath, FixForPrintf(szTemp, pMirc->Evaluate(FixForPrintf(szTemp, szLine + 15))));
                CloseHandle(hInFile);
                hInFile = ReadExistingFile(szFileInc);
                if (hFile != INVALID_HANDLE_VALUE)
                {
                    DWORD dwRead;
                    TCHAR szBuffer[1024];
                    do
                    {
                        ReadFile(hInFile, szBuffer, 1024, &dwRead, NULL);
                        if (dwRead)
                        {
                            szBuffer[dwRead] = 0;
                            *this << szBuffer;
                        }
                    } while (dwRead);
                    CloseHandle(hInFile);
                }
                hInFile = ReadExistingFile(szInFile);
                SetFilePointer(hInFile, dwLastPlace, 0, FILE_BEGIN);
            }
            else
            {
                *this << szLine << "\r\n";
            }

            break;

        case PARSING_SCRIPT:
            if (!stricmp(szLine, "-->"))
            {
                ms.Execute();                   // Load script, run script, unload script, delete script
                typeParse = PARSING_HTML;
            }
            else
            {
                ms << szLine << "\r\n";
            }

            break;

        case PARSING_ALIAS:
            if (!stricmp(szLine, "-->"))
            {
                ma.EndAlias();                  // End alias definition.
                typeParse = PARSING_HTML;
            }
            else
            {
                ma << szLine << "\r\n";
            }
        }
    }

    --iRecursion;

    CloseHandle(hInFile);
}