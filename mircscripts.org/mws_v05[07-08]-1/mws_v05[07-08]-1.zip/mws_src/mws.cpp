/* mIRC Web Server by rkzad
 * mws.cpp - Exported DLL Functions
 */
#include <windows.h>
#include <stdlib.h>
#include <time.h>
#include "Mirc.h"
#include "FileUtils.h"
#include "mircAlias.h"
#include "mircScript.h"
#include "mwsError.h"
#include "mws_version.h"
#include "mwsTempOutFile.h"

CMirc *pMirc = NULL;

// Called when DLL is loaded
void __stdcall LoadDll(PLOADINFO pLoadInfo)
{
    pMirc = new CMirc(pLoadInfo->m_hWnd);

    // Seed now for random parse IDs
    srand((unsigned int)time(NULL));
}

// When DLL is unloaded
int __stdcall UnloadDll(int iTimeout)
{
    if (!iTimeout)      // If hadn't timed out, delete our CMirc class cleanly
        delete pMirc;

    return 0;
}

// Called by MWS when an MHTML file needs to be parsed
MIRCFUNC(ParseFile)
{
    TCHAR szFilename[128];
    TCHAR* pFilePtr = lpstrData;

    while (*pFilePtr && *pFilePtr++ != ' ');
    
    if (!*pFilePtr)
        return 3;

    *(pFilePtr-1) = 0;

    GetFilename(szFilename, pFilePtr);
    // If you're confused, lpstrData will now be a string representing the name of the socket
    // in mIRC
    // pFilePtr is the full path of the file (including the CGI values)
    // szFilename is the filename without the CGI values
    

    // Make sure the script did not make a goof, and that it is an MHTML File
    if (!stricmp(szFilename + strlen(szFilename) - 6, ".mhtml"))
    {
        // Create the parser, and send the filename to create a temp file
        TCHAR* pStart = TakeCGI(pFilePtr);          // Put the CGI values in pStart, and take them out of pFilePtr
        mhtmlParse Parse(szFilename, lpstrData);    // Create a temporary output file that mIRC will output to the client later
        mwsTempOutFile cgiFile("cgi.dat", &Parse);  // Create a temporary file that will hold the CGI values in an INI format

        cgiFile << "[_]\r\n";                       // Topic in INI file
        if (pStart && *pStart)
        {
            TCHAR *pPtr = pStart;
            bool bSearchEquals = true;
            while (*pPtr++)
            {
                if (bSearchEquals && (!*pPtr || *pPtr == '='))
                {
                    char chr = *pPtr;
                    *pPtr = 0;
                    FixCGI(pStart);
                    cgiFile << pStart << "=";
                    if (chr)
                        *pPtr++;
                    pStart = pPtr;
                    bSearchEquals = !bSearchEquals;
                }
                else if (!bSearchEquals && (!*pPtr || *pPtr == '&'))
                {
                    char chr = *pPtr;
                    *pPtr = 0;
                    FixCGI(pStart);
                    cgiFile << pStart << "\r\n";
                    if (chr)
                        *pPtr++;
                    pStart = pPtr;
                    bSearchEquals = !bSearchEquals;
                }
            }
        }

        cgiFile.Close();

        // If a destination file was created successfully
        if (Parse)
        {
            try
            {
                // Attempt to parse the MHTML file
                Parse.Parse(pFilePtr);
            }
            catch (mwsError error)
            {
                // If an error was caught from the main mhtml file, display it
                Parse << "<html><head><title>Error</title></head><body><h2>Error</h2>";
                Parse << error.GetInfo();
                Parse << "</body></html>";
            }

            // Return the filename that mirc should send to the client socket
            lstrcpy(lpstrData, Parse.GetFilename());
        }
    }
    return 3;
}

// Send version automatically created by newbuild
MIRCFUNC(Version)
{
    GetCurrentBuildInfo(lpstrData);

    return 3;
}