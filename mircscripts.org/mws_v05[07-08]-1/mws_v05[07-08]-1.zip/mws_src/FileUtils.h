#pragma once

LPCSTR FixForPrintf(LPSTR lpstrDest, LPCSTR lpcstrText);
LPCSTR GetFilename(LPSTR lpstrDest, LPCSTR lpcstrFile);
void FixCGI(LPSTR lpstrFile);
LPSTR TakeCGI(LPSTR szFile);
LPCSTR GetPath(LPSTR szDest, LPCSTR szFile);
BOOL GetLine(HANDLE hFile, LPSTR lpstrDest);
HANDLE ReadExistingFile(LPCSTR lpcstrFile);
HANDLE WriteNewFile(LPCSTR lpcstrFile);
HANDLE AppendExistingFile(LPCSTR lpcstrFile);
BOOL FileExists(LPCSTR lpcstrFile);