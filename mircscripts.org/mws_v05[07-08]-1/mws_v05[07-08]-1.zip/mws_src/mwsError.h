#pragma once

#include <string.h>

enum mwsErrorType
{
    MWS_NONE = 0,
    MWS_404,
    MWS_RECURSION
};

class mwsError
{
private:
    mwsErrorType errorType;
    LPSTR szInfo;

public:
    mwsError(mwsErrorType errorType) : errorType(errorType) { };
    mwsError(mwsErrorType, LPCSTR szInfo) : errorType(errorType)
    {
        this->szInfo = new char[strlen(szInfo)+1];
        strcpy(this->szInfo, szInfo);
    }
    mwsError(const mwsError& error)
    {
        errorType = error.GetType();
        szInfo = new char[strlen(error.GetInfo()) + 1];
        strcpy(szInfo, error.GetInfo());
    }
    ~mwsError()
    {
        if (szInfo)
            delete []szInfo;
    }

    inline mwsErrorType GetType() const { return errorType; };
    inline const char* GetInfo() const { return szInfo; };
};