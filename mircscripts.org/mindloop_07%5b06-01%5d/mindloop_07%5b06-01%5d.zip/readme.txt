�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�
�        MindLoop 0.7 - A chatterbot scripted in mIRC         �
�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�
�              by b00stA (b00stA@goe-clan.net)                �
�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�`�

 1) Requirements

 2) How to load

 3) Functions
   3.1) Introduction
   3.2) Main dialog control
   3.3) Public commands

 4) Version history

 5) Misc/Hints

 6) Thanks/Greetings



>>>>> >>>> >>> >> 1> REQUIREMENTS

  - mIRC 6.03
     It *could* work with older versions of mIRC. To be sure
     just use v6.03!



>>>>> >>>> >>> >> 2> HOW TO LOAD

  1> Extract all the files to a new&empty folder
  2> Put a mirc.exe (version 6.03) into this folder
  3> Start mirc.exe
  4> Press F1 to view/change the options

     For example extract the files to "c:\mindloop\"
     then you just take a mirc.exe from your regular script
     and place it in "c:\mindloop\".

  5> This copy of MindLoop has already a brain installed.
     It has about 1500 lines and it will find replies
     to many english/german sentences.
     You may delete the current brain and start a new one
     by deleting the file "brain\lines.txt".



>>>>> >>>> >>> >> 3> FUNCTIONS

>>> >> 3.1> INTRODUCTION

  MindLoop creates 'his' sentences dynamically due to his 'brain'.
  Brain? - Yes. The file 'brain\lines.txt' is his brain.
  He uses the sentences in it for generating other NEW sentences.
  You're able to 'teach' him new sentences and after a while
  you'll notice he's using words/expressions you just said.
  Due to this 'system' he's well able to learn almost every language.
  Actually I only tested german and english. German is a bit
  difficult because of the grammar but you'll get good results
  tricking some newbies! English is the best language for him
  because it's some kind of 'easy' (for his system) to use.

  There are three main 'cores' (don't know how to call it):
   - Reply:   System for reacting on text said by users
   - Learn:   System for learning new lines as they're said
                (instantly, no checking for spam..)
   - Sniffer: Records the lines said, you have to choose which
                line is good and which one will be deleted



>>> >> 3.2> MAIN DIALOG CONTROL

  Press F1 to open the main dialog and the tab 'Main':

   - Master password:
      MindLoop will authorise you as an admin when
      you message this password to MindLoop.
      Being an admin you are able to use ALL of the public
      commands. Please be careful telling others this password.

   - Readme:
      Opens *this* file

   - Reply log:
      Opens replog.txt
      In this files all triggers (user-side) and replies (MindLoop)
      are saved.

   - Quotes:
      Opens quotes.txt
      In this file all quotes added by !quote are saved

   - Show splash screen:
      If checked, a splash screen is showed everytime you press F1


  Press F2 to open the main dialog and the tab 'Reply / Learn':

   - Reply:
      If checked, replies to the messages said in the channels
      specified in the textbox next to the checkbox.
      Different channels are seperated by commas: #blah1,#blah2,...
      Setting the replyrate on 100% will cause MindLoop
      reply to everything in the specified chans.
      15% is a good setting when others want to talk IMHO.

      If "On Join" is checked MindLoop creates a sentence
      containing the nick of the joining user. If he's unable
      to create one, he uses the following masks:
      "'$nick was', '$nick should', '$nick will', '$nick would',
      '$nick has' and '$nick is'".
      You're able to change the language of these "additions" he's
      going to use by clicking on the button next to the checkbox.
      Following languages are available: German and English.
      If you want new languages to be added, send me a little list
      of combinations in your language. Thanks.

      Hint: MindLoop decreases the replyrate for this action by 33%
            of the original replyrate, otherwise it would be
            very annoying (it was, I know what I'm talking about @_#).

   - Learn:
      If checked, saves the said lines in the specified channels
      instantly, without checking for spam etc.

   - Listbox:
      Shows all lines/sentences known to MindLoop.
      To delete single lines, double-click on one.
      To delete multiple lines, select the ones you'd
      like to delete and click on 'Delete'.

      You can 'filter' and therefor search for particular
      words using the textbox with the 2 asterisks '**'.


  Press F3 to open the main dialog and the tab 'Sniffer':

    - If checked, the lines said in the specified channels
      will be logged, but NOT LEARNED.
      i.e. everytime someone says a line it's logged
      and you can choose whether to delete it or to teach it
      to MindLoop.
      To do this, select the lines you'd like to delete/teach
      and click on 'Learn' or 'Delete'.


  HINT: Don't use the learn function directly.
        Set the sniffer to all channels (*) and choose for yourself,
        so you can be sure he doesn't learn crap like MP3 player
        messages or the colours from 1337 away scripts >_<



>>> >> 3.3> PUBLIC COMMANDS

 [Optional Parameters] (Required parameters)

  !cmd                  Shows all public commands

  !brain                Shows some infos about MindLoops knowledge

  !version              Shows the version of MindLoop

  !replyrate 20         Changes the replyrate to 20%

  !reply [0|1]          Without parameters: Reply on/off (0/1)
                        With parameters: Changes the state to on/off (0/1)

  !reply.c [Chan(s)]    Without parameters: Shows the chans to reply to
                        With parameters: Changes the chans to reply to
                        Example: '!reply.c #blah1,#blah2' Now MindLoop will
                        reply only in these 2 chans

  !learn [0|1]          Same as '!reply' except it handles the "learning"

  !learn.c              Same as '!reply.c' except it handles the "learning"

  !sniffer              Same as '!reply' except it handles the "sniffing"

  !sniffer.c            Same as '!reply.c' except it handles the "sniffing"

  !quote [add|#n|*m*]   '!quote add This is funny' would add 'This is funny'
                           to the quotes
                        '!quote #2' would show the second quote
                        '!quote *Wildmark*' would show the first quote
                           matching the mask '*Wildmark*'
                        '!quote' would show a random quote

  !words [*m*]          '!words *m00*' would show how many references to
                           the mask '*m00*' are known to MindLoop
                        '!words' would show how many words&lines are known
                           to MindLoop

  !flush                Removes authorised users (Log-out)

  !mode (params)        '!mode -o nick' would deop 'nick'
                        '!mode +nt' would set the channel modes '+nt'

  !op [nick]            '!op' would op yourself
                        '!op nick' would op 'nick'

  !deop [nick]          Self-explanatory

  !voice [nick]             "

  !devoice [nick]           "

  !kick [nick] [reason] '!kick' would kick yourself
                        '!kick nick Bye!' would kick 'nick' with the
                           the reason 'Bye!'

  !kb (nick) [reason]   Kickbans 'nick' with optional reason

  !quit [message]       Disconnects MindLoop from the current server

  !exit [message]       Disconnects and closes MindLoop

  !server (server)      Changes server to 'server'

  !join (chan)          Joins 'chan'

  !part (chan)          Parts 'chan'

  !hop                  Rejoins (hops) the current chan

  !topic (text)         Changes the topic to 'text'

  !nick (newnick)       Changes the nick to 'newnick'



>>>>> >>>> >>> >> 4> VERSION HISTORY

   0.6 	          (14.4.03)
    - First public release

   0.0-0.9        (Unknown date)
    - No logs available



>>>>> >>>> >>> >> 5> MISC/HINTS

  - MindLoop will increase the replyrate by 33% when he
    receives a line containing his own nick. So you are
    able to some kind of point questions/sentences to him.

  - If you think your MindLoop has a decent brain, feel free
    to send it to me (compressed (ACE, ZIP, etc.)).
    Perhaps it'll be added to the newest version of MindLoop
    (with your credits of course!).
    'What is the brain?' - Just goto the MindLoop directory ->
    brain\lines.txt. Compress this file and send it to
    b00stA@goe-clan.net


>>>>> >>>> >>> >> 6> THANKS/GREETINGS

  - Moretom, for helping me with the 'engine' (Moretom.net)

  - Khaled Mardam-Bey, for creating mIRC (mIRC.co.uk)

  - Simon Laven, for all the infos provided on his page (SimonLaven.com)

  - all the users not getting that this is a bot

  - MindLoop, for all the funny sentences he made :)



<<>> <> End of readme - Last update: 08:59 22.02.2003 <> <<>>