 =====================================

  xMemoserv
  version 2
  Written by: xDaeMoN
  Email: xdaemon@xdaemon.us
  02.08.06
   
 =====================================


 --------------
  INTRODUCTION
 --------------

  A script for a bot that will save the message & notify the person addressed to retrieve it. 
  If the person is offline, they will be notified when they get back online. User needs to be 
  registered to be able to send & retrieve a message. I added a simple register system and you 
  could also change your password.

 ---------------
  REQUIREMENTS
 ---------------

  mIRC 6.16


 ----------------
  HOW TO INSTALL
 ----------------

  Unzip the xMemoserv.zip file to a folder on your hard drive.
  Open mIRC. 

  Then you can do:

  1.
  Go to the remotes editor (Alt +R) and select File -> Load -> Script. 
  Browse to the xmemoserv.mrc file that you extracted from the .zip.
  Press "Open." 
  Press "Yes" if asked to run setup routines.

   -OR-

  2.
  Type the command below in mIRC, change the 'PATH_TO' 

     /load -rs path_to/xmemoserv.mrc

  
 ------------
  HOW TO USE
 ------------
 
  For the Dialog, type '/xMemo2' in any window -OR- Right-Click on any window and select 'xMemoserv'.

  On the Settings Tab, you can select "xMemoserv" or the Network name.

     If you select 'xMemoserv', you can Enable or Disable the script itself.

     If you select a Network Name, you can Enable or Disable the script for that network & change the settings.

  On the Data Tab, you can select "All Servers" or the Network name.

     If you select "All Servers", you would be able to see ALL the queued messages for all the networks. 
     You can delete messages (One at a time) & Save all the messages by clicking "Save ALL".

     If you select a Network Name, you would only see all the queued messages for that network only & also
     delete the messages.

  On the Flood Tab, you can change the settings for the Query Flood Protection.

  ** Now for the remote commands:
 
  To register: /msg botname !register <password>
   
  To Login: /msg botname !login <password>

  To Logout: /msg botname !logout

  * To send message: /msg botname !send <nick> <message>

  * To retrieve message: /msg botname !read 

  * To change password: /msg botname !cpass <oldpassword> <newpassword>

  Note: 1. The trigger can be changed. '!' is the default. It can be changed in the dialog.
           2. <> means required.
    
   * These commands requires you to login before using them.
   


 ------------------
  HOW TO UNINSTALL
 ------------------

  Simply type in any window in mIRC:

   1. 
.       /unload -rs DIRECTORY/xmemoserv.mrc

  -OR-

  2 .
       Go to the Remotes Section (Alt-R) and click VIEW to select xmemoserv.mrc
       Then Click FILE -> UNLOAD
       Done, the script will be unloaded.

  -OR-

  3.
       Right-Click on any window & select 'xMemoserv' then click 'Unload'.

   and the script will be unloaded.

 ---------
  HISTORY
 ---------

 Version 1   

	03.07.05 - Finished version 1 

 Version 1.1 
	
	05.21.05 - Added user registration for security

 Version 1.2

	05.27.05 - Used Hash tables for storage

 Version 1.3

	10.22.05 - Added Delay on retrieving messages

 Version 1.4 

	01.24.06	- Added Menu to enable/disable script
		- Made trigger configurable		
		- Added 'removeme' & 'memohelp' command	 
  Version 2
  
	02.08.06	- Re-coded script
		- Added dialog for easier configuration
		- Added !login & !logout commands
		- The users on the notify list will now be deleted on unload if they were registered.
