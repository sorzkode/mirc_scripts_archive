typedef struct {
    DWORD  mVersion;
    HWND   mHwnd;
    BOOL   mKeep;
} LOADINFO;

struct psItem {
	DWORD id;
	char exe[MAX_PATH];
};



