Copyright (C) 2002-2005 HazliCyber Corp. Ltd. - Software Foundation.
All right reserved by MarHazK.
IRCSC.DLL STATIC LIBRARY.

--------------------------------------------------------------------

IRCSC.DLL is for a mIRC program used to control a service.
Service Control also known as SC. When its combains with IRC,
we named it IRCSC (Internet Relay Chat Service Control
Configuration). IRCSC.DLL is very useful to control a service
via mIRC software.

Supported Operation System:-
OS: Windows NT, 2000, XP, .NET (All version,including Servers,etc.)
Software: mIRC
RAM: 16MB of RAM or above.
Free SPACE: 500Kbs

IRCSC.DLL has many functions. There are 2 categories and
7 different types of function.

1st Category.
- 4 useful functions: stop, start, restart, version.
- You can use /ECHO command or $dll(file,command,parameters) event.
Syntax: //echo $dll(ircsc.dll,<function>,<service name>)

- Example:-
stop function:
Syntax: $dll(ircsc.dll,stop,<service name>)
Example: //echo $dll(ircsc.dll,stop,EventLog)
Result return: KILLED

start function:
Syntax: $dll(ircsc.dll,start,<service name>)
Example: //echo $dll(ircsc.dll,start,EventLog)
Result return: START_SUCCESS, START_FAILED

restart function
Syntax: $dll(ircsc.dll,restart,<service name>)
Example: //echo $dll(ircsc.dll,restart,EventLog)
Result return: RESTART_SUCCESS, RESTART_FAILED

Version function:
Syntax: $dll(ircsc.dll,version,0)
Example: //echo $dll(ircsc.dll,version,0)
Result return: IRCSC.DLL information...

2nd Category
- 5 useful commands: stopProc, startProc, restartProc
- Its send a DDE command via mIRC. (DLL to mIRC)
- Same with first category.
- You only can use /DLL command if you use this functions.
Syntax: /DLL ircsc.dll <function> <service Name>

stopProc Function:
Syntax: /DLL ircsc.dll stop <service name>
Example: /DLL ircsc.dll stop EventLog
DDE Command return: KILLED

startProc Function:
Syntax: /DLL ircsc.dll start <service name>
Example: /DLL ircsc.dll start EventLog
DDE Command return: START_SUCCESS, START_FAILED

restartProc Function:
Syntax: /DLL ircsc.dll restart <service name>
Example: /DLL ircsc.dll restart EventLog
DDE Command return: RESTART_SUCCESS, RESTART_FAILED

--------------------------------------------------------------------

For more information, visit www.hazlicyber.cjb.net
This software is legally registered under HazliCyber Corp. Ltd -
Software Foundation. All right reserved by MarhazK.

P/S: If you want to create or delete existed service, download
at www.hazlicyber.cjb.net. Its FREE.
IRC: #AirChat at irc.airchat.cjb.net
     #kolej-abdillah at irc.dal.net
FREE: You get free IRCSC.DLL SOURCES for Visual C++. More, download
      at www.hazlicyber.cjb.net