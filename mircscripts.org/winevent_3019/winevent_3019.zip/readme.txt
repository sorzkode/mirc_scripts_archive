Winevent.dll by hixxy

What does this dll do?
  This dll will tell you when a status, channel, query, send, get, chat, fserve, custom, channel list, notify list, url list or finger window is created or 
  destroyed.
  It was written because of inconsistencies in the way mIRC treats different types of windows.

How do I use this dll?
  Just type "/dll Winevent.dll Load ." without the quotes and then you'll start receiving signals from the dll.

What do the signals look like?
  Signal name: Winevent 
  Parameters: <event> - either Create or Destroy. 
              <class> - either mIRC_Status, mIRC_Channel, mIRC_Query, mIRC_Send, mIRC_Get, mIRC_Chat, mIRC_Fserve, mIRC_Custom, 
                        mIRC_List (for the channel list window) mIRC_Url (for the URL list window) mIRC_Notify (for the notify list window) or
                        mIRC_Finger (for the window that opens when you /finger an ip).
              <hwnd>  - the hwnd of the window.
              <title> - the text in the titlebar of the window. 

How can I catch the signals?
  Just use the on signal event in mIRC.

Can I have an example?
  on *:signal:Winevent:{
    if ($1 == Create) echo -a Window created: $2-
    elseif ($1 == Destroy) echo -a Window destroyed: $2-
  }

How can I contact you if I have a problem, suggestion, etc?
  You can either find me in #mIRC on Undernet or you can email me at hixxy@mircscripting.info