#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winuser.h>

typedef struct 
{
    DWORD  mVersion;
    HWND   mHwnd;
    BOOL   mKeep;
} LOADINFO;

HANDLE mFile;
HHOOK hID;
HWND mWnd;
LPSTR mData;

LRESULT CALLBACK CBTProc(int nCode,WPARAM wParam,LPARAM lParam)
{
    LPCBT_CREATEWND cw;
    char *Action;
    char Class[MAX_PATH];
    char Title[MAX_PATH];
    if (nCode < 0)
        return CallNextHookEx(hID,nCode,wParam,lParam);
    switch (nCode)
    {
        case HCBT_CREATEWND:
            cw = (LPCBT_CREATEWND)lParam;
            GetClassName((HWND)wParam,Class,MAX_PATH);
            if ((!strcmp(Class,"mIRC_Status")) || (!strcmp(Class,"mIRC_Channel")) || (!strcmp(Class,"mIRC_Query")) || 
            (!strcmp(Class,"mIRC_Send")) || (!strcmp(Class,"mIRC_Get")) || (!strcmp(Class,"mIRC_Chat")) || 
            (!strcmp(Class,"mIRC_Fserve")) || (!strcmp(Class,"mIRC_Custom")) || (!strcmp(Class,"mIRC_List")) || 
            (!strcmp(Class,"mIRC_Notify")) || (!strcmp(Class,"mIRC_Url")) || (!strcmp(Class,"mIRC_Finger")))
            {
                if (strlen(cw->lpcs->lpszName))
                {
                    wsprintf(mData,"/.signal Winevent Create %s %d %s",Class,wParam,cw->lpcs->lpszName);
                    SendMessage(mWnd,WM_USER+200,0,0);
                }
            }
            break;
        case HCBT_DESTROYWND:
            GetClassName((HWND)wParam,Class,MAX_PATH);
            if ((!strcmp(Class,"mIRC_Status")) || (!strcmp(Class,"mIRC_Channel")) || (!strcmp(Class,"mIRC_Query")) || 
            (!strcmp(Class,"mIRC_Send")) || (!strcmp(Class,"mIRC_Get")) || (!strcmp(Class,"mIRC_Chat")) || 
            (!strcmp(Class,"mIRC_Fserve")) || (!strcmp(Class,"mIRC_Custom")) || (!strcmp(Class,"mIRC_List")) || 
            (!strcmp(Class,"mIRC_Notify")) || (!strcmp(Class,"mIRC_Url")) || (!strcmp(Class,"mIRC_Finger")))
            {
                GetWindowText((HWND)wParam,Title,MAX_PATH);
                wsprintf(mData,"/.signal Winevent Destroy %s %d %s",Class,wParam,Title);
                SendMessage(mWnd,WM_USER+200,0,0);
            }
            break;
    }
    return CallNextHookEx(hID,nCode,wParam,lParam);
}

extern "C" _declspec(dllexport) int __stdcall Load(HWND,HWND,char*,char*,BOOL,BOOL)
{
    return 1;
}

extern "C" _declspec(dllexport) void __stdcall LoadDll(LOADINFO *mIRC)
{
    mWnd = mIRC->mHwnd;
    mFile = CreateFileMapping(INVALID_HANDLE_VALUE,0,PAGE_READWRITE,0,4096,"mIRC");
    mData = (LPSTR)MapViewOfFile(mFile,FILE_MAP_ALL_ACCESS,0,0,0);
    hID = SetWindowsHookEx(WH_CBT,CBTProc,GetModuleHandle(NULL), GetCurrentThreadId());
}

extern "C" _declspec(dllexport) int __stdcall UnloadDll(int timeout)
{
    if (!timeout)
    {
        UnmapViewOfFile(mData);
        CloseHandle(mFile);
        UnhookWindowsHookEx(hID);
    }
    return 0;
}
