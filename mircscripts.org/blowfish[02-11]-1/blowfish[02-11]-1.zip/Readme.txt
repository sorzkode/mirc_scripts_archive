Blowfish Encryption mIRC Script Readme
Coded by: GR81

+=+=+= How to load =+=+=+
* Extract all files to your mIRC directory.  In mIRC type /load -rs bfscript.mrc
* A little warning pops up.. just click yes
* A little dialog pops up and asks you for your key.. type one.. if you dont have one.. just type somthing
* mIRC will freeze a few seconds while it sets the blowfish key.  This is normal.

+=+=+= How to use =+=+=+
1) load it using the instructions above
2) right click in any channel or query and you will get a menu
3) use the menu to do what you want.. the menu items are described in the following section

+=+=+= Blowfish Popup Menu Description =+=+=+

* Add xxxx to chan/nick list: You will only encrypt/decrypt messages in the channels/querys in this internal list.
* Quick Msg: If you have Encrypting disabled, but you want to say somthing encrypted real quick, use this.
* Quick Decrypt: If you want to decrypt somthing somone said if you have decrypting disabled, use this.
* Encrypting [on/off]: If this is disabled you will see encrypted messages as meaningless lines of letters and numbers.
* Decrypting [on/off]: If this is disabled, nothing you type will ever be encrypted.
* Change Msg Prefix [$%&-->]: Use this to change what the messages you send/decrypt are prefixed with so the script knows it is an encrypted message.  You may want to change this if other people start using this script using diffrent keys.
* Set Key: Sets Blowfish key
* Unload: Unloads the script

+=+=+= Reason =+=+=+
People don't trust dll files for good reason.  Why should a person need to decrease their security by enabling the /dll command just to increase their security to using blowfish encryption? At least with an mIRC script, a person can read through it to see if there is any reson not to trust it.  So I made a script :-D

+=+=+= Q & A =+=+=+
Q: Why does it take so long to set the blowfish key?
A: The encryption procedure has to be called 521 times before the key is set

Q: What are these files for? PBox.hash SBox1.hash etc..
A: PBox is an array used in blowfish encryption, and so are the SBoxes.  Dont delete these files or it wont work.

Q: What are these files for? PB.hash SB1.hash etc...
A: These files are your saved blowfish key.  This is what is made when your mIRC is froze when it is settin your key.  I save them so that I dont have to re-make them and freeze your mIRC every time it starts.

Q: Can I use blowfish.mrc in my script?
A: Yes, just give credit.

Q: Is this blowfish just as good as the blowfish that the dlls use?
A: blowfish is blowfish is blowfish

Q: Could this be used to encrypt files or other things?
A: Only if you could figure out how to modify it to do so. This was only implemented for chat. sorry.

Q: Why didnt you do a script for (insert other encryption algorithm here)?
A: I have worked with blowfish before, so that is what I used.  Maybe some day I will try another one.

Q: Where do I report bugs? 
A: Dont. Fix them yourself.

Q: How do I contact you? How old are you?  Who are you?  What color is your hair?
A: LEAVE ME ALONE!!!


