Hash Tables Manager v4.0 (Saved Tables)

In this folder all the files are saved in.

The tables names are in: NAME.lst
While the Items & Data are in: TABLENAME.hsh

Even after a file is deleted, It's dir is not deleted, Thats normal.