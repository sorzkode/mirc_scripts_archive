ProXieS mIRC Addon (Hash Tables Manager)

Script Version:   4.0 
Script Purpose:   Hash Tables Manager \ Editor.
Author Nickname:  ProXieS
Author Email:     Lamest@hotmail.com
Note: IF theres any problem please report at my email, or visit me in #ProXieS @ DALnet. I hang there...




Loading Script:
===============
After you unzip the script, All the files + SAVES folder mush be in 1folder called HASH.
When you open your mIRC type: /load -rs Path\HTManager.mrc (The HTManager.mrc is the main file)
After that check Menubar / Status for popups containing word: HT Manager and press on it, It will open the main dialog and then go the tab5 HELP and you can find anything you need in there.


Using Script:
===============
Using the script is so easy, Just open the dilaog, and it will display the tables you have, and the help file got all.
THe script aint slow, But if you got more the 1000Item it may ned few seconds to update the tree view.


Usage of MDX:
===============
As you see MDX.dll by DragonZAP was used for some stuff in the dialog.



Credits:
===============
Thanx for all #helpdesk @ DALnet (Staff/Helpers)
Special thank for (Propogater & CoolKill & [on]) For their helping / testing the script.

Sincerly, ProXieS
