#ifndef _MAIN_H_
#define _MAIN_H_

#pragma check_stack(off)
#pragma comment(linker,"/OPT:NOWIN98")
#pragma comment(lib, "libv2.lib")

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>

#include "libv2.h"
#include "mirc.h"

#endif