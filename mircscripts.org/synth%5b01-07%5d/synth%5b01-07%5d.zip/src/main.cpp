#include "main.h"

unsigned char *ucTune;
int n = 0;
bool bPlaying = FALSE;

extern "C" 
{
	void WINAPI LoadDll	( LOADINFO *loadInfo )
	{
		loadInfo->mKeep = true;
		return;
	}

	int WINAPI UnloadDll ( int timeout )
	{
		if ( !timeout )
		{
			if ( ucTune != NULL )
			{
				if ( bPlaying )
				{
					ssStop ();
					ssClose ();
				}
				delete[] ucTune;
			}

			return MIRC_RET_CONTINUE;
		}
		return MIRC_RET_HALT;
	}
}

MIRC_FUNCTION ( isPlaying )
{
	if ( bPlaying )
	{
		MIRC_RETURN(MIRC_TRUE);
	}
	else
	{
		MIRC_RETURN(MIRC_FALSE);
	}
}

MIRC_FUNCTION ( Create )
{
	if ( !bPlaying )
	{
		int nSize = atoi ( data );

		if (ucTune != NULL)
			delete[] ucTune;

		ucTune = new unsigned char[nSize];

		n = 0;

		if ( ucTune == NULL )
		{
			MIRC_RETURN(MIRC_FALSE);
		}
		MIRC_RETURN(MIRC_TRUE);
	}
	MIRC_RETURN("ERROR! Stop your song firs!");
}

MIRC_FUNCTION ( FillTuneByChars )
{
	if ( !bPlaying )
	{
		int i = 0;    
		while (data[i] != 0)
			ucTune[n++] = data[i++];

		return MIRC_RET_CONTINUE;
	}
	return MIRC_RET_HALT;
}

MIRC_FUNCTION ( FillTuneByNumbers )
{
	if ( !bPlaying )
	{
		char *cByte;
		cByte = strtok (data," ");

		while ( cByte != NULL )
		{
			ucTune[n++] = (unsigned char)atoi ( cByte );
			cByte = strtok(NULL, " ");
		}

		return MIRC_RET_CONTINUE;
	}
	return MIRC_RET_HALT;
}

MIRC_FUNCTION ( Play )
{
	if ( !bPlaying )
	{
		if ( ucTune != NULL )
		{
			ssInit ( ucTune , GetForegroundWindow() );
			ssPlay ();

			bPlaying = TRUE;

			return MIRC_RET_CONTINUE;
		}
	}
	return MIRC_RET_HALT;
}


MIRC_FUNCTION ( Stop )
{
	if ( bPlaying )
	{
		ssStop ();
		ssClose ();

		delete[] ucTune;
		n = 0;

		bPlaying = FALSE;

		return MIRC_RET_CONTINUE;
	}
	return MIRC_RET_HALT;
}

MIRC_FUNCTION ( DLLInfo )
{
	MessageBox ( mWnd, MIRC_DLLINFO_TEXT, MIRC_DLLINFO_TITLE, MIRC_DLLINFO_BUTTONS );
	return MIRC_RET_CONTINUE;
}