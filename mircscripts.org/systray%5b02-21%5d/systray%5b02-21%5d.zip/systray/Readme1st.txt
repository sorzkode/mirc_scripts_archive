; Systray Information Addon version 1.5beta
; by Tribe @ PTnet
; SCT - Simple Coders Team 2002/2006
;
; http://www.tscript.page.vu
;
; Sugestions, comments, flames to:
; tribemx@gmail.com
;
; You can find on:
;
; PTnet (irc.clix.pt:6667) - #SCT , #ICC
; nickname: tribe
;
; Undernet (irc.undernet.org:6667) - #mirc.net
; nickname: tribe`


; *** Why make an addon based on systray.dll?
; Systray.dll should be a must in every script, its a nice and simple way to show anykind of informations
; and lots of people don't know how to work with systray.dll, so I decided to make an addon with the purpose
; of introducing systray.dll in personal more scripts.
: ***

; *** How can I use it?
; This addon isn't very hard to use, you just need to open the main configuration dialog, you can access it
; on the menubar popup, or doing /systray.
; When you open the dialog you have a checkbox list with several mIRC events, to edit each one of those 
; events you just need to double click on the selected event that you want to edit. 
; To activate or desactivate a popup message, you just need to check or uncheck the checkbox of the event that
; you don't want to view. You can edit almost every mIRC events.
; You can edit the title that appears on the system tray, the double click, and the right click.
; ***

; *** Commands?
; /syslog - opens systray messages log history
; /sysabout - opens systray about dialog
; /systray - opens systray configuration dialog
; ***

; *** Next version? Updates?
; This was just a remake of the old systray addon that I have..
; In the next version I want to add a popup editor, to perfom the right click event
; and I want to add more events.
; Don't know when im going to do a next update, I will not say dates.
; ***