#include <windows.h>

extern "C" _declspec(dllexport) int __stdcall get_fore_tbar(HWND mWnd, HWND aWnd, char* data, char*, BOOL, BOOL)
{
	HWND Fwnd; 
	char buf[500]; 
	Fwnd = GetForegroundWindow(); 
	GetWindowText(Fwnd,buf,500);
	strcpy(data,buf); 
	return 3;
}
extern "C" _declspec(dllexport) int __stdcall get_mirc_tbar(HWND mWnd, HWND aWnd, char* data, char*, BOOL, BOOL)
{
	char buf[500]; 
	GetWindowText(mWnd,buf,500);
	strcpy(data,buf); 
	return 3;
}

extern "C" _declspec(dllexport) int __stdcall about(HWND mWnd, HWND aWnd, char* data, char*, BOOL, BOOL)
{
	strcpy(data,"gtb dll - by void.");
	return 3;
}
