gtb mIRC DLL by void (aka munashii)

DLL functions:

$dll(gtb.dll,get_fore_tbar,) - Returns the titlebar text of the foreground (active) window. Useful for status scripts (to show people what you're doing when you're idle, for instance)
$dll(gtb.dll,get_mirc_tbar,) - Returns the titlebar text of the mIRC window.
$dll(gtb.dll,about,) - Self-explanatory.

Compiled with: Dev-C++ 4.9.9.0