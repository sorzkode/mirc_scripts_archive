IP Tracer by BloW-MaN
___________________________
Official spread: 02.06.2004
__________FAQ______________

[*] What this snippet does?

This snippet can trace IP's and Hostnames. It shows the country and the city the IP belongs to.

[*] How this snippet works?

When you performing /DNS (ip) command. A socket called traceip(ip) connects to www.DNSStuff.com and performing
"City From IP" lookup on the specified target.

[*] Does this snippet take a lot of bandwidth?

No, since after connecting to DNSStuff it reads only 3 lines from the result page (50bytes max. per checking). 

[*] How can I load/unload/use the snippet? Do I have to unset any variables?

Load:
- Extract the contents of the archive (for example, to 'c:\mirc\ip' and not to 'c:\program files\ip').
Note: This snippet uses $scriptdir identifier so please make sure there is no space in script's dir name.
- Open mIRC and type: /load -rs c:\mirc\traceip.mrc
Unload:
- In mIRC type /unload -rs c:\mirc\traceip.mrc
** Note: you don't have to unset any virable since the snippet doesn't uses perm. vars.
Usage:
- Open mIRC.
- Type /DNS <host/nick/ip> ---> /DNS BloW-MaN
-OR-
/TraceIP IP                ---> /TraceIP 127.0.0.1
/TraceIP Hostname          ---> /TraceIP 80-219-59-87.dclient.hispeed.ch
-OR-
Right-Click on someone from the nicklist and click Country...

[*] Can I load this snippet from 'C:\Program Files\mIRC\IPTracer.mrc'?

Yes, you can load this snippet from every location on your PC (and probably on network).

[*] Can I host your CACHE ini file?

Not ATM. Thanks :)
Thanks fly to ..:: PRINCE ::.. (www.sialkoti.com) for hosting the cache file.
The URLs for the cache are: http://iptracer.sialkoti.com/scripts/IPTracer/dns.cache.ini
						    http://scripts.THM.org.ua/scripts/IPTracer/dns.cache.ini
							
__________________________________________

[Common Terms]
Loopback
 Some people know it as 127.0.0.1.
 The special internet address, 127.0.0.1, definded by the Internet Protocol (IP). A host can use local the loopback address to send
 messages to itself.
IANA Reserved
 IANA is Internet Assigned Names Authority. IANA is the official agency that is responsible for assigning domain names IP
 addresses and protocols.

[Update History]
05.06.2004
- Known BUG fixed =)
- Separate treats to various IPs.
- '[' and ']' removed from the output and 'from' removed as well.
27.06.2004
- Multiply DNS improved and won't flood you anymore.
- An echo was added (Going to trace X IP/IP's...).
- Some scripting descriptions added.
- New alias - $ClassC(IP). Returns Class C of the given IP.
- CACHE ADDED. Use '/traceip -r IP' to remove IP from the cache (for once).
07.07.2004
- Stupid status echo removed (echo -s %tot). Sorry, I forgot in previous ver.
- Better Tracing.
- EXPERIMENTAL Internet Cache Updater added. Use: '/traceip -u' to update your cache file.
  Note: I need an account on a stable server with 1 FTP account and 1MB (maximum!!!) quota to host the cache file.
        Please email me (email below) if you can donate me one.
- Readme updated and added some FAQ's.
14.07.2004
- Algorithm is wayyyyy faster! Removed more than 20 lines. My mistake.
- Some small fixes.
- Internet Cache file is now contains more than 2450 ranges. Use '/traceip -u' to update yours. 
21.07.2004
- Cache file will be created when you load the snippet if not exists in script's dir.
- If you deleted the cache file, the script will create it back (could be critical error before).
- '/traceip -r' is much faster now.
- Internet Cache file is now contains more than 5250 ranges. Use '/traceip -u' to update yours.
- You can now load the snippet from every location. Thanks, Chris (www.p44.org).
- Binary downloading is now used when updating the CACHE file (/traceip -u). MUCH faster download and operation.
31.07.2004
- More than 20 $scriptdir fixes :(
12.08.2004
- When people saw '(High)' in output they didn't know what is it (so I), so it was removed. 
  Update your cache please.
- TLD (top level domains) support added. You can now use /TraceIP TLD.
  Example: /TraceIP sk will return: 'sk is Slovak Republic'.
- Menus changed a little; from 'Country [host]' to 'Trace IP'. Some people said it was too long.
- Update-echo's were changed a bit.
- The whole CACHE Update system is different now. You won't download the whole cache file if you have a bigger one.
26.08.2004
- If an IP/Host is unresolvable, then there won't be a tracing echo.
- $ClassC() was changed and became more efficient. Please update your cache.
06.09.2004
- Found and fixed a little bug that removes your cache every time you load the snippet. Thanks for reporting, CaeSpock.
16.03.2005
- Improved $ClassC() module. It checks the validity of the IP better: checks the structure and the ranges.
- City is now shown in addition to the country. They will be both saved in the cache.
- /TraceIP works for hosts in addition to IPs. /Traceip [Host]
- Only IPs are cached.
- Even unresolvable hostnames and IP's will be traced.
- 'Common Terms' section added to this readme file.
12.04.2005
- Not supporting TLD anymore.
- Using regex instead of iswm to verify the validity of an IP. 
- TraceIP menu behaviour changed.
- Few little changes in code.
14.09.2005
- DNSStuff.com seemed to block access to "Unauthorized Programs" so users got "*.*.*.* is Unauthorized Program (Unauthorized Program)" in reply. Fixed!
- Updated contact information.
29.09.2005
- Cache updater had an issue with the httpd on www.sialkoti.com but it's now fixed and you can update your cache now.

[*] I have suggestions/flames! How can I contact you?

It's very simple. Contact info:
E-MAiL...: IPTracer[at]THM.org.ua
MESSENGER: Admin[at]THM.org.ua
iRC CHAN.: Not at this moment, but you can msg BloW-MaN on EFnet.
UiN......: 53-364-772
