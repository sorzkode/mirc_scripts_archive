This is an edited .hlp file for mIRC v6.16.
This file was made strictly for helping people, mIRC Co. Ltd. still has every rights to the mIRC helpfile (mirc.hlp).
The commands added in this .hlp is hidden commands that does not appear in normal .hlp,
some of them because they have been covered in another identifier/alias, some of them just forgotten
The following commands/identifiers has been added (To file and index):

$r, $lof, $opnick, $hnick, $rnick, $vnick, $mode, $~<identifier>
$nopnick, $nvnick, $nhnick, $colour, $evalnext
$iaddress, $naddress, $raddress, $mp3, $pi, $nickmode
$*, $remote, $/<identifier>, $.<identifier>, $bits, $beta
$hregex, $dir, $hfile, $initopic, $mp3dir, $wavedir, $inmp3
/notice, /quote, /leave, /xyzzy, /action
/registration, /closemsg, /colour, /wallchops, /auto
/username, /timers, /setlayer, on OWNER/DEOWNER

The following commands/identifiers has been edited and/or indexed:

$mircdir, $mircini, $mircexe, $mididir, $logdir, $result
$scriptdir, $getdir, $nick(), $asc, $highlight
$window, $ok, $cancel, $yes, $no, $adate
$inmode, $banlist, $auto, $token, $left, $right
$(...), $mid, $scon, $scid, $msfile
$disk, $os, $input, $iif, $calc, $leftwin
$notify, 
/font, /save, /server, /timer
/set, /unset, /unsetall, /inc, /dec, /ignore
/ban, /debug, /server, /hdel, /hadd, /aline
/hfree, /hload, /hsave, /hinc, /hdec, /echo
/window, /query, /editbox, /cnick
/background, /filter, /ctcp, /if

Following chapters has also been edited:

Access Levels, added me: level
Aliases, added a note on aliases/identifiers for events
Raw Events, added non-numeric $event note, added $nick note
Control Codes, removed color code 99, not working
if then else, added isvo, ishelp isowner and !===, added ! to index
on DIALOG, added ACTIVE event, edited CLOSE and INIT events,
also added the "flat" style for checkbox/radiobutton,
changed $dialog().result explanation. Added explanation for option notheme
Remote Identifiers, added the same note as in /scid and /scon page
File Handling, minor edit to the $identifiers and /aliases
Halting Default Text, added RAWMODE, CTCP, OWNER/DEOWNER, PONG.
mIRC Commands, added note on /!<command>

The new (hidden) identifiers/aliases has been added to index.

I encourage all that find a spacing issue (ie where the text is placed wrong) to report it.

Teazle
#Scripting, QuakeNet