#ifndef _LISTFILES_
#define _LISTFILES_

void scandir(const char *, const char *, const char *);

//defs
#define LF_RETURN	"lf_return"
#define LF_FILE		"lf_file"
#define LF_DIR		"lf_dir"

#define MAX_TYPES 32

//user defined (first 8 bytes)
#define OUT_SIGNAL_FILE		(1 << 0)
#define OUT_SIGNAL_DIR		(1 << 1)
#define OUT_FILE			(1 << 2)
#define OUT_APPEND			(1 << 3)
#define OUT_SKIPHIDDEN		(1 << 4)		//skip file / directory if the attr hidden is set
#define OUT_ALL				(1 << 5)		//parse all files if not excluded

//parser defined (second 8 bytes)
#define OUT_READ_AUDIOINFO	(1 << 8)
#define OUT_READ_V1			(1 << 9)
#define OUT_READ_V2			(1 << 10)
#define OUT_VORBIS_COMMENT	(1 << 11)


#define PREFIX '<'
#define SUFFIX '>'


//mirc.hlp: string has a maximum of 900 chars
//however, a mircstring seems to have a maximum size of 950bytes allowed in mircscript (949bytes data + null termination)
//of course, the string is larger 950chars and truncated to 950byte inside the script engine
//therefore, we use 940 to be able to copy more data
#define MIRCSTRLEN	940
struct LOADINFO
{
    DWORD  version;
    HWND   hwnd;
    BOOL   keep;
};

#define BUFFERSIZE	0x0800
class CBUFFER
{
private:
	CBUFFER(const CBUFFER&);	//hide copy ctor
public:
	char buffer[BUFFERSIZE];
	int pos;

	CBUFFER();
	~CBUFFER();
	CBUFFER& operator<<(const char *);
	CBUFFER& operator<<(const char);
	CBUFFER& operator<<(const int);
	CBUFFER& operator<<(const unsigned int);
	CBUFFER& operator<<(const unsigned __int64);
	CBUFFER& operator<<(const float);
	//CBUFFER& operator<<(const void *);
};

struct PARSE_INFO
{
	CBUFFER out;
	const char *ldir;
	const char *sdir;
	const char *adir;
	int type;
	WIN32_FIND_DATA *finddata;
};


#define PARSERCALL	__fastcall
struct PARSER_ENTRY
{
	void (PARSERCALL *func)(PARSE_INFO *, char *);
	char *str;	//used by PARSER_STRING and PARSER_V2.. set to NULL otherwise
};

struct USIZE64
{
	unsigned int	low;
	unsigned int	high;
};

#endif _LISTFILES_
