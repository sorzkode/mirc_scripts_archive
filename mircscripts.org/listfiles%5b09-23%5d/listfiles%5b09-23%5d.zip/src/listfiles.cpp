#pragma comment(linker,"/OPT:NOWIN98")
#pragma comment(linker, "/version:1.1")

#include <windows.h>
#include <list>
#include "listfiles.h"
#include "mpeg.h"
#include "id3v1.h"
#include "id3v2.h"
#include "oggvorbis.h"

HWND hWndmIRC;
HANDLE hFileMap;
char *mData;


std::list<PARSER_ENTRY> parser_list;

char *types[MAX_TYPES];
char *etypes[MAX_TYPES];

//std::list<PARSER_ENTRY> *array[MAX_TYPES+1] = { 0 };	//type/wildmatch specific parsing?

DWORD outputflags = 0;
int ldirlen;
int sdirlen;
unsigned int depth;
unsigned int maxdepth;
unsigned int totalfiles;
__int64 totalbytes;

FILE *file;	//file for output

FILE *mpegfile;			//used to open mpeg files to read mpeg info, id3v1 or id3v2
FILE *vorbisfile;
MPEGInfo mpeginfo;	//the mpeg info reader class
CID3V1 id3v1;		//the id3v1 reader class
CID3V2 id3v2;		//the id3v2 reader class
bool isv1;
COggVorbis vorbisinfo;

/*
replace with own class based on WinAPI or file mapping
fread()	
fgetc()
*/

//helper functions
CBUFFER::CBUFFER()
{
	pos = 0;
	for (int i = 0; i < BUFFERSIZE; i++)
		buffer[i] = 0;
}

CBUFFER::~CBUFFER()
{
}

CBUFFER &CBUFFER::operator <<(const char *str)
{
	if (str)
	{	
		while (pos < BUFFERSIZE-1 && *str)
			buffer[pos++] = *str++;
	}

	return *this;
}

CBUFFER &CBUFFER::operator <<(const char c)
{
	if (pos < BUFFERSIZE-1)
		buffer[pos++] = c;

	return *this;
}

CBUFFER &CBUFFER::operator <<(const int i)
{
	if (pos < BUFFERSIZE-1)
	{
		int bytes = _snprintf(&buffer[pos], BUFFERSIZE - pos -1, "%i", i);
		if (bytes < 0)
			pos = BUFFERSIZE-1;
		else pos += bytes;
	}
	return *this;
}

CBUFFER &CBUFFER::operator <<(const unsigned int u)
{
	if (pos < BUFFERSIZE-1)
	{
		int bytes = _snprintf(&buffer[pos], BUFFERSIZE - pos -1, "%u", u);
		if (bytes < 0)
			pos = BUFFERSIZE-1;
		else pos += bytes;
	}
	return *this;
}

CBUFFER& CBUFFER::operator<<(const unsigned __int64 i64)
{
	if (pos < BUFFERSIZE-1)
	{
		int bytes = _snprintf(&buffer[pos], BUFFERSIZE - pos -1, "%I64i", i64);
		if (bytes < 0)
			pos = BUFFERSIZE-1;
		else pos += bytes;
	}
	return *this;
}

CBUFFER &CBUFFER::operator <<(const float f)
{
	if (pos < BUFFERSIZE-1)
	{
		int bytes = _snprintf(&buffer[pos], BUFFERSIZE - pos -1, "%f", f);
		if (bytes < 0)
			pos = BUFFERSIZE-1;
		else pos += bytes;
	}
	return *this;
}

/*
CBUFFER &CBUFFER::operator <<(const void *p)
{
	if (pos < BUFFERSIZE-1)
	{
		int bytes = _snprintf(&buffer[pos], BUFFERSIZE - pos -1, "%x", p);
		if (bytes < 0)
			pos = BUFFERSIZE-1;
		else pos += bytes;
	}
	return *this;
}
*/

#include <crtdbg.h>

//NOT null terminated
int UTF8toAscii(char *instr, char *outstr, int maxlen)
{
	if (maxlen <= 0)
		return 0;

	int len = 0;
	while (len < maxlen)
	{
		if (*instr == 0x00)
			break;
		if (!(*instr & 0x80))	//7 bit ascii 0x00 to 0x7f
		{
			*outstr++ = *instr++;
			len++;
		}

		else if (*instr == 0xc2)	//0x80 to 0xbf
		{
			instr++;
			_ASSERTE(*instr >= 0x80 && *instr <= 0xbf);
			*outstr++ = *instr++;
			len++;
		}
		else if (*instr == 0xc3)	//0xc0 to 0xff
		{
			instr++;
			_ASSERTE(*instr >= 0x80 && *instr <= 0xbf);
			char difference = 0xc0 - 0x80;	//0x40 = 64
			*outstr++ = *instr++ + difference;
			len++;
		}
		else
		{
			instr++;
			outstr++;
		}
	}
	return len;
}

bool chkdoublespace(const char *str)
{
	while (*str)
	{
		if (*(unsigned __int16 *)str == (unsigned __int16)0x2020)
			return true;
		str++;
	}
	return false;
}

int __fastcall my_strncpy(char *dest, const char *src, int bytes)
{
	if (bytes <= 0)
		return 0;

	for (int i = 0; i < bytes; i++)
	{
		dest[i] = src[i];
		if (src[i] == '\0')
			break;
	}
	return i;
}

void __fastcall convertsize(char result[32], unsigned __int64 size)
{
	if (size < 1024)			_snprintf(result, 31, "%.2ib"	,(int)size);
	else if (size < 1048576)	_snprintf(result, 31, "%.2fkb"  ,(double)(__int64)size / 1024);
	else if (size < 1073741824)	_snprintf(result, 31, "%.2fmb"  ,(double)(__int64)size / 1048576);
	else						_snprintf(result, 31, "%.2fgb"  ,(double)(__int64)size / 1073741824);
}

//return if matches (case insensitive)
//this function is written by... unknown, found some "authors" of this code
//the function has been modified to compare case insensitive

char chr2upper(char c)
{
	if (c == '�')
		return '�';
	if (c == '�')
		return '�';
	if (c == '�')
		return '�';
	return c & 0xdf;
}

bool __fastcall wildcmp(const char *wild, const char *string)
{
	const char *cp = 0, *mp = 0;
	
	while ((*string) && (*wild != '*'))
	{
		if (chr2upper(*wild) != chr2upper(*string) && (*wild != '?'))
			return false;

		wild++;
		string++;
	}

	while (*string)
	{
		if (*wild == '*')
		{
			if (!*++wild)
				return true;

			mp = wild;
			cp = string+1;
		}
		else if (chr2upper(*wild) == chr2upper(*string) || (*wild == '?'))
		{
			wild++;
			string++;
		}
		else
		{
			wild = mp;
			string = cp++;
		}
	}

	while (*wild == '*')
		wild++;

	return !*wild;
}

time_t FileTimeToTime_t(FILETIME *ft)
{
	unsigned __int64 i = *(unsigned __int64 *)ft;
	i -= 116444736000000000;
	i /= 10000000;

	return i;	
}




//parser functions
void PARSERCALL parse_null(PARSE_INFO *ppi, char *)
{
}

void PARSERCALL parse_string(PARSE_INFO *ppi, char *str)
{
	ppi->out << str;
}

void PARSERCALL parse_size(PARSE_INFO *ppi, char *)
{
	USIZE64 s64 = { ppi->finddata->nFileSizeLow, ppi->finddata->nFileSizeHigh };
	unsigned __int64 s = *((unsigned __int64 *)&s64);
	ppi->out << s;
}

void PARSERCALL parse_fsize(PARSE_INFO *ppi, char *)
{
	char temp[32];
	USIZE64 s64 = { ppi->finddata->nFileSizeLow, ppi->finddata->nFileSizeHigh };
	unsigned __int64 s = *((unsigned __int64 *)&s64);
							
	convertsize(temp, s);
	ppi->out << temp;
}

void PARSERCALL parse_fname(PARSE_INFO *ppi, char *)
{
	char *str = chkdoublespace(ppi->finddata->cFileName) ? ppi->finddata->cAlternateFileName : ppi->finddata->cFileName;
	ppi->out << str;
}

void PARSERCALL parse_dir(PARSE_INFO *ppi, char *)
{
	ppi->out << ppi->adir << '\\';
}

void PARSERCALL parse_reldir(PARSE_INFO *ppi, char *)
{
	const char *a = ppi->adir + ldirlen;
	if (*a != '\0')
		ppi->out << (++a) << '\\';
}

void PARSERCALL parse_lfname(PARSE_INFO *ppi, char *)
{
	ppi->out << ppi->finddata->cFileName;
}

void PARSERCALL parse_ldir(PARSE_INFO *ppi, char *)
{
	ppi->out << ppi->ldir << '\\';
}

void PARSERCALL parse_lreldir(PARSE_INFO *ppi, char *)
{
	const char *a = ppi->ldir + ldirlen;
	if (*a != '\0')
		ppi->out << (++a) << '\\';
}

void PARSERCALL parse_sfname(PARSE_INFO *ppi, char *)
{
	ppi->out << ppi->finddata->cAlternateFileName;
}

void PARSERCALL parse_sdir(PARSE_INFO *ppi, char *)
{
	ppi->out << ppi->sdir << '\\';
}

void PARSERCALL parse_sreldir(PARSE_INFO *ppi, char *)
{
	const char *a = ppi->sdir + sdirlen;
	if (*a != '\0')
		ppi->out << (++a) << '\\';
}

void PARSERCALL parse_type(PARSE_INFO *ppi, char *)
{
	ppi->out << ppi->type;
}

void PARSERCALL parse_attr(PARSE_INFO *ppi, char *)
{
/*
	a = archive
	c = compressed
				
	e = encrypted
	h = hidden
				
	r = readonly
	s = system
	t = temporary
*/

	if (ppi->finddata->dwFileAttributes & FILE_ATTRIBUTE_ARCHIVE)
		ppi->out << 'a';
	
	if (ppi->finddata->dwFileAttributes & FILE_ATTRIBUTE_COMPRESSED)
		ppi->out << 'c';
	
	if (ppi->finddata->dwFileAttributes & FILE_ATTRIBUTE_ENCRYPTED)
		ppi->out << 'e';
	
	if (ppi->finddata->dwFileAttributes & FILE_ATTRIBUTE_HIDDEN)
		ppi->out << 'h';
	
	if (ppi->finddata->dwFileAttributes & FILE_ATTRIBUTE_READONLY)
		ppi->out << 'r';
	
	if (ppi->finddata->dwFileAttributes & FILE_ATTRIBUTE_SYSTEM)
		ppi->out << 's';
	
	if (ppi->finddata->dwFileAttributes & FILE_ATTRIBUTE_TEMPORARY)
		ppi->out << 't';
}


void PARSERCALL parse_created(PARSE_INFO *ppi, char *)
{
	ppi->out << FileTimeToTime_t(&ppi->finddata->ftCreationTime);
}

void PARSERCALL parse_modified(PARSE_INFO *ppi, char *)
{
	ppi->out << FileTimeToTime_t(&ppi->finddata->ftLastWriteTime);
}

void PARSERCALL parse_accessed(PARSE_INFO *ppi, char *)
{
	ppi->out << FileTimeToTime_t(&ppi->finddata->ftLastAccessTime);
}


void PARSERCALL parse_audio_len(PARSE_INFO *ppi, char *)
{
	if (mpegfile)
	{
		unsigned long len = ppi->finddata->nFileSizeLow;
		len -= mpeginfo.GetHeaderPos();
		if (isv1)
			len -= sizeof(ID3V11);

		int secs = 0;
		unsigned int bitrate = mpeginfo.GetBitrate();
		if (bitrate)
			secs = len / (bitrate * 125);
		ppi->out << secs;
	}
	else if (vorbisfile)
	{
		unsigned long len = ppi->finddata->nFileSizeLow;

		int secs = 0;
		unsigned int bitrate = vorbisinfo.GetBitrate();
		if (bitrate)
		{
			secs = len / (bitrate * 125);
			if (secs > 2)	//using the filesize is wrong cause of the header.. implement a better method later...
				secs -= 2;
		}
		ppi->out << secs;
	}
}

void PARSERCALL parse_audio_flen(PARSE_INFO *ppi, char *)
{
	if (mpegfile)
	{
		unsigned long len = ppi->finddata->nFileSizeLow;
		len -= mpeginfo.GetHeaderPos();
		if (isv1)
			len -= sizeof(ID3V11);

		int secs = 0;
		unsigned int bitrate = mpeginfo.GetBitrate();
		if (bitrate)
		{
			secs = len / (bitrate * 125);
			if (secs > 2)
				secs -= 2;
		}

		int hrs = secs / 3600;
		secs %= 3600;
		int mins = secs / 60;
		secs %= 60;

		if (mins)
		{
			if (hrs)
				ppi->out << hrs << ':';
			if (hrs || mins >= 10)
				ppi->out << (char)('0' + mins / 10);
		}
		ppi->out << (char)('0' + mins % 10) << ':' << (char)('0' + secs / 10) << (char)('0' + secs % 10);
	}
	else if (vorbisfile)
	{
		unsigned long len = ppi->finddata->nFileSizeLow;

		int secs = 0;
		unsigned int bitrate = vorbisinfo.GetBitrate();
		if (bitrate)
			secs = len / (bitrate * 125);

		int hrs = secs / 3600;
		secs %= 3600;

		int mins = secs / 60;
		secs %= 60;
		
		if (mins)
		{
			if (hrs)
				ppi->out << hrs << ':';
			if (hrs || mins >= 10)
				ppi->out << (char)('0' + mins / 10);
		}
		ppi->out << (char)('0' + mins % 10) << ':' << (char)('0' + secs / 10) << (char)('0' + secs % 10);
	}
}

void PARSERCALL parse_audio_bitrate(PARSE_INFO *ppi, char *)
{
	if (mpegfile)
		ppi->out << mpeginfo.GetBitrate();
	else if (vorbisfile)
		ppi->out << vorbisinfo.GetBitrate();
}

void PARSERCALL parse_vorbis_minbitrate(PARSE_INFO *ppi, char *)
{
	if (vorbisfile)
		ppi->out << vorbisinfo.GetMinBitrate();
}

void PARSERCALL parse_vorbis_maxbitrate(PARSE_INFO *ppi, char *)
{
	if (vorbisfile)
		ppi->out << vorbisinfo.GetMaxBitrate();
}

void PARSERCALL parse_audio_sample(PARSE_INFO *ppi, char *)
{
	if (mpegfile)
		ppi->out << mpeginfo.GetSampleRate();
	else if (vorbisfile)
		ppi->out << vorbisinfo.GetSampleRate();
}

void PARSERCALL parse_audio_chans(PARSE_INFO *ppi, char *)
{
	if (mpegfile)
		ppi->out << mpeginfo.GetChannel();
	else if (vorbisfile)
		ppi->out << vorbisinfo.GetChannel();
}

void PARSERCALL parse_mp3_layer(PARSE_INFO *ppi, char *)
{
	if (mpegfile)
		ppi->out << mpeginfo.GetLayer();
}

void PARSERCALL parse_vorbis_vendor(PARSE_INFO *ppi, char *)
{
	if (vorbisfile)
		ppi->out << vorbisinfo.GetVendor();
}

void PARSERCALL parse_audio_ver(PARSE_INFO *ppi, char *)
{
	if (mpegfile)
		ppi->out << mpeginfo.GetVersion();
	else if (vorbisfile)
		ppi->out << vorbisinfo.GetVersion();
}

void PARSERCALL parse_mp3_vbr(PARSE_INFO *ppi, char *)
{
	if (mpegfile)
		ppi->out << (mpeginfo.IsVBR() ? '1' : '0');
}

void PARSERCALL parse_mp3_priv(PARSE_INFO *ppi, char *)
{
	if (mpegfile)
		ppi->out << (mpeginfo.IsPrivate() ? '1' : '0');
}

void PARSERCALL parse_mp3_crc(PARSE_INFO *ppi, char *)
{
	if (mpegfile)
		ppi->out << (mpeginfo.IsCRC() ? '1' : '0');
}

void PARSERCALL parse_mp3_copy(PARSE_INFO *ppi, char *)
{
	if (mpegfile)
		ppi->out << (mpeginfo.IsCopyright() ? '1' : '0');
}


void PARSERCALL parse_mp3_orig(PARSE_INFO *ppi, char *)
{
	if (mpegfile)
		ppi->out << (mpeginfo.IsOriginal() ? '1' : '0');
}

void PARSERCALL parse_v1_title(PARSE_INFO *ppi, char *)
{
	if (isv1)
		ppi->out << id3v1.GetTitle();
}

void PARSERCALL parse_v1_artist(PARSE_INFO *ppi, char *)
{
	if (isv1)
		ppi->out << id3v1.GetArtist();
}

void PARSERCALL parse_v1_album(PARSE_INFO *ppi, char *)
{
	if (isv1)
		ppi->out << id3v1.GetAlbum();
}

void PARSERCALL parse_v1_year(PARSE_INFO *ppi, char *)
{
	if (isv1)
		ppi->out << id3v1.GetYear();
}

void PARSERCALL parse_v1_comment(PARSE_INFO *ppi, char *)
{
	if (isv1)
		ppi->out << id3v1.GetComment();
}

void PARSERCALL parse_v1_track(PARSE_INFO *ppi, char *)
{
	if (isv1)
		ppi->out << id3v1.GetTrack();
}

void PARSERCALL parse_v1_genre(PARSE_INFO *ppi, char *)
{
	if (isv1)
		ppi->out << id3v1.GetGenre();
}


void PARSERCALL parse_v2(PARSE_INFO *ppi, char *str)
{
	if (str && mpegfile)
	{
		int frames = id3v2.GetFrames();
		for (int i = 0; i < frames; i++)
		{
			ID3V2FRAME *f = id3v2.GetFrame(i);
			if (f)
			{
				__int32 i1 = *(__int32 *)str;
				__int32 i2 = *(__int32 *)f->field;
				if ((i1 & 0xdfdfdfdf) == (i2 & 0xdfdfdfdf))
				{
					ppi->out << f->value;
					break;
				}
			}
		}
	}
}

void PARSERCALL parse_vorbis_comment(PARSE_INFO *ppi, char *str)
{
	if (str && vorbisfile)
	{
		std::list<char *> list = vorbisinfo.GetCommentList();	//get the STL container by reference
		for (std::list<char *>::const_iterator it = list.begin(); it != list.end(); it++)
		{
			char *comment = (*it);
			if (comment)
			{
				char *c = strchr(comment, '=');
				if (c)
				{
					int len = c - comment;
					if (!strnicmp(comment, str, len))
					{
						c++;
						int copied = UTF8toAscii(c, &ppi->out.buffer[ppi->out.pos], BUFFERSIZE - 1 - ppi->out.pos);
						ppi->out.pos += copied;
						return;
					}					
				}
			}
		}
	}
}

void clearlist()
{
	while (!parser_list.empty())
	{
		PARSER_ENTRY& e = parser_list.front();
		if (e.str)
			delete [] e.str;
		parser_list.pop_front();
	}
}


//always returns "OK"
extern "C" int __declspec(dllexport) __stdcall setoutput(HWND, HWND, char *data, char *, BOOL, BOOL)
{
	clearlist();

	outputflags &= 0x0000FF00;

	char *start = data;
	char *loop = data;

	while (*loop)
	{
		if (*loop == PREFIX)
		{
			char *tagstart = loop;

			//if start points to prefix, do NOT set start to the next char... 
			loop++;
			while (tagstart)	//search for suffix or \0 or another prefix
			{
				PARSER_ENTRY entry = { parse_null, 0 };

				if (*loop == '\0')	//found: "blabla<hmm"
				{
					tagstart = NULL;	//leaves both loops
					continue;
				}
				else if (*loop == PREFIX)	//found: "blabla < hmm <a_tag>"
				{
					//reset tagstart
					int len = loop - start;
					entry.func = parse_string;
					entry.str = new char[len+1];
					my_strncpy(entry.str, start, len);
					entry.str[len] = '\0';

					start = tagstart = loop;
					loop++;
				}
				else if (*loop == SUFFIX)	//found: "blabla <a_tag>" OR "<a_tag>"
				{
					*loop = '\0';

					if (start < tagstart)	//found "blabla <a_tag>"
					{
						int len = tagstart - start;
						PARSER_ENTRY e = { parse_string, 0 };
						e.str = new char[len+1];
						my_strncpy(e.str, start, len);
						e.str[len] = '\0';

						parser_list.push_back(e);

						start = tagstart;
					}

					//now we've always "<a_tag>"
					//check how to handle empty/unknown tags
					//<len>
					char *tag = tagstart;
					tag++;

					if (!stricmp(tag, "size"))
						entry.func = parse_size;
					
					else if (!stricmp(tag, "fsize"))
						entry.func = parse_fsize;

					else if (!stricmp(tag, "fname"))
						entry.func = parse_fname;

					else if (!stricmp(tag, "dir"))
						entry.func = parse_dir;

					else if (!stricmp(tag, "reldir"))
						entry.func = parse_reldir;

					else if (!stricmp(tag, "lfname"))
						entry.func = parse_lfname;

					else if (!stricmp(tag, "ldir"))
						entry.func = parse_ldir;

					else if (!stricmp(tag, "lreldir"))
						entry.func = parse_lreldir;

					else if (!stricmp(tag, "sfname"))
						entry.func = parse_sfname;

					else if (!stricmp(tag, "sdir"))
						entry.func = parse_sdir;

					else if (!stricmp(tag, "sreldir"))
						entry.func = parse_sreldir;

					else if (!stricmp(tag, "type"))
						entry.func = parse_type;

					else if (!stricmp(tag, "attr"))
						entry.func = parse_attr;

					else if (!stricmp(tag, "created"))
						entry.func = parse_created;

					else if (!stricmp(tag, "modified"))
						entry.func = parse_modified;

					else if (!stricmp(tag, "accessed"))
						entry.func = parse_accessed;

					else if (!stricmp(tag, "len"))
					{
						entry.func = parse_audio_len;
						outputflags |= OUT_READ_AUDIOINFO;
					}
					else if (!stricmp(tag, "flen"))
					{
						entry.func = parse_audio_flen;
						outputflags |= OUT_READ_AUDIOINFO;
					}
					else if (!stricmp(tag, "bitrate"))
					{
						entry.func = parse_audio_bitrate;
						outputflags |= OUT_READ_AUDIOINFO;
					}
					else if (!stricmp(tag, "minbitrate"))
					{
						entry.func = parse_vorbis_minbitrate;
						outputflags |= OUT_READ_AUDIOINFO;
					}
					else if (!stricmp(tag, "maxbitrate"))
					{
						entry.func = parse_vorbis_maxbitrate;
						outputflags |= OUT_READ_AUDIOINFO;
					}
					else if (!stricmp(tag, "sample"))
					{
						entry.func = parse_audio_sample;
						outputflags |= OUT_READ_AUDIOINFO;
					}
					else if (!stricmp(tag, "chans"))
					{
						entry.func = parse_audio_chans;
						outputflags |= OUT_READ_AUDIOINFO;
					}
					else if (!stricmp(tag, "layer"))
					{
						entry.func = parse_mp3_layer;
						outputflags |= OUT_READ_AUDIOINFO;
					}
					else if (!stricmp(tag, "ver"))
					{
						entry.func = parse_audio_ver;
						outputflags |= OUT_READ_AUDIOINFO;
					}
					else if (!stricmp(tag, "vendor"))
					{
						entry.func = parse_vorbis_vendor;
						outputflags |= OUT_READ_AUDIOINFO;
					}
					else if (!stricmp(tag, "vbr"))
					{
						entry.func = parse_mp3_vbr;
						outputflags |= OUT_READ_AUDIOINFO;
					}
					else if (!stricmp(tag, "priv"))
					{
						entry.func = parse_mp3_priv;
						outputflags |= OUT_READ_AUDIOINFO;
					}
					else if (!stricmp(tag, "crc"))
					{
						entry.func = parse_mp3_crc;
						outputflags |= OUT_READ_AUDIOINFO;
					}
					else if (!stricmp(tag, "copy"))
					{
						entry.func = parse_mp3_copy;
						outputflags |= OUT_READ_AUDIOINFO;
					}
					else if (!stricmp(tag, "orig"))
					{
						entry.func = parse_mp3_orig;
						outputflags |= OUT_READ_AUDIOINFO;
					}
					else if (!stricmp(tag, "title"))
					{
						entry.func = parse_v1_title;
						outputflags |= OUT_READ_V1;
					}
					else if (!stricmp(tag, "artist"))
					{
						entry.func = parse_v1_artist;
						outputflags |= OUT_READ_V1;
					}
					else if (!stricmp(tag, "album"))
					{
						entry.func = parse_v1_album;
						outputflags |= OUT_READ_V1;
					}
					else if (!stricmp(tag, "year"))
					{
						entry.func = parse_v1_year;
						outputflags |= OUT_READ_V1;
					}
					else if (!stricmp(tag, "comment"))
					{
						entry.func = parse_v1_comment;
						outputflags |= OUT_READ_V1;
					}
					else if (!stricmp(tag, "track"))
					{
						entry.func = parse_v1_track;
						outputflags |= OUT_READ_V1;
					}
					else if (!stricmp(tag, "genre"))
					{
						entry.func = parse_v1_genre;
						outputflags |= OUT_READ_V1;
					}

					else if ((tag[0] & 0xdf) == 'V' && tag[1] == '2' && tag[2] == '_' && tag[3] != '\0' && tag[3] != SUFFIX)
					{
						//<v2_TIT2>
						char *value = &tag[3];	//TIT2>

						int len = loop - value;
						entry.func = parse_v2;
						entry.str = new char[len+1];
						my_strncpy(entry.str, value, len);
						entry.str[len] = '\0';
						
						outputflags |= OUT_READ_V2;
					}
					else if ((tag[0] & 0xdf) == 'C' && (tag[1] & 0xdf) == 'O' && (tag[2] & 0xdf) == 'M' && tag[3] == '_' && tag[4] != '\0' && tag[4] != SUFFIX)
					{
						//<COM_TITLE>
						char *value = &tag[4];

						int len = loop - value;
						entry.func = parse_vorbis_comment;
						entry.str = new char[len+1];
						my_strncpy(entry.str, value, len);
						entry.str[len] = '\0';

						outputflags |= OUT_READ_AUDIOINFO;
					}
					else
					{
						*loop = SUFFIX;
						loop++;	//unknown tag or empty tag
						continue;
					}
					start = ++loop;
					tagstart = NULL;
				}
				else
				{
					loop++;	//neithder PREFIX nor SUFFIX nor '\0'
					continue;
				}
				parser_list.push_back(entry);
			}
		}
		else loop++;
	}
	if (start < loop)
	{
		int len = loop - start;
		PARSER_ENTRY entry = { parse_string, 0 };
		entry.str = new char[len+1];
		my_strncpy(entry.str, start, len);
		entry.str[len] = '\0';

		parser_list.push_back(entry);
	}
	
	*(int *)data = 'O' | 'K' << 8;
	return 3;
}

// $dll(filename, listfiles, outputbitmask > target > dir > ext1;ext2;ext3 > eext1;eext2;eext3 > depth)
extern "C" int __declspec(dllexport) __stdcall listfiles(HWND, HWND, char *data, char *, BOOL, BOOL)
{
	int i;
	for (i = 0; i < MAX_TYPES; i++)
		types[i] = 0;
	for (i = 0; i < MAX_TYPES; i++)
		etypes[i] = 0;
	

	file = 0;
	mpegfile = 0;
	vorbisfile = 0;
	totalfiles = 0;
	totalbytes = 0;
	depth = 0;

	char *line = data;
	
	char *param[8] = { 0 };
	unsigned int params = 1;
	param[0] = line;


	if (*line == ' ')
		line++;
	while (*line)
	{
		if (*line == '>')
		{
			if (line > data && *(line-1) == ' ')
				*(line-1) = 0;
				
			*line++ = '\0';
			if (*line == ' ')
				*line++ = '\0';
			param[params++] = line;
			if (params == sizeof(param) / sizeof(*param))
				break;
		}
		else line++;
	}

	char *mask = param[0];
	char *target = param[1];
	char *dir = param[2];
	char *wild = param[3];
	char *ewild = param[4];
	char *depthstr = param[5];

	if (params < 3 || dir == 0 || *dir == '\0')
	{
		my_strncpy(data, "ERROR insufficient parameters", MIRCSTRLEN);
		return 3;
	}

	outputflags &= 0xFFFFFF00;	//disable all user defined bits
	for (char *loop = mask; *loop; loop++)
	{
		switch (*loop)
		{
		case 'a':
			outputflags |= OUT_FILE | OUT_APPEND;
			break;
		case 'f':
			outputflags |= OUT_FILE;
			break;
		case 'h':
			outputflags |= OUT_SKIPHIDDEN;
			break;
		case 's':
			outputflags |= OUT_SIGNAL_FILE;
			break;
		case 'd':
			outputflags |= OUT_SIGNAL_DIR;
		case '*':
			outputflags |= OUT_ALL;
			break;
		default:
			break;
		}
	}

	ldirlen = (int) strlen(dir);
	if (ldirlen && dir[ldirlen-1] == '\\')
	{
		ldirlen--;
		dir[ldirlen] = '\0';
	}
	if (!ldirlen)
	{
		my_strncpy(data, "ERROR no directory", MIRCSTRLEN);
		return 3;
	}
	
	char sdir[MAX_PATH];
	GetShortPathName(dir, sdir, MAX_PATH);
	sdirlen = (int) strlen(sdir);
	
	maxdepth = depthstr ? atoi(depthstr) : 0;

	int n = 1;
	if (wild)
	{
		types[0] = wild;
		while (*wild)
		{
			if (*wild == ';')
			{
				if (wild != etypes[0] && *(wild-1) == ' ')
					*(wild-1) = '\0';
				*wild++ = '\0';
				if (*wild == ' ')
					*wild++ = '\0';
				types[n++] = wild;
				if (n == MAX_TYPES)
					break;
			}
			wild++;
		}
	}
	else if (!(outputflags & OUT_ALL))
	{
		my_strncpy(data, "ERROR set search type or 'all'", MIRCSTRLEN);
		return 3;
	}

	n = 1;
	etypes[0] = ewild;
	if (ewild)
		while (*ewild)
		{
			if (*ewild == ';')
			{
				if (ewild != etypes[0] && *(ewild-1) == ' ')
					*(ewild-1) = '\0';
				*ewild++ = '\0';
				if (*ewild == ' ')
					*ewild++ = '\0';
				etypes[n++] = ewild;
				if (n == MAX_TYPES)
					break;
			}
			ewild++;
		}

	if (outputflags & OUT_FILE)
	{
		if (target == 0 || *target == '\0')
		{
			my_strncpy(data, "ERROR need target for file output", MIRCSTRLEN);
			return 3;
		}

		file = fopen(target, (outputflags & OUT_APPEND) ? "a+S" : "wS");
		
		if (!file)
		{
			my_strncpy(data, "ERROR can't open file", MIRCSTRLEN);
			return 3;
		}
	}
			
	scandir(dir, sdir, dir);
	
	if (outputflags & OUT_FILE)
	{
		fclose(file);
		file = 0;
	}
	char newsize[32];
	char targetbackup[512] = { 0 };	//need to make a copy, cause target points to data and we want to write to data
	my_strncpy(targetbackup, target, sizeof(targetbackup)-1);

	convertsize(newsize, totalbytes);
	_snprintf(data, MIRCSTRLEN, "OK \"%s\" %d %I64u %s", targetbackup, totalfiles, totalbytes, newsize);
	
	_snprintf(mData, 1023, "//.signal -n " LF_RETURN " %s", data);
	SendMessage(hWndmIRC, WM_USER + 200, 1, 0);
	return 3;
}

extern "C" int __declspec(dllexport) __stdcall DllInfo(HWND, HWND, char *data, char *, BOOL, BOOL)
{
	my_strncpy(data, "listfiles.dll 1.10 <beta2> aka 1.091 by Carpe Noctem / Misanthrop (Carpe@Bexcrew.de)", MIRCSTRLEN);
	return 3;
}

extern "C" int __declspec(dllexport) __stdcall GetFileSystem(HWND, HWND, char *data, char *, BOOL, BOOL)
{
	char drive[4];
	*(DWORD *)drive = (DWORD)(*data | ':' << 8 | '\\' << 16);
			
	char name[256];
	DWORD componentlen;
	DWORD flags;
	char filesystemname[256];	//this is the interesting part

	BOOL b = GetVolumeInformation(drive, name, sizeof(name), NULL, &componentlen, &flags, filesystemname, sizeof(filesystemname));
	if (b)
		_snprintf(data, MIRCSTRLEN, "OK %s", filesystemname);
	else my_strncpy(data, "ERROR", MIRCSTRLEN);
	return 3;
}







void scandir(const char *ldir, const char *sdir, const char *adir)
{
	WIN32_FIND_DATA finddata;
	char searchdir[1024];		//should be enough.. its greater than MAXPATH
	_snprintf(searchdir, sizeof(searchdir)-1, "%s\\*",ldir);
	
	HANDLE hFind = FindFirstFile(searchdir, &finddata);
	if (hFind == INVALID_HANDLE_VALUE)
		return;

	depth++;

	do
	{
		if ((finddata.dwFileAttributes & FILE_ATTRIBUTE_HIDDEN) && (outputflags & OUT_SKIPHIDDEN))
			continue;
		
		if (finddata.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
		{
			if (depth == maxdepth)
				continue;

			//keep the byte that MUST be '\0' (if matching) 'active' by using 0xFF for this byte (0xff = don't change this byte)
			//cFileName is char[MAXPATH], therefore it's save to access the first 4 bytes
			unsigned __int32 temp = *(unsigned __int32 *)finddata.cFileName;
			if ((temp & 0x0000FFFF) == '.')
				continue;
			if ((temp & 0x00FFFFFF) == ('.' | '.' << 8))
				continue;
			
			_snprintf(searchdir, sizeof(searchdir)-1, "%s\\%s", ldir, finddata.cFileName);

			if (outputflags & OUT_SIGNAL_DIR)
			{
				//this is a only a pathname.. no identifier (no mirc evaluation for pathnames).. single slash is enough
				_snprintf(mData, MIRCSTRLEN, "/.signal -n " LF_DIR " %s\\", searchdir);
				SendMessage(hWndmIRC, WM_USER + 200, 1, 0);
			}

			char ssearchdir[1024];
			if (finddata.cAlternateFileName[0])
				_snprintf(ssearchdir, sizeof(ssearchdir)-1, "%s\\%s", sdir, finddata.cAlternateFileName);
			else _snprintf(ssearchdir, sizeof(ssearchdir)-1, "%s\\%s", sdir, finddata.cFileName);
			
			char asearchdir[1024];
			if (chkdoublespace(finddata.cFileName))
				_snprintf(asearchdir, sizeof(asearchdir)-1, "%s\\%s", adir, finddata.cAlternateFileName);
			else _snprintf(asearchdir, sizeof(asearchdir)-1, "%s\\%s", adir, finddata.cFileName);
			
			scandir(searchdir, ssearchdir, asearchdir);
			continue;
		}
			
		//bool doexclude = false;
		bool doparse;
		int type = 0;

		if (outputflags & OUT_ALL)
		{
			//check for exclude..
			//if not excluded, check for type number... else type is 0...
			//the file will be parsed if it is not excluded
			doparse = true;
			for (int i = 0; i < MAX_TYPES; i++)
			{
				if (etypes[i] && wildcmp(etypes[i], finddata.cFileName))
				{
					doparse = false;
					break;
				}
			}

			if (doparse)
			{
				for (int i = 0; i < MAX_TYPES; i++)
				{
					if (types[i] && wildcmp(types[i], finddata.cFileName))
					{
						type = i+1;
						break;
					}
				}
			}
		}
		else
		{
			//insert if a wildcard matches the filename..
			//use exclude? this would allow something like: include "*.mp?", exclude "*.mpg".. for scanning all audio files (mp3, mp2, mp1, mpc).. but exclude mpg videos
			doparse = false;
			for (int i = 0; i < MAX_TYPES; i++)
			{
				if (types[i] && wildcmp(types[i], finddata.cFileName))
				{
					type = i+1;
					doparse = true;
					break;
				}
			}
			if (doparse)
			{
				for (int i = 0; i < MAX_TYPES; i++)
				{
					if (etypes[i] && wildcmp(etypes[i], finddata.cFileName))
					{
						doparse = false;
						break;
					}
				}
			}
		}


		if (doparse)
		{
			USIZE64 s64 = { finddata.nFileSizeLow, finddata.nFileSizeHigh };
			unsigned __int64 s = *((unsigned __int64 *)&s64);
			totalbytes += s;
			totalfiles++;

			if (outputflags & (OUT_FILE | OUT_SIGNAL_FILE))
			{
				if (outputflags & (OUT_READ_AUDIOINFO | OUT_READ_V1 | OUT_READ_V2))
				{
					char *loop = finddata.cFileName;
					while (*loop)
						loop++;
					char *ext = loop - 4;
					
					if (ext > finddata.cFileName)
					{
						if ((*(int *)ext & 0x00DFDFFF) == ('.' | 'M' << 8 | 'P' << 16) && (*(loop-1) & 0xdf) != 'G')
						{
							//MPEG
							char filename[512];
							_snprintf(filename, sizeof(filename)-1, "%s\\%s", ldir, finddata.cFileName);
							mpegfile = fopen(filename, "rbS");
							if (mpegfile)
							{
								bool success = true;
								if (outputflags & OUT_READ_V2)
									id3v2.LoadData(mpegfile);
								if (outputflags & OUT_READ_AUDIOINFO)
								{
									success = mpeginfo.LoadData(mpegfile);
									if (!success)
									{
										fclose(mpegfile);
										mpegfile = 0;
									}
								}
								if (success && outputflags & OUT_READ_V1)
									isv1 = id3v1.LoadData(mpegfile);
								else isv1 = false;
							}
						}
						else if ((*(int *)ext & 0xDFDFDFFF) == ('.' | 'O' << 8 | 'G' << 16 | 'G' << 24))
						{
							//VORBIS
							char filename[512];
							_snprintf(filename, sizeof(filename)-1, "%s\\%s", ldir, finddata.cFileName);

							vorbisfile = fopen(filename, "rbS");
							if (vorbisfile)
							{
								bool success = vorbisinfo.LoadData(vorbisfile);
								if (!success)
								{
									fclose(vorbisfile);
									vorbisfile = 0;
								}
							}
						}
					}

				}

				PARSE_INFO pi;
				pi.ldir = ldir;
				pi.sdir = sdir;
				pi.adir = adir;
				pi.type = type;
				pi.finddata = &finddata;


				for (std::list<PARSER_ENTRY>::iterator it = parser_list.begin(); it != parser_list.end(); it++)
				{
					PARSER_ENTRY& pe = *it;
					(*pe.func)(&pi, pe.str);
				}

				if (pi.out.pos > 0)
				{
					if (outputflags & OUT_FILE)
					{
						fwrite(pi.out.buffer, sizeof(char), pi.out.pos, file);
						fputc('\n', file);
					}
					if (outputflags & OUT_SIGNAL_FILE)
					{
						//may contain mirc identifiers -> use // to evaluate the string
						_snprintf(mData, MIRCSTRLEN, "//.signal -n " LF_FILE " %s", pi.out.buffer);
						SendMessage(hWndmIRC, WM_USER + 200, 1, 0);
					}
				}


				if (mpegfile)
				{
					fclose(mpegfile);
					mpegfile = 0;
				}
				if (vorbisfile)
				{
					fclose(vorbisfile);
					vorbisfile = 0;
				}
			}
		}
	} while (FindNextFile(hFind, &finddata));

	FindClose(hFind);
	depth--;
}




//mircs (un)load
extern "C" void __declspec(dllexport) WINAPI LoadDll(LOADINFO *li)
{
	hWndmIRC = li->hwnd;
	li->keep = true;
	hFileMap = CreateFileMapping(INVALID_HANDLE_VALUE,0,PAGE_READWRITE,0,1024,"mIRC");
	mData = (char *) MapViewOfFile(hFileMap,FILE_MAP_ALL_ACCESS,0,0,0);

	char *str = new char[2];
	*(__int16 *)str = 0x0020;	//set to ' ', '\0';
	
	PARSER_ENTRY e1 = { parse_fname, 0 };
	PARSER_ENTRY e2 = { parse_string, str };
	PARSER_ENTRY e3 = { parse_fsize, 0 };
	parser_list.push_back(e1);
	parser_list.push_back(e2);
	parser_list.push_back(e3);
}

extern "C" int __declspec(dllexport) WINAPI UnloadDll(int timeout)
{
	if (timeout)
		return 0;

	UnmapViewOfFile(mData);
	CloseHandle(hFileMap);
	clearlist();

	return 1;
}
