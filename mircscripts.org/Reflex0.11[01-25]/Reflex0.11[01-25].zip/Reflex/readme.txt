
	IrcLink 0.1 by Cypher (allenhunt@gmail.com)
	
------------

Description:

A lightweight irc script designed for someone wanting a nice looking useable interface and a few tools to make casual chatting easier.
The extensions allow for you to add addons to the script without going through the search/extract/load process. Its just point and click so customize away ala firefox.
I'll be adding more extensions as i go :).

------------

Installation:

Put mirc.exe (6.16) into the directory this readme is in... then run.

------------

Requests:

Want an mts theme adding ?
Want a favourite addon adding ?

email allenhunt@gmail.com with the request. i'll look into it and you hopefully you'll see it in the list of downloadable themes/extensions soon.

Any other bug submissions or feature requests can also go to this email.

------------

Credits :

	kte - kamek - underlying theme engine (mts) and preview creator.
	kTools - kamek - Docking dll
	sz - GrimZ - sizing functions.
	mdx - dragonzap - extra dialog controls
	nHtmln - Necroman/Dan/FoLKeN^ - allows use of IE html rendering engine in mIRC 
	download.mrc - ^BeAsT^ - HTTP downloading.
	popup.mrc - Voice of Power - Picture Window Popups
	Theme authors and Addon Authors
	
-----------

Plans :

I plan on creating a mts2.0 engine for the next version.

What would you like to see ?

allenhunt@gmail.com