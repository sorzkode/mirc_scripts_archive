[Document]
mIRC MTS Theme (tested on NoName Script 3.70+)
Version 1.1 post final (1.0 was unfortunatly not the last version, sorry ;) )
  (fixed a reported bug, implemented a feature request)




[License]
huh? Do what you like: modify it, implement it in your script, add themes, change themes,
whatever. You could credit me though.





[Description]
Negative Entropy (NE) is a mIRC MTS theme designed to increase the readability of mIRCs output.
It does not add any fancy colours and symbols, leet stuff or whatever. Pure readability.
By default, NE separates normal text from system events (kick, modes...) and aligns nicknames for
better readability (even with proportional fonts like Tahoma).
The user can pick a timestamp mode that fits his needs or turn timestamping of entirely.




[Using Negative Entropy]
Go to your themes menu and load "negative-entropy.mts". The theme should start up using the Tahoma
font but you can pick any font from the KTE-settings (or whatever engine you use).
To change NE settings, go to your scripts menu > Themes > Theme Settings.

Use timestamp		Allows you to turn on/off timestamping

Timestamp ->		Chose between hours and minutes ([hh:mm], ie: [05:12]) and hours, minutes
			and seconds ([hh:mm:ss])

Nick space ->		Chose between Very Large, Large, Normal, Small or Very Small. This controls how much
			space will be alotted for aligned nicknames. "None" turns nick-alignment off.

Other -> Text/Event	If enabled, NE will insert an empty line between texts (/msg, /say, /me...)
         separation	and system events (mode, kick..)

Other -> Monochromatic	If enabled, NE will display all events in a low contrast grey color. This makes
	 events		Mirc's screen output a lot more readable if you don't use the separation system.

Reoptimize for <font>	NE needs to analyze the font you use if you want to use nick-alignment. Since
			this process is time-consuming (well.. milliseconds, but still...) NE will
			only do this automatically on theme load once.
			If you change mIRCs font, you'll want to run a new optimization.
			IMPORTANT: Your active window must be a status, channel or querywindow for this
			function to work!




[Event markers]
In NE, some messages and events are prefixed with the following symbols for quick recognition:

���			incoming query
���			outgoing query

n-�			incoming notice (all notices are grey)
#n�			incoming channel-wide notice
�-n			outgoing notice
�n#			outgoing channel-wide notice

c-�			incoming ctcp or ctcp.reply (all ctcps are orange)
#c�			incoming channel-wide ctcp
�-c			outgoing ctcp or ctcp.reply
�c#			outgoing channel-wide ctcp

:=			nick change 
**			mode change
##			topic change

�-?			channel invite

���			join (green)
���			part/quit (red)
��			kick (even redder :p)




[Known issues]
- font analysis currently only works in status, channel and querywindows - this includes font analysis
  on theme-load
- you cannot use different fonts for different mIRC windows or alignment will be messed up
- I did not write a fixed/new section for this readme ;) you gotta live with that or look it up at
  mircscripts.org

Feel free to report bugs or make suggestions to mail@darksaidin.de but don't expect fast bugfixes as I'm
mostly working with Linux atm.