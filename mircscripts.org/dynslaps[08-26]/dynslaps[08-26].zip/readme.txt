|Dynamic Slaps
|---
|version: 1.2
|purpuse: this makes managing popups easier
|features:
  - unlimitted entries
  - add/remove/edit abilities
  - user-friendly (imo :P)
  - (new) a little smart picwin preview generator

|---
|installation:

  /load -rs <path-to-slaps.mrc>
or load it through the scripts editor (alt + r)

|---
|usage: /slaps or through the nicklist menu

|---
|author: madson
|contact: 
  email - like2code<at>gmail<dot>com 
  irc - UniBG, #mircscripting, madson

|---
| 1.2 version updates:
  (*) fixed the menu definition. now the custom slaps are available in queries and chat sessions.
  (+) added a slap picwin preview. it will display how the slap will look. supports burc codes... thanks to zzattack for his $burcwrap() snippet... i said it before. this snippet is really useful.
      - because of the disability of detecting dialogs' positiong changes (except the timer method) i put a rclick menu on the preview with an option ot fix its position.