#include <windows.h>
#include <string.h>
#include <io.h>
#include <direct.h>
#include <sys\types.h>
#include <sys\stat.h>
#include <stdio.h>
#include <ctype.h>

#define LINE_MAX 890

char *delspace(char *data);
int countparams(char *data, int max);

char *delspace(char *data)
{
	char *data2 = data + strlen(data) -1;
	while (data2[0] == ' ')
	{
		data2[0] = 0;
		data2--;
	}
	while (data[0] == ' ')
	{
		data[0] = 0;
		data++;
	}
	return data;
}
int checkparams(char *data, int max)
{
	int i = 0, invalid = 0, count = 0, count2 = 0, count3 = 1;
	while (data[i] != 0)
	{
		if (isalnum(data[i]) || data[i] == '<')
		{
			count++;
			if (data[i] != '<')
				count2++;
			else
			{
				count3++;
				if (count3 > max)
				{
					strcpy(data,"E_TOO_MANY_PARAMS");
					return 1;
				}
				if (!count2)
					invalid = 1;
				count2 = 0;
			}
		}
		i++;
	}
	if (!count)
	{
		strcpy(data,"E_WHERE_ARE_THE_PARAMS?");
		return 1;
	}
	if (count3 < max)
	{
		strcpy(data,"E_NEED_MORE_PARAMS");
		return 1;
	}
	if (!count2 || invalid)
	{
		strcpy(data,"E_INVALID_PARAMS");
		return 1;
	}
	return 0;
}
int __stdcall info(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)
{
	strcpy(data,"<< FileManager.dll >> Author: Buddyke << Contact: scorpi_16@hotmail.com >>");
    return 3;
}
int __stdcall version(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)
{
	strcpy(data,"1.0");
	return 3;
}
int __stdcall isfile(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)
{
	char *p1;
	if (checkparams(data,1))
		return 3;
	p1 = delspace(strtok(data,"<"));
	if (access(p1,0))
	{
		strcpy(data,"$false");
		return 3;
	}
	strcpy(data,"$true");
	return 3;
}
int __stdcall get(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)
{
	char *p1, *p2;
	struct _stat stats;
	if (checkparams(data,2))
		return 3;
	p1 = delspace(strtok(data,"<"));
	p2 = delspace(strtok(NULL,"<"));
	if (_stat(p1,&stats))
	{
		strcpy(data,"E_INVALID_FILE");
		return 3;
	}
	if (!strcmp(p2,"size"))
		sprintf(data,"%ld",stats.st_size);
	else if (!strcmp(p2,"atime"))
		sprintf(data,"%ld",stats.st_atime);
	else if (!strcmp(p2,"ctime"))
		sprintf(data,"%ld",stats.st_ctime);
	else if (!strcmp(p2,"mtime"))
		sprintf(data,"%ld",stats.st_mtime);
	else if (!strcmp(p2,"write"))
	{
		if (access(p1,2))
			strcpy(data,"$false");
		else
			strcpy(data,"$true");
	}
	else if (!strcmp(p2,"read"))
	{
		if (access(p1,4))
			strcpy(data,"$false");
		else
			strcpy(data,"$true");
	}
	else if (!strcmp(p2,"r/w"))
	{
		if (access(p1,6))
			strcpy(data,"$false");
		else
			strcpy(data,"$true");
	}
	else
		strcpy(data,"E_UNKNOWN_COMMAND");
	return 3;
}
int __stdcall mode(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)
{
	char *p1, *p2;
	if (checkparams(data,2))
		return 3;
	p1 = delspace(strtok(data,"<"));
	p2 = delspace(strtok(NULL,"<"));
	if (access(p1,0))
	{
		strcpy(data,"E_INVALID_FILE");
		return 3;
	}
	if (!strcmp(p2,"write"))
	{
		if (!chmod(p1,S_IWRITE))
			strcpy(data,"S_OK");
		else
			strcpy(data,"E_PERMISSION_DENIED");
	}
	else if (!strcmp(p2,"read"))
	{
		if (!chmod(p1,S_IREAD))
			strcpy(data,"S_OK");
		else
			strcpy(data,"E_PERMISSION_DENIED");
	}
	else if (!strcmp(p2,"r/w"))
	{
		if (!chmod(p1,S_IREAD | S_IWRITE))
			strcpy(data,"S_OK");
		else
			strcpy(data,"E_PERMISSION_DENIED");
	}
	else
		strcpy(data,"E_UNKNOWN_COMMAND");
	return 3;
}
int __stdcall createf(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)
{
	char *p1, *p2;
	FILE *FileP;
	if (checkparams(data,2))
		return 3;
	p1 = delspace(strtok(data,"<"));
	p2 = delspace(strtok(NULL,"<"));
	if (!access(p1,0))
	{
		strcpy(data,"E_FILE_EXISTS");
		return 3;
	}
	FileP = fopen(p1,"w");
	if (!FileP)
	{
		strcpy(data,"E_FAILED");
		return 3;
	}
	fclose(FileP);
	if (!strcmp(p2,"write"))
	{
		chmod(p1,S_IWRITE);
		strcpy(data,"S_OK");
	}
	else if (!strcmp(p2,"read"))
	{
		chmod(p1,S_IREAD);
		strcpy(data,"S_OK");
	}
	else if (!strcmp(p2,"r/w"))
	{
		chmod(p1,S_IWRITE | S_IREAD);
		strcpy(data,"S_OK");
	}
	else
		strcpy(data,"E_UNKNOWN_MODE");
	return 3;
}
int __stdcall deletef(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)
{
	char *p1;
	if (checkparams(data,1))
		return 3;
	p1 = delspace(strtok(data,"<"));
	if (access(p1,0))
	{
		strcpy(data,"E_INVALID_FILE");
		return 3;
	}
	if (!remove(p1))
		strcpy(data,"S_OK");
	else
		strcpy(data,"E_READ_ONLY_FILE");
	return 3;
}
int __stdcall renamef(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)
{
	char *p1, *p2;
	if (checkparams(data,2))
		return 3;
	p1 = delspace(strtok(data,"<"));
	p2 = delspace(strtok(NULL,"<"));
	if (access(p1,0))
	{
		strcpy(data,"E_INVALID_OLD_FILE");
		return 3;
	}
	if (!access(p2,0))
	{
		strcpy(data,"E_NEW_FILE_EXISTS");
		return 3;
	}
	rename(p1,p2);
	strcpy(data,"S_OK");
	return 3;
}
int __stdcall searchf(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)
{
	unsigned int lineN = 0, count = 0, opt = 0, length, p4;
	char *p1, *p2, *p3, *s1, *s2, lineV[LINE_MAX];
	FILE *FileP;
	if (checkparams(data,4))
		return 3;
	p1 = delspace(strtok(data,"<"));
	p2 = delspace(strtok(NULL,"<"));
	p3 = delspace(strtok(NULL,"<"));
	p4 = atoi(delspace(strtok(NULL,"<")));
	if (access(p1,0))
	{
		strcpy(data,"E_INVALID_FILE");
		return 3;
	}
	if (strcmp(p2,"l") && strcmp(p2,"ml") && strcmp(p2,"mw"))
	{
		strcpy(data,"E_UNKNOWN_OPTION");
		return 3;
	}
	if (p3[0] == '*')
	{
		opt++;
		p3[0] = 0;
		p3++;
	}
	if (p3[strlen(p3) -1] == '*')
	{
		opt += 2;
		p3[strlen(p3) -1] = 0;
	}
	length = strlen(p3);
	FileP = fopen(p1,"r");
	if (!FileP)
	{
		strcpy(data,"E_FAILED_TO_OPEN_FILE");
		return 3;
	}
	if (!p4)
		strcpy(data,"0");
	else
		data[0] = 0;
	while (fgets(lineV,912,FileP))
	{
		lineV[strlen(lineV) -1] = 0;
		lineN++;
		if (opt == 0 && !strcmp(lineV,p3))
		{
			count++;
			if (!p4)
				sprintf(data,"%ld",count);
			else if (p4 == count)
			{
				sprintf(data,"%ld ",lineN);
				strcat(data,lineV);
				break;
			}
		}
		if (opt == 1 && !strcmp(&lineV[strlen(lineV) - length],p3))
		{
			count++;
			if (!p4)
				sprintf(data,"%ld",count);
			else if (p4 == count)
			{
				if (!strcmp(p2,"l") || !strcmp(p2,"ml") || length == strlen(lineV))
					s1 = &lineV[0];
				else
				{
					s1 = &lineV[strlen(lineV) - length];
					while (!isspace(s1[-1]) && s1 != &lineV[0])
						s1--;
				}
				sprintf(data,"%ld ",lineN);
				strcat(data,s1);
				break;
			}
		}
		if (opt == 2 && !strncmp(lineV,p3,length))
		{
			count ++;
			if (!p4)
				sprintf(data,"%ld",count);
			else if (p4 == count)
			{
				if (!strcmp(p2,"mw"))
				{
					s2 = &lineV[length];
					while (!isspace(s2[0]) && s2[0] != 0)
						s2++;
					s2[0] = 0;
				}
				sprintf(data,"%ld ",lineN);
				strcat(data,lineV);
				break;
			}
		}
		if (opt == 3)
		{
			s1 = &lineV[0];
			s2 = &lineV[length];
			while (s2[-1] != 0)
			{
				if (!strncmp(s1,p3,length))
				{
					count++;
					if (!strcmp(p2,"l"))
					{
						s1 = &lineV[0];
						break;
					}
					else if (p4 == count)
					{
						if (!strcmp(p2,"ml"))
							s1 = &lineV[0];
						else
						{
							while (!isspace(s1[-1]) && s1 != &lineV[0])
								s1--;
							while (!isspace(s2[0]) && s2[0] != 0)
								s2++;
							s2[0] = 0;
						}
						break;
					}
				}
				s1++;
				s2++;
			}
			if (!p4)
				sprintf(data,"%ld",count);
			else if (p4 == count)
			{
				sprintf(data,"%ld ",lineN);
				strcat(data,s1);
				break;
			}
		}

	}
	fclose(FileP);
	return 3;
}
