
>> FileManager.dll
>> Author: Buddyke
>> version: 1.0
>> contact: scorpi_16@hotmail.com

This is my first serious attempt on creating a dll, so i hope i did well :)
Any comments, bugs, suggestions, ... are welcome.
To see what it can do, check the functions.

Install
-------
Extract the file anywhere you want.

Use
---

dll(path\to\filemanager.dll,function,option1<option2<option3<...)
/dll path\to\filemanager.dll function option1<option2<option3<...

Functions
---------

1. info : returns info about the dll > $dll(filemanager,info,)

2. version : returns the dll's version > $dll(filemanager,version,)

3. isfile : returns $true if the specified file exists, $false otherwise > $dll(filemanager,isfile,filename.ext)

4. get : returns the size of the file > $dll(filemanager,get,filename.ext<size)
         returns the time of last access > $dll(filemanager,get,filename.ext<atime)
         returns the time of creation > $dll(filemanager,get,filename.ext<ctime)
         returns the time of last modification > $dll(filemanager,get,filename.ext<mtime)
         returns $true if you have access to read the file, $false otherwise > $dll(filemanager,get,filename.ext<read)
         returns $true if you have access to write in the file, $false otherwise > $dll(filemanager,get,filename.ext<write)
         returns $true if you have access to read and write in the file, $false otherwise > $dll(filemanager,get,filename.ext<r/w)

5. mode : changes the file-access to read-only > $dll(filemanager,mode,filename.ext<read)
          changes the file-access to write > $dll(filemanager,mode,filename.ext<write)
          changes the file-access to read and write > $dll(filemanager,mode,filename.ext<r/w)

6. createf : creates a file to read-only > $dll(filemanager,createf,filename.ext<read)
             creates a file to write > $dll(filemanager,createf,filename.ext<write)
             creates a file ro read and write > $dll(filemanager,createf,filename.ext<r/w)

7. deletef : deletes the specified file > $dll(filemanager,deletef,filename.ext)

8. renamef : renames the specified file > $dll(filemanager,renamef,oldfilename.ext<newfilename.ext)

9. searchf : searches the file line by line for a matching text and returns the whole line > $dll(filemanager,searchf,filename.ext<l<*wildcard text*<N)
             searches the file word by word for a matching text and returns the whole line > $dll(filemanager,searchf,filename.ext<ml<*wildcard text*<N)
             searches the file word by word for a matching text and returns the words > $dll(filemanager,searchf,filename.ext<mw<*wildcard text*<N)
             (if N = 0, it returns the number of all matching values, otherwise it returns the line-number folowed by the line of the Nth matching value)

PS1: If you don't specify any path to a filename, the dll will take your mirc.exe's path as default.
PS2: The size of the file is returned in bytes.
PS3: Times are always returned in seconds elapsed since 00:00:00 GMT, January 1, 1970