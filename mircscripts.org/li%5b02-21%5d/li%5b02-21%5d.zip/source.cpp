/* 	Transparent Making 
	DLL by li.
	Ripping is lame.
	Visit me at Quakenet #li -> nick:li
*/
 	
#define _WIN32_WINNT 0x0500
#include <windows.h>

#ifndef WS_EX_LAYERED 
#define WS_EX_LAYERED			0x00080000 
#endif 
#ifndef LWA_ALPHA 
#define LWA_ALPHA				0x00000002 
#endif 
#ifndef LWA_COLORKEY
#define LWA_COLORKEY 0x00000001
#endif

HMODULE hUser32 = GetModuleHandle("USER32.DLL");

HANDLE hFileMap;
LPSTR mData;

HWND mIRC = FindWindowEx(0,0,"mIRC",0);

extern "C"
{

void WINAPI LoadDll(void*)
{
	if (!mIRC) MessageBox(0,"mIRC not Started or modified",0,0);
	else MessageBox(mIRC,"Sucessfully injected in class: 'mIRC'",0,0);

	hFileMap = CreateFileMapping(INVALID_HANDLE_VALUE,0,PAGE_READWRITE,0,4096,"mIRC");	
	mData = (LPSTR)MapViewOfFile(hFileMap,FILE_MAP_ALL_ACCESS,0,0,0);
}

int WINAPI UnloadDll(int timeout)
{
	timeout = 5;
	if (!timeout)
	{
		MessageBox(mIRC,"Sucessfully Unloaded",0,0);
		UnmapViewOfFile(mData);
		CloseHandle(hFileMap);
	}
	return 0;
}

int WINAPI TitleSet(HWND mWnd,HWND aWnd,char *data,char*,BOOL,BOOL)
{

	if (mWnd)
	{
		SetWindowText(mIRC,data);
	}
	return 0;
}

int WINAPI trans(HWND mWnd,HWND aWnd,char *data,char*,BOOL,BOOL)
{
	
if (mWnd) 
{
 
	SetWindowLong(
			  mWnd,
			  GWL_EXSTYLE,
						GetWindowLong(
										mWnd,
										GWL_EXSTYLE)
			  |WS_EX_LAYERED );

	SetLayeredWindowAttributes( 
						   mWnd,
						   0,
						   atoi(data),
						   LWA_ALPHA 
						   );
} else {
	MessageBox(mIRC,"mWnd not found",0,MB_OK);
}
return 0;
}

}