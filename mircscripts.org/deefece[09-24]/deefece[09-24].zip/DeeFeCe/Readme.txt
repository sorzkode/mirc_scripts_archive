
Author: AnTr0
E-mail: antr0@terra.com.ar

My english is poor to explain my future plans about this theme, but I whant to try:

* Translate the theme to other languages. If you want to contribute e-mail me.
* Add more schemes. If you make a good scheme e-mail me, and if I like the scheme I will include
  it in the next version of the theme.

Well this are all the things I want in the next version.


                            Sorry about my broken english

