first you have to make sure the files mp3p.mrc and mp3p2.mrc are
both in the main part of your mIRC folder where all the folders and
the file "mirc.ini" would be.

then type /load -rs mp3p.mrc
that's it!
have fun

!!WARNING!!
this version only works with mIRC 5.8 and above.. and...DO NOT DELETE PLAYLIST.TXT