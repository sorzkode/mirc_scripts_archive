============================
=                          =
= Soul-Cursor DLL v1.6     =
=                          =
= by Soul_Eater            =
============================

The purpose of this DLL is to change various window cursors within mIRC.
It can however, also be used as a plugin for MTS 2.0
When MTS 2.0 plugin code is finalized, it will be provided in this readme


Filenames MUST be .ico or .ani


Function:

-SwitchCursor

Use: //echo -a $dll(soulcursor.dll,SwitchCursor,filename)

Purpose: Changes the switchbar cursor to the specified filename

Example: //echo -a $dll(soulcursor.dll,SwitchCursor,c:\mirc\cool.ico)

-ToolCursor

Use: //echo -a $dll(soulcursor.dll,ToolCursor,filename)

Purpose: Changes the toolbar cursor to the specified filename

Example: //echo -a $dll(soulcursor.dll,ToolCursor,c:\mirc\cool.ico)

-ScrollCursor

Use: //echo -a $dll(soulcursor.dll,ScrollCursor,filename)

Purpose: Changes the main scrollbar cursor to the specified filename

Example: //echo -a $dll(soulcursor.dll,ScrollCursor,c:\mirc\cool.ico)

-NormalCursor

Use: //echo -a $dll(soulcursor.dll,NormalCursor,status|channel|mdi > filename)

Purpose: Changes the normal cursor of the mdi window, channel window, 
or status window to the specified filename

mdi = mdi client window
channel = channel window
status = status window

Example: //echo -a $dll(soulcursor.dll,ScrollCursor,mdi > c:\mirc\cool.ico)

-OtherCursor

Use: //echo -a $dll(soulcursor.dll,OtherCursor,hwnd > filename)

Purpose: Changes the specified hwnd's cursor

Example: //echo -a $dll(soulcursor.dll,OtherCursor,$window($active).hwnd > c:\mirc\cool.ico)


-DllInfo

Use: //echo -a $dll(soulcursor.dll,DllInfo,.)

Returns info about the DLL & goes to the author's homepage


Contact info:

SoulEata on AIM

Email: SoulEata@mircthemes.com

http://www.freewebz.com/souleata

