Transfer Manager 1.0
---------------------

Description:

The Transfer Manager basically does as is named it tells you various information on your
current transfers you have going in mirc i hope you find it helpful.



Installation:

1) Extract the folder "TransferManager" to your main mirc directory

2) Type //load -rs TransferManager\trans.mrc

3) Access from menubar or channel menu under option Transfer Wizard

Easy as 1,2,3


Created By NightMare