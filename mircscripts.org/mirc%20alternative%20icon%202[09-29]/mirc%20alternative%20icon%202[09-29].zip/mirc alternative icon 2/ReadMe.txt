mIRC alternative icon 2
------------------------

Hai again... Thanx for downloading this icon collection.
Firstly, I didnt think to making more icons when posted the last one
but hey guess what? Ive made more this time :P 

Well Im still stick with the name 'mIRC alternative icon' coz
dont even try to find other name :P

This time, its came with a subject where this one Ive make it based
on the 'C' character of original mIRC icon.

There's will be 5 different thing which is:

mIRCsmile - smile... you using mIRC
mIRCpirate - the 'c' become pirate
mIRCsanta - is it christmas already??
mIRCpumpkins - when is halloween?
mIRCpolice - dude, youre being arrest!


Its come in .bmp, .ico, .gif and .png with a 32x32 dimension.

If you like this thing then use it when ever you want, if not then you can deleted it :P

Do anything you like with it either use it on your script, on your website or anything,
anyplace and anytime since its a free to use :p Its up to you!

Last thing ENJOY it!

zonIRC