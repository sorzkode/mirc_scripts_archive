
      
     :: s.Winamp Control Script by Seldaek v2.7 ::
        ���������������������������������������

     :: Install ::
        �������
!!! If you already have another version installed, do not uninstall it, just install the new and it'll be deleted but you'll keep your configuration !!!
- Unzip s_WinampControl_v2_7.mrc, WC2.dll and all .wc2 language files into your mIRC directory.
- Type "/load -rs s_WinampControl_v2_7.mrc" in the mIRC window and click YES when you're asked.

     :: Contact ::
        �������
Web : http://www.sscripts.be.tf/
ICQ : 38559737
Mail: seldaek@hotmail.com
MSN : seldaek@hotmail.com
IRC : #sscripts @ irc.quakenet.org

     :: Helpfile ::
        ��������
Connect to http://www.sscripts.be.tf/ and look into the "Script>Winamp Control" Section.

     :: Changelog ::
        ���������
 -2.7-
  - 'Time showing 00:00' bug fixed. (i hope)
  - Added multilanguage support for Options dialog and Right-clic menus.
  - Added "say it!" button into the remote controller, works like Right clic>Winamp Control>Say Current Song
  - DCC Send is limited to one send per user at a time. (anti !get spam)
  - winampcontrolv2.ini is now using $scriptdir !

 -2.6-
  - The infos can now be displayed on more than one line using ";" as a line breaker.
  - Added field to set your own "winamp not playing" message.

  - Changed time format. (will now display 2digits, 00:00:00 instead of 0:0:00)
  - Alarm Clock now allow user to edit active alarms.
  - Bug Fix. (thx to Jan Soelter)
  - Added !FN (File Name) info.
  - Added ability to display the track at a defined interval (ex: every 10mins)

 -2.5-
  - Added !MS (Mono/Stereo) info.
  - Added !EX (File Extension) info.
  - Script can now handle file longer than one hour.
  - Bug Fixes.
  - Script now save titlebar while installing for the first time and restore it when uninstalling.
  - Added option to disable titlebar update on track change.

 -2.4-
  - Added Remote Controler to control winamp from irc with all the main stuff..
  - Added ability to configure the keys. (to say/echo the track you're playing, to open alarm clock dialog and to open Remote Control)
  - Added option to send automatically the tracks only to ONE defined channel.
  - Rebuild of some dialogs/right-clic menus.