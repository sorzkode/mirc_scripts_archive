mIRC-Greets v1.0
Created by: Ken^neth

Introduction
=============
mIRC-Greets is a simple addon for you to manage your Auto-Greet Messages for your friends.
With a channel filter, you don't have to worry about your messages appearing in channels you
don't want them to. You can also format your greet messages any way you want using the
MSG formatter.

To install
==========
To install this addon, make sure the mdx & dll files(view.mdx,dialog.mdx,mdx.dll,popread.dll) 
in the MDX Directory in your mIRC folder and the  /load -rs mgreet.mrc in your mIRC 
to install. Make sure the MDX directory & the Greets Directory(icons) is in your mIRC Folder
too. :)

note: the MDX directory is also required even if you already have MDX in your mirc
directory as the version of MDX may differ and cause problems in the dialog.

How To Use the Msg Formatter
===========================
It's kinda like html. Use the <c>(Color),<b>(Bold),<u>(Underline) tags like you normally do
with ctrl+k,ctrl+b,ctrl+u. <nick> stands for the nick who joined and <channel> is the channel
the person joined. <greeting> holds your greet message for the person.


Contact
=======
E-mail/IM me @ okenneth89o@hotmail.com
Chat with me on irc.mediadriven.sytes.net, look for me in #nohacks or #bobthebuilder

Credits
=======
Khaled - mIRC Creator =O 
#nohacks - For comments and stuff