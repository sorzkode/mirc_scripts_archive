  _           _          _     _   _   _
 | |__  _   _| |__  _ __(_) __| | | |_| |__   ___ _ __ ___   ___
 | '_ \| | | | '_ \| '__| |/ _` | | __| '_ \ / _ \ '_ ` _ \ / _ \
 | | | | |_| | |_) | |  | | (_| | | |_| | | |  __/ | | | | |  __/
 |_| |_|\__, |_.__/|_|  |_|\__,_|  \__|_| |_|\___|_| |_| |_|\___|
        |___/ _                 _                    _
             | |__  _   _    __| |_ __ _____   _____| | ___
             | '_ \| | | |  / _` | '__/ _ \ \ / / _ \ |/ _ \
             | |_) | |_| | | (_| | | |  __/\ V /  __/ |  __/
             |_.__/ \__, |  \__,_|_|  \___| \_/ \___|_|\___|
                    |___/
this is the final release! prob not 100% but its sweet!
_____________________________________________________________________
info:
theme: hybrid
files: hybrid.mts/hybrid.mrc
maker: jeff johnson
email: jeff@jeffsworld.net
nick: drevele
server: realnet.servirc.com
my host is: *.zoominternet.net
or: *.Amcool.net
or: Local.USA.Ohio.Medina.Con-oc12.L33t.Hosting.jeffsworld.net
my ident always has ~
if that matters
website: http://www.jeffsworld.net/
based on: mIRC
made with: KTE Theme Editor
tested with KTE 1.5
mIRC Version: 6.03
MTS Version: 1.1
Report all bugs to JeffJohnson@ZoomInternet.net
because jeff@jeffsworld.net gose d0wn!
mts theme version: 1