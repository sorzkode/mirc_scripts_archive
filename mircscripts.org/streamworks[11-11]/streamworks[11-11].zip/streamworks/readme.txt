mIRC MP3 StreamWorks v1.8 by Cynagen

Contents:
-----
1. Installation
2. Credits
3. Intro
4. How it works
5. System requirements (READ THEM!)


1. Installation
-----
To install StreamWorks, just put the file streamworks.mrc into the main folder of mIRC.
I suggest installing a second copy of mIRC for this script and copying the file there.
Once you have mIRC open and the file in the folder, type /load -rs streamworks.mrc
StreamWorks can run right "out of the box" using C:\ as it's MP3 serve folder.
Check the commands menu or rightclick in a Status window for the StreamWorks menu.


2. Credits
-----
Thanks to KXRM for the metadata technical specs
Thanks to all who helped me test it along the way
And Thanks to all those that submit to mircscripts.org for such inspiration!


3. Intro
-----
mIRC MP3 StreamWorks is a Winamp native built mp3 streaming server built from scratch.
It's design is mainly for use on local intranets (LANs). StreamWorks can run on the net.
Downloading of the songs is expressly disabled for a reason and SHOULD NOT be enabled!
Please view the script's internal disclaimer page via a browser.
Do not abuse the use of this script. Thank you. Have fun listening!


4. How it works
-----
This server is quite simple really... here...
When a user makes a direct call to the server (http://127.0.0.1:6000/) it gives an artist listing.
The user can then browse each artist individually for songs they wish to listen to...
After they find a song they wish to listen to, they click the link and a small playlist is downloaded...
The appropriate player automatically opens and handles playing the file for the user.

The internals of how the mp3 is streamed is binary reading, then writing to the socket in binary... simple :)
It's a bit more complicated to explain the MetaData system but here's the basic...
The server hands over 4096 bytes of MP3 data to the player, then the MetaData for the song...
The server continues switching back and forth sending MP3-Meta-MP3-Meta-MP3-Meta

The server is loosely based on the SHOUTcast technologies by NullSoft Inc. (http://shoutcast.com/)
And as such is 100% compatible with any player capible of playing SHOUTcast streams...

5. System Requirements
-----
(These are rough estimates... but pay attention to them!)
Pentium 3 1Ghz or AMD Duron 1Ghz or better
256mb RAM (or 128mb DDRRAM)
DSL/Cable (internet streaming)
Local Area Network (network streaming)