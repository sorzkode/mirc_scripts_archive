/*
	WhileFix.cpp 
	Main Source WhileFix.dll
*/

#include <windows.h>
// Warning Disable time
// due to strsafe being important by W_FindFile.h all the old krappy str copy functions are deprecated causeing
// many many retarded warnings; good practice is to update to the new stuff; however, with file mappings im just
// as well off useing wsprintf and with csArray.h i know the buffers are big enough so its ok
#pragma warning(disable : 4995)
#include "csArray.h"
#include "W_FindFile.h"

typedef struct {
    DWORD  mVersion;
    HWND   mHwnd;
    BOOL   mKeep;
} LOADINFO;

BOOL APIENTRY DllMain( HANDLE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved )
{
	switch(ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		break;
	case DLL_PROCESS_DETACH:
		break;
	}
    return TRUE;
}

void _stdcall LoadDll(LOADINFO *load)
{
	hFileMap	= CreateFileMapping(INVALID_HANDLE_VALUE,0,PAGE_READWRITE,0,0x4000,"mIRC");
	mData		= (LPSTR)MapViewOfFile(hFileMap,FILE_MAP_ALL_ACCESS,0,0,0);
	aThreads.Resize(0);
}

int _stdcall UnloadDll(int mTimeOut)
{
	// in the extreamly unlikely event you have a shitty enough computer to have 
	// thread searching for ten minutes your screwed... its being terminated
	// i was going to try to catch and return 0 to keep it loaded but it proved pointless
	// PS if you actually have this happen... get a new computer... cause damn
	for (int i = 1;i <= aThreads.GetCount();i++)
	{
		LPTHREAD thread = (LPTHREAD)aThreads.GetCell(i);
		TerminateThread(thread->hThread,1);	// terrible idea dont ever do this but if you were stupid enough to unload the dll
											// while it was working then we must do what we must do to prevent a catastrophe
		delete thread;
	}

	UnmapViewOfFile(mData);
	CloseHandle(hFileMap);
	mData = 0;
	hFileMap = 0;
	return 1;
}
int __stdcall W_FindFile(HWND mWnd, HWND aWnd, char *data, char *params, BOOL show, BOOL nopause)
{
	csArray *ar = new csArray(data);
	if (ar->getCount() < 4)
	{
		delete ar;
		wsprintf(data,"WF_ERROR 1 Invalid Parameters");
		return 3;
	}
	LPTHREAD th = new THREAD;
	ZeroMemory(th,sizeof(THREAD));
	DWORD dw;

	ar->eXtra = (LPARAM)mWnd;
	
	HANDLE hWrk = CreateThread(NULL,0,SearchTime,(LPVOID)ar,0,&dw);
	th->hThread = hWrk;
	th->iID = dw;
	th->iClose = 0;
	th->iCell = aThreads.AddCell((LPARAM)th);

	ar->lpUser = (LPARAM)th;
	
	wsprintf(data,"S_OK %ld",dw);
	return 3;
}
LPTHREAD GetAThread(DWORD id)
{
	for (int i = 1;i <= aThreads.GetCount();i++)
	{
		LPTHREAD thread = (LPTHREAD)aThreads.GetCell(i);	
		if (thread->iID == id)
			return thread;
	}
	return NULL;
}
int _stdcall W_FindFileFORCEEXIT(HWND mWnd, HWND aWnd, char *data, char *params, BOOL show, BOOL nopause)
{
	DWORD threadID = atol(data);
	LPTHREAD lpThread = GetAThread(threadID);

	if (!lpThread)
	{
		wsprintf(data,"S_ERROR Invalid ID");
		return 3;
	}

	lpThread->iClose = 1;
	wsprintf(data,"S_OK Thread Closeing");
	return 3;
}
int __stdcall WhileFix(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)
{
	MSG msg;
	PeekMessage(&msg,NULL,0,0,PM_REMOVE);
	TranslateMessage(&msg);
	DispatchMessage(&msg);
	if (msg.message == WM_QUIT)
	{
		PostQuitMessage((int)msg.wParam);
		return 0;
	}
	return 1;
}
int __stdcall Version(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)
{
	wsprintf(data,"WhileFix.dll - Version 3.0.1");
	return 3;
}
