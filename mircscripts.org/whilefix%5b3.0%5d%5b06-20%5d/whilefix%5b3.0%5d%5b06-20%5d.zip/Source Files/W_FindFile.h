/*
	I made it into its own header
	i didnt feel like messing up WhileFix.cpp
	and its simplistic nature (:
*/

#define WM_MCOMMAND (WM_USER + 200)

#include <arrays.h>
#include <shlwapi.h>

#pragma comment(lib,"shlwapi.lib")

HANDLE hFileMap = NULL;
char *mData		= NULL;
Array aThreads;

typedef struct tagTHREAD
{
	DWORD iID;
	HANDLE hThread;
	int iClose;
	int iCell;
}THREAD, *LPTHREAD;

// note the use of __fastcall directive, its an attempt to speed up the dll since fastcall pushs args onto registers if possible... sometimes helps most of the time its kinda immaterial
bool __fastcall CheckDot(const char *string)
{
	if (!strcmpi(string,"."))
		return true;
	if (!strcmpi(string,".."))
		return true;
	return false;
}

int __fastcall wildcmp(const char *wild, const char *string) {
  // Written by Jack Handy - <A href="mailto:jakkhandy@hotmail.com">jakkhandy@hotmail.com</A>
  
  // ill be honest with you i got this from code project... it wasnt gonna happen otherwise...
  // this was too wierd for me to take the time to codem, i gotta give him props on this cause otherwise
  // my find file wasnt going to include wildcards... that woulda sucked wouldnt it of? lol

  // MY MODIFICATION //
  // keeps me from comparing and outputting . and ..
  if (CheckDot(string))
	  return 0;
  // MY MODIFICATION //

  register const char *cp = NULL, *mp = NULL;

  while ((*string) && (*wild != '*')) {
    if ((*wild != *string) && (*wild != '?')) {
      return 0;
    }
    wild++;
    string++;
  }

  while (*string) {
    if (*wild == '*') {
      if (!*++wild) {
        return 1;
      }
      mp = wild;
      cp = string+1;
    } else if ((*wild == *string) || (*wild == '?')) {
      wild++;
      string++;
    } else {
      wild = mp;
      string = cp++;
    }
  }

  while (*wild == '*') {
    wild++;
  }
  return !*wild;
}

void __fastcall CheckOut(csArray *ar, int iFile)
{
	if ((ar->getCount() <= 4) || (ar->isSwitch('l')))
		SendMessage((HWND)ar->eXtra,WM_MCOMMAND,NULL,NULL);
	else
	{
		int limit = atoi(ar->getString(4));
		if (iFile == limit)
			SendMessage((HWND)ar->eXtra,WM_MCOMMAND,NULL,NULL);
	}
}

bool __fastcall CheckLimit(csArray *ar, int current)
{
	if (ar->getCount() > 4)
	{
		int limit = atoi(ar->getString(4));
		if ((current > limit) && (limit != 0))
			return true;
		return false;
	}
	return false;
}
// easily checks to see if thread should begin exiting
bool __fastcall CheckClose(csArray *ar) 
{ 
	if (((LPTHREAD)ar->lpUser)->iClose) 
		return true; 
	return false;
}
void __fastcall ScanDir(char *orig, char *cDir, csArray *ar, int *iDepth, int *iFile)
{
	if (*iDepth == 0)
		return;
	*iDepth = *iDepth - 1;	// subtract a depth

	char nDir[MAX_PATH + 5];
	wsprintf(nDir,"%s\\%s\\*",orig,cDir);

	// Mem hog since i haveta do it twice but one is for th new find the next is if i haveta keep searching deeper
	char pDir[MAX_PATH + 5];
	wsprintf(pDir,"%s\\%s",orig,cDir);

	// We basicly now repeat what we did in SearchTime to recursively call this on all directories until we are outa depth
	WIN32_FIND_DATA data;
	ZeroMemory(&data,sizeof(data));
	HANDLE fSearch;

	fSearch = FindFirstFile(nDir,&data);
	if (fSearch == INVALID_HANDLE_VALUE)
	{
		FindClose(fSearch);
		return; // dont message the user just know something went wrong... though it shoudlnt ever.
	}
	
	// i dont really know if this is neccessary right here but i dont feel like doing the checking to find out
	if (CheckLimit(ar,*iFile) || CheckClose(ar))
		return;

	if (((data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY) && (!CheckDot(data.cFileName)))
	{
		ScanDir(pDir,data.cFileName,ar,iDepth,iFile);	// recurse back into this fn
	}
	else if (wildcmp(ar->getString(1),data.cFileName))
	{
		wsprintf(mData,"//%s WF_SEARCH %i %s\\%s",ar->getString(3),*iFile,pDir,data.cFileName);
		CheckOut(ar,*iFile);
		*iFile = *iFile + 1;
	}

	for (BOOL bNext = FindNextFile(fSearch,&data);((bNext) && (!CheckLimit(ar,*iFile)) && (!CheckClose(ar)));bNext = FindNextFile(fSearch,&data))
		if (((data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY) && (!CheckDot(data.cFileName)))
		{
			ScanDir(pDir,data.cFileName,ar,iDepth,iFile);	// recurse back into this fn
		}
		else if (wildcmp(ar->getString(1),data.cFileName))
		{
			wsprintf(mData,"//%s WF_SEARCH %i %s\\%s",ar->getString(3),*iFile,pDir,data.cFileName);
			CheckOut(ar,*iFile);
			*iFile = *iFile + 1;
		}

	FindClose(fSearch);

	*iDepth = *iDepth + 1;	// add one back
}

DWORD WINAPI SearchTime(LPVOID lpParam) 
{ 
	csArray *ar = (csArray *)lpParam;
	ar->parseSwitchs();
	PathRemoveBackslash(ar->getString(0));

	char *path = ar->getString(0);
	GetShortPathName(path,path,(DWORD)(strlen(path) + 1));

	WIN32_FIND_DATA data;
	ZeroMemory(&data,sizeof(data));
	HANDLE fSearch;

	char tDir[MAX_PATH + 5];
	ZeroMemory(tDir,sizeof(char) * (MAX_PATH + 5)); // good practice

	wsprintf(tDir,"%s\\*",path);
	fSearch = FindFirstFile(tDir,&data);

	int iFile = 1, iDepth = atoi(ar->getString(2));

	if (fSearch == INVALID_HANDLE_VALUE)
	{
		FindClose(fSearch);
		wsprintf(mData,"//%s WF_SERROR 0",ar->getString(3));
		SendMessage((HWND)ar->eXtra,WM_MCOMMAND,NULL,NULL);
		return 1;
	}
	
	// a limit of 0 will not be enforced and just keeps anything from being outputted except the total files
	if (((data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY) && (!CheckDot(data.cFileName)))
	{
		ScanDir(ar->getString(0),data.cFileName,ar,&iDepth,&iFile);
	}
	else if (wildcmp(ar->getString(1),data.cFileName))
	{
		wsprintf(mData,"//%s WF_SEARCH %i %s\\%s",ar->getString(3),iFile,ar->getString(0),data.cFileName);
		CheckOut(ar,iFile);
		iFile++;
	}
	
	for (BOOL bNext = FindNextFile(fSearch,&data);((bNext) && (!CheckLimit(ar,iFile)) && (!CheckClose(ar)));bNext = FindNextFile(fSearch,&data))
		if (((data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY) && (!CheckDot(data.cFileName)))
		{
			ScanDir(ar->getString(0),data.cFileName,ar,&iDepth,&iFile);
		}
		else if (wildcmp(ar->getString(1),data.cFileName))
		{
			wsprintf(mData,"//%s WF_SEARCH %i %s\\%s",ar->getString(3),iFile,ar->getString(0),data.cFileName);
			CheckOut(ar,iFile);
			iFile++;
		}

	wsprintf(mData,"//%s WF_SDONE %i",ar->getString(3),iFile - 1);
	SendMessage((HWND)ar->eXtra,WM_MCOMMAND,NULL,NULL);
	FindClose(fSearch);
	LPTHREAD thread = (LPTHREAD)ar->lpUser;
	CloseHandle(thread->hThread);
	aThreads.DelCell(thread->iCell);
	delete thread;
	delete ar;
    return 1; 
} 
