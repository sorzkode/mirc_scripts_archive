/*
	csArray.h
	Easy array for me to do char **
	this keeps us from leaking etc
*/
#include <arrays.h>
#include <strsafe.h>

class csArray
{
private:
	char **array;
	char *switchs;

	int iCount;
	bool bSwitch;

	void csPop(int iIndex);
	void freeArray(void);
public:
	csArray(char *in);
	~csArray(void);

	LPARAM eXtra;				// stores a pointer to eXtra information
	LPARAM lpUser;				// another storage pointer provided to the user

	int addString(char *string);
	char *getString(int count);

	bool parseSwitchs(char cSwitch = '-');
	bool isSwitch(char cSwitch);

	int getCount(void);
};

csArray::csArray(char *in)
{
	Array tempHold;
	tempHold.Resize(0);

	iCount = 0;
	int len = (int)strlen(in);

	bool bQuote = false, jQuoted = false;

	int last = 0;
	for (int i = 0; i <= len; i++)	// we also do <= len such that it gets \0
		if (in[i] == '"')
			if (!bQuote)	// we have happend upon quoted text
			{
				last = i+1;
				bQuote = true;
			}
			else			// we are finishing up quoted text
			{
				bQuote = false;
				jQuoted = true;
				int iSize = (i-1)-last;
				char *string = new char[iSize+2];
				StringCchCopyN(string,iSize+2,&in[last],iSize);
				tempHold.AddCell((LPARAM)string);
				last = i+2;	// assume there is a space after 
			}
		else if (((in[i] == 32) || (in[i] == '\0')) && (!jQuoted) && (!bQuote))
		{
			int iSize = i-last;		
			char *string = new char[iSize+2];
			StringCchCopyN(string,iSize+2,&in[last],iSize);
			tempHold.AddCell((LPARAM)string);
			last = i+1;
		}
		else
			jQuoted = false;

		iCount = tempHold.GetCount();
	array = new char*[iCount];	// makes an array of char *
	for (int i = 0; i < iCount; i++)
	{
		char *string = (char *)tempHold.GetCell(i+1);
		array[i] = string;
	}

	eXtra = NULL;
	bSwitch = false;
}

int csArray::addString(char *string)
{
	array = (char **)realloc(array,sizeof(char *) * iCount + 1);
	iCount++;
	array[iCount-1] = new char[strlen(string) + 1];
	strcpy(array[iCount-1],string);
	array[iCount-1][strlen(string)] = '\0';
	return iCount-1;
}

char *csArray::getString(int count)
{
	if ((count + 1) > iCount)
		return "Invalid";
	return (char *)array[count];
}

// Note it only supports one cell full of switchs and not two seperate types of switchs like -ab +cd
bool csArray::parseSwitchs(char cSwitch)
{
	for (int i = 0; i < iCount; i++)
	{
		if ((array[i][0] == cSwitch) && ((array[i][1] > 65) && (array[i][1] < 122)))
		{
			char *string = array[i];
			bSwitch = true;
			switchs = new char[strlen(string) + 1];
			strcpy(switchs,string);
			csPop(i);
			return true;
		}
	}
	return false;
}
bool csArray::isSwitch(char cSwitch)
{
	if (!bSwitch)
		return false;
	int len = (int)strlen(switchs);
	for (int i = 0; i < len; i++)
	{
		if (cSwitch == switchs[i])
			return true;
	}
	return false;
}
void csArray::csPop(int iIndex)
{
	if (iCount == 1)
		return; // dont allow a pop with only 1 item in the array
	register char **nArray = new char*[iCount - 1];
	for (int i = 0; i < iCount; i++)
	{
		if (i < iIndex)
		{
			nArray[i] = new char[strlen(array[i]) + 1];
			strcpy(nArray[i],array[i]);
		}
		else if (i > iIndex)
		{
			nArray[i-1] = new char[strlen(array[i]) + 1];
			strcpy(nArray[i-1],array[i]);
		}
	}
	freeArray();
	array = nArray;
	iCount--;
}
int csArray::getCount(void) { return iCount; }

void csArray::freeArray(void)
{
	for (int i = 0; i < iCount; i++)
		delete [] array[i];
	delete [] array;
}
csArray::~csArray(void)
{
	freeArray();
	if (bSwitch)
		delete [] switchs;
}