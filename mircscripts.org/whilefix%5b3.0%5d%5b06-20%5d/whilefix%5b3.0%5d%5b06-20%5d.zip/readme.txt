WhileFix.dll 
Version 3.0
By Bamaboy

[Forward]
This helpfile will be a little better lol the last one i
left out a key part by accident and didnt realize it for a couple of months

[Props]
Misanthrop	- PeekMessage idea.. much much better :) thx
Naru/Ami	- taught me this trick forever and a day ago in an application i wrote just it hit me while
			  i was doing nothing that hey this would work great in mIRC :)
			  Also she helped with version 3 with the threading and stuff
#genscripts	- on irc.vidgamechat.net - da^hype, tux` everyone :)

[Change Log]
Version 3.0.1	-	W_FindFile had a nasty parseing bug that caused crazy unexpected problems just randomly when useing the dll (i can personally blame this
					on my string handling skills) 3.0.1 fixed this bug however with a complete rewrite of the parser and should not have any random
					crashs due to W_FindFile also decided against making two different dll versions cause its only a bit bigger, also fixed the only other
					nasty bug that was because some retard(me) made UnloadDll void and not int and didnt return the right values so the shit hit the fan
					when mIRC tried to unload the dll after 10 minutes and this bug was the cause of a lot of frustrations on my part (how... sad...)
Version 3.0		-	Attempted Fix with bug in reference to TheGateKeeper which allowed the closeing of mIRC while a script was processing
					this was bad, not fatal but bad and caused unexpected results when restarting mIRC such as unloading certain script files
					Added W_FindFile fn and W_FindFileFORCEEXIT which provide an interface very similar to mIRC's $findfile identifier which allows
					a user to retrieve files from the operating systems, also in this release there will be two version of the dll one with findfile
					the other without it, findfile stuff takes all of about 8 kbs but some people cringe over size
Version 2.0.2	- 	A readme update nothing spectacular i kept laughing about the readme sucking then i realized i left the
					call to my dll out of the example... no wonder it was complicated to figure out hrmm? shoudl be better...
					wish i had a better reason to update it.... if u have some ideas give me a shout... i coudl always do
					a $findfilecall type thing like $findfile just uses my pseudo-multithreading thing if theres enoguh
					support than i will.
Version 2.0.1	- 	Staticly linked the c runtime library, while this increased the size to 40kbs there shoudl be
					0 in the way of unable to open problems, if this size increases pisses you off recompile it with dynamic
					linkage and distrubute in scripts at your own risk.... you have been warned :)
Version 2.0 	- 	Updating with TranslateMessage, aka what was missing to allow keyboard input, forgot about that.
					ya... my bad :)
Version 1.5 	- 	Updated to use peekmessage instead of getmessage, result... much much faster does not slow
					script processing anymore... :)
Version 1.0 	-	Initial Release

[Functions]
dll WhileFix.dll WhileFix .
Useage is the exact same as before call it in a loop of any kind and it will post messages for mIRC effectivly keeping
it from locking up..
- Example -
while (1) {
  dll WhileFix.dll WhileFix .
  echo -a This loop can go on forever and mIRC appears to act as normal.
  .timerecho 0 4 echo -a This Timer is still working during a while loop
}
- Example -
-------------------------------------------------------------------------------------
dll WhileFix.dll W_FindFile	[-l] c: * -1 somealias [0]
Returns: an identifier for the search that can be sent to W_FindFileFORCEEXIT to immediatly stop search
Parameters or -1 if there was an error with the input
c:	-	The directory you want to search without a trailing backslash (DO NOT INCLUDE trailing backslashes[though i think i fixed that bug])
		so for example c: c:\windows c:\temp c:\windows\temp\some\spyware
*	-	Wild card to match files with, this can include * and ? or neither so you can get some pretty detailed matchs
		so for example b*boy.ext b?m?b*.e?? bamaboy.ext the list goes on
-1	-	is the depth to search 0 means just the directory such as c: it would just search its files, 1 goes 1 subfolder 
		deep 2, two sub folders deep etc.  -1 recurses infinitly through all directories until none are left so -1 would
		search every file on c: in this case
somealias	-	an alias for the dll to return to this is required and the dll will send one of three messages to it
			-	WF_SERROR 0, this means there was a search error aka you did something stupid most notably the folder
				doesnt exist since i think thats the only error checking i implemented (: 
			-	WF_SEARCH # c:\path\to\file.ext, this is sent for every file matching the wildcard; and # is the #
				including this file that have matched and path\to\file.ext is obviously the flie
			-	WF_SDONE #, this is sent once the search is compleated either natually or after a call to force exit 
				and the # is the number of files matching your query
[0]	-	Without the -l switch; if this number is > 0, it will return that file when it gets to it, this is not a reliable
		way to find files since new files can be added and my dll does not return the files int he same order as mIRC's
		built in $findfile, they are returned in alphabetical order and subdirectories are outputed as soon as they are found,
		refer to an example at the end of this helpfile for how they are returned.  if this number is 0 no files are returned
		just WF_SDONE # where # is the total files that match under that wildcard mask
[-l]-	with -l (YES thats an L) the dll will output every file matching your wildcard until it reachs that limit so if 
		you have -l and the # is 50 it will only output the first fifty files no matter how many match your wildcard.
[Note]
the input string does not have very good error checking so if you input the wrong parameters dont be surprsied if you
get unexpected results i think the only thing checked is if there is at least 4 tokens and if there is no holds bared
its going to try to search whatever you passed to it lol	
-------------------------------------------------------------------------------------
dll WhileFix.dll W_FindFileFORCEEXIT id
Returns: S_OK, S_ERROR
Parameters
id	-	should be an id returned by W_FindFile any others will cause this function to fail and return S_ERROR
This function is a safe way to end the thread it does not use TerminateThread and allows the search to clean up allocated
memory and not leak it all over the floor.  Though there really shoudlnt be a reaosn to call this.
-------------------------------------------------------------------------------------
dll WhileFix.dll Version .
Returns: Dll Version information, will return the version of the dll you are useing
-------------------------------------------------------------------------------------
[Bugs]
Bugs are probably not going to be uncommon i have tried my best to test this dll and catch my mistakes however i am very
prone to making them so there were probably way too many to catch lol if you have a bug please notify me via email at
bamaboy1217@gmail.com or join irc.vidgamechat.net #genscripts and drop a memo to bamaboy if im not there or if i am
just let me know or pm me or something with as much information on how to replicate the bug as possible

[Note]
An important note the behavior of the dll is defined if mIRC is closed with threads opened; however, it would be
the equivalent of ending a task through the task manager and does not allow th ethread to clean up pointers and such
so in short dont do it; if you do it wont break it or anything though.

[Another Note]
The dll returns files in the order the file system gives files to it.  This differs between fat and ntfs drives; 
the following is directly out of Microsoft's MSDN Library
--
The order in which this function returns the file names is dependent on the file system type. 
With NTFS and CDFS file systems, the names are returned in alphabetical order. With FAT file systems, 
the names are returned in the order the files were written to the disk, which may or may not be in alphabetical order.
--
As a further point the dll immediatly goes into a directory once found such that this will happen in the following example
-- Imaginary NTFS C Directory --
[Folder1]
Alex-B4FolderOne.ext
Gamma-AfterFolderOne.ext
-- Imaginary c:\Folder1 --
Carry.ext
Alex.ext
Bama.ext
--
The dll on a ntfs drive will return like this
WF_SEARCH 1 c:\Alex-B4FolderOne.ext
WF_SEARCH 2 c:\Folder1\Alex.ext
WF_SEARCH 3 c:\Folder1\bama.ext
WF_SEARCH 4 c:\Folder1\Carry.ext
WF_SEARCH 5 C:\gamma-AfterFolderOne.ext
WF_SDONE  5
