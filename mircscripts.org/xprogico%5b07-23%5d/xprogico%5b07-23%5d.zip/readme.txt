High Color/XP Program Icon
by David Hammond


ABOUT:

The default mIRC program icon has low resolution colors and was only made for 16x16 and 32x32 sizes. The icon included in this ZIP file is an enhanced version of the default icon, supporting monochrome, 16-color, 256-color, true color, and XP resolutions at 16x16, 32x32, and 48x48.

If you only view 16-color icons at 16x16 and 32x32, you won't see any difference with this icon.

This icon was made using Adobe Photoshop 7.0 and Microangelo 5.5.

NOTE:

This assumes that you use a shortcut icon to run mIRC, rather than double-clicking on the actual program.

INSTALLATION:

1. Copy the included mirc.ico into your mIRC folder.
2. Find the shortcut you use to start mIRC and right-click on it. Click on "Properties".
3. Click on the "Shortcut" tab if it isn't already in focus. Click on "Change Icon...".
4. Click on "Browse...". Navigate to your mIRC folder and click on mirc.ico and click "Open". Click "OK". Click "OK".

Your shortcut icon should change to the new icon in a few seconds.