MSN Messenger for mIRC
v3.45

- *** Block Checker ***
- Works with the new MSN protocol
- /msnname and /msn.status commands
- MSN File receiving and sending
- Invite people and be invited to conversations
- Allows you to change your MSN Name to anything, even if it's banned.
- Lets you know when people open or close a chat window to you.
- Colour coded online contact list.
- Logs when users go on/offline.
- View Contact Groups
- Allows you to choose whether the person you are chatting to knows if you're typing.
- HTTP Proxy / Socks support
- Conversation Logging
- Add/Delete and Block/Unblock Users
- Lots more...

*****************
To install extract the entire msn directory in this zip to your mIRC directory, then, in mIRC type:
/load -rs msn/msn.mrc

To initiate the script type:
/msn

Or use the menu in mIRC.

E-Mail andy@burningimage.net to comment or for help.
Check http://www.burningimage.net/msn for updates.
*****************

Windows XP Tip:  You may need to disable the XP firewall in order to use this script.  Chances are you have already done this as the XP firewall does not allow ANY incoming connections.  For you talk to people using this script, the msn servers must be able to connect to you.

Andy Carvell 2003-2005