Author : Red_DaZa (azadder on mircscripts.org)

Installation:
1. Unzip contents into a directory
2. Load the periodictable.mrc file
3. Use the channel popups or type /pertab

Features:
1. All kinds of info about the elements

Thanks:
Bill Klein for his compilation of the elemental info.