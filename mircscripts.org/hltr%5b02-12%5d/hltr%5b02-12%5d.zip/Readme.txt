------------------------------------------------------------------------
Highliter By -KiX-
------------------------------------------------------------------------
It allows you to be in multiple rooms and never miss anything
for instance: if someone says your nick, and you're not paying attention 
to that channel, it echos to the channel or window you are paying attention 
to. It also has flashing, and beeping features to notify you as well. 
------------------------------------------------------------------------
Place this file in your mirc directory
Load this to your mirc with:
//load -rs pathtothisfile\hltr.mrc

Usage: right click and go to Highliter
------------------------------------------------------------------------

Theres a few features:
------------------------------------------------------------------------

-Flash: Flashes the channel where 
keyword has been said

-Log msgs: logs highliter stuff
-Change Focus: Changes focus to the last 
chan a keyword was said in

-Beep on msg: Beeps mirc when a keyword 
was last said

------------------------------------------------------------------------

Key Words:
Key words can be anything, a #channel, 
a persons nick, a persons isp, 
or specific word like Blah

*Note: your own nick is automaticly
added you cannot edit or delete it.
it keeps up with your nick chg as well.
----------------------------------------------------------------

When someone says a keyword, it is echo'd
to your active channel. 