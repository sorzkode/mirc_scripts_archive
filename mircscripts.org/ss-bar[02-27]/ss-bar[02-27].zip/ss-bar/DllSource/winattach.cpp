/*
 * winattach.dll
 *
 * This DLL forces a window whose handle is passed in to conform to the exact size of mIRC's
 * channel bar.  The window can be a picture window, dialog or anything else.  Even the toolbar
 * if you wanted to (don't).
 *
 * Usage:
 *  Loading: $dll(winattach.dll, attach, <handle>)
 *  Unloading: /dll -u winattach.dll
 *  When this handle is no longer valid (unloaded or what have you), you *MUST* unload this dll
 *  using the /dll -u command in mIRC.  If you don't, mIRC remains subclassed. Albeit this 
 *  won't directly cause problems, its just good practice.
 *
 * License:
 *  This DLL is provided openly to those who it is distributed to.  Anyone using this DLL in
 *  their script must give some sort of credit to the author (listed below).  If this DLL is
 *  modified, or any code segments are used, the source must remain open source.
 *
 * Author:
 *  Jedi <miles at turboflux dot net>
 *  irc.gamesnet.net #GamesNET,#Script
 *
*/
#include <windows.h>

WNDPROC oldWndProc;	//original wndproc
HWND hMainHandle;	//mircs handle
HWND hDialog;		//dialog handle
HWND hCbar;			//channel bar handle
HWND hOrigFocus;	//original focus control

// mirc defined structure
typedef struct {
	DWORD  mVersion;
	HWND   mHwnd;
	BOOL   mKeep;
} LOADINFO;


// LoadDLL makes mirc keep the dll loaded instead of unloading immediatly
void __stdcall LoadDll(LOADINFO *Info) {
	// pointless.  we already have it.  just something to do.
	hMainHandle = Info->mHwnd;
}

// UnloadDll removes the subclasses when mIRC wants to unload it.
int __stdcall UnloadDll(int mTimeout) {
	if (mTimeout == 0) {
		// only happens when someone /dll -u's
		SetWindowLong(hMainHandle, GWL_WNDPROC, (LONG)oldWndProc);
		SetParent(hDialog, hMainHandle);
		return 1;
	} else {
		// automatic timeout, mirc wants to unload.
		if (!IsWindow(hDialog)) { // window is invalid, may as well unload
			SetWindowLong(hMainHandle, GWL_WNDPROC, (LONG)oldWndProc);
			return 1;
		} else { 
			return 0; // window is still around, stay loaded.
		}
	}
}

// newWndProc is the subclass for mIRC, it intercepts WM_SIZE and WM_DESTROY
LRESULT CALLBACK newWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	LRESULT resultCode = 1;

	switch(message) {
	case WM_SIZE:
		RECT rBarRect;
		// make sure the user didnt close the dialog
		if (IsWindow(hDialog)) {
			// get the size of the channel bar and move the dialog to match
			GetClientRect(hCbar, &rBarRect);
			MoveWindow(hDialog, rBarRect.left, rBarRect.top, (rBarRect.right - rBarRect.left), (rBarRect.bottom - rBarRect.top), true);
		}
	case WM_DESTROY:
		// mirc exited, it closes the dialog first
		// so we restore its WndProc to allow normal closing
		SetWindowLong(hMainHandle, GWL_WNDPROC, (LONG)oldWndProc);
	default:
		// else let mirc deal with it.
		resultCode = oldWndProc(hWnd, message, wParam, lParam);
	}

	return resultCode;
}

// attach is the actually interface to mIRC.  only passed in param is the window handle.
int __stdcall attach(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause) {
	hDialog = (HWND)atol(data);
	// make sure we're getting passed a dialog
	if (IsWindow(hDialog)) {
		// check who had focus before we start messing around
		hOrigFocus = GetFocus();

		// remember mircs handle
		hMainHandle = mWnd;
		
		// make sure the window isnt subclassed to us already
		if (GetWindowLong(mWnd, GWL_WNDPROC) != (LONG)newWndProc) {
			// find the status bar
			hCbar = FindWindowEx(mWnd, 0, "mIRC_SwitchBar", "");
			if (IsWindow(hCbar)) {
				// save old WndProc and replace with our new one
				if (!(oldWndProc = (WNDPROC)SetWindowLong(mWnd, GWL_WNDPROC, (LONG)newWndProc))) {
					MessageBox(NULL, "Unable to subclass this window.", "Error", MB_ICONERROR | MB_OK);
				} else {
					RECT rBarRect;
					// put the dialog inside the channel bar and resize appropriatly
					SetParent(hDialog, hCbar);
					GetClientRect(hCbar, &rBarRect);
					MoveWindow(hDialog, rBarRect.left, rBarRect.top, (rBarRect.right - rBarRect.left), (rBarRect.bottom - rBarRect.top), true);
				}
			} else {
				// wah wah.  mirc sucks! (why doesnt it have a channel bar...?) ;/
				MessageBox(NULL, "Unable statusbar window handle.", "Error", MB_ICONERROR | MB_OK);
			}
		}
	} else {
		// ghetto window handle
		MessageBox(NULL, "Unable invalid window handle.", "Error", MB_ICONERROR | MB_OK);
	}
	
	// restore focus
	SetFocus(hOrigFocus);

	// continue processing
    return 1;
}
// attach is the actually interface to mIRC.  only passed in param is the window handle.
int __stdcall attachtb(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause) {
	hDialog = (HWND)atol(data);
	// make sure we're getting passed a dialog
	if (IsWindow(hDialog)) {
		// check who had focus before we start messing around
		hOrigFocus = GetFocus();

		// remember mircs handle
		hMainHandle = mWnd;
		
		// make sure the window isnt subclassed to us already
		if (GetWindowLong(mWnd, GWL_WNDPROC) != (LONG)newWndProc) {
			// find the status bar
			hCbar = FindWindowEx(mWnd, 0, "mIRC_Channel", "");
			if (IsWindow(hCbar)) {
				// save old WndProc and replace with our new one
				if (!(oldWndProc = (WNDPROC)SetWindowLong(mWnd, GWL_WNDPROC, (LONG)newWndProc))) {
					MessageBox(NULL, "Unable to subclass this window.", "Error", MB_ICONERROR | MB_OK);
				} else {
					RECT rBarRect;
					// put the dialog inside the channel bar and resize appropriatly
					SetParent(hDialog, hCbar);
					GetClientRect(hCbar, &rBarRect);
					MoveWindow(hDialog, rBarRect.left, rBarRect.top, (rBarRect.right - rBarRect.left), (rBarRect.bottom - rBarRect.top), true);
				}
			} else {
				// wah wah.  mirc sucks! (why doesnt it have a channel bar...?) ;/
				MessageBox(NULL, "Unable statusbar window handle.", "Error", MB_ICONERROR | MB_OK);
			}
		}
	} else {
		// ghetto window handle
		MessageBox(NULL, "Unable invalid window handle.", "Error", MB_ICONERROR | MB_OK);
	}
	
	// restore focus
	SetFocus(hOrigFocus);

	// continue processing
    return 1;
}