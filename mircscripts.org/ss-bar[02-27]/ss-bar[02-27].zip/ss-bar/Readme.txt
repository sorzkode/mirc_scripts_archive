*************************
*    SwitchBar replacement     *
*    Coded by SilentSounD      *
*    (Silent@mircdev.net)       *
*                                        *
*************************
*** Updates***
- v1.1
* Fixed the custom Button so it activates the selected item. thanks TaZ1(taz1@dreamirc.com)
* Fixed problems with spaces in Directorys

*************
*** Requirements ***
    *
    * mIRC 6.02 or higher
    *
    *  MDX 0.92 beta (http://www.dim-bulb.net/~dragonzap/dlls/count.php?http://members.aol.com/dragonzap1/mdx-beta-0.92.zip)
    * 
*** To Load ***
    * Unzip the zip SS-Bar.zip into your mIRC Home directory, this will create a folder called ss-bar in your base folder.
    *
*** Installing MDX ***
    * Unzip mdx-beta-0.92.zip to <MIRCDIR>\ss-bar\
    * Replace <MIRCDIR> with your Mirc directory, ie. C:\mIRC\ss-bar
    *
*** Once in mIRC ***
    *
    * Type  /load -rs  <mircdir>\ss-bar\ss-bar.mrc
    *
*** To Open the Switchbar:
    * Be sure that your Current SwitchBar is Docked to the Top, or Bottom of mIRC
    * Once You are sure the current switchbar is docked in the correct position as explained above, type:
    * /openbar
    *
*** To Close the Switchbar:
    * 
    * Type: /Closebar
    *
*** In the next Versions *** 
    *
    * Blinking buttons to simulate the mIRC switchbar when an action or text is performed in a channel or other window
    * A Options dialog to change icons, and other misc. options.
    *
*** Special Thanks to ***
    * 
    * rkzad (rkzad@hotmail.com) for helpig write this script and  for helping me learn to script, he is one of the best scripters I know.. 
    * he helped reduce the code in the mrc file and made it much more efficent, he is a life saver, thanks rkzad :)
    *
    * Jedi- on irc.gamesnet.net, for Writing me Winattach.DLL,
    *  he is an awesome programmer.. please don't bug him to write you stuff, he is a VERY busy person.
    *
    * Dragonzap (Dragonzap1@aol.com) for the Awesome MDX and popups DLL's they are truly amazing, thanks dragonzap for    
    * answering all my questions on   
    * the forums and e-mails
    *
    * All the Testers that actually wanted to test this (Khasm, and others)
    *
    * [TACO] for his support :-D
    *
    * K-Dub (#Script/irc.gamesnet.net) for always yelling at me when I didn't quite meet his standards. 
    * He's always there when you need a good beat-down, as well as helping to create AWESOME scripts.
    *    
    *  Mircscripts.org for being a helpful place for scripters and me :)
    *
    * Everyone on Irc.GamesNET.net #script, and Irc.DarkTides.net #scriptaz for their help and comments :)
    *
    * Last but not least, You, for downloading this script. If you have any questions or comments please feel free to e-mail me at  
    * silent@mircdev.net. 
    *
    * Thank You :)
***
-----------------------------------------
- Check for updates:
- http://scriptaz.com/
- http://www.mircscripts.org/