#ifndef MEM_RES_H_
#define MEM_RES_H_

#include <windows.h>

class MemRes
{

protected:
	
	LPVOID	heapRes;
	LPWORD	pRes;
	DWORD	size;

public:
	
	MemRes(HMODULE hModule,LPCSTR name,LPCSTR type);
	MemRes(const MemRes &ref);
	MemRes &operator =(const MemRes &ref);
	virtual ~MemRes() { LocalFree(heapRes); }
	
	operator LPWORD() const { return pRes; }
	
	DWORD sizeres() { return size; }
	static void align(WORD **ptr);
	static LPWORD ordinal(LPWORD pDlg);

};

#endif //ifndef MEM_RES_H_