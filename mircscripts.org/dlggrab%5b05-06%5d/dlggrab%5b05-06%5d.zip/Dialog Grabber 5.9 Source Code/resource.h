//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Dialog Grabber.rc
//
#define IDC_LIST_DLG                    1001
#define IDC_BUTTON_VIEW                 1002
#define IDC_BUTTON_BROWSE               1004
#define IDC_EDIT_TABLE                  1005
#define IDC_RADIO_DBU                   1011
#define IDC_RADIO_PIXELS                1012
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
