//----------------------------------------------------------------------------
//STRING.CPP

#include "windows.h"
#include <stdlib.h>
#include "String.h"

//----------------------------------------------------------------------------
String::String(char c)
{
	buffer = (char*)LocalAlloc(0,4);
	len = 1;
	buffer[1] = 0;
	*buffer = c;
}

//----------------------------------------------------------------------------
String::String(const char *str)
{
	//if (!str) str = "";
	len = lstrlen(str);
	buffer = (char*)LocalAlloc(0,len << 1);
	CopyMemory(buffer,str,len);
	buffer[len] = 0;
}

//----------------------------------------------------------------------------
String::String(int number)
{
	buffer = itoa(number,(char*)LocalAlloc(0,50),10);
	len = lstrlen(buffer);
}

//----------------------------------------------------------------------------
String::String(DWORD number)
{
	buffer = ultoa(number,(char*)LocalAlloc(0,50),10);
	len = lstrlen(buffer);
}

//----------------------------------------------------------------------------
String::String(const String &ref)
{
	len = ref.len;
	buffer = (char*)LocalAlloc(0,len << 1);
	CopyMemory(buffer,ref.buffer,len);
	buffer[len] = 0;
}

//----------------------------------------------------------------------------
String::String(HWND window)
{
	len = GetWindowTextLength(window);
	buffer = (char*)LocalAlloc(0,len << 1);
	GetWindowText(window,buffer,len + 1);
	buffer[len] = 0;
}

//----------------------------------------------------------------------------
String::String(LPCWSTR unicode)
{
	len = WideCharToMultiByte(CP_ACP,0,unicode,-1,0,0,0,0);
	buffer = (char*)LocalAlloc(0,len << 1);
	WideCharToMultiByte(CP_ACP,0,unicode,-1,buffer,len,0,0);
	buffer[--len] = 0;
}

//----------------------------------------------------------------------------
String &String::operator <=(const String &ref)
{
	if ((len + ref.len) >= (int)LocalSize(buffer))
	{
		char *newbuf = (char*)LocalAlloc(0,(len + ref.len) << 1);
		CopyMemory(newbuf,buffer,len);
		LocalFree(buffer);
		buffer = newbuf;
	}
	CopyMemory(buffer + len,ref.buffer,ref.len);
	len += ref.len;
	buffer[len] = 0;
	return *this;
}

//----------------------------------------------------------------------------
String &String::operator =(const String &ref)
{
	len = ref.len;
	if (len >= (int)LocalSize(buffer))
	{
		LocalFree(buffer);
		buffer = (char*)LocalAlloc(0,len << 1);
	}
	CopyMemory(buffer,ref.buffer,len);
	buffer[len] = 0;
	return *this;
}

//----------------------------------------------------------------------------
String operator <(const String &a,const String &b)
{
	return String(a) <= b;
}

//----------------------------------------------------------------------------
String replace(const String &source,const String &substring,const String &newstring)
{
	String temp;
	char *src = source.buffer, *end = source.buffer + source.len - substring.len;
	while (src <= end)
	{
		if (!memcmp(src,substring.buffer,substring.len))
		{
			temp <= newstring;
			src += substring.len;
		}
		else temp <= *src++;
	}
	return temp <= src;
}
