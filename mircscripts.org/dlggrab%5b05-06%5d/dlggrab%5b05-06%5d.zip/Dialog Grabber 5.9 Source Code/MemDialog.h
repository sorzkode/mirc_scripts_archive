#ifndef MEMDIALOG_H_
#define MEMDIALOG_H_

#include "MemRes.h"
#include "String.h"

class MemDialog : public MemRes
{
	int item;

public:

	MemDialog(HMODULE hModule,LPCSTR name);

	//offsets
	LPWORD offset() const;
	LPWORD menu_offset() const;
	LPWORD class_offset() const;
	LPWORD title_offset() const;
	LPWORD font_offset() const;
	LPWORD items_offset() const;

	//values
	String title() const;				
	String item_title() const;
	DWORD &style() const;
	short x() const;
	short y() const;
	short w() const;
	short h() const;

	BOOL ex() const { return pRes[1] == 0xFFFF; } 
	int items() const;
	void set_item(int count) { item = count; }

	//item_offsets
	LPWORD item_offset() const;
	LPWORD item_class_offset() const;
	
	//item_values
	DWORD &item_style() const;
	short item_x() const;
	short item_y() const;
	short item_w() const;
	short item_h() const;
	short item_id() const;
	WORD item_type() const;

	void deletemenu();
};

#endif //#ifndef MEMDIALOG_H_