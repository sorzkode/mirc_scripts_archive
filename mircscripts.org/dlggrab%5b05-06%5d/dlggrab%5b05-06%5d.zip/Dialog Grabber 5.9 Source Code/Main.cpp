//----------------------------------------------------------------------------
//MAIN.CPP

#include "Main.h"

//----------------------------------------------------------------------------
int WINAPI WinMain(HINSTANCE hInst,HINSTANCE,LPSTR,int)
{
	return DialogBoxParam(0,"dialog_grabber",0,main_dlg_proc,(LPARAM)hInst);
}

//----------------------------------------------------------------------------
BOOL CALLBACK main_dlg_proc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
	switch (msg)
	{
	case WM_INITDIALOG:
		{
			//retrieve control handles
			for (HWND *control = &hListBox; control <= &hButtonGrab; control++)
				*control = GetDlgItem(hWnd,(int)*control);
			hDialog = hWnd;
			
			//set dialog table name and icon path fields
			SetWindowText(hEditTable,"table");
			
			//set this dialog as parent for common open/save_as dialogs
			mrc.hwndOwner = hWnd;
			dlg.hwndOwner = hWnd;
			
			//check DBU
			CheckDlgButton(hWnd,IDC_RADIO_DBU,BST_CHECKED);
			
			//attach icon
			SendMessage(hWnd,WM_SETICON,ICON_BIG,(LPARAM)LoadIcon((HINSTANCE)lParam,"dialog_grabber_icon"));
		}
		return 0;
		
	case WM_COMMAND:
		switch(HIWORD(wParam))
		{

		//double-click displays dialog
		case LBN_DBLCLK:
			view();
			show_last_error();
			return 0;
			
		//user must select dialog before trying to view/grab it
		case LBN_SELCHANGE:
			EnableWindow(hButtonView,true);
			EnableWindow(hButtonGrab,true);
			return 0;
			
		case BN_CLICKED:
			switch(LOWORD(wParam))
			{

			//Browse
			case IDC_BUTTON_BROWSE:
				browse();
				return 0;
				
			//View 
			case IDC_BUTTON_VIEW:
				view();
				show_last_error();
				return 0;
				
			//Grab
			case IDOK:
				grab();
				show_last_error();
				return 0;
				
			//X
			case IDCANCEL:
				EndDialog(hWnd,0);
			}
		}
	}
	return 0;
}

//----------------------------------------------------------------------------
void show_last_error()
{
	int error = GetLastError();
	if (error)
	{
		LPVOID lpMsgBuf;
		FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,0,error,MAKELANGID(LANG_NEUTRAL,SUBLANG_DEFAULT),(LPTSTR)&lpMsgBuf,0,0);
		MessageBox(0,(LPCTSTR)lpMsgBuf, "Dialog Grabber Error", MB_OK | MB_ICONINFORMATION );
		LocalFree(lpMsgBuf);
	}
}

//----------------------------------------------------------------------------
void browse()
{
	if (GetOpenFileName(&dlg))
	{
		//modify titlebar
		SetWindowText(hDialog,(String)"Dialog Grabber - " < dlg.lpstrFileTitle);
		
		//update listbox and buttons
		SendMessage(hListBox,LB_RESETCONTENT,0,0);
		EnableWindow(hButtonView,false);
		EnableWindow(hButtonGrab,false);
		
		//load module
		HINSTANCE hModule = LoadLibraryEx(dlg.lpstrFile,0,LOAD_LIBRARY_AS_DATAFILE);
		if (hModule)
		{
			//list all dialogs
			EnumResourceNames(hModule,RT_DIALOG,enum_dialogs,0);
			FreeLibrary(hModule);
		}
	}
}
BOOL CALLBACK enum_dialogs(HMODULE hModule,LPCTSTR,LPTSTR lpszName,LONG)
{
	MemDialog dialog(hModule,lpszName);
	SendMessage(hListBox,LB_ADDSTRING,0,(LPARAM)(LPSTR)dialog.title());
	return true;
}

//----------------------------------------------------------------------------
void view()
{
	//load module
	HMODULE hModule = LoadLibraryEx(dlg.lpstrFile,0,LOAD_LIBRARY_AS_DATAFILE);
	if (!hModule) return;
	
	//display dialog
	cur = SendMessage(hListBox,LB_GETCURSEL,0,0);
	EnumResourceNames(hModule,RT_DIALOG,view_dialog,0);
	
	//free module
	FreeLibrary(hModule);
}

//----------------------------------------------------------------------------
BOOL CALLBACK view_dialog(HMODULE hModule,LPCTSTR,LPTSTR lpszName,LONG)
{
	//skip <cur> dialogs
	while (cur--) return true;
	
	//load dialog
	MemDialog dialog(hModule,lpszName);
	
	//load menu
	LPWORD p = dialog.menu_offset();
	MemMenu pMenu(hModule,*p == 0xFFFF ? MAKEINTRESOURCE(*++p) : (String)(LPCWSTR)p);
	hMenu = LoadMenuIndirect(pMenu); 
	
	//prepare for displaying
	dialog.style() = WS_EX_NOPARENTNOTIFY | DS_CENTER | WS_SYSMENU | WS_POPUP | WS_CAPTION | WS_EX_MDICHILD;
	dialog.deletemenu();
	
	//display dialog
	HWND hFakeDlg;
	if (-1 == DialogBoxIndirectParam(0,(DLGTEMPLATE*)(LPWORD)dialog,hDialog,view_dlg_proc,(LONG)&hFakeDlg))
	{
		MessageBox(hDialog,"Unable to display this dialog","Dialog Grabber Error",MB_OK | MB_ICONINFORMATION);
		EndDialog(hFakeDlg,0);
	}
	return false;
}

//----------------------------------------------------------------------------
void grab()
{
	//load module
	HMODULE hModule = LoadLibraryEx(dlg.lpstrFile,0,LOAD_LIBRARY_AS_DATAFILE);
	if (!hModule) return;

	//grab dialog
	cur = SendMessage(hListBox,LB_GETCURSEL,0,0);
	EnumResourceNames(hModule,RT_DIALOG,grab_dialog,0);
		
	//free module
	FreeLibrary(hModule);
}

//----------------------------------------------------------------------------
BOOL CALLBACK grab_dialog(HMODULE hModule,LPCTSTR,LPTSTR lpszName,LONG)
{
	//skip <cur> dialogs
	while (cur--) return true;
	
	//get menu
	MemDialog dialog(hModule,lpszName);
	
	LPWORD p = dialog.menu_offset();
	MemMenu pMenu(hModule,*p == 0xFFFF ? MAKEINTRESOURCE(*++p) : (String)(LPCWSTR)p);
	hMenu = LoadMenuIndirect(pMenu); 

	//prepare for "displaying" (needed for GetClientRect)
	dialog.style() = WS_EX_NOPARENTNOTIFY | DS_CENTER | WS_SYSMENU | WS_POPUP | WS_CAPTION | WS_EX_MDICHILD;
	dialog.deletemenu();
	
	HWND hFakeDlg;
	if (!CreateDialogIndirectParam(0,(DLGTEMPLATE*)(LPWORD)dialog,0,view_dlg_proc,(LONG)&hFakeDlg))
		MessageBox(hDialog,"Unable to grab this dialog","Dialog Grabber Error",MB_OK | MB_ICONINFORMATION);
	else
	{
		DestroyWindow(hFakeDlg);
		
		//header
		SYSTEMTIME st; GetLocalTime(&st);
		String txt(";Dialog Grabber 5.9 - date: ");
		if (st.wDay < 9) txt <= "0";
		txt <= st.wDay <= ".";
		if (st.wMonth < 9) txt <= "0";
		txt <= st.wMonth <= "." <= st.wYear <= "\r\n;(c) 2000 Necroman - necroman@europe.com, irc://irc.undernet.org/mIRC\r\n\r\n";
		
		//scales
		sX = (float)dlg_rect.right;
		sY = (float)dlg_rect.bottom;
		if (IsDlgButtonChecked(hDialog,IDC_RADIO_DBU))
		{
			DWORD dbu = GetDialogBaseUnits();
			sX /= dialog.w() * LOWORD(dbu) / 4;
			sY /= dialog.h() * HIWORD(dbu) / 8;
		}
		else
		{
			sX /= dialog.w();
			sY /= dialog.h();
		}
		
		//title
		txt <= "dialog " <= hEditTable <= " {\r\n  title \"" <= dialog.title();
		
		//size
		txt <= "\"\r\n" <= "  size -1 -1 " <= (int)(dialog.w() * sX + 0.5) <= " " <= (int)((dialog.h() + (hMenu ? 10 : 0)) * sY + 0.5) <= "\r\n";

		//option dbu
		if (IsDlgButtonChecked(hDialog,IDC_RADIO_DBU))
			txt <= "  option dbu\r\n";
		
		//menus
		cur = 0;
		if (hMenu)
			txt <= menuitems(pMenu,0);

		//controls
		cur = 0;
		while (++cur <= dialog.items())
		{
			dialog.set_item(cur);
			DWORD style = dialog.item_style(); 		
			int style0xF = style & 0xF;
			String styles;
			int text_field = true;
			txt <= "  ";
			
			switch (dialog.item_type())
			{
				//buttons, checkboxes, radioboxes, groupboxes
			case 0x80:
				if (dialog.item_id() == IDCANCEL)	styles <= ", cancel";
				if (dialog.item_id() == IDOK)		styles <= ", ok";
				styles <= add_styles(style,button_styles);
				
				switch (style0xF)
				{
				case BS_DEFPUSHBUTTON:
					styles <= ", default";
				case BS_PUSHBUTTON:
					txt <= "button";
					break;
					
				case BS_3STATE:
				case BS_AUTO3STATE:
					styles <= ", 3state";
				case BS_CHECKBOX:
				case BS_AUTOCHECKBOX:
					txt <= "check";
					break;
					
				case BS_GROUPBOX:
					txt <= "box";
					break;
					
				case BS_RADIOBUTTON:
				case BS_AUTORADIOBUTTON:
					txt <= "radio";
					break;
				default:
					txt <= ";button?";
				}
				break;
				
				//edit boxes
				case 0x81:
					txt <= "edit";
					styles <= add_styles(style,edit_styles);
					break;
					
				//labels and icons
				case 0x82:
					if ((style0xF == SS_ICON) || (style0xF == SS_BITMAP))
					{
						text_field = false;
						if (!(style & WS_BORDER)) styles <= ", noborder";
						txt <= ";icon";
						break;
					}
					txt <= "text"; styles <= add_styles(style,text_styles);
					break;
					
				//list boxes
				case 0x83:
					text_field = false;
					txt <= "list";
					styles <= add_styles(style,list_styles);
					break;

				//scroll bars
				case 0x84:
					txt <= "scroll";
					styles <= add_styles(style,scroll_styles);
					if (!(style & SBS_VERT)) styles <= ", horizontal";
					break;
					
				//combo boxes
				case 0x85:
					text_field = false;
					txt <= "combo";
					switch (style0xF)
					{
					case CBS_DROPDOWN:
						styles <= ", edit";
					case CBS_DROPDOWNLIST:
						styles <= ", drop";
						break;
					default:
						styles <= ", edit";
					}
					styles <= add_styles(style,combo_styles);		
					break;
					default:
						txt <= ";ctrl";
			}
			styles <= add_styles(style,window_styles);
			
			txt <= " ";
			
			//"text" is absent for listboxes, combo boxes and icons
			if (text_field)
			{
				String title(dialog.item_title());
				if (strchr(title,'\n'))
					txt <= replace(replace(title,","," $+ $chr(44) $+ "),"\r\n"," $+ $crlf $+ ");
				else
					txt <= '\"' <= title <= '\"';
				txt <= ", ";
			}
			
			//id, x y w h, styles 
			txt <= cur * 10 <= ", " <= (int)(dialog.item_x() * sX + 0.5) <= " " <= (int)(dialog.item_y() * sY + 0.5) <= " " <= (int)(dialog.item_w() * sX + 0.5) <= " " <= (int)(dialog.item_h() * sY + 0.5) <= styles <= "\r\n";
		}
		txt <= "}\r\n\r\n";
		
		//save
		if (GetSaveFileName(&mrc))
		{
			HANDLE hFile = CreateFile(mrc.lpstrFile,GENERIC_WRITE,0,0,OPEN_ALWAYS,0,0);
			if (hFile != INVALID_HANDLE_VALUE)
			{
				DWORD actually_written;
				SetFilePointer(hFile,0,0,FILE_END);
				WriteFile(hFile,txt,txt.length(),&actually_written,0);
				CloseHandle(hFile);
			}
		}
	}
	return false;
}

//----------------------------------------------------------------------------
BOOL CALLBACK view_dlg_proc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
	switch(msg)
	{
		
	case WM_INITDIALOG:
		{
			//set title
			SetWindowText(hWnd,(String)hWnd < " (Preview) ");
			
			//set icon
			SendMessage(hWnd,WM_SETICON,ICON_BIG,(LPARAM)LoadIcon(GetModuleHandle(0),"dialog_grabber_icon"));
			
			
			//return window handle
			*(HWND*)lParam = hWnd;
			
			
			//increase dialog height (for menu)
			if (hMenu)
			{
				SetMenu(hWnd,hMenu);
				RECT menu,window;
				GetMenuItemRect(hWnd,hMenu,0,&menu);
				GetWindowRect(hWnd,&window);
				SetWindowPos(hWnd,0,0,0,window.right - window.left,window.bottom - window.top + menu.bottom - menu.top,SWP_NOZORDER | SWP_NOMOVE);
			}

			//get size 
			GetClientRect(hWnd,&dlg_rect);
			
			return false;
		}
	case WM_COMMAND:
		if (wParam == MAKELONG(IDCANCEL,BN_CLICKED))
		{
			EndDialog(hWnd,0);
			return false;
		}
	}
	return false;
}

//----------------------------------------------------------------------------
String add_styles(DWORD style,CONTROL_STYLES *styles)
{
	String mrc;
	do
	{
		if ((*styles).win & style) mrc <= ", " <= (*styles).mirc;
	} while ((*(++styles)).win);
	return mrc;
}

//----------------------------------------------------------------------------
String menuitems(MemMenu &pMenu, int parentid)
{
	int item_flag = false,id,final;
	String txt;
	do
	{	
		pMenu.set_item(++cur);
		id = cur * 10 + 5;
		final = pMenu.is_final();
		String caption(pMenu.is_break() ?  "break" : String('\"') <= pMenu.caption() <= '\"');
		caption <= ", " <= id;
		if (pMenu.is_popup())
		{
			if (parentid) caption <= ", " <= parentid;
			txt <= "  menu " <= caption <= "\r\n" <= menuitems(pMenu,id);
			item_flag = true;
		}
		else
		{
			if (item_flag)
			{
				caption <= ", " <= parentid;
				item_flag = false;
			}
			txt <= "  item " <= caption <= "\r\n";
		}
	} while (!final);
	return txt;
}