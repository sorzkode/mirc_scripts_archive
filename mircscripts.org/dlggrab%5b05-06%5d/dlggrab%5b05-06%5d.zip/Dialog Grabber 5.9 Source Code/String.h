//----------------------------------------------------------------------------
//STRING.H

#ifndef STRING_H_
#define STRING_H_

#include "windows.h"
#define mb(text) MessageBox(0,(String)text,0,0)

class String
{
protected:
	
	char *buffer;
	int len;

public:
	
	String(const char *ptr = "");
	String(char ch);
	String(int number);
	String(unsigned long dword);
	String(double number,int precision = 6);
	String(const String&);
	String(LPCWSTR widearray);
	String(HWND window);

	virtual			~String() { LocalFree(buffer); }
	
	String&			operator =(const String&);
	String&			operator <=(const String&);
	friend String	operator <(const String&,const String&);
	
	operator char *() const { return buffer; }
	int				length() const { return len; }
	friend String	replace(const String &src,const String &substr,const String &newstr);
};

#endif //STRING_H_ defined