///////////////////////////////////////////////////////////////////////////////////
//																				 //
//  CTTree - A template-based class to handle binary height-balanced (AVL) trees //
//	(C) 1999 P. Niklaus, University of Basel, Switzerland						 //
//                                                                               //
//  This program is free software; you can redistribute it and/or modify         //
//  it under the terms of the GNU General Public License as published by         //
//  the Free Software Foundation; either version 2 of the License, or            //
//  (at your option) any later version.                                          //
//                                                                               //
//  This program is distributed in the hope that it will be useful,              //
//  but WITHOUT ANY WARRANTY; without even the implied warranty of               //
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                //
//  GNU General Public License for more details.                                 //
//                                                                               //
//  You should have received a copy of the GNU General Public License            //
//  along with this program; if not, write to the Free Software                  //
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA    //
//                                                                               //
//  P. Niklaus, email: Pascal.Niklaus@gmx.ch, subject "CTTree"                   //
//                                                                               //
///////////////////////////////////////////////////////////////////////////////////
//                                                                               //
//  This template class wraps original algorithms by Donald Knuth, as            //
//  implemented in C in the avl-library of Ben Pfaff. Ben Pfaff's original       //
//  library as well as AVL-tree related algorithms can be found under			 //
//	http://www.msu.edu/user/pfaffben/avl. His library also implements red-black  //
//  trees, which I did not needed and did not implement therefore...			 //
//																			     //  
///////////////////////////////////////////////////////////////////////////////////
//																			     //
//	History:																	 //
//	20-nov-99: Release of version 1.0								             //
//																			     //
//	Bugs:																	     //
//	none known                                                                   //
//                                                                               //																		     //
///////////////////////////////////////////////////////////////////////////////////

#ifndef _CTTREE_H
#define _CTTREE_H

#include <stdlib.h>

#ifndef TREE_MAX_HEIGHT
#define TREE_MAX_HEIGHT (32)
#endif

// Structure for a node in an AVL tree
template <class TreeData> class TreeNode
{   	
public:
    TreeNode<TreeData> * link[2];			// Subtrees. 
    signed char bal;			// Balance factor. 
    char cache;					// Used during insertion. 
	TreeData *data;				// Pointer to data. 
};

// Used for traversing an AVL tree. 
template <class TreeData> struct TreeTraverser
{
    int init;					// Initialized? 
    int nstack;					// Top of stack.
    TreeNode<TreeData> *p;		// Used for traversal. 
    TreeNode<TreeData> *stack[TREE_MAX_HEIGHT];// Descended trees. 
};

// The CTTree template
template <class TreeData> class CTTree
{
	typedef int (*TreeCompareFunc) (const TreeData *a, const TreeData *b);
	typedef void (*TreeCallbackFunc) (TreeData *data);

public:
	CTTree(TreeCompareFunc Func);
	virtual ~CTTree();

	TreeData * TryInsert(TreeData *item);
	TreeData * Insert(TreeData *item);
	TreeData * Detach (TreeData *item);

	TreeData * Find(TreeData *item);
	TreeData * FindClose(TreeData *item);

	void Destroy(TreeCallbackFunc callback=NULL, TreeNode<TreeData> * TheRoot = NULL);
	void Resort(TreeCompareFunc Func);
	
	void ProcessCallback(TreeCallbackFunc callback);
	void ProcessInit();
	TreeData * ProcessNext();

	long GetWeight() { return NumItems; }

	//-------------- data elements ----------------------------------
private:
	TreeNode<TreeData> Root;	// Tree root node. 
	TreeNode<TreeData> TempRoot;// Used for resort
    TreeCompareFunc Compare;	// Used to compare keys. 
    long NumItems;				// Number of nodes in the tree.     
private:
	TreeTraverser<TreeData> Traverser;
};

template <class TreeData> CTTree<TreeData>::CTTree(TreeCompareFunc Func)
{
	NumItems=0;
	assert(Func);
	Compare=Func;	
	Root.link[0] = NULL;
	Root.link[1] = NULL; 
}

template <class TreeData> CTTree<TreeData>::~CTTree()
{
	Destroy();	// delete all elements
}

template <class TreeData> TreeData * CTTree<TreeData>::TryInsert(TreeData *item)
{
	// Uses Knuth's Algorithm 6.2.3A (balanced tree search and
	// insertion), but caches results of comparisons.  In empirical
	// tests this eliminates about 25% of the comparisons seen under
	// random insertions.  

	/* A1. */
	TreeNode<TreeData> *t = &Root;
	TreeNode<TreeData> *s, *p, *q, *r;
	
	s = p = t->link[0];
	
	if (s == NULL)
    {
		NumItems++;
		assert (NumItems == 1);
		q = t->link[0] = new TreeNode<TreeData>;
		q->data = item;
		q->link[0] = q->link[1] = NULL;
		q->bal = 0;
		return q->data;
    }
	
	for (;;)
    {
		/* A2. */
		int diff = Compare (item, p->data);
		
		/* A3. */
		if (diff < 0)
		{
			p->cache = 0;
			q = p->link[0];
			if (q == NULL)
			{
				p->link[0] = q = new TreeNode<TreeData>;
				break;
			}
		}
		/* A4. */
		else if (diff > 0)
		{
			p->cache = 1;
			q = p->link[1];
			if (q == NULL)
			{
				p->link[1] = q = new TreeNode<TreeData>;
				break;
			}
		}
		else
			/* A2. */
			return p->data;
		
		/* A3, A4. */
		if (q->bal != 0)
			t = p, s = q;
		p = q;
    }
	
	/* A5. */
	NumItems++;
	q->data = item;
	q->link[0] = q->link[1] = NULL;
	q->bal = 0;
	
	/* A6. */
	r = p = s->link[(int) s->cache];
	while (p != q)
    {
		p->bal = p->cache * 2 - 1;
		p = p->link[(int) p->cache];
    }
	
	/* A7. */
	if (s->cache == 0)
    {
		/* a = -1. */
		if (s->bal == 0)
		{
			s->bal = -1;
			return q->data;
		}
		else if (s->bal == +1)
		{
			s->bal = 0;
			return q->data;
		}
		
		assert (s->bal == -1);
		if (r->bal == -1)
		{
			/* A8. */
			p = r;
			s->link[0] = r->link[1];
			r->link[1] = s;
			s->bal = r->bal = 0;
		}
		else
		{
			/* A9. */
			assert (r->bal == +1);
			p = r->link[1];
			r->link[1] = p->link[0];
			p->link[0] = r;
			s->link[0] = p->link[1];
			p->link[1] = s;
			if (p->bal == -1)
				s->bal = 1, r->bal = 0;
			else if (p->bal == 0)
				s->bal = r->bal = 0;
			else 
			{
				assert (p->bal == +1);
				s->bal = 0, r->bal = -1;
			}
			p->bal = 0;
		}
    }
	else
    {
		/* a == +1. */
		if (s->bal == 0)
		{
			s->bal = 1;
			return q->data;
		}
		else if (s->bal == -1)
		{
			s->bal = 0;
			return q->data;
		}
		
		assert (s->bal == +1);
		if (r->bal == +1)
		{
			/* A8. */
			p = r;
			s->link[1] = r->link[0];
			r->link[0] = s;
			s->bal = r->bal = 0;
		}
		else
		{
			/* A9. */
			assert (r->bal == -1);
			p = r->link[0];
			r->link[0] = p->link[1];
			p->link[1] = r;
			s->link[1] = p->link[0];
			p->link[0] = s;
			if (p->bal == +1)
				s->bal = -1, r->bal = 0;
			else if (p->bal == 0)
				s->bal = r->bal = 0;
			else 
			{
				assert (p->bal == -1);
				s->bal = 0, r->bal = 1;
			}
			p->bal = 0;
		}
    }
	
	/* A10. */
	if (t != &Root && s == t->link[1])
		t->link[1] = p;
	else
		t->link[0] = p;
	
	return q->data;
}

//	Inserts ITEM into TREE.  Returns NULL if the item was inserted,
//	otherwise a pointer to the duplicate item.
template <class TreeData> TreeData * CTTree<TreeData>::Insert(TreeData *item)
{
	TreeData *p;
	
	p = TryInsert(item);
	return (p == item) ? p : NULL;
}

template <class TreeData> void CTTree<TreeData>::ProcessInit()
{
	Traverser.init=0;
}

template <class TreeData> TreeData * CTTree<TreeData>::ProcessNext()
{	
	/* Uses Knuth's algorithm 2.3.1T (inorder Traverserersal). */
	if (Traverser.init == 0)
    {
		/* T1. */
		Traverser.init = 1;
		Traverser.nstack = 0;
		Traverser.p = Root.link[0];
    }
	else
		/* T5. */
		Traverser.p = Traverser.p->link[1];
	
	for (;;)
    {
		/* T2. */
		while (Traverser.p != NULL)
		{
			/* T3. */
			Traverser.stack[Traverser.nstack++] = Traverser.p;
			Traverser.p = Traverser.p->link[0];
		}
		
		/* T4. */
		if (Traverser.nstack == 0)
		{
			Traverser.init = 0;
			return NULL;
		}
		Traverser.p = Traverser.stack[--Traverser.nstack];
		
		/* T5. */
		return Traverser.p->data;
    }
}

// Search the tree an item matching <item>, and return it if found. 
template <class TreeData> TreeData * CTTree<TreeData>::Find(TreeData *item)
{
	TreeNode<TreeData> *p;
	
	for (p = Root.link[0]; p; )
    {
		int diff = Compare (item, p->data);
		
		if (diff < 0)
			p = p->link[0];
		else if (diff > 0)
			p = p->link[1];
		else
			return p->data;
    }
	
	return NULL;
}

template <class TreeData> void CTTree<TreeData>::ProcessCallback(TreeCallbackFunc callback)
{
	/* Uses Knuth's algorithm 2.3.1T (inorder traversal). */
	assert (callback);
	
	/* T1. */
	TreeNode<TreeData> *an[TREE_MAX_HEIGHT];	/* Stack A: nodes. */
	TreeNode<TreeData> **ap = an;				/* Stack A: stack pointer. */
	TreeNode<TreeData> *p = Root.link[0];
	
	for (;;)
	{
		/* T2. */
		while (p != NULL)
		{
			/* T3. */
			*ap++ = p;
			p = p->link[0];
		}
		
		/* T4. */
		if (ap == an)
			return;
		p = *--ap;
		
		/* T5. */
		callback (p->data);
		p = p->link[1];
	}
	
}

template <class TreeData> TreeData * CTTree<TreeData>::Detach (TreeData *item)
{
	/* Uses Ben Pfaff's algorithm D, which can be found at
	http://www.msu.edu/user/pfaffben/avl.  Algorithm D is based on
	Knuth's Algorithm 6.2.2D (Tree deletion) and 6.2.3A (Balanced
	tree search and insertion), as well as the notes on pages 465-466
	of Vol. 3. */
	
	/* D1. */
	TreeNode<TreeData> *pa[TREE_MAX_HEIGHT];/* Stack P: Nodes. */
	char a[TREE_MAX_HEIGHT];				/* Stack P: Bits. */
	int k = 1;								/* Stack P: Pointer. */
	
	TreeNode<TreeData> **q;
	TreeNode<TreeData> *p;
	
	a[0] = 0;
	pa[0] = &Root;
	p = Root.link[0];
	for (;;)
    {
		/* D2. */
		if (p == NULL)
			return NULL;				// not found
		
		int diff = Compare (item, p->data);
		if (diff == 0)
			break;						// item found
		
		/* D3, D4. */
		pa[k] = p;
		if (diff < 0)
		{
			p = p->link[0];
			a[k] = 0;
		}
		else if (diff > 0)
		{
			p = p->link[1];
			a[k] = 1;
		}
		k++;
    }
	NumItems--;							// we have one item less
	
	item = p->data;						// item = pointer to the data
	
	/* D5. */
	q = &pa[k - 1]->link[(int) a[k - 1]];
	if (p->link[1] == NULL)
    {
		*q = p->link[0];
		if (*q)
			(*q)->bal = 0;
    }
	else
    {
		/* D6. */
		TreeNode<TreeData> *r = p->link[1];
		if (r->link[0] == NULL)
		{
			r->link[0] = p->link[0];
			*q = r;
			r->bal = p->bal;
			a[k] = 1;
			pa[k++] = r;
		}
		else
		{
			/* D7. */
			TreeNode<TreeData> *s = r->link[0];
			int l = k++;
			
			a[k] = 0;
			pa[k++] = r;
			
			/* D8. */
			while (s->link[0] != NULL)
			{
				r = s;
				s = r->link[0];
				a[k] = 0;
				pa[k++] = r;
			}
			
			/* D9. */
			a[l] = 1;
			pa[l] = s;
			s->link[0] = p->link[0];
			r->link[0] = s->link[1];
			s->link[1] = p->link[1];
			s->bal = p->bal;
			*q = s;
		}
    }
	delete p;			// delete the node (not the item !!!)
	
	assert (k > 0);
	/* D10. */
	while (--k)
    {
		TreeNode<TreeData> *s = pa[k], *r;
		
		if (a[k] == 0)
		{
			/* D10. */
			if (s->bal == -1)
			{
				s->bal = 0;
				continue;
			}
			else if (s->bal == 0)
			{
				s->bal = 1;
				break;
			}
			
			assert (s->bal == +1);
			r = s->link[1];
			
			assert (r != NULL);
			if (r->bal == 0)
			{
				/* D11. */
				s->link[1] = r->link[0];
				r->link[0] = s;
				r->bal = -1;
				pa[k - 1]->link[(int) a[k - 1]] = r;
				break;
			}
			else if (r->bal == +1)
			{
				/* D12. */
				s->link[1] = r->link[0];
				r->link[0] = s;
				s->bal = r->bal = 0;
				pa[k - 1]->link[(int) a[k - 1]] = r;
			}
			else 
			{
				/* D13. */
				assert (r->bal == -1);
				p = r->link[0];
				r->link[0] = p->link[1];
				p->link[1] = r;
				s->link[1] = p->link[0];
				p->link[0] = s;
				if (p->bal == +1)
					s->bal = -1, r->bal = 0;
				else if (p->bal == 0)
					s->bal = r->bal = 0;
				else
				{
					assert (p->bal == -1);
					s->bal = 0, r->bal = +1;
				}
				p->bal = 0;
				pa[k - 1]->link[(int) a[k - 1]] = p;
			}
		}
		else
		{
			assert (a[k] == 1);
			
			/* D10. */
			if (s->bal == +1)
			{
				s->bal = 0;
				continue;
			}
			else if (s->bal == 0)
			{
				s->bal = -1;
				break;
			}
			
			assert (s->bal == -1);
			r = s->link[0];
			
			if (r == NULL || r->bal == 0)
			{
				/* D11. */
				s->link[0] = r->link[1];
				r->link[1] = s;
				r->bal = 1;
				pa[k - 1]->link[(int) a[k - 1]] = r;
				break;
			}
			else if (r->bal == -1)
			{
				/* D12. */
				s->link[0] = r->link[1];
				r->link[1] = s;
				s->bal = r->bal = 0;
				pa[k - 1]->link[(int) a[k - 1]] = r;
			}
			else if (r->bal == +1)
			{
				/* D13. */
				p = r->link[1];
				r->link[1] = p->link[0];
				p->link[0] = r;
				s->link[0] = p->link[1];
				p->link[1] = s;
				if (p->bal == -1)
					s->bal = 1, r->bal = 0;
				else if (p->bal == 0)
					s->bal = r->bal = 0;
				else
				{
					assert (p->bal == 1);
					s->bal = 0, r->bal = -1;
				}
				p->bal = 0;
				pa[k - 1]->link[(int) a[k - 1]] = p;
			}
		}
    }
	
	return item;
}

// Search the tree for an item close to the value of ITEM, and return it.
// This function will return a null pointer only if the tree is empty. 
template <class TreeData> TreeData * CTTree<TreeData>::FindClose (TreeData *item)
{
	const TreeNode *p;
	
	p = Root.link[0];
	if (p == NULL)
		return NULL;
	
	for (;;)
    {
		int diff = Compare (item, p->data);
		int t;
		
		if (diff < 0)
			t = 0;				// walk left
		else if (diff > 0)
			t = 1;				// walk right
		else
			return p->data;		// exact match
		
		if (p->link[t])			// if link exists, follow link
			p = p->link[t];
		else
			return p->data;		// there is no next item, 
								// return value at actual node
    }
}

template <class TreeData> void CTTree<TreeData>::Destroy(TreeCallbackFunc callback, TreeNode<TreeData> * TheRoot)
{
/*  Uses Knuth's Algorithm 2.3.1T as modified in exercise 13
	(postorder traversal). */
	
	/* T1. */
	TreeNode<TreeData> *an[TREE_MAX_HEIGHT];	// Stack A: nodes
	char ab[TREE_MAX_HEIGHT];					// Stack A: bits
	int ap = 0;									// Stack A: height
	TreeNode<TreeData> *p = (TheRoot?*TheRoot:Root).link[0];

    /* ### 2002/07/22 - Gustavo Picon ### */
    NumItems = 0;

    for (;;)
	{
		/* T2. */
		while (p != NULL)
		{
			/* T3. */
			ab[ap] = 0;
			an[ap++] = p;
			p = p->link[0];
		}
		
		/* T4. */
		for (;;)
		{
            if (ap == 0) {
                /* ### 2002/07/22 - Gustavo Picon ### */
                (TheRoot?*TheRoot:Root).link[0] = NULL;
                return;
            }
			
			p = an[--ap];
			if (ab[ap] == 0)
			{
				ab[ap++] = 1;
				p = p->link[1];
				break;
			}

			if(callback)			// if there is a callback function:
				callback(p->data);	//		call it
			else					// if there is none
				delete p->data;		//		delete the data
			
			delete p;				// delete the node
		}
	}
    /* ### 2002/07/22 - Gustavo Picon ### */
    (TheRoot?*TheRoot:Root).link[0] = NULL;
}

template <class TreeData> void CTTree<TreeData>::Resort(TreeCompareFunc Func)
{
	TempRoot = Root;
	Root.link[0] = NULL;
	Root.link[1] = NULL; 
	NumItems=0;

	assert(Func);
	Compare=Func;

	/*  Uses Knuth's Algorithm 2.3.1T as modified in exercise 13
	(postorder traversal). */
	
	/* T1. */
	TreeNode<TreeData> *an[TREE_MAX_HEIGHT];	// Stack A: nodes
	char ab[TREE_MAX_HEIGHT];					// Stack A: bits
	int ap = 0;									// Stack A: height
	TreeNode<TreeData> *p = TempRoot.link[0];	

	for (;;)
	{
		/* T2. */
		while (p != NULL)
		{
			/* T3. */
			ab[ap] = 0;
			an[ap++] = p;
			p = p->link[0];
		}
		
		/* T4. */
		for (;;)
		{
			if (ap == 0) return;
			
			p = an[--ap];
			if (ab[ap] == 0)
			{
				ab[ap++] = 1;
				p = p->link[1];
				break;
			}

			TryInsert(p->data);		// insert the data			
			delete p;				// delete the node
		}
	}
}

#endif // #ifndef _CTTREE_H

//---------------------------------- end of CTTree.h -----------------------------
