#include "common.h"

#define ELEM_FORMAT	"$evaltext_g(%s)"
#define Fail 0
#define Success 1
#define Nsuccess 2

extern char Paratransfer[1024];
extern LPSTR mData;
extern HWND MIRC;
extern char ccolor[4][3];
extern char cprefix[BLEN];
extern int cprefixlen;
extern BOOL cAddColor;

#ifdef __cplusplus
extern "C" {
#endif

char *pc_eval(char *tok,char *startpos,char *function,const BOOL Findstartpos);
void pc_parseid(char *id,char *function);
BOOL Npc_eval(char *str,const char BType,const BOOL comma);
BOOL Npc_variable(char *str,const BOOL comma);
UINT replacecomma(char * parm);

#ifdef __cplusplus
}
#endif