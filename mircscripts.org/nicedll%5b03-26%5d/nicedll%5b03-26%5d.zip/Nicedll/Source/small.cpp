/*
 * small.cpp
 *	
 * Copyright (C) 2003-2004 Niceboy-DvD  . email dvd21us@yahoo.com
 *
 * Speacial Thanks Tabo  for Many sources take from Aircdll.dll 
 *  [ Tabo ( Gustavo Picon )  www.airc.ws ]
 *
 * This program is free software; you can redistribute it
 * and/or modify  it under the terms of the GNU General Public 
 * License as published by  the Free Software Foundation; either 
 * version 2 of the License, or  (at your option) any later version.   
 */

#include "small.h"

void savemenubar(HWND w, tbool b)
{
	HMENU m;

	m = GetMenu(w);
	if (IsMenu(m))
		menubar = m;
	else if (b)
		menubar = NULL;
}

/*
 * Small Exported functions
 */

/*
 * SetTitle <hwnd> [string]
 */
MircFunc SetTitle(FUNCPARMS)
{
	char *tmp = data;
	HWND window;

	window = (HWND)atolp(getword(&tmp));
	if (IsWindow(window)) {
		SetWindowText(window, tmp);
		r_ok("");
	}
	r_err("BADWIN", "Invalid HWND")
}

/*
 * GetTitle <hwnd>
 */
MircFunc GetTitle(FUNCPARMS)
{
	char *tmp = data, s[MAXSTRINGLEN];
	HWND window;

	window = (HWND)atolp(getword(&tmp));
	if (IsWindow(window)) {
		GetWindowText(window, s, MAXSTRINGLEN - 5);
		if (*tmp) { SetVar(tmp,s);lstrcpy(data,"+OK"); }
		else if (isin_fpara(data,'x','X')) wsprintf(data, "%s",s);
		else wsprintf(data, "+OK %s",s);
		return 3;
	}
	r_err("BADWIN", "Invalid HWND")
}

/*
 * SetMircTitle <string>
 */
MircFunc SetMircTitle(FUNCPARMS)
{
	lstrcpy(mTitlebar,data);
	VBtitlebar = -3;
	Vtitlebar = FALSE;
	SetWindowText(mWnd, data);
	r_ok("");
}

LRESULT CALLBACK NRetProc(UINT code,WPARAM wParam,LPARAM lParam)
{	
	#define WM_NTIT 127
	if (code < 0)	return CallNextHookEx(mIRC_Hook,code,wParam,lParam);
	if (wParam == PM_REMOVE) 
	{
		if (PCWPRETSTRUCT(lParam)->message == WM_NTIT) {
			 if (VBtitlebar != -3) {
				VBtitlebar = -3;
				SetWindowText(MIRC,mTitlebar);
			 }
			 else ++VBtitlebar;
		}
	}
	else return CallNextHookEx(mIRC_Hook,code,wParam,lParam);
	return 0;
}
MircFunc SetNBTitle(FUNCPARMS)
{
	lstrcpy(mTitlebar,data);
	if (!mIRC_Hook) {
		if (mIRC_OldProc) {
			SetWindowLong(MIRC,GWL_WNDPROC,(LONG)mIRC_OldProc);
			mIRC_OldProc = NULL;
		}
		mIRC_Hook = SetWindowsHookEx(WH_CALLWNDPROCRET,(HOOKPROC)NRetProc,0,GetCurrentThreadId());
	}
	VBtitlebar = -3;
	SetWindowText(MIRC,mTitlebar);
	r_ok("");
}

Proc(mIRCProc)
{	
	switch(uMsg)
	{
	 case WM_CLOSE: 
		{
			SetWindowLong(MIRC,GWL_WNDPROC,(LONG) mIRC_OldProc);
			PostMessage(hwnd, uMsg,0,0);
			return 0;
		}
		break;
	}
    LRESULT result = CallWindowProc(mIRC_OldProc,hwnd,uMsg,wParam,lParam);
	switch(uMsg)
	{
	 case WM_SETTEXT:
		 if (Vtitlebar) {
			Vtitlebar = FALSE;
			SetWindowText(MIRC,mTitlebar);
		 }
		 else Vtitlebar = TRUE;
		break;
	}
	return result;
}
MircFunc SetNTitle(FUNCPARMS)
{
	lstrcpy(mTitlebar,data);
	if (!mIRC_OldProc) {
		if (mIRC_Hook) { 
			UnhookWindowsHookEx(mIRC_Hook);
			mIRC_Hook = NULL;
		}
		mIRC_OldProc = (WNDPROC)SetWindowLong(MIRC,GWL_WNDPROC,(LONG)mIRCProc);
	}
	Vtitlebar = FALSE;
	SetWindowText(MIRC,mTitlebar);
	r_ok("");
}
void unlock_title() {
	if (mIRC_Hook) {
		UnhookWindowsHookEx(mIRC_Hook);
		mIRC_Hook = NULL;
	}
	else if (mIRC_OldProc) {
		SetWindowLong(MIRC,GWL_WNDPROC,(LONG)mIRC_OldProc);
		mIRC_OldProc = NULL;
	}
}
MircFunc UnLockTitle(FUNCPARMS) {
	unlock_title();
	r_ok("");
}
/*
 * GetMircTitle
 */
MircFunc GetMircTitle(FUNCPARMS)
{
	char r[MAXSTRINGLEN];

	if (data[0] == '-')  lstrcpy(data,data + 1);
	GetWindowText(mWnd, r, MAXSTRINGLEN - 5);
	r_var(data,r);
	return 3;
}

MircFunc HHelp (FUNCPARMS) 
{
	long numtok = -1;
	long next_tok = -1;
	char *tmp = data,*file;
	char buf[1024],*b = &buf[0];
	DWORD Result;

	file = getnexttok(&tmp,62);
	if (!*file)	ret("-ERROR Invalid File Name")	
	Result = GetFileAttributes(file);
	if (Result == 0xFFFFFFFF) ret_FNF
	DWORD dwCookie = NULL;
	if (!*tmp) {
		HtmlHelp(aWnd,file, HH_DISPLAY_TOPIC, 0);
		ret("+OK")
	}
	else {
		wsprintf(buf,"%s::/%s%s",file,tmp);
		HtmlHelp(aWnd,b, HH_DISPLAY_TOPIC, 0);
	}
	ret("+OK")
}

MircFunc Splay(FUNCPARMS)
{	
	PlaySound(data, NULL, SND_FILENAME | SND_ASYNC | SND_NOWAIT | SND_NODEFAULT);
	return 1;
}

MircFunc findnearestcolor(FUNCPARMS)
{
 char *tmp = data; 
 char *p = data;
 char *aux;
 char allcolor[10] = "";
 char st[2];
 char bkcolor[5]= ",-",color[5]= "-";
 char result[10] = "";
 unsigned char c; 
 int len = 0,r = -1 ,b = -1,u = -1;
 st[1] = 0;

 while (*p) { p++ ; len++ ; }
 while (len > -1) {
	c = *p;
	if (c == 15) break;
	if ((c == 3) && ((bkcolor[1] == '-') || (color[0] == '-'))) {
		aux = p; ++aux;
		if ((*aux >= '0') && (*aux <= '9')) {
			if (color[0] == '-') {
				color[0] = *aux; 
				++aux;
				if ((*aux >= '0') && (*aux <= '9')) {
					color[1] = *aux;
					color[2] = 0;
				} 
				else color[1] = 0;
			}
			else {
				++aux;
				if ((*aux >= '0') && (*aux <= '9')) ++aux;
			}
			if (*aux == ',') {
				++aux;
				if ((*aux >= '0') && (*aux <= '9') && (bkcolor[1] == '-')) {
						bkcolor[1] = *aux; 
						++aux;
						if ((*aux >= '0') && (*aux <= '9')) {
							bkcolor[2] = *aux;
							bkcolor[3] = 0;
						} 
						else bkcolor[2] = 0;
				}
			}

		}

		else break;
	}
	else
		if ((c == 22)&& (r == -1)) { r = 0 ; st[0] = 22; lstrcat(allcolor,st); }
		else 
			if ((c == 2) && (b == -1)) { b = 0;st[0] = 2; lstrcat(allcolor,st); }
			else
				if ((c == 31) && (u == -1)) { u = 0; st[0] = 31; lstrcat(allcolor,st);}
 --len; p--;
 }
 if (color[0] != '-')  {
	result[0] = 3; result[1] = 0;
	lstrcat(result,color);
 }
if (bkcolor[1] == '-')  bkcolor[0] = 0;
 wsprintf(data,"%s%s%s",allcolor,result,bkcolor);
return 3;
}

//syntax: $dll(messages2.dll, MsgBox, <flags>;<title>;<text>)
// flags:
//      y: creates a yes\no message box
//      a: creates an about\retry\ignore message box
//      c: creates a yes\no\cancel message box
//      m: creates a normal message box
//      i: creates an info icon (a lowercase itallic "i")
//      e: creates an error icon (a stop)
//      w: creates an warn icon ("!")
//      q: creates an question icon ("?")
//		d: modal  dialog
//		s: system dialog
//		t: Task  dialog 

MircFunc MsgBox (FUNCPARMS)
{
	char *title,*txt,*flags,*tmp = data;
	HWND handle = mWnd;
    flags = getnexttok(&tmp,59);
	int  intflags = 0;
    if (isincs(flags,'y')) intflags = intflags + MB_YESNO;
	if (isincs(flags,'a'))  intflags = intflags + MB_ABORTRETRYIGNORE;
	if (isincs(flags,'c'))  intflags = intflags + MB_YESNOCANCEL;
	if (isincs(flags,'m'))  intflags = MB_OK;
	if (isincs(flags,'i'))  intflags = intflags + MB_ICONINFORMATION;
	if (isincs(flags,'e'))  intflags = intflags + MB_ICONERROR;
	if (isincs(flags,'w'))  intflags = intflags + MB_ICONWARNING;
	if (isincs(flags,'q'))  intflags = intflags + MB_ICONQUESTION;
	if (isincs(flags,'d'))  intflags = intflags + MB_APPLMODAL;
	if (isincs(flags,'s'))  intflags = intflags + MB_SYSTEMMODAL;
	if (isincs(flags,'t'))  intflags = intflags + MB_TASKMODAL;
	if (isincs(flags,'l'))  {
		handle = (HWND)atolp(getnexttok(&tmp,59));
		if (!IsWindow(handle))  handle = NULL ; 
	} 
	title = getnexttok(&tmp,59);
	txt = getnexttok(&tmp,59);
  int returned = MessageBox(handle,txt,title,intflags);
  switch (returned) {
    case 0: ret("ERROR"); break;
    case IDABORT: ret("ABORT"); break;
    case IDCANCEL:ret("CANCEL"); break;
    case IDIGNORE: ret("IGNORE"); break;
    case IDNO: ret("NO"); break;
    case IDOK: ret("OK");break;
    case IDRETRY: ret("RETRY"); break;
    case IDYES: ret("YES"); break;
	case IDCONTINUE: ret("CONTINUE"); break;
	case IDTRYAGAIN: ret("TRYAGAIN"); break;
	default:    ret("ERROR");
  }
}  

MircFunc mBeep (FUNCPARMS)
{
	UINT beeptype;
	char *tmp = data;
    getnexttok(&tmp,32);
   	if (data[0] == '-') { beeptype = MB_OK; goto end; }
	if (!lstrcmpi(data,"Info"))  { beeptype = MB_ICONASTERISK; goto end; }
	if (!lstrcmpi(data,"Warn"))  { beeptype = MB_ICONEXCLAMATION; goto end; }
	if (!lstrcmpi(data,"Error"))  { beeptype = MB_ICONHAND; goto end; }
	if (!lstrcmpi(data,"Default"))  { beeptype = MB_OK; goto end; }
	if (!lstrcmpi(data,"Question")) { beeptype = MB_ICONQUESTION; goto end; }
	ret("ERROR Type: Info,Warn,Error,Default,Question")
end: MessageBeep(beeptype);
	return 1;
}

MircFunc MircLook(FUNCPARMS)
{
	char *tmp = data;
	int x,y,w,h;
	x = y = w = h = NULL;
	if (getfirstnum(&tmp,x)== HaveNumHaveToken) 
		if (getfirstnum(&tmp,y) == HaveNumHaveToken) 
			if (getfirstnum(&tmp,w) == HaveNumHaveToken) 
				getfirstnum(&tmp,h);
	RECT mIRC;
	GetWindowRect(mWnd,&mIRC);
	if (x == NULL) x = mIRC.left;
	if (y == NULL) y = mIRC.top;
	if (w == NULL) w = mIRC.right - mIRC.left;
	if (h == NULL) h = mIRC.bottom - mIRC.top;
	ret(SetWindowPos(mWnd,NULL,x,y,w,h,SWP_NOZORDER)?"+OR":"ERROR")
}

MircFunc GetTaskbarSize(FUNCPARMS)
{
	char tbarpos[10];
	HWND tbar = FindWindow("Shell_TrayWnd",NULL);
	RECT taskbar;
	GetWindowRect(tbar,&taskbar);

	if (taskbar.left > 0) lstrcpy(tbarpos,"right");
	else 
		if (taskbar.top > 0) lstrcpy(tbarpos,"bottom");
		else 
			if (taskbar.bottom > taskbar.right) lstrcpy(tbarpos,"left");
			else lstrcpy(tbarpos,"top");
	wsprintf(data,"%s %d %d %d %d",tbarpos,taskbar.left,taskbar.top,taskbar.right - taskbar.left,taskbar.bottom - taskbar.top);
	return 3;
}

/*
 * Get Paths Dir
 */
MircFunc FindPath(FUNCPARMS)
{   char * tmp = data;
	if (data[0] == '-') {
		tmp++;
		switch (*tmp)
		{
			case '1': 
				GetWindowsDirectory(data,MLEN - 5); break; 
			case '2': 
				GetSystemDirectory(data,MLEN - 5);  break; 
			case '3': 
				GetCurrentDirectory(MLEN - 5,data); break; 
			case '4':
				GetTempPath(MLEN - 5, data); break;
			default: lstrcpy(data,"Error Invalid Number or Type");
		}
		return 3;
	} 
	int directory = atolp(tmp);
	if (directory == 0) {
#define DIRSTR(cst,str) if (!lstrcmpi(data,#str)) directory = cst
	DIRSTR(CSIDL_ADMINTOOLS,ADMINTOOLS);
	else DIRSTR(CSIDL_ALTSTARTUP,ALTSTARTUP);
	else DIRSTR(CSIDL_APPDATA,APPDATA);
	else DIRSTR(CSIDL_BITBUCKET,BITBUCKET);
	else DIRSTR(CSIDL_CDBURN_AREA,CDBURN_AREA);
	else DIRSTR(CSIDL_COMMON_ADMINTOOLS,COMMON_ADMINTOOLS);
	else DIRSTR(CSIDL_COMMON_ALTSTARTUP,COMMON_ALTSTARTUP);
	else DIRSTR(CSIDL_COMMON_APPDATA,COMMON_APPDATA);
	else DIRSTR(CSIDL_COMMON_DESKTOPDIRECTORY,COMMON_DESKTOPDIRECTORY);
	else DIRSTR(CSIDL_COMMON_DOCUMENTS,COMMON_DOCUMENTS);
	else DIRSTR(CSIDL_COMMON_FAVORITES,COMMON_FAVORITES);
	else DIRSTR(CSIDL_COMMON_MUSIC,COMMON_MUSIC);
	else DIRSTR(CSIDL_COMMON_PICTURES,COMMON_PICTURES);
	else DIRSTR(CSIDL_COMMON_PROGRAMS,COMMON_PROGRAMS);
	else DIRSTR(CSIDL_COMMON_STARTMENU,COMMON_STARTMENU);
	else DIRSTR(CSIDL_COMMON_STARTUP,COMMON_STARTUP);
	else DIRSTR(CSIDL_COMMON_TEMPLATES,COMMON_TEMPLATES);
	else DIRSTR(CSIDL_COMMON_VIDEO,COMMON_VIDEO);
	else DIRSTR(CSIDL_CONTROLS,CONTROLS);
	else DIRSTR(CSIDL_COOKIES,COOKIES);
	else DIRSTR(CSIDL_DESKTOP,DESKTOP);
	else DIRSTR(CSIDL_DESKTOPDIRECTORY,DESKTOPDIRECTORY);
	else DIRSTR(CSIDL_DRIVES,DRIVES);
	else DIRSTR(CSIDL_FAVORITES,FAVORITES);
	else DIRSTR(CSIDL_FONTS,FONTS);
	else DIRSTR(CSIDL_HISTORY,HISTORY);
	else DIRSTR(CSIDL_INTERNET,INTERNET);
	else DIRSTR(CSIDL_INTERNET_CACHE,INTERNET_CACHE);
	else DIRSTR(CSIDL_LOCAL_APPDATA,LOCAL_APPDATA);
	else DIRSTR(CSIDL_MYDOCUMENTS,MYDOCUMENTS);
	else DIRSTR(CSIDL_MYMUSIC,MYMUSIC);
	else DIRSTR(CSIDL_MYPICTURES,MYPICTURES);
	else DIRSTR(CSIDL_MYVIDEO,MYVIDEO);
	else DIRSTR(CSIDL_NETHOOD,NETHOOD);
	else DIRSTR(CSIDL_NETWORK,NETWORK);
	else DIRSTR(CSIDL_PERSONAL,PERSONAL);
	else DIRSTR(CSIDL_PRINTHOOD,PRINTHOOD);
	else DIRSTR(CSIDL_PROFILE,PROFILE);
	else DIRSTR(0x003e,PROFILES);
	else DIRSTR(CSIDL_PROGRAM_FILES,PROGRAM_FILES);
	else DIRSTR(CSIDL_PROGRAM_FILES_COMMON,PROGRAM_FILES_COMMON);
	else DIRSTR(CSIDL_PROGRAMS,PROGRAMS);
	else DIRSTR(CSIDL_RECENT,RECENT);
	else DIRSTR(CSIDL_SENDTO,SENDTO); 
	else DIRSTR(CSIDL_STARTMENU,STARTMENU);
	else DIRSTR(CSIDL_STARTUP,STARTUP);
	else DIRSTR(CSIDL_SYSTEM,SYSTEM);
	else DIRSTR(CSIDL_TEMPLATES,TEMPLATES);
	else DIRSTR(CSIDL_WINDOWS,WINDOWS);
	else ret("ERROR Invalid Number or Type") 
#undef DIRSTR
	}

	LPITEMIDLIST list;
	LPMALLOC pShellMalloc;
	if(SUCCEEDED(SHGetMalloc(&pShellMalloc)))
	{
		if(SUCCEEDED(SHGetSpecialFolderLocation(0,directory ,&list)))
		{
			SHGetPathFromIDList(list,data);
			pShellMalloc->Free(list);
		}
		else lstrcpy(data,"0");
		pShellMalloc->Release();
	}
	else lstrcpy(data,"0");
	return 3;
}

MircFunc GetWinDir(FUNCPARMS)
{
	char r[MAXSTRINGLEN];

	GetWindowsDirectory(r, MAXSTRINGLEN - 5);
	lstrcpy(data,r);
	return 3;
}

/*
 * GetSystemDir
 */
MircFunc GetSysDir(FUNCPARMS)
{
	char r[MAXSTRINGLEN];

	GetSystemDirectory(r, MAXSTRINGLEN - 5);
	lstrcpy(data,r); 
	return 3;
}

/*
 * GetTempDir
 */
MircFunc GetTmpDir(FUNCPARMS)
{
	char r[MAXSTRINGLEN];

	GetTempPath(MAXSTRINGLEN - 5, r);
	lstrcpy(data,r); 
	return 3;
}

/*
 * HideMenuBar
 */
MircFunc HideMenuBar(FUNCPARMS)
{
	savemenubar(mWnd, FALSE);
	SetMenu(mWnd, NULL);
	r_ok("");
}

/*
 * ShowMenuBar
 */
MircFunc ShowMenuBar(FUNCPARMS)
{
	if (IsMenu(menubar)) {
		SetMenu(mWnd, menubar);
		r_ok("");
	}
	r_err("BADMENU","Stored Menu handle is messed up")
}

/*
 * MatchTokString <wildstring>
 */
MircFunc MatchTokString (FUNCPARMS)
{
	lstrcpy(matchtok_tokens, data);
	wsprintf(data, "+OK %s", matchtok_tokens);
	return 3;
}


char *matchtokaux (char *string, int tokchar, char *result, tbool cs /* case sensitive */)
{
	char saux[MAXSTRINGLEN + 8], maux[MAXSTRINGLEN + 8], toks[MAXSTRINGLEN], *word, *ptoks;
	int len;

	ptoks = toks;
	wsprintf(saux, "* %s *", string);
	lstrcpy(toks, matchtok_tokens);
	for (;;) {
		word = getnexttok(&ptoks, tokchar);
		if (*word == ' ')
			++word;
		len = lstrlen(word);
		if (len) {
			if (word[len - 1] == ' ') word[len-- - 1] = 0;
			lstrcpy(maux, word);
			if (len > 1) {
				if (word[0] != '*' || word[1] != ' ')
					wsprintf(maux, "* %s", word);
				if (word[len - 2] != ' ' || word[len - 1] != '*')
					lstrcat(maux, " *");
			}
			if (match(maux, saux, cs)) {
				lstrcpy(result, word);
				return result;
			}
			continue;
		}
		return NULL;
	}
}

/*
 * MatchTok <+flags> <tokchar> <string>
 */
MircFunc MatchTok (FUNCPARMS)
{
	char *tmp = data, word[MAXSTRINGLEN], *flags, *aux;
	int tokchar = 32;

	word[0] = 0;
    flags = getword(&tmp);
    tokchar = atolp(getword(&tmp));

	if (!tokchar || tokchar > 255) 
		r_err("TOKCHAR", "Invalid token character number")
	if (isincs(flags, 'r')) {
		for (aux = tmp; *aux; ++aux) {
			if (isincs(",.:-\"'()[]�_�!�?", *aux))
				*aux = ' ';
		}
	}
	matchtokaux(tmp, tokchar, word, isincs(flags, 'c')?TRUE:FALSE );
	if (lstrlen(word)) {
		wsprintf(data, "+OK %s", word);
		return 3;
	}
	r_err("FOUND", "No token matched the string")
}

/*
 * PickColor [DefColor] [CustomColor1] ... [CustomColor16]
 */
MircFunc PickColor(FUNCPARMS)
{
	char *tmp = data,*aux = NULL;
	CHOOSECOLOR ctmp;
	/* static, to re-use if no parms are given */
	static DWORD curgb = 0;
	static COLORREF customcolor[16];
	int i = 0,result;

	if (data[0] == '-')  lstrcpy(data,data + 1);
	result = getfirstnum(&tmp,curgb);
	if ((result == HaveTokenOnly) || (result == HaveNumHaveToken))
	{
		if (result == HaveTokenOnly) {
			aux = getword(&tmp); result = getfirstnum(&tmp,curgb);
		}
		while ((result == HaveNumHaveToken) && (i < 16))
		{ 
			result = getfirstnum(&tmp,customcolor[i]) ;
			i++;
		} 
	}
	ctmp.lStructSize = sizeof(CHOOSECOLOR);
	ctmp.hwndOwner = mWnd;
	ctmp.hInstance = NULL;
	ctmp.rgbResult = curgb;
	ctmp.lpCustColors = (COLORREF*)customcolor;
	ctmp.Flags = CC_RGBINIT|CC_FULLOPEN;
	ctmp.lCustData = (LPARAM)NULL;
	ctmp.lpfnHook = NULL;
	ctmp.lpTemplateName = NULL;
 
	if(ChooseColor(&ctmp)) {
		curgb = ctmp.rgbResult; /* storing it to re-use */
		rnum_var(aux,ctmp.rgbResult);
	}
	else { 	Unsetvar(aux); lstrcpy(data,"$false"); }
	return 3;
}
HWND GetTargetWindow(char* data, HWND aWnd, HWND mWnd) {
	if (lstrlen(data) <= 3) return NULL;
	if ((data[0] == '-') && (data[2] == ' '))
		switch (data[1]) {
			case 'm':
				lstrcpy(data, &data[3]);
				return mWnd;
			case 'a':
				lstrcpy(data, &data[3]);
				return aWnd;
			case 'w':
			{
				int n;
				char *newdata = &data[3];

				if (getfirstnum(&newdata,n) > 0) {
					lstrcpy(data, newdata);
					return IsWindow((HWND)n)? (HWND)n : NULL;
				}
			}
		}
	return NULL;
}
MircFunc SetIcon(FUNCPARMS) {
	HICON LargeIcon, SmallIcon;
	int Index;
	DWORD Result;
	char *FileName = data, FullName[MAX_PATH];
	HWND hWnd = GetTargetWindow(data, aWnd, mWnd);

	if (!hWnd) 	r_err("BADWIN", "Invalid HWND")
	if (getfirstnum(&FileName,Index) < 0)	Index = 0;
	else if (Index > 0) Index--;

	// look for the file in default paths...
	Result = SearchPath(NULL, FileName, NULL, sizeof(FullName), FullName, NULL);
	if (Result == 0) r_err("FILE", "File not found")
	if (Result > sizeof(FullName)) r_err("PATH","file path is too big");
	if (ExtractIconEx(FullName, Index, &LargeIcon, &SmallIcon, 1) == 0) r_err("NO","icon not found");

	// try to have both icons
	if (!LargeIcon) LargeIcon = SmallIcon;
	else if (!SmallIcon) SmallIcon = LargeIcon;

	SmallIcon = (HICON)SendMessage(hWnd, WM_SETICON, ICON_SMALL, (LPARAM)SmallIcon);
	LargeIcon = (HICON)SendMessage(hWnd, WM_SETICON, ICON_BIG, (LPARAM)LargeIcon);
	if (SmallIcon) DestroyIcon(SmallIcon);
	if (LargeIcon) DestroyIcon(LargeIcon);
	r_ok("");
}

MircFunc mSetCursor(FUNCPARMS) {
	const char Cursors[][12] = {"default", "appstarting", "cross", "help",
		"ibeam", "no", "size", "sizenesw", "sizens", "sizenwse", "sizewe",
		"uparrow", "wait","hand"};
	const LPTSTR Values[] = {IDC_ARROW, IDC_APPSTARTING, IDC_CROSS, IDC_HELP,
		IDC_IBEAM, IDC_NO, IDC_SIZEALL, IDC_SIZENESW, IDC_SIZENS, IDC_SIZENWSE, IDC_SIZEWE,
		IDC_UPARROW, IDC_WAIT,IDC_HAND};

	UINT i;
	HCURSOR hCurNew;
	HWND hWnd = GetTargetWindow(data, aWnd, mWnd);

	if (!hWnd) r_err("BADWIN", "Invalid HWND");
	for (i = 0; i < 14; i++)
		if (!lstrcmpi(Cursors[i], data)) {
			hCurNew = LoadCursor(NULL, Values[i]);
			if (!hCurNew) r_err("SYSERR","system error; unknown problem happened");
			SetClassLong(hWnd, GCL_HCURSOR, (LONG)hCurNew);
			r_ok("");
		}		
	r_err("PARA","Invalid parameter");
}

MircFunc SetBit(FUNCPARMS)
{
	char *tmp = data;
	DWORD num, power = 1 ;
	int pos;

	if (getfirstnum(&tmp,num) < 0) lstrcpy(data,"-PARA Invalid num"); 
	else {
		if (getfirstnum(&tmp,pos) <0) lstrcpy(data,"-PARA Invalid bit"); 
		else {
			if (pos < 0)  { num = 0; }
			else 
				if ( pos > 0) {	power <<= pos - 1; num |= power; }
			nrnum_var(tmp,num);
		}
	}
	return 3;
}
MircFunc CountIcons(FUNCPARMS) {
	char FullName[MLEN];
	char *var;
	char *tmp = data;
	DWORD Result;
    var = get_af_para(&tmp,'v');
	if ((var) && (*var)) SetVar(var,0);
	Result = SearchPath(NULL, tmp, NULL, sizeof(FullName), FullName, NULL);
	if (Result == 0) ret_FNF 
	if (Result > sizeof(FullName)) ret("-ERROR file path is too long")
	rnum_var(var, ExtractIconEx(FullName, -1, NULL, NULL, 1));
	if (var) delete var;
	return 3;
}
MircFunc UnSetBit(FUNCPARMS)
{
	char *tmp = data;
	DWORD num, power = 1 ;
	int pos;

	if (getfirstnum(&tmp,num) < 0) lstrcpy(data,"-PARA Invalid num"); 
	else {
		if (getfirstnum(&tmp,pos) <0) lstrcpy(data,"-PARA Invalid bit"); 
		else {
			if (pos < 0)  { num = 0; }
			else 
				if ( pos > 0) {	
					power <<= pos - 1; 
					num  &= (0xffffffff ^ power) ;
				}
			nrnum_var(tmp,num);
		}
	}
	return 3;
}

MircFunc GetBit(FUNCPARMS)
{
	char *tmp = data;
	DWORD num, power = 1 ;
	int pos;

	if (getfirstnum(&tmp,num) < 0) lstrcpy(data,"-PARA Invalid num"); 
	else {
		if (getfirstnum(&tmp,pos) <0) lstrcpy(data,"-PARA Invalid bit"); 
		else {
			if (pos < 0)  { num = 0; }
			else 
				if ( pos > 0) {	
					power <<= pos - 1; 
					num = (num & power)?1:0;
				}
			nrnum_var(tmp,num);
		}
	}
	return 3;
}

MircFunc AddPath(FUNCPARMS) {
	char *var = NULL,buf[MLEN];
	char *file = data,*aux;
	DWORD Result = 0;
	int i = 0;
	if (data[0] == '-') {
		if (data[1] == 0) RETINVF
		var = get_af_para(&file,'v');
		if (!var) getword(&file);
	}
	if ((var) && (*var)) SetVar(var,"");
	if (!*file)  RETINVF
	if (getfirstnum(&file,i) == HaveTokenOnly) {
		aux = getword(&file);
		if (!lstrcmpi(data,"Mircdir")) i = 1;
		else if (!lstrcmpi(data,"Scriptdir")) i = 2;
		else if (!lstrcmpi(data,"Windir")) i = 3;
		else if (!lstrcmpi(data,"Sysdir")) i = 4;
		else if (!lstrcmpi(data,"Bothdir")) i = 5;
		else { if (*file) aux[lstrlen(aux)] = 32 ; file = aux; }
	}
	switch (i) {
		case 1: {
			lstrcpy(mData,"$mircdir"); SendMessage(MIRC, WM_USER + 201,0,0);
			Result = SearchPath(mData,file,0,MLEN,buf,0);
			break;
				}
		case 2: {
			lstrcpy(mData,"$scriptdir"); SendMessage(MIRC, WM_USER + 201,0,0);
			Result = SearchPath(mData,file,0,MLEN,buf,0);
			break;
				}
		case 3:{
			GetWindowsDirectory(buf,MLEN);
			Result = SearchPath(buf,file,0,MLEN,buf,0);
			break;
			   }
		case 4: {
			GetSystemDirectory(buf,MLEN);
			Result = SearchPath(buf,file,0,MLEN,buf,0);
			break;
				}
		case 5:{
			GetWindowsDirectory(buf,MLEN);
			Result = SearchPath(buf,file,0,MLEN,buf,0);
			if (!Result) {
				GetSystemDirectory(buf,MLEN);
				Result = SearchPath(buf,file,0,MLEN,buf,0);
			}
			break;
			   }
		default: { 
			lstrcpy(mData,"$scriptdir"); SendMessage(MIRC, WM_USER + 201,0,0);
			Result = SearchPath(mData,file,0,MLEN,buf,0);
			if (!Result) {	Result = SearchPath(0,file,0,MLEN,buf,0); }
				 }
	}
	if (Result) { r_var(var,buf) }
	else lstrcpy(data,"-ERROR File not found");
	return 3;
}

MircFunc IOFile(FUNCPARMS)
{
	char *filter,*tmp = data,*aux;
	char title[BLEN];
	char files[0x4000];
	char b[MLEN];
	int preselected = 0,result;
	BOOL multiselect = 0;
	BOOL isalias = 0;
	BOOL shortfile = 0,autos = 0;

	//dir>file name>Title>filter>preselect>@ms command
	OPENFILENAME *o = new OPENFILENAME;
	ZeroMemory(o, sizeof(OPENFILENAME));
    o->lStructSize = sizeof(OPENFILENAME);
	o->hwndOwner = mWnd;
	o->lpstrInitialDir = getnexttokB(&tmp,'>');
	aux = getnexttokB(&tmp,'>');
	if (aux) { lstrcpy(files,aux); }
	else files[0] = 0;
	o->lpstrFile = files;
	aux = getnexttokB(&tmp,'>');
	if (aux)  lstrcpy(title,aux); else title[0] = 0;
	o->lpstrTitle = title;
	filter = getnexttokB(&tmp,'>');
	if (filter) {
		if(!lstrcmpi(filter,"Music")) filter = "Media files\0*.wav;*.mid;*.rmi;*.mp1;*.mpeg;*.mpg;*.mp2;*.mp3;*.wma;*.aif;*.avi;*.dat\0MP3 files\0;*.mp1;*.mp2;*.mp3\0Midi files\0*.mid;*.midi\0Wave files\0*.wav\0\0";
		else if(!lstrcmpi(filter,"mMusic")) filter = "Media files\0*.wav;*.mid;*.mp3\0Mp3 files(*.mp3)\0*.mp3\0Midi Files(*.mid)\0*.mid\0Wave Files(*.wav)\0*.wav\0\0";
		else if(!lstrcmpi(filter,"mp3"))	filter = "Mp3 Files(*.mp3)\0*.mp3\0\0";
		else if(!lstrcmpi(filter,"wav")) filter = "Wave Files(*.wav)\0*.wav\0\0";
		else if(!lstrcmpi(filter,"midi")) filter = "Midi Files(*.mid,*.midi)\0*.mid;*.midi\0\0";
		else if(!lstrcmpi(filter,"Images"))	filter = "Images\0*.bmp;*.gif;*.jpg;*.jpeg;*.png;*.tif\0Bitmap (*.bmp)\0;*.bmp\0Gif (*.gif)\0*.gif\0Image jpeg (*.jpg;*.jpeg)\0*.jpg;*.jpeg\0Images png (*.png)\0*.png\0Images tif (*.tif)\0*.tif\0\0";
		else if(!lstrcmpi(filter,"bmp")) filter = "Image bitmap (*.bmp)\0*.bmp\0\0";
		else if(!lstrcmpi(filter,"mImages")) filter = "Images\0*.bmp;*.jpg;*.png\0Bitmap (*.bmp)\0;*.bmp\0Image jpeg (*.jpg;*.jpeg)\0*.jpg;*.jpeg\0Images png (*.png)\0*.png\0\0";
		else if(!lstrcmpi(filter,"HTML")) filter = "web Pages\0*.htm;*.html;*.shtml;*.mht\0\0";
		else if(!lstrcmpi(filter,"ico"))	filter = "Icon Files (*.ico,*.icl)\0*.ico;*.icl\0\0";
		else if(!lstrcmpi(filter,"exe")) filter = "Applications\0*.exe;*.com;*.bat\0\0" ;
		else if(!lstrcmpi(filter,"txt")) filter = "Text files(*.txt)\0*.txt\0\0" ;
		else if(!lstrcmpi(filter,"log")) filter = "Log Files(*.log)\0*.log\0\0" ;
		else if(!lstrcmpi(filter,"compress")) filter = "Compress files\0*.zip;*.lzh;*.arj;*.arc;*.cab;*.tar;*.tgz;*.taz;*.tz;*.gz;*.z;*.uu;*.uue;*.xxe;*.b64;*.hqx;*.bhx;*.mim;*.gzip;*.rar\0\0";
		else if(!lstrcmpi(filter,"mZip")) filter = "Zip Files\0*.zip;*.gz\0\0";
		else if(!lstrcmpi(filter,"mIRC")) filter = "No selection\0*\0All files (*.*)\0*.*\0Scripts (*.ini;*.mrc)\0*.ini;*.mrc\0Text files (*.txt;*.doc)\0*.txt;*.doc\0Log files (*.log)\0*.log\0Sounds (*.wav;*.mid;*.mp3)\0*.wav;*.mid;*.mp3\0Pictures (*.bmp;*.png;*.jpg)\0*.bmp;*.png;*.jpg\0Zip files (*.zip)\0*.zip\0\0";
		else if(!lstrcmpi(filter,"All")) filter = "All Files\0*\0Text Files\0*.txt;*.doc\0Log Files (*.log)\0*.log\0web pages(*.htm;*.html;*.mht)\0*.htm;*.html\0mIRC Scripts(*.ini;*.mrc)\0*.ini;*.mrc\0Images (*.bmp;*.gif;*.jpg;*.jpeg;*.png;*.tif)\0*.bmp;*.gif;*.jpg;*.jpeg;*.png;*.tif\0Icon Files (*.ico,*.icl)\0*.ico;*.icl\0Sound Files(*.wav;*.mp3;*.mid)\0*.wav;*.mp3;*.mid\0Applications (*.exe)\0*.exe\0Zips (*.zip,*.gz)\0*.zip;*.gz\0\0";
		else if(!filter[0]) filter = "All Files\0*\0Text Files\0*.txt;*.doc\0Log Files (*.log)\0*.log\0web pages(*.htm;*.html;*.mht)\0*.htm;*.html\0mIRC Scripts(*.ini;*.mrc)\0*.ini;*.mrc\0Images (*.bmp;*.gif;*.jpg;*.jpeg;*.png;*.tif)\0*.bmp;*.gif;*.jpg;*.jpeg;*.png;*.tif\0Icon Files (*.ico,*.icl)\0*.ico;*.icl\0Sound Files(*.wav;*.mp3;*.mid)\0*.wav;*.mp3;*.mid\0Applications (*.exe)\0*.exe\0Zips (*.zip,*.gz)\0*.zip;*.gz\0\0";
		else {
			lstrcpy(b,filter); filter = b;
			BOOL w = 1;int i = 0;
			while(filter[i]) {
				if(filter[i] == '|' && w == 0 ) { filter[i] = 0; w = 1;}
				if (filter[i] == '=' && w == 1) { filter[i] = 0; w = 0; }
				i++;
			}
			filter[i+1] = 0; filter[i+2] = 0;
		}

	}
	else { filter = "All Files\0*\0Text Files\0*.txt;*.doc\0Log Files (*.log)\0*.log\0web pages(*.htm;*.html;*.mht)\0*.htm;*.html\0mIRC Scripts(*.ini;*.mrc)\0*.ini;*.mrc\0Images (*.bmp;*.gif;*.jpg;*.jpeg;*.png;*.tif)\0*.bmp;*.gif;*.jpg;*.jpeg;*.png;*.tif\0Icon Files (*.ico,*.icl)\0*.ico;*.icl\0Sound Files(*.wav;*.mp3;*.mid)\0*.wav;*.mp3;*.mid\0Applications (*.exe)\0*.exe\0Zips (*.zip,*.gz)\0*.zip;*.gz"; }
	o->lpstrFilter = filter;
	aux = getnexttokB(&tmp,'>');
	if (aux)  preselected = atolp(aux);
	o->nFilterIndex = (DWORD) preselected;
	o->nMaxFile = 0x4000;
	o->nMaxFileTitle = BLEN;
	o->nFileExtension = o->nFileOffset = 0;
	o->Flags =  OFN_PATHMUSTEXIST |OFN_NOCHANGEDIR | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY | OFN_EXPLORER;
	o->lpstrCustomFilter = o->lpstrFileTitle = 0 ;
	if (*tmp == '>') ++tmp;
	if (*tmp) {
		if (*tmp == '@') {
			aux = getword(&tmp);
			if (isind(aux,'m','M'))  { o->Flags |= OFN_ALLOWMULTISELECT; multiselect = 1; }
			if (isind(aux,'s','S'))  shortfile = 1;
			if (isind(aux,'a','A'))  autos = 1;
		}
		if (*tmp) isalias = 1;
	}
	if (!GetOpenFileName(o)) {
		files[0] = 0;
		preselected = CommDlgExtendedError();
		if(preselected) {
			if (preselected == FNERR_BUFFERTOOSMALL) lstrcpy(data,"-Over Too many files selected");
			else lstrcpy(data,"-ERROR");
		}
		else data[0] = 0;
		delete o;
		return 3;
	}
	if (!multiselect) {
		if (!isalias) { 
			if (autos) { if (strstr(o->lpstrFile,"  ")) shortfile = 1; else	shortfile = 0; }
			if (shortfile) {
				result = GetShortPathName(o->lpstrFile,data,MAX_PATH); 
				if (!result) lstrcpy(data,o->lpstrFile); 
			}
			else lstrcpy(data,o->lpstrFile); 
		}
		else {
			if (autos) { if (strstr(o->lpstrFile,"  ")) shortfile = 1; else	shortfile = 0; }
			if (shortfile) {
				result = GetShortPathName(o->lpstrFile,Paratransfer,MAX_PATH); 
				if (!result) lstrcpy(data,Paratransfer); 
			}
			else lstrcpy(Paratransfer,o->lpstrFile);
			lstrcpy(b,tmp);	
			if (Npc_eval(b,'\\',FALSE)) {
				lstrcpy(mData,b);
				SendMessage(mWnd, WM_USER + 200,0,0);
			}
			delete o;	return 1;
		}
	}
	else {  
		char *c = files;
		char r[MLEN]; 	
		char path[512];
		int slc,t,j,msc;

		if ((shortfile) || (autos)) { 
			lstrcpyn(b,c,o->nFileOffset);
			if (autos) { if (!strstr(b,"  ")) { shortfile = 0; goto flform; } }
			result = GetShortPathName(b,&path[0],MAX_PATH); 
			if (!result) { shortfile = 0; goto flform; }
			slc = lstrlen(path); 
			path[slc++] = '\\';	
		}
		else {
flform:		lstrcpy(path,c); slc = o->nFileOffset; 
			if (path[slc-1] == 0) path[slc-1] = '\\'; 
		}
		path[slc] = 0;
		b[0] = 0;	c = &files[o->nFileOffset];
		if (!isalias) {
			msc = 899 - slc;
			do {
				if (autos) { 
					if (!strstr(c,"  ")) { shortfile = 0; goto flform1; }
					else shortfile = 1;
				}
				if (shortfile) {
					aux = lstrcat(path,c);
					GetShortPathName(aux,&r[0],BLEN);
					aux = &r[slc];t = lstrlen(aux); j = slc + t;
					r[j] = '>'; t++; r[++j] = 0;
				}
				else { 
flform1:			lstrcpy(r,c); aux = &r[0] ; 
					t = lstrlen(aux); r[t++] = '>'; r[t] = 0; 
				}
				msc -= t;
				if (msc > 0) lstrcat(b,aux); else goto nL;
				if (shortfile) { path[slc] = 0; c += lstrlen(c) + 1; }
				else c += t;
			}while (*c);
nL:		wsprintf(data,"%s>%s",path,b);
		}
		else {
			do {
				if (!strstr(c,"  ")) { shortfile = 0; goto flform2; }
				else shortfile = 1;
				if (shortfile) {
					aux = lstrcat(path,c);
					GetShortPathName(aux,&r[0],BLEN);
					lstrcpy(Paratransfer,r);
				}
				else { flform2:			lstrcat(path,c); lstrcpy(Paratransfer,path);	}
				lstrcpy(b,tmp);
				if (Npc_eval(b,'\\',FALSE)) {
					lstrcpy(mData,b);
					SendMessage(mWnd, WM_USER + 200,0,0);
				}
				path[slc] = 0; 	c += lstrlen(c) + 1; 
			}while (*c);
			delete o;
			return 1;
		}
	}
	delete o;
	return 3;
}
MircFunc ISFile(FUNCPARMS)
{
	char *filter,*tmp = data,*aux,*ts;
	char title[BLEN],file[MLEN],b[MLEN];
	int preselected = 0;
	BOOL shortfile = 0, index = 0;

	//dir>file name>Title>filter>preselect>@ms command
	OPENFILENAME *o = new OPENFILENAME;
	ZeroMemory(o, sizeof(OPENFILENAME));
    o->lStructSize = sizeof(OPENFILENAME);
	o->hwndOwner = mWnd;
	o->lpstrInitialDir = getnexttokB(&tmp,'>');
	aux = getnexttokB(&tmp,'>');
	if (aux) { lstrcpy(file,aux); }
	else file[0] = 0;
	o->lpstrFile = file;
	aux = getnexttokB(&tmp,'>');
	if (aux)  lstrcpy(title,aux); else title[0] = 0;
	o->lpstrTitle = title;
	filter = getnexttokB(&tmp,'>');
	if (filter) {
		if(!lstrcmpi(filter,"Music")) { ts = "mp3;mp3;mid;wav" ; filter = "Media files\0*.wav;*.mid;*.rmi;*.mp1;*.mpeg;*.mpg;*.mp2;*.mp3;*.wma;*.aif;*.avi;*.dat\0MP3 files\0;*.mp1;*.mp2;*.mp3\0Midi files\0*.mid;*.midi\0Wave files\0*.wav\0\0"; }
		else if(!lstrcmpi(filter,"mMusic")) { ts = "mp3;mp3;mid;wav" ; filter = "Media files\0*.wav;*.mid;*.mp3\0Mp3 files(*.mp3)\0*.mp3\0Midi Files(*.mid)\0*.mid\0Wave Files(*.wav)\0*.wav\0\0"; }
		else if(!lstrcmpi(filter,"mp3")) { ts = "mp3" ;	filter = "Mp3 Files(*.mp3)\0*.mp3\0\0"; }
		else if(!lstrcmpi(filter,"wav")) { ts = "wav" ; filter = "Wave Files(*.wav)\0*.wav\0\0"; }
		else if(!lstrcmpi(filter,"midi")){ ts = "mid"; filter = "Midi Files(*.mid,*.midi)\0*.mid;*.midi\0\0"; }
		else if(!lstrcmpi(filter,"Images")) { ts = "bmp;bmp;gif;jpg;png;tif";	filter = "Images\0*.bmp;*.gif;*.jpg;*.jpeg;*.png;*.tif\0Bitmap (*.bmp)\0;*.bmp\0Gif (*.gif)\0*.gif\0Image jpeg (*.jpg;*.jpeg)\0*.jpg;*.jpeg\0Images png (*.png)\0*.png\0Images tif (*.tif)\0*.tif\0\0"; }
		else if(!lstrcmpi(filter,"bmp")) { ts = "bmp"; filter = "Image bitmap (*.bmp)\0*.bmp\0\0"; }
		else if(!lstrcmpi(filter,"mImages")) { ts = "bmp;bmp;jpg;png"; filter = "Images\0*.bmp;*.jpg;*.png\0Bitmap (*.bmp)\0;*.bmp\0Image jpeg (*.jpg;*.jpeg)\0*.jpg;*.jpeg\0Images png (*.png)\0*.png\0\0"; }
		else if(!lstrcmpi(filter,"HTML")) { ts = "html"; filter = "web Pages\0*.htm;*.html;*.shtml;*.mht\0\0"; }
		else if(!lstrcmpi(filter,"ico")) { ts = "ico";	filter = "Icon Files (*.ico,*.icl)\0*.ico;*.icl\0\0"; }
		else if(!lstrcmpi(filter,"exe")) { ts = "exe"; filter = "Applications\0*.exe;*.com;*.bat\0\0" ; }
		else if(!lstrcmpi(filter,"txt")) { ts = "txt"; filter = "Text files(*.txt)\0*.txt\0\0" ; }
		else if(!lstrcmpi(filter,"log")) { ts = "log"; filter = "Log Files(*.log)\0*.log\0\0" ; }
		else if(!lstrcmpi(filter,"compress")) { ts = "zip"; filter = "Compress files\0*.zip;*.lzh;*.arj;*.arc;*.cab;*.tar;*.tgz;*.taz;*.tz;*.gz;*.z;*.uu;*.uue;*.xxe;*.b64;*.hqx;*.bhx;*.mim;*.gzip;*.rar\0\0"; }
		else if(!lstrcmpi(filter,"mZip")) { ts = "zip"; filter = "Zip Files\0*.zip;*.gz\0\0"; }
		else if(!lstrcmpi(filter,"mIRC")) { ts = "-;mrc;txt;log;mp3;bmp;zip"; filter = "No selection\0*\0All files (*.*)\0*.*\0Scripts (*.ini;*.mrc)\0*.ini;*.mrc\0Text files (*.txt;*.doc)\0*.txt;*.doc\0Log files (*.log)\0*.log\0Sounds (*.wav;*.mid;*.mp3)\0*.wav;*.mid;*.mp3\0Pictures (*.bmp;*.png;*.jpg)\0*.bmp;*.png;*.jpg\0Zip files (*.zip)\0*.zip\0\0"; }
		else if(!lstrcmpi(filter,"All")) { ts = "-;txt;log;htm;mrc;bmp;ico;mp3;exe;zip"; filter = "All Files\0*\0Text Files\0*.txt;*.doc\0Log Files (*.log)\0*.log\0web pages(*.htm;*.html;*.mht)\0*.htm;*.html\0mIRC Scripts(*.ini;*.mrc)\0*.ini;*.mrc\0Images (*.bmp;*.gif;*.jpg;*.jpeg;*.png;*.tif)\0*.bmp;*.gif;*.jpg;*.jpeg;*.png;*.tif\0Icon Files (*.ico,*.icl)\0*.ico;*.icl\0Sound Files(*.wav;*.mp3;*.mid)\0*.wav;*.mp3;*.mid\0Applications (*.exe)\0*.exe\0Zips (*.zip,*.gz)\0*.zip;*.gz\0\0"; }
		else if(!filter[0]) { ts = "-;txt;log;htm;mrc;bmp;ico;mp3;exe;zip"; filter = "All Files\0*\0Text Files\0*.txt;*.doc\0Log Files (*.log)\0*.log\0web pages(*.htm;*.html;*.mht)\0*.htm;*.html\0mIRC Scripts(*.ini;*.mrc)\0*.ini;*.mrc\0Images (*.bmp;*.gif;*.jpg;*.jpeg;*.png;*.tif)\0*.bmp;*.gif;*.jpg;*.jpeg;*.png;*.tif\0Icon Files (*.ico,*.icl)\0*.ico;*.icl\0Sound Files(*.wav;*.mp3;*.mid)\0*.wav;*.mp3;*.mid\0Applications (*.exe)\0*.exe\0Zips (*.zip,*.gz)\0*.zip;*.gz\0\0"; }
		else {
			lstrcpy(b,filter); filter = b;
			index = 1;ts = 0;
			BOOL w = 1;int i = 0;
			while(filter[i]) {
				if(filter[i] == '|' && w == 0 ) { filter[i] = 0; w = 1;}
				if (filter[i] == '=' && w == 1) { filter[i] = 0; w = 0; }
				i++;
			}
			filter[i+1] = 0; filter[i+2] = 0;
		}

	}
	else { ts = "-;txt;log;htm;mrc;bmp;ico;mp3;exe;zip"; filter = "All Files\0*\0Text Files\0*.txt;*.doc\0Log Files (*.log)\0*.log\0web pages(*.htm;*.html;*.mht)\0*.htm;*.html\0mIRC Scripts(*.ini;*.mrc)\0*.ini;*.mrc\0Images (*.bmp;*.gif;*.jpg;*.jpeg;*.png;*.tif)\0*.bmp;*.gif;*.jpg;*.jpeg;*.png;*.tif\0Icon Files (*.ico,*.icl)\0*.ico;*.icl\0Sound Files(*.wav;*.mp3;*.mid)\0*.wav;*.mp3;*.mid\0Applications (*.exe)\0*.exe\0Zips (*.zip,*.gz)\0*.zip;*.gz"; }
	o->lpstrFilter = filter;
	aux = getnexttokB(&tmp,'>');
	if (aux)  preselected = atolp(aux);
	o->nFilterIndex = (DWORD) preselected;
	o->nMaxFile = 900;
	o->nMaxFileTitle = BLEN;
	o->nFileExtension = o->nFileOffset = 0;
	o->Flags =  OFN_PATHMUSTEXIST |OFN_NOCHANGEDIR | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_EXPLORER;
	o->lpstrCustomFilter = o->lpstrFileTitle = 0 ;
	if (*tmp == '>') ++tmp; 
	if ((*tmp == 'S') || (*tmp == 's')) shortfile = 1;

	if (!GetSaveFileName(o)) { delete o; data[0] = 0;	return 3;	}
	if (ts) {
		lstrcpy(title,ts);
		getnthtok(title,o->nFilterIndex,';');
		if (title[0] == '-') title[0] = 0;
	} else {
		if (index) wsprintf(title,"%d",o->nFilterIndex);
		else title[0] = 0;
	}
	if (shortfile) {
		int re = GetShortPathName(o->lpstrFile,b,MAX_PATH); 
		if (re) wsprintf(data,"%s>%s",b,title);
		else {
			o->lpstrFile[o->nFileOffset - 1] = 0;
			int re = GetShortPathName(o->lpstrFile,b,MAX_PATH); 
			wsprintf(data,"%s\\%s>%s",re?b:o->lpstrFile,&o->lpstrFile[o->nFileOffset],title);
		}
	}
	else wsprintf(data,"%s>%s",o->lpstrFile,title);
	delete o;
	return 3;
}

VOID CALLBACK BANDR(HWND hwnd,UINT message,UINT idTimer,DWORD dwTime)
{
    ULONG x = 0;
	GetIfTable(ifMIB,&gbb_s,1);
	gbb_o_get = gbb_get; gbb_o_snd = gbb_snd;	gbb_get=gbb_snd=0;
	while (x++ <= ifMIB->dwNumEntries) {
		gbb_get += ifMIB->table[x].dwInOctets;
		gbb_snd += ifMIB->table[x].dwOutOctets;
	}
	gbb_gets = (gbb_get - gbb_o_get); gbb_snds = (gbb_snd - gbb_o_snd); 
}
MircFunc InitBandTime(FUNCPARMS) {
	if (!ifMIB) {
		gbb_o_get = gbb_o_snd = gbb_snd = gbb_get = gbb_gets = gbb_snds = gbb_s = 0;
		GetIfTable(0,&gbb_s,1); 
		ifMIB = (PMIB_IFTABLE)smalloc((size_t)gbb_s);
		SetTimer(MIRC,150, 1000, (TIMERPROC) BANDR);
	}
	ret("+OK");
}
MircFunc DestroyBandTime(FUNCPARMS) {
	if (ifMIB) {
		gbb_gets = gbb_snds = 0;
		KillTimer(MIRC,150);
		mfree(ifMIB);ifMIB = 0;
	}
	ret("+OK");
}
MircFunc BandWidth(FUNCPARMS) {
	wsprintf(data,"%d %d", gbb_gets, gbb_snds);
	return 3;
}
MircFunc FileOperation(FUNCPARMS) {
	SHFILEOPSTRUCT fstruct;
	char source[MLEN];
	char dest[MLEN];
	char *tmp = data;
	char *aux;
	BOOL  baux = 0;

	aux = getnexttokB(&tmp,'>');
	if (!aux) RETINVP
	if (!lstrcmpi(aux,"copy")) fstruct.wFunc = FO_COPY;
	else if (!lstrcmpi(aux,"Delete")) fstruct.wFunc = FO_DELETE;
	else if (!lstrcmpi(aux,"Move")) fstruct.wFunc = FO_MOVE;
	else ret("-OP invalid operation");
	aux = getnexttok(&tmp,'>');
	if (!aux || !*aux) RETINVF
	lstrcpy(source,aux); aux = source; fstruct.pFrom = &source[0];
	while(*aux) {
		if(*aux == '|') *aux = 0;
		aux++;
	}
	*aux++ = 0; *aux = 0; fstruct.fFlags = FOF_NOCOPYSECURITYATTRIBS;
	if (fstruct.wFunc != FO_DELETE) {
		aux = getnexttok(&tmp,'>');
		if (!aux || !*aux) RETINVF
		lstrcpy(dest,aux); aux = dest; fstruct.pTo = &dest[0];
		while(*aux) {
			if(*aux == '|') { *aux = 0; baux = 1; }
			aux++;
		}
		*aux++ = 0; *aux = 0;
		if (baux) fstruct.fFlags |= FOF_MULTIDESTFILES;
	}
	else fstruct.pTo = 0;
	aux = getnexttok(&tmp,'>');
	if (aux && *aux) {
		CharUpper(aux);
		if (isincs(aux,'R')) fstruct.fFlags |= FOF_NORECURSION;
		if (isincs(aux,'C')) fstruct.fFlags |= FOF_NOCONFIRMMKDIR;
		if (isincs(aux,'N')) fstruct.fFlags |= FOF_RENAMEONCOLLISION;
		if (isincs(aux,'S')) fstruct.fFlags |= FOF_SILENT;
		if (isincs(aux,'E')) fstruct.fFlags |= FOF_NOERRORUI;
		if (isincs(aux,'Y')) fstruct.fFlags |=  FOF_NOCONFIRMATION;
		if (isincs(aux,'A')) {
			aux = getnexttok(&tmp,'>');
			if (aux && *aux) {
				int n = 0;
				if (getfirstnum(aux,n) > 0) 
					if ((IsWindow(HWND(n))) || (n == 0))	aWnd =  (HWND)n;
			}
		}
		if (isincs(aux,'P')) {
			fstruct.fFlags |= FOF_SIMPLEPROGRESS;
			fstruct.lpszProgressTitle = getnexttok(&tmp,'>');
		}
		else fstruct.lpszProgressTitle = NULL;
	}
	else fstruct.lpszProgressTitle = NULL;
	fstruct.hwnd = aWnd;
	fstruct.hNameMappings = NULL;
	if (!SHFileOperation(&fstruct)) ret("+OK")
	else if (fstruct.fAnyOperationsAborted) ret ("ABORT")
	else ret("-ERROR")
}

MircFunc ShutdownBox(FUNCPARMS) {
	HANDLE hToken;            
	TOKEN_PRIVILEGES tkp;       
	BOOL fResult;               
	DWORD Time = 20;
	BOOL forceapp = FALSE, ReBoot = FALSE;
	char *tmp = data, buf[MLEN],*tmpbuf;
	char *aux =  getword(&tmp);
	if (aux[0] == '-') {
		tmpbuf = creat_para("FRT[NUM]",aux);
		if (take_para(tmpbuf,"T",&buf[0])) Time = atolp(buf);
		if (find_para(tmpbuf,'F')) forceapp = TRUE;
		if (find_para(tmpbuf,'R')) ReBoot = TRUE;
		delete tmpbuf;
	}
	else { aux[lstrlen(aux)] = 32; tmp = aux; }

	if (!OpenProcessToken(GetCurrentProcess(), 
        TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken)) 
      ret("-ACCESS Couldn't retrieve system privileges"); 

	LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME,
	   &tkp.Privileges[0].Luid); 

	tkp.PrivilegeCount = 1;    
	tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED; 

    AdjustTokenPrivileges(hToken, FALSE, &tkp, 0, 
      (PTOKEN_PRIVILEGES) NULL, 0); 
    if (GetLastError() != ERROR_SUCCESS)  
			ret("-ACCESS Couldn't Initial Request Access"); 

	fResult = InitiateSystemShutdown(NULL,tmp,Time,forceapp,ReBoot);   
 	if (!fResult) ret("-ERROR"); 
 
	tkp.Privileges[0].Attributes = 0; 
	AdjustTokenPrivileges(hToken, FALSE, &tkp, 0, 
        (PTOKEN_PRIVILEGES) NULL, 0); 
 	ret("+OK"); 
}
MircFunc HaltShutdown(FUNCPARMS) {
	HANDLE hToken;              
	TOKEN_PRIVILEGES tkp;       
 
 	if (!OpenProcessToken(GetCurrentProcess(), 
        TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken)) 
      ret("-ACCESS Couldn't retrieve system privileges"); 

	LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME,
	   &tkp.Privileges[0].Luid); 

	tkp.PrivilegeCount = 1;    
	tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED; 

    AdjustTokenPrivileges(hToken, FALSE, &tkp, 0, 
      (PTOKEN_PRIVILEGES) NULL, 0); 
    if (GetLastError() != ERROR_SUCCESS)  
			ret("-ACCESS Couldn't Initial Request Access"); 
 
   if ( !AbortSystemShutdown(NULL) ) ret("-ERROR");

   tkp.Privileges[0].Attributes = 0; 
   AdjustTokenPrivileges(hToken, FALSE, &tkp, 0, 
       (PTOKEN_PRIVILEGES) NULL, 0); 
   ret("+OK");
 }

MircFunc m_ExitWindows(FUNCPARMS) {
	HANDLE hToken;            
	TOKEN_PRIVILEGES tkp;       
	UINT flags = 0;
	BOOL access = 1;
	char *tmp = data;
	char *aux =  getword(&tmp);

    if (aux[0] == '-') {
		CharUpper(aux);
		if (isincs(aux,'F')) flags |= EWX_FORCE;
		if (isincs(aux,'H')) flags |= 0x00000010;
	}
	else tmp = aux;
	if (!lstrcmpi(tmp,"ReBoot")) flags |= EWX_REBOOT;
	else if (!lstrcmpi(tmp,"PowerOff")) flags |=  EWX_POWEROFF;
	else if (!lstrcmpi(tmp,"LogOff")) { flags |=  EWX_LOGOFF; access = 0; }
	else flags |= EWX_SHUTDOWN;
	if (access) {
		if (!OpenProcessToken(GetCurrentProcess(), 
			TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken)) 
		ret("-ACCESS Couldn't retrieve system privileges"); 
	
		LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME,
			&tkp.Privileges[0].Luid); 

		tkp.PrivilegeCount = 1;    
		tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED; 

		AdjustTokenPrivileges(hToken, FALSE, &tkp, 0, 
			(PTOKEN_PRIVILEGES) NULL, 0); 
		if (GetLastError() != ERROR_SUCCESS)  
			ret("-ACCESS Couldn't Initial Request Access"); 
	}
	if (!ExitWindowsEx(flags, 0)) ret("-ERROR"); 
 	if (access) {
		tkp.Privileges[0].Attributes = 0; 
		AdjustTokenPrivileges(hToken, FALSE, &tkp, 0, 
			(PTOKEN_PRIVILEGES) NULL, 0); 
	}
 	ret("+OK"); 
}