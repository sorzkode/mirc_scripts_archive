// LinkedList.h: interface for the LinkedList class.

// ---------- Module include files --------------------------------------------
#include <windows.h>
#include <assert.h>

#ifndef Fail
#define Fail 0
#define Success 1
#define Nsuccess 2
#endif
/******************************************************************************
*	Here is the class definition for a list Node class
******************************************************************************/
class CDLitem {
public:
	CDLitem();
	virtual	~CDLitem();
	class	CDLitem *Prev;					// Points to previous node
    class	CDLitem *Next;					// Points to Next node
    LPVOID	Data;							// Points to node data
};
//CDLitem  * l = l->Next;
/******************************************************************************
*	Here is the class definition for the List class handler/manager
******************************************************************************/
class CDLList {
public:
	int GetStatus( void );
	virtual ~CDLList();
	CDLList(int ( *pCompData )( const void *, const void*,BOOL sort), void( *pFreeData)( void **));

    void    ( *m_pFreedata )( void **);		// Data freeing function
    int     ( *m_pCompdata )( const void *, const void *,BOOL sort); // List compare function
	BOOL	m_SortOnInsert;					// Sort when adding to list?
	BOOL	m_Sorted;						// Boolean sorted/unsorted list
	LONG	m_Position;						// Currency position in list
	unsigned long	m_Count;						// Number of nodes in list
	CDLitem *m_pMark;						// Mark a node in the list
	CDLitem *m_pScanner;					// List "Cursor"
	CDLitem *m_pAnchor;						// List Sentinel

	enum ErrorFlag {						// Possible Errors
		NoErrors = 0,
		NoMoreMemory,						// Heap exhausted
		NoComparisonFunction,				// 
		EmptyListReceived,					//
		ListHasNotBeenSorted,				//
		CantDeleteSentinel,					//
		CantMarkSentinel,					//
		NodeNotPreviouslyMarked,			//
		DebugNotDefined,					//
		NullAddress,						//
		InvalidDataLength,					//
		NoCurrency,							//
		OutOfRange
	};
	ErrorFlag m_eErrorFlag;
};

/******************************************************************************
*   Bidirection Link List with sort and some useful functions , also
*   Support for current position (mark ,unmark) 
*	Technical Note 1.      
*   when the CLinkedList object falls out of scope, all previously allocated
*   memory is automatically released.
*******************************************************************************/

class CLinkedList : public CDLList
{
public:
	typedef CDLitem * iterator;
	BOOL	dlsorted( void );				// BOOL - the list is sorted or not
	int		dlatmark( void );				// Test if at marked node
	int		dltomark( void);				// Go to a marked node in list
	int		dlunmark( void );				// Unmark a node in the list
	int		dlmark( void );					// Mark a Node in list
	int		dlsort( void );					// Sort using primitive swap sort
	int		dlqsort( void );				// Sort using qsort() function
	int		dlreplace( LPVOID data );		// Replace this node with the data
	LPVOID	dlget( void );					// Get currency (the current data)
	int		dldelete( void );				// Delete the current node
	LONG	dlposn( void );					// Node's position in the list
	LONG	dlcount( void );				// Number of nodes in list
	LPVOID	dlbsearch( LPVOID data );		// Binary search of the linked list
	LPVOID	dlfind( LPVOID data );			// Find the node with this data
	int		dlrewind( void );				// Rewind to start of list
	// Change the user supplied comparison function (if required) to another
	int		dlsetcompare( int (*pCompData) (const void *, const void *,BOOL sort));
	LPVOID	dlgoback( void );				// Travel backwards through list
	LPVOID	dlgofwd( void );				// Travel forwards through list
	int		dladdins( LPVOID data );		// Add as insertion sort
	int		dladd( LPVOID data );			// Add to the list
	int		dlinsert( LPVOID data );		// Insert a new node here
	LPVOID	dltolast( void );				// Go to the last node in list
	LPVOID	dltofirst( void );				// Go to the first node in list
	LPVOID  dltonum(ULONG  number);			// find node number
	void clear();
	iterator	begin(void);
	iterator	end( void);
	ULONG		size(void);
	iterator	erase(iterator i);
	
	// Some operator overloading, use if suited to taste.
	int		operator<<( LPVOID );					// Same as dladd()
	LPVOID	operator[]( ULONG );
	// The int argument below enforces postfix increment		
    LPVOID	operator++( int );				// Equates to dlgofwd()	
    LPVOID	operator--( int );				// Equates to dlgoback()

	// The CLinkedList class constructors
	CLinkedList(int ( *pCompData )( const void *, const void*,BOOL sort) = NULL, void( *pFreeData)( void **) = NULL);
	// The class destructor
	virtual ~CLinkedList();
	// Internal pointer to the internal add function (dladd or dladdins)
	int ( CLinkedList::*m_pAddFunction )(LPVOID);
	// The internal comparison function used exclusively by the qsort function
	friend	int _Compare(const void *p1, const void *p2);
	// A temporary static internal CLinkedlist pointer
	static CLinkedList *dllp;

private:
	int dlrestore( void );					// Restore node position numbers
};
