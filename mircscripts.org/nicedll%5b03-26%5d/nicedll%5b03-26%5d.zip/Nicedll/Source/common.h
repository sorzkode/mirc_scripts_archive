/*
 * common.h
 * File header for Nicedll project
 * Copyright (C) 2003-2004 Niceboy-DvD
 *
 */

#pragma once

#pragma warning(disable:4100)
#pragma warning(disable:4786)
#pragma warning(disable:4018)

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "nicelib.h"
#include "Eval.h"
#include <map>
#include <list>
#include <vector>
#include <assert.h>
#include <htmlhelp.h>
#include <Mmsystem.h>
#include <shlobj.h>
#include <shellapi.h>
#include <Iphlpapi.h>

using namespace std ;

/*
 * #defines
 */

#define MAXSTRINGLEN 900
#define MLEN 900
#define PLEN 30
#define MBUF 4096
#define FUNCPARMS    HWND mWnd, HWND aWnd, char *data, char *parms, tbool show, tbool nopause
#define DLLNAME      "NICEDLL"
#define VERSION      "1.64"
#define DLLINFO      DLLNAME " " VERSION " (C) Niceboy-DvD - DvD21us@yahoo.com"
#define VERSIONL     DLLNAME " " VERSION
#define MircFunc     extern "C" __declspec(dllexport) int __stdcall
#define Proc(x) LRESULT CALLBACK x(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
#define BUF_SIZE	1024
/*
 * Macros
 */

#define r_ok(parms)    { wsprintf(data, "+OK %s", (parms));  return 3; }
#define r_err(code, parms) { wsprintf(data, "-%s %s", (code), (parms)); return 3; }
#define ret(parms)         { lstrcpy(data, (parms)); return 3; }
#define r_s(code, parms)   { wsprintf(data, "+%s %s", (code), (parms)); return 3; }
#define r_var(var,parms) { \
	if ((var) && (*(var))) { SetVar((var),(parms));lstrcpy(data,"+OK"); } \
	else if (isin_fpara(data,'x','X')) wsprintf(data, "%s",(parms)); \
	else wsprintf(data, "+OK %s",(parms)); }
#define rnum_var(var,parms) { \
	if ((var) && (*(var))) { SetVar((var),(parms));lstrcpy(data,"+OK"); } \
	else if (isin_fpara(data,'x','X')) wsprintf(data, "%ld",(parms)); \
	else wsprintf(data, "+OK %ld",(parms)); }
#define nrnum_var(var,parms) { \
	if(*(var)) { SetVar((var),(parms));lstrcpy(data,"+OK"); } \
	else if (isin_fpara(data,'x','X')) wsprintf(data,"%ld",(parms)); \
	else wsprintf(data, "+OK %ld",(parms)); }
#define RETINVT { lstrcpy(data,"-PARA Invalid Type"); return 3; }
#define RETINVP { lstrcpy(data,"-PARA Invalid Parameters"); return 3; }
#define RETNOLIST { lstrcpy(data,"-LIST List is empty"); return 3; }
#define RETINVITEM { lstrcpy(data,"-PARA Invalid Item"); return 3; }
#define RETINVNth { lstrcpy(data,"-PARA Invalid Nth Number");return 3; }
#define RETOoR { lstrcpy(data,"-PARA Number Out of Range");return 3; }
#define RETFERR(var)  msg_error(data,(var)); return 3;
#define RETNUL { lstrcpy(data,"NULL"); return 3; }
#define RETNULL { lstrcpy(data,"$NULL"); return 3; }
#define RETYN(var) { if ((var))  lstrcpy(data,"Yes"); \
					 else lstrcpy(data,"NO"); }
#define RETNY(var) { if ((var))  lstrcpy(data,"NO"); \
					 else lstrcpy(data,"Yes"); }
#define RETFT(var) { if ((var))  lstrcpy(data,"$TRUE"); \
					 else lstrcpy(data,"$FALSE"); }
#define ret_FNF	{ lstrcpy(data,"-NO File not Exits"); return 3; }
#define Hidewin(z) SetWindowPos(z,NULL,0,0,0,0,SWP_FRAMECHANGED | SWP_NOMOVE | SWP_NOSIZE | SWP_NOOWNERZORDER | SWP_NOACTIVATE);
#define RETINVF { lstrcpy(data,"-File Invalid File Name"); return 3; }
#define mIRC_evalute SendMessage(MIRC, WM_USER + 201,0,0)
/*
	GetFirstNum will check if the first token of the specified string is a
	number. If so, it will copy the numeric value to the variable pointed
	by the 'n' parameter, will change the position of the pointer sent to
	the first parameter to the next token, and return TRUE.

	Token : A version ( mean if it has  a chain of sep  , point to the last sep)
	Sep is blank
	n will be changed when first token is a number or blank(num = 0) 
	not  relative  with result  of function,
	---------------------------
	return : bellow 
*/
#define HaveNumHaveToken 2  // return num,change pointer
#define HaveTokenOnly -2	   // no change any ( > 0  have num)
#define NoHaveAny -1			// no change any 
#define HaveNumOnly 1		// return num , change pointer (<0  no have num)
		

typedef vector<char*> INTVECTOR;

template <class T> int getfirstnum(char **str,T &num,const BOOL negative = FALSE) 
{
	register char *p = *str;
	register T n = 0;
	register mark = 1;
	if ((!p) || (!*p)) return NoHaveAny;
	while (*p == ' ')	p++;
	if ((negative) && (*p == '-')) { mark = -1 ;  p++ ; }
	while (*p)	 {
		if ((*p >= '0') && (*p <= '9'))  n = n * 10 + *p - '0';
		else
			if ((*p == ' ') && (p > *str)) {
				do  p++; while (*p == ' ');
				break; 
			}  
			else 
				return HaveTokenOnly; 
		p++;
	}
	*str = p; num = n * mark;
	if (*p) return HaveNumHaveToken;
	else return HaveNumOnly;
}
//pointer not move;
template <class T> int getfirstnum(char *str,T &num,const BOOL negative = FALSE) 
{
	register char *p = str;
	register T n = 0;
	register mark = 1;
	if ((!p) || (!*p)) return NoHaveAny;
	while (*p == ' ')	p++;
	if ((negative) && (*p == '-')) { mark = -1 ;  p++ ; }
	while (*p)	 {
		if ((*p >= '0') && (*p <= '9'))  n = n * 10 + *p - '0';
		else
			if ((*p == ' ') && (p > str)) {
				do  p++; while (*p == ' ');
				break; 
			}  
			else 
				return HaveTokenOnly; 
		p++;
	}
	num = n * mark;
	if (*p) return HaveNumHaveToken;
	else return HaveNumOnly;
}
template <class T> int getfirstnumB(char **str,T &num,const BOOL negative = FALSE) 
{
	register char *p = *str;
	register T n = 0;	
	register mark = 1;
	if ((!p) || (!*p)) return NoHaveAny;
	while (*p == '|')	p++;
	if ((negative) && (*p == '-')) { mark = -1 ;  p++ ; }
	while (*p)	 {
		if ((*p >= '0') && (*p <= '9'))  n = n * 10 + *p - '0';
		else
			if ((*p == '|') && (p > *str)) {
				do  p++; while (*p == ' ');
				break; 
			}  
			else 
				return HaveTokenOnly; 
		p++;
	}
	*str = p; num = n * mark;
	if (*p) return HaveNumHaveToken;
	else return HaveNumOnly;
}