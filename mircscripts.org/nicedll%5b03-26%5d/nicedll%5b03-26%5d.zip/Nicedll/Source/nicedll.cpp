/*====================================================================
				Dynamic-link Library  NICEDLL 
								A dll for mIRC
  -------------------------------------------------------------------
  Copyright (C) 2003-2004  Niceboy-DvD . email dvd21us@yahoo.com

  This program is distributed in the hope that it will be useful,              
  but WITHOUT ANY WARRANTY; without even the implied warranty of               
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                
  GNU General Public License for more details.                                
                                                                              
  You should have received a copy of the GNU General Public License            
  along with this program; if not, write to the Free Software                  
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  

  Niceboy-DvD , email dvd21us@yahoo.com , subject NICEDLL

 *====================================================================
*/
#include "nicedll.h"

HANDLE hFileMap;
char* dfarray = NULL;
char* defpara = NULL;
char* Para = NULL;
parray farray = NULL;
CLinkedList * listtable = NULL;
CLinkedList * listarray = NULL;
MapCurNode luse;
ListTableType lttype;
ListTableType lttype2;
ListNetType lntype;
ListChanType lctype;
Dstore hs;
SubType *AType = NULL;
LPSTR mData;
HWND MIRC;
//WNDPROC mIRC_OldProc = NULL;
WNDPROC mIRC_OldProc = NULL;
HHOOK mIRC_Hook = NULL;
char Paratransfer[1024] = "";
char ccolor[4][3] = {"","","",""};
char cprefix[BLEN] = "";
int cprefixlen ;
int gbl_sorttype,gbls_column,gbls_sorttype,gbls_numeric,gbls_char,gbls_filter;
INTVECTOR::iterator ib,je;
PMIB_IFTABLE ifMIB = 0;
BOOL cAddColor;
vector<int>  lresult;

#define chfinditem(var) \
	if (type > -2) { \
		if (type == -1)  aux = eval_exp(command) ; \
		else {  \
			(var) ; \
			getnthtok(buf,type,'|'); \
			aux = eval_exp(command,buf,sep); \
		}   \
	}  \
	if  ((mod == 0) || (mod == 1)) { \
		if (type == -2) itemnode->property = mnum; \
		else getfirstnum(aux,itemnode->property); }   \
	else \
		if (mod == 2) { \
			if (type == -2) itemnode->assign(command); \
			else  itemnode->assign(aux); \
		} \
	if (aux) delete aux;
	// use  getfirtnum because of unsigned int , may be change  in future

#define chgetnum \
	if ((type == -2) && ((mod == 0) || (mod == 1))) { \
	change = ( getfirstnum(command,mnum) == HaveTokenOnly)?TRUE:FALSE; 	}  
/*-----------------------------------------------------------
				 Load and UnLoad DLL
 *------------------------------------------------------------
*/
static int NodeClass_comparetable(const void* i1,const void* i2,BOOL sort)
{
	if (sort) return rfc_cmp(ptable(i1)->table,ptable(i2)->table);
	else if ((ptable(i1)->hash == ptable(i2)->hash) && !rfc_cmp(ptable(i1)->table,ptable(i2)->table)) return 0;
	return 1;
}
static int  NodeClass_comparechan(const void* i1,const void* i2,BOOL sort)
{
	if (sort) return rfc_cmp(pchannel(i1)->channel,pchannel(i2)->channel) ;
	else if ((pchannel(i1)->hash == pchannel(i2)->hash) && !rfc_cmp(pchannel(i1)->channel,pchannel(i2)->channel)) return 0;
	return 1;
}
static int NodeClass_comparenet(const void * i1,const void * i2,BOOL sort)
{
	if (sort) return rfc_cmp(pnetwork(i1)->network,pnetwork(i2)->network);
	else if ((pnetwork(i1)->hash == pnetwork(i2)->hash) && !rfc_cmp(pnetwork(i1)->network,pnetwork(i2)->network)) return 0;
	return 1;
}
static int NodeClass_comparearray(const void * i1,const void * i2,BOOL sort)
{
	if (sort) return rfc_cmp(parray(i1)->arrayname,parray(i2)->arrayname);
	else if ((parray(i1)->hash == parray(i2)->hash) && !rfc_cmp(parray(i1)->arrayname,parray(i2)->arrayname)) return 0;
	return 1;
}

extern "C" __declspec(dllexport) void __stdcall LoadDll(LOADINFO* l)
{
	nicelib_onload();
    l->mKeep = TRUE; /* we _must_ stay loaded */
    hFileMap = CreateFileMapping(INVALID_HANDLE_VALUE,0,PAGE_READWRITE,0,4096,"mIRC");     
    mData = (LPSTR)MapViewOfFile(hFileMap,FILE_MAP_ALL_ACCESS,0,0,0);
	MIRC = l->mHwnd;
	defpara = new char[60];
	lstrcpy(defpara,"Y[NUM]D[NUM]G[NUM]N[I]C[I]HBVXM[NUM]E[NUM]"); //46 char
	hs.init();
	lttype.clear();
	savemenubar(l->mHwnd, TRUE);
} 

extern "C" __declspec(dllexport) int __stdcall UnloadDll(int m)
{
    if (!m) {
    	table_cleanup();
		unlock_title();
		if (defpara) delete defpara;
		KillTimer(MIRC,150);
		if (ifMIB) mfree(ifMIB);
		UnmapViewOfFile(mData);
		CloseHandle(hFileMap);
    }
    return 0; //Force  to unload dll
}

/*----------------------------------------------------------
						Error return 
 *----------------------------------------------------------
*/
// first num  is  a target, second num is a sentence
void msg_error (char *str,int error)
{					// 1		2		3		 4		 5
	char *s[] = {"","table","net","chan","nick","address"
			// 6		7		 8					9
			,"Data","number" ,"type number" ,"maxnicks number",
			// 10		11					12			13    14
			"command","function parameter","comment","item","array" 
		
	};
	register int n,i;
   	if (!error) { lstrcpy(str,"+OK"); return; }
	i = error / 10;
	n = error % 10;
	switch (n)
	{ 
	case 0: {
		error = i;
		i = error / 10;
		n = error % 10;
		switch (n) {
			case 1:{ lstrcpy(str,"-File Your save data has been damaged"); break; }
			case 2:{ wsprintf(str,"-List: %s list is Empty",s[i]);break; }
			case 3:{ wsprintf(str,"-Nth %s: Number Out Of Range",s[i]);break; }
			case 4:{ wsprintf(str,"-Nth %s: Invalid Nth Number",s[i]);break; }
			case 5:{ wsprintf(str,"-DUP %s has been used,couldn't rename it",s[i]);break; }
			default:lstrcpy(str,"-Err Unknow Error,Process halt"); break; 
		}
		break;
			} 
	case 1:{ wsprintf(str,"-PARA Invalid %s name",s[i]) ; break; }
	case 2:{ wsprintf(str,"-DUP There is already a %s with that name",s[i]); break; }
	case 3:{ wsprintf(str,"-NO %s not found",s[i]); break; }
	case 4:{ wsprintf(str,"-PARA Invalid %s",s[i]); break; }
	case 5:{ wsprintf(str,"-PARA invalid index num,%s not set",s[i]); break; }
	case 6:{ lstrcpy(str,"-Func Function can not be evaluated or return Null");break; }
	case 7:{ wsprintf(str,"-PARA Invalid max %ss number",s[i]); break; }
	case 8:{ wsprintf(str,"-PARA Invalid %s parameter",s[i]); break; }
	case 9:{ lstrcpy(str,"-PARA Too Many Types,Max Types is 32"); break; }
	default:str = "";
	}
}	
void SetVar(char *var,char *st)
{
	wsprintf(mData,"/set %c%s %s",'%',var,st);
	SendMessage(MIRC, WM_USER + 200,0,0);
}
void SetVar(char *var,int num)
{
	wsprintf(mData,"/set %c%s %d",'%',var,num);
	SendMessage(MIRC, WM_USER + 200,0,0);
}
void Unsetvar(char *var)
{
	if ((var) && (*var)) {
		wsprintf(mData,"/unset %c%s",'%',var);
		SendMessage(MIRC, WM_USER + 200,0,0);
	}
}
void nicknodeitemnull (NickNode *item)
{
    item->addy = NULL;
    item->msg  = NULL;
    item->nick = NULL;
    item->data = NULL;
}
inline void getnumtype(SubType *x,char *tmp,DWORD &num)
{
	str_to_type(x->shorttype,tmp,num);
	if ((x->longtype) && (x->longtype != x->shorttype))
			str_to_type(x->longtype,tmp,num);
}
void SendMirc(char *st,int num)
{
	wsprintf(mData,"/echo >  %s - %d",st,num);
	SendMessage(MIRC, WM_USER + 200,0,0);
}
inline void Docommand(char *command,char *buf,int type,char sep)
{
	char text[MBUF];
	getnthtok(buf,type);
	lstrcpy(Paratransfer,buf);
	lstrcpy(text,command);
	if (Npc_eval(text,sep,FALSE)) {
		lstrcpy(mData,text);
		SendMessage(MIRC, WM_USER + 200,0,0);
	}
}
inline void  sendmsg(char *command,char *msg,char sep) { 
	char text[MBUF];
	lstrcpy(Paratransfer,msg);
	lstrcpy(text,command);
	if (Npc_eval(text,sep,FALSE)) {
		lstrcpy(mData,text);
		SendMessage(MIRC, WM_USER + 200,0,0);
	}
}
inline void DocommandB(char *command,char *buf,int type,char sep)
{
	char text[MBUF];
	getnthtok(buf,type,'|');
	lstrcpy(Paratransfer,buf);
	lstrcpy(text,command);
	if (Npc_eval(text,sep,FALSE)) {
		lstrcpy(mData,text);
		SendMessage(MIRC, WM_USER + 200,0,0);
	}
}

inline void copystr(char **target,char *source)
{
	if (*target) delete *target;
	*target = new char[lstrlen(source) + 1];
	lstrcpy(*target,source);
}
inline char* N(char *st) 
{
	if (st)  return st ;
	else return "$NULL";
}

/*----------------------------------------------------------
 * Table,Network and Channel
 *-----------------------------------------------------------
 */

/*
 find table node
 return NULL for not found otherwise ptable
 find at first or specify table node
 */

ptable f_tablenode (char *table,int &err)
{
	DWORD key;

	if (getfirstnum(table,key) > 0) {
		if (listtable) {
			if ((key == 0) || (key > listtable->m_Count)) err = 130;
			else 	return ptable(listtable->dltonum(key));
		}
		else err = 120;
	}
	else err = 140;
	return NULL;
}
ptable f_tablenode (char* table)
{
    TableClass T;
	if  ((!*table) ||(listtable == NULL))   return NULL;
	T.table = new char [ lstrlen(table) + 1 ];
	lstrcpy(T.table,table);
	T.hash = rfchash(table);
	if (listtable->m_Sorted) return ptable(listtable->dlbsearch(&T));
	else return ptable(listtable->dlfind(&T));
}

parray f_arraynode (char *array,int &err)
{
	DWORD key;

	if (getfirstnum(array,key) > 0) {
		if (listarray) {
			if ((key == 0) || (key > listarray->m_Count)) err = 1430;
			else 	return parray(listarray->dltonum(key));
		}
		else err = 1420;
	}
	else err = 1440;
	return NULL;
}
parray f_arraynode (char* array)
{
    TArrayClass T;
	if  ((!*array) ||(listarray == NULL))   return NULL;
	T.arrayname = new char [ lstrlen(array) + 1 ];
	lstrcpy(T.arrayname,array);
	T.hash = rfchash(array);
	if (listarray->m_Sorted) return parray(listarray->dlbsearch(&T));
	else return parray(listarray->dlfind(&T));
}
pnetwork f_netnode (char* network,ptable Table,int &err)
{
	DWORD key;
	if (getfirstnum(network,key) > 0) {
		if (Table->listnet) {
			if ((Table->listnet->m_Count < key) || (key == 0)) err = 230;
			else return pnetwork(Table->listnet->dltonum(key));
		}
		else err = 220;
	}
	else err = 240;
	return NULL;
}
pnetwork f_netnode (char* network,ptable Table)
{
    NetClass N;
    if  ((!*network) ||(Table->listnet == NULL))   return NULL;
	N.network = new char [ lstrlen(network) + 1 ];
	lstrcpy(N.network,network);
	N.hash = rfchash(network);
	if (Table->listnet->m_Sorted) return pnetwork(Table->listnet->dlbsearch(&N));
	else return pnetwork(Table->listnet->dlfind(&N));
}
pchannel f_channode (char* channel,pnetwork Net)
{
    ChanClass N;
    if  ((!*channel) ||(Net->listchan == NULL))   return NULL;
	N.channel = new char [ lstrlen(channel) + 1 ];
	lstrcpy(N.channel,channel);
	N.hash = rfchash(channel);
	if (Net->listchan->m_Sorted) return pchannel(Net->listchan->dlbsearch(&N));
	else return pchannel(Net->listchan->dlfind(&N));
}
pchannel f_channode (char* channel,pnetwork Net,int &err)
{
	DWORD key;
	if (getfirstnum(channel,key) > 0) {
		if (Net->listchan) {
			if ((Net->listchan->m_Count < key) || (key == 0)) err = 330;
			else return pchannel(Net->listchan->dltonum(key));
		}
		else err = 320;
	}
	else err = 340;
	return NULL;
}
/*-------------------------------------------------------
	function for index 
 *------------------------------------------------------
*/
char *eval_exp(char *st,char *para,char sep)
{ 
	char *buf = NULL;
	char text[MBUF];

	lstrcpy(text,st);
	if (para) {
		lstrcpy(Paratransfer,para);
		if (!Npc_eval(text,sep,FALSE)) return 0;
	}
	lstrcpy(mData,text);
	if (SendMessage(MIRC, WM_USER + 201,0,0))	{
		buf = new char[MAXSTRINGLEN];
		lstrcpy(buf,mData);
	}
	return buf;
}
char *eval_exp(char *st)
{ 
	char *buf = NULL;
    if (st[0] != '$')  wsprintf(mData,"$%s",st);
	else lstrcpy(mData,st);
	if (SendMessage(MIRC, WM_USER + 201,0,0))	{
		buf = new char[MAXSTRINGLEN];
		lstrcpy(buf,mData);
	}
	return buf;
}

void del_curchan(pchannel chan)
{
	MapCurNode::iterator i;
	for (i = luse.begin(); i != luse.end(); ++i)
	 if ((*i).second.chan == chan) (*i).second.chan = NULL;
}
void del_curnet(pnetwork net)
{
	MapCurNode::iterator i;
	for (i = luse.begin(); i != luse.end(); ++i)
		if ((*i).second.net == net) {
			(*i).second.net = NULL;
			(*i).second.chan = NULL;
		}
}
void del_curtable(ptable table)
{
	MapCurNode::iterator i;
	for (i = luse.begin(); i != luse.end(); ++i)
		if ((*i).second.table == table) {
		 	(*i).second.net = NULL;
			(*i).second.chan = NULL;
			(*i).second.table = NULL;
		}
}
void del_curarray(parray array)
{
	MapCurNode::iterator i;
	for (i = luse.begin(); i != luse.end(); ++i)
		if ((*i).second.array == array) (*i).second.array = NULL;
	if (farray == array) {
		farray = 0;
		lresult.clear();
	}
}
/*
@V: type == -2 ; default: type == -1 ; @p[Num] : type >= 0
@M[Num] : mod >= 0 ; default: mod == -1
store: more = 0 || 1
*/
void aux_getcommand(char ** para, char ** command)
{
	char *p = *para;
	*para = NULL;

	while (*p && *p == ' ') p++;
	if (*p == '@') {
		*para = p;
		p++;
		while ((*p) && (*p != ' ')) p++;
		if (*p) { *p = 0 ; *command = ++p ; }
		else *command = p;
	}
	else  *command = p;
}

void get_command(char **tmp,char **command,int &type,DWORD &num,unsigned int &maxnicks,BOOL del,int err,int &more,int &mod,char &sep)
{ 
	char *aux,*tmpbuf,buf[PLEN];
	int nt;
	mod = -1;more = 0;type = -1; num = 0; maxnicks = del?0:1; *command = NULL;

	nt = getfirstnum(tmp,num);
	if ( nt == HaveNumHaveToken ) {
		if (getfirstnum(tmp,maxnicks) == HaveNumHaveToken)	
			getfirstnum(tmp,type);
	}
	else 
		if (nt == HaveTokenOnly)   maxnicks =  0; 
	aux = *tmp;
	aux_getcommand(&aux,command);
	if (aux) {
		tmpbuf = creat_para("VSP[NUM]M[NUM]C[NUM]",aux + 1);
		if (take_para(tmpbuf,"P",&buf[0])) type = atolp(buf); 
		if (find_para(tmpbuf,'S')) more = 1;
		if (find_para(tmpbuf,'V')) type = -2;
		if (take_para(tmpbuf,"M",&buf[0])) mod = atolp(buf);
		if (take_para(tmpbuf,"C",&buf[0])) { 
			nt = atolp(buf); 
			if ((nt <= 255) && (nt > 0)) sep = nt;
		}
		delete tmpbuf; 
	} 
	if ((!**command) && (mod < 0)) *command = NULL;
}

inline int get_item_para(char **tmp,char **item,char **command,int& type,DWORD &num,unsigned int &maxnicks,BOOL del,int &more,int &mod,char &sep)
{ 
	*item = getword(tmp);
	if (!**item)  return 134; 
	get_command(tmp,command,type,num,maxnicks,del,137,more,mod,sep);
	return 0;
}

/*
 desc : analyze parameter , return para take from switch  if It has 
 pointer  will be moved to the next  para, use blank  as a seperator
 Input : - source string
		 - formated switch
		 - a buffer for receive parameter
		 - style para
 OutPut:- para pointer point to a buffer or Null 
		- source string has been modified (pointer)
		- return code error or 0 (success)
			-1 not have para
*/

int analyzepara(char **data,char *fp,char **sp,char *style)
{	
	char buf[PLEN];
	if (take_para(fp,style,&buf[0])) {  
		*sp = getword(data);
		if (!**sp) 
			if (style[0] == 'N') return 21;	
			else return 31;
		return 0;
		
	}     
	else { *sp = ""; return -1; }
}
int currenttablefp(char **tmp,ptable *thead,char **para)
{
	char buf[PLEN],*tmpbuf, *table;
	CurNode x;
	*thead = NULL;
	*para = NULL;
	int err = 0,Nth = 0,gw = 1;
    
	table = getword(tmp);
	 if (table[0] == '-') {
		tmpbuf = creat_para(defpara,table); //not case sentitve
		if (take_para(tmpbuf,"D",&buf[0])) {
			x = luse[atolp(buf)];
			if (x.table) *thead = x.table;
			else { delete tmpbuf; return 15; }
		} 
		else {
			if (take_para(tmpbuf,"M",&buf[0])) {
				if (buf[0] != '0') lstrcpy(table,buf); 
				else table = getword(tmp);
				*thead = f_tablenode(table,err);
			}
			else table =  getword(tmp);
		}
		*para = tmpbuf;
	 }
	 if (!*thead) {
		*thead = f_tablenode(table);
		if (!*thead) return 11;
	 }
	return 0;
}
int currenttable(char **tmp,ptable *thead)
{
	char *para ;
	int result = currenttablefp(tmp,thead,&para);
	if (para) delete para;
	return result;
}
int pathtable(char **tmp,char **network,ptable *thead)
{
	int result = currenttable(tmp,thead);
	if (result) return result;
	*network = getword(tmp);
	if (!**network) return 21;
	return 0;
}
int currentnetfp(char **tmp,ptable *thead,pnetwork *Net,char **para)
{
	char *table,*network,buf[PLEN],*tmpbuf;
	int err = -1;
	BOOL y = FALSE,Nth = FALSE;
	CurNode x;
	*thead = NULL;
	*Net = NULL;
	*para = NULL;

	 table = getword(tmp);
	 if (table[0] == '-') {
		tmpbuf = creat_para(defpara,table);
		Nth = find_para(tmpbuf,'M');
		if (take_para(tmpbuf,"D",&buf[0])) {
			x = luse[atolp(buf)];
			if (x.table) *thead = x.table;
			else err = 15;
			y = TRUE;
		}  
		else {
			if (Nth) {
				take_para(tmpbuf,"M",&buf[0]);
				if (buf[0] != '0') lstrcpy(table,buf); 
				else table = getword(tmp);
				*thead = f_tablenode(table,err);
			}
			else table =  getword(tmp);
		}
		*para = tmpbuf;
	    err = analyzepara(tmp,tmpbuf,&network,"N");
        if (err > 0) return err; 
	 }
	 if (!*thead) {
		*thead = f_tablenode(table);
		if (!*thead) return 11;
	 }
	 if (err)  {
		 if (y) {
			if (!x.net) return 25;
			*Net = x.net;
		 }
		 else {
			 network =  getword(tmp);
			if (Nth) {
				err = 0;
				*Net = f_netnode(network,*thead,err);
				if (err) return err;
			}
		 }
	 }
	 if (!*Net) {
		if (Nth) { 
			*Net = f_netnode(network,*thead,err);
			if (err) return err;
		}
		else {
			*Net = f_netnode(network,*thead);
			if (!*Net) return 21;
		}
	 }
	return 0;
}
int currentnetf(char **tmp,ptable *thead,pnetwork *Net)
{
	char *para ;
	int result = currentnetfp(tmp,thead,Net,&para);
	if (para) delete para;
	return result;
}

int pathnetf(char **tmp,char **channel,ptable *thead,pnetwork *Net)
{
	char *para ;
	int err = currentnetfp(tmp,thead,Net,&para);
	if (para) delete para;
	if (err) return err;
	*channel = getword(tmp);
	if (!**channel)    return 31;
	return 0;
}
int pathnet(char **tmp,char **channel,pnetwork *Net)
{
	ptable thead;
	return pathnetf(tmp,channel,&thead,Net);
}

int currentarrayfp(char **tmp,parray *thead,char **para)
{
	char buf[PLEN],*tmpbuf, *array;
	CurNode x;
	*thead = NULL;
	*para = NULL;
	int err = 0,Nth = 0,gw = 1;
    
	array = getword(tmp);
	if (array[0] == '-') {
		tmpbuf = creat_para(defpara,array);
		if (take_para(tmpbuf,"D",&buf[0])) {
			x = luse[atolp(buf)];gw = 0;
			if (!x.array)  { delete tmpbuf;  return 145; }
		}
		if (take_para(tmpbuf,"M",&buf[0])) {
			Nth = 1; if (buf[0] != '0') { lstrcpy(array,buf); gw = 0; }
		}
		if (gw) array = getword(tmp);
		*para = tmpbuf;
	}
	if (!x.array) {
		if (Nth) {	*thead = f_arraynode(array,err); return err; }
		else {
			x.array = f_arraynode(array);
			if (!x.array) return 141;
		}
	}
	*thead = x.array;
	return 0;
}
int currentarray(char **tmp,parray *thead)
{
	char *para ;
	int result;
	result = currentarrayfp(tmp,thead,&para);
	if (para) delete para;
	return result;
}

inline int currentnetp(char **tmp,pnetwork *Net,char **para)
{
	ptable thead;
	return currentnetfp(tmp,&thead,Net,para);
}
inline int currentnet(char **tmp,pnetwork *Net)
{
	ptable thead;
	return currentnetf(tmp,&thead,Net);
}


int currentchanfp(char **tmp,ptable *thead,pnetwork *Net,pchannel *Chan,char **para)
{
	char *table,*network,*channel,buf[PLEN],*tmpbuf;
	int err = -1 ,errc = -1;
	CurNode x; 	*thead = NULL;	 *Net = NULL;
	BOOL y = FALSE,Nth = FALSE;
	*Chan = NULL;
	*para = NULL;

	table = getword(tmp);
	if (table[0] == '-') {
		tmpbuf = creat_para(defpara,table);
		Nth = find_para(tmpbuf,'M');
		if (take_para(tmpbuf,"D",&buf[0])) {
			x = luse[atolp(buf)];
			if (x.table) *thead = x.table;
			else err = 15;
			y = TRUE;
		}  
		else {
			if (Nth) {
				take_para(tmpbuf,"M",&buf[0]);
				if (buf[0] != '0') lstrcpy(table,buf); 
				else table = getword(tmp);
				*thead = f_tablenode(table,err);
			}
			else table =  getword(tmp);
		}
		*para = tmpbuf;
		err = analyzepara(tmp,tmpbuf,&network,"N");
		errc = analyzepara(tmp,tmpbuf,&channel,"C");
		if (err > 0) return err;
		if (errc > 0) return errc;
	}
 	if (!*thead) {
		*thead = f_tablenode(table);
		if (!*thead) return 11;
	}
	if (err)  {
		 if (y) { if (!x.net) return 25;	*Net = x.net; }
		 else {
			 network =  getword(tmp);
			 if (Nth) {
				 err = 0;
				 *Net = f_netnode(network,*thead,err);
				 if (err) return err;
			 }
		 }
	}
	if (!*Net) {
		if (Nth) { 
			*Net = f_netnode(network,*thead,err);
			if (err) return err;
		}
		else {
			*Net = f_netnode(network,*thead);
			if (!*Net) return 21;
		}
	}
	if (errc) {
		if (y) { if (!x.chan)  return 35; *Chan = x.chan;	}
		else {
			channel = getword(tmp);
			if (Nth) {
				errc = 0;
				*Chan = f_channode(channel,*Net,errc);
				if (errc) return errc;
			}
		}
	}
	if (!*Chan) {
		if (Nth) { 
			*Chan = f_channode(channel,*Net,err);
			if (err) return err;
		}
		else {
			*Chan = f_channode(channel,*Net);
			if (!*Chan) return 31;
		}
	}
	return 0;
}
inline int currentchanf(char **tmp,ptable *thead,pnetwork *Net,pchannel *Chan)
{
	char *para;
	int result;
	result = currentchanfp(tmp,thead,Net,Chan,&para);
	if (para) delete para;
	return result;

}
 inline int currentchanp(char **tmp,pchannel *Chan,char **para)
{
 	ptable thead;	
	pnetwork Net;
	return currentchanfp(tmp,&thead,&Net,Chan,para);
}
inline int currentchan(char **tmp,pchannel *Chan)
{
 	ptable thead;	
	pnetwork Net;
	return currentchanf(tmp,&thead,&Net,Chan);
}

int find_index_key()
{
	MapCurNode::iterator j;
	int key = 0;
	for (j = luse.begin();j != luse.end();j++)
		key = ((*j).first > key)?(*j).first:key;
	return ++key;
}
//N[PASF]C[PTAQF]
void usenet_add(char *data,char *second,char *third,int key,int param)
{
	CurNode x;
	MapCurNode::iterator i;
	int err = 0;

	i = luse.find(key);
	if (i == luse.end()) {		
		if (!*third) lstrcpy(data,"-PARA Invalid index num ");
		else {
			if (param) {
					x.table = f_tablenode(second,err);
					if (err) msg_error(data,err);
			}
			else {
				x.table = f_tablenode(second);
				if (!x.table) lstrcpy(data,"-NO Table not found"); 
			}
			if (x.table)  {
				if (param) {
					err = 0;
					x.net = f_netnode(third,x.table,err);
					if (err) msg_error(data,err);
				}
				else {
					x.net = f_netnode(third,x.table);
					if (!x.net)  lstrcpy(data,"-NO Net not found"); 
				}
				if (x.net)  {
					luse.insert(luse.end(),MapCurNode::value_type(key,x));
					lstrcpy(data,"+OK");
				} //exists net, create new index
			}
		}  
	}      
	else { 
		if (!*third) {
			if ((*i).second.table != NULL)	{
				if (param) {
					err = 0;
					x.net = f_netnode(second,(*i).second.table,err);
					if (err) msg_error(data,err);
				}
				else x.net = f_netnode(second,(*i).second.table);
				if (!x.net) { if (!param) lstrcpy(data,"-NO Net not found"); }
				else {   
					(*i).second.net = x.net;
					lstrcpy(data,"+OK");
				}   
			}
			else  lstrcpy(data,"-PARA  invalid index - index table not set");
		}
		else {
			if (param) {
				err = 0;
				x.table = f_tablenode(second,err);
				if (err)  msg_error(data,err);
			}
			else x.table = f_tablenode(second);
			if (!x.table) { if (!param) lstrcpy(data,"-NO Table not found"); }
			else {
				if (param) {
					err = 0;
					x.net = f_netnode(third,x.table,err);
					if (err) msg_error(data,err);
				}
				else {
					x.net = f_netnode(third,x.table);
					 if (!x.net) lstrcpy(data,"-NO Net not found");
				}
				if (x.net)	{  
					(*i).second.table = x.table;
					(*i).second.net = x.net;
					lstrcpy(data,"+OK");
				}
			 }
		}
	}     
}  
 
/*
 desc : set index Net and table  , It overwrite an index if Index's 
		already exists . Otherwise a new index will be created
 Input:
	style1: [Table] <network>  , index 0 is used,
	style2: -D[NUM] [Table] <network> , index num is used
    style3: -D[NUM]N[PASF] [para] [Table]  , network input from function
		note:
			All parameters beside  will be bypassed
			D[NUM] = D[0] in case D[NUM] Not Available
 OutPut: None 
*/

MircFunc SetIndexNet (FUNCPARMS)
{
	char *st,*tmpbuf,*tmp = data,buf[PLEN],*second,*third,*para = NULL;
	MapCurNode::iterator i;
	CurNode x;
	int err;
	unsigned long key;
	BOOL Nth = FALSE;

	st =  getword(&tmp);
	if (!*st)  r_err("PARA","Invalid index num")
	if (st[0] == '-') {
		tmpbuf = creat_para(defpara,st);
		err = analyzepara(&tmp,tmpbuf,&second,"N");
		if (err > 0) msg_error(data,err);
		else {
			if (err == -1) {
				second = getword(&tmp);
				if (!*second) lstrcpy(data,"-PARA Invalid network");
			} 
			if (*second) { 
				third = getword(&tmp);
				if ((find_para(tmpbuf,'H')) && (*third)) {
					if (find_para(tmpbuf,'M')) {
						err = 0;
						x.table = f_tablenode(second,err);
						if (err) msg_error(data,err);
						Nth = TRUE;
					}
					else {
						x.table = f_tablenode(second);
						if (!x.table) lstrcpy(data,"-NO Table not found");
					}
					if (x.table)  {  
						if (Nth) {
							err = 0;
							x.net = f_netnode(third,x.table,err);
							if (err) msg_error(data,err);
						}
						else x.net = f_netnode(third,x.table);
						if (!x.net) { if (!Nth) lstrcpy(data,"-NO Net not found"); }
						else  { 
							key = find_index_key();
							luse.insert(luse.end(),MapCurNode::value_type(key,x));
							if (find_para(tmpbuf,'X'))wsprintf(data,"%d",key);
							else wsprintf(data,"+OK %d",key);
						} //exists network, create new index
					} 
				}  
				else {
					if (take_para(tmpbuf,"D",&buf[0])) key = atolp(buf); 
					else key = 0;
					if ((!err) && (*third))
						usenet_add(data,third,second,key,find_para(tmpbuf,'M'));
					else
						usenet_add(data,second,third,key,find_para(tmpbuf,'M'));
					if (!err)  delete second;
				}   
			}  
		}
		delete tmpbuf;
	}  
	else {
		third = getword(&tmp);
		usenet_add(data,st,third,0,0);
	}
	return 3;
} 
/*
 desc : Set index for a table
 InPut:
	-D[NUM] <Table> 
	  index 0  will be used if Switch -D[NUM] not be specific
 Output: None
*/
MircFunc SetIndexTable (FUNCPARMS)
{
	char *st,*tmpbuf,*tmp = data,buf[PLEN] ;
	pair<MapCurNode::iterator,BOOL> i;
	CurNode x;
	int key,success;
	st =  getword(&tmp);
	BOOL autofill = FALSE , Nth = FALSE;

	if (!*st)  r_err("PARA","Invalid Table")
	if (st[0] == '-') {
	 tmpbuf = creat_para(defpara,st);
	 if (find_para(tmpbuf,'M')) Nth = TRUE;
	 if (isincs(tmpbuf,'H')) { 
		autofill = TRUE ;st = getword(&tmp);
		delete tmpbuf;
	 }
	 else {
		success = take_para(tmpbuf,"D",&buf[0]);
		delete tmpbuf;
		if (success) {
			st = getword(&tmp);
			key = atolp(buf);
		} 
		else r_err("PARA","Invalid index num")
	 }
	}  
	else key = 0;
	if (Nth) {
		success = 0;
		x.table = f_tablenode(st,success);
		if (success) msg_error(data,success);
	}
	else {
		x.table = f_tablenode(st);
		if (!x.table) lstrcpy(data,"-PARA Invalid Table");
	}
	if (x.table) {
	  if (autofill) {
		key = find_index_key();
		luse.insert(luse.end(),MapCurNode::value_type(key,x));
		nrnum_var(tmp,key);
	  }
	  else {
		i = luse.insert(MapCurNode::value_type(key,x));
		if (i.second) lstrcpy(data, "+OK 1");
		else {  
			(*i.first).second.table = x.table;
			lstrcpy(data,"+OK 0");
		}   
	  } 
	} 
 	 return 3;
}
MircFunc SetIndexArray (FUNCPARMS)
{
	char *st,*tmpbuf,*tmp = data,buf[PLEN] ;
	pair<MapCurNode::iterator,BOOL> i;
	CurNode x;
	int key,success;
	st =  getword(&tmp);
	BOOL autofill = FALSE , Nth = FALSE;

	if (!*st)  r_err("PARA","Invalid Array")
	if (st[0] == '-') {
	 tmpbuf = creat_para(defpara,st);
	 if (find_para(tmpbuf,'M')) Nth = TRUE;
	 if (isincs(tmpbuf,'H')) { 
		autofill = TRUE ;st = getword(&tmp);
		delete tmpbuf;
	 }
	 else {
		success = take_para(tmpbuf,"D",&buf[0]);
		delete tmpbuf;
		if (success) {
			st = getword(&tmp);
			key = atolp(buf);
		} 
		else r_err("PARA","Invalid index num")
	 }
	}  
	else key = 0;
	if (Nth) {
		success = 0;
		x.array = f_arraynode(st,success);
		if (success) msg_error(data,success);
	}
	else {
		x.array = f_arraynode(st);
		if (!x.array) lstrcpy(data,"-PARA Invalid Array");
	}
	if (x.array) {
	  if (autofill) {
		key = find_index_key();
		luse.insert(luse.end(),MapCurNode::value_type(key,x));
		nrnum_var(tmp,key);
	  }
	  else {
		i = luse.insert(MapCurNode::value_type(key,x));
		if (i.second) lstrcpy(data, "+OK 1");
		else {  
			(*i.first).second.array = x.array;
			lstrcpy(data,"+OK 0");
		}   
	  } 
	} 
 	 return 3;
}

int checkpara(char *firsttok,char *secondtok,char *thirdtok,CurNode * x,BOOL ms)
{
	if (ms) {
		int err = 0;
		x->table = f_tablenode(firsttok,err);
		if (err) return err;
		x->net = f_netnode(secondtok,x->table,err);
		if (err) return err;
		x->chan = f_channode(thirdtok,x->net,err);
		if (err) return err;
	}
	else {
		x->table = f_tablenode(firsttok);
		if (!x->table) return 13;
		x->net = f_netnode(secondtok,x->table);
		if (!x->net) return 23;
		x->chan = f_channode(thirdtok,x->net);
		if (!x->chan) return 33;
	}
	return 0;
}
void usechan_addi (char *data,char *firsttok,char *secondtok,char *thirdtok,int key,BOOL ms)
{
	CurNode x;
	MapCurNode::iterator i;
	i = luse.find(key);
	int err;
		if (i == luse.end())	{ 		
			if (!*thirdtok) lstrcpy(data,"-PARA Invalid index num ");
			else {
				err = checkpara(firsttok,secondtok,thirdtok,&x,ms);
				if (err) msg_error(data,err);
				else { 
					luse.insert(luse.end(),MapCurNode::value_type(key,x));
					lstrcpy(data,"+OK");
				} 
			}
		} 
		else {  
			if (!*secondtok) {
				if (!(*i).second.net) lstrcpy(data,"-PARA invalid index - Network not set");
				else {
					if (ms) {
						err = 0;
						x.chan = f_channode(firsttok,(*i).second.net,err);
						if (err) msg_error(data,err);
					}
					else {
						x.chan = f_channode(firsttok,(*i).second.net);
                        if (!x.chan) lstrcpy(data,"-NO Chan not found");
					}
					if (x.chan) {    
						(*i).second.chan = x.chan;
						lstrcpy(data,"+OK");
					}  
				}
			} 
			else {
				if  (!*thirdtok) lstrcpy(data,"-PARA invalid parameter");
				else {
					err = checkpara(firsttok,secondtok,thirdtok,&x,ms);
					if (err) msg_error(data,err);
					else {
						(*i).second.table = x.table;
						(*i).second.net = x.net;
						(*i).second.chan = x.chan;
						lstrcpy(data,"+OK");
					}
				} 
			}
		}
} 
/*
 desc : set index channel  , It overwrite an index if Index's 
		already exists . Otherwise a new index will be created
 Input:
	style1: [ <Table> <network> ] <Channel> , index 0 is used,
	style2: -D[NUM] [<Table> <network> ] <Channel> , index num is used
    style3: -D[NUM]C[PTAQF] [para] [<Table> <network> ]  , network input from function
		note:
			All parameters beside  will be bypassed
			D[NUM] = D[0] in case D[NUM] Not Available
 OutPut: None 
*/

MircFunc SetIndexChan (FUNCPARMS)
{
	char *st,*tmpbuf,*tmp = data,buf[PLEN],*second,*third,*para = NULL;
	MapCurNode::iterator i;
	CurNode x;
	int key,err;
	st =  getword(&tmp);
	if (!*st)  r_err("PARA","Invalid index num")
	if (st[0] == '-') {
		tmpbuf = creat_para(defpara,st);
		err = analyzepara(&tmp,tmpbuf,&second,"C");
		if (err > 0) msg_error(data,err);
		else {
			if (err == -1) {
				second = getword(&tmp);
				if (!*second) lstrcpy(data,"-PARA Invalid channel");
			} 
			if (*second) { 
			   third = getword(&tmp);
			   if (*third) para = getword(&tmp);
			   else para = "";
			   if ((find_para(tmpbuf,'H')) && (*para))   { 
					err = checkpara(second,third,para,&x,find_para(tmpbuf,'M'));
					if (err) msg_error(data,err);
					else {	 
						key = find_index_key();
						luse.insert(luse.end(),MapCurNode::value_type(key,x));
						if (find_para(tmpbuf,'X')) wsprintf(data,"%d",key);
						else wsprintf(data,"+OK %d",key);
					}  
			   }    
			   else {
					if (take_para(tmpbuf,"D",&buf[0])) key = atolp(buf); 
					else key = 0;
		 
					if ((!err) && (*para))
						usechan_addi(data,third,para,second,key,find_para(tmpbuf,'M'));
					else
						usechan_addi(data,second,third,para,key,find_para(tmpbuf,'M'));
						if (!err)  delete second;
			   }
			}   
		} 
		delete tmpbuf;
	}   
	else
	{
		third = getword(&tmp);
		if (*third) para = getword(&tmp);
		else para = "";
		usechan_addi(data,st,third,para,0,0);
	}
	return 3;
}

MircFunc DelIndex(FUNCPARMS)
{ 
	int key;
	if (getfirstnum(data,key) > 0) wsprintf(data,"+OK %d",luse.erase(key));
	else lstrcpy(data,"-PARA Invalid index num");
 	return 3;
}
MircFunc ClearIndex(FUNCPARMS)
{
	luse.clear();
	r_ok("");
}
MircFunc WriteIndex (FUNCPARMS)
{
	MapCurNode::iterator i;
	for (i = luse.begin(); i != luse.end(); ++i)
	{ 
	wsprintf(mData,"/echo >  %d - %s - %s - %s - %s",(*i).first,
		(*i).second.table?(*i).second.table->table:"N/A",
		(*i).second.net?(*i).second.net->network:"N/A",
		(*i).second.chan?(*i).second.chan->channel:"N/A",
		(*i).second.array?(*i).second.array->arrayname:"N/A");
	SendMessage(MIRC, WM_USER + 200,0,0);
	} 
	return 1;
}

/*-------------------------------------------------------
 * Proccess for  Nick Class & Item Class
 *--------------------------------------------------------
*/
NickNode* NickClass::Add(char* pnick, char* paddy, char* ptype, char* pmsg, unsigned int num,DWORD numtype)
{
    NickNode *snew = new NickNode(pnick, paddy,  ptype,  pmsg, num,numtype);
    NickNode *saux = TryInsert(snew);
    if (saux != snew) {
        /* duplicated item */
        saux->assign(paddy,  ptype,  pmsg, num, numtype);
    }
    return saux;
}	

NickNode* NickClass::AddType(char* pnick,DWORD numtype,BOOL overwrite)
{
   NickNode *saux = Find(pnick);
    if (saux) {
      		if (!overwrite)
				saux->nicktype |= numtype;
			else
				saux->nicktype = numtype;
    }
    return saux;
}
int NickClass::AddOther(SubType *x,char *pnick,char *ptype, char *data)
{
	DWORD num = 0;
	NickNode *saux = Find(pnick);
	if (saux) {
		if (!lstrcmpi(ptype,"COMMENT")) {
			if (!*data) return 124 ;
			if (saux->msg) delete saux->msg;
			saux->msg = new char[lstrlen(data) + 1];
			lstrcpy(saux->msg,data);
		}
		else 
			if (!lstrcmpi(ptype,"TYPE")) {
				if (!*data)  return 84;
				if (getfirstnum(data,num) < 0)  {
					if (x) getnumtype(x,data,num);
					else return 64;
				}
				saux->nicktype = num;
			}
			else
				if (!lstrcmpi(ptype,"NUM")) {
					if (getfirstnum(data,saux->num) < 0 )  return 74;
				}
				else 
					if (!lstrcmpi(ptype,"HOST")) {
						if (!*data) return 54;
						if (saux->addy) delete saux->addy;
						saux->addy = new char[lstrlen(data) + 1];
						lstrcpy(saux->addy,data);
					}
					else
						if (!lstrcmpi(ptype,"DATA")) {
							if (saux->data) delete saux->data;
							if ((data) && (*data)) {
								saux->data = new char[lstrlen(data) + 1];
								lstrcpy(saux->data,data);
							}
							else saux->data = NULL;
						} 
						else return 64;
		return 0;
	}
	else return 43;
}

NickNode* NickClass::Find(char *nick)
{
    NickNode *pItem, SearchKey;
    SearchKey.nick = nick;

    pItem=CTTree<NickNode>::Find(&SearchKey);
    nicknodeitemnull(&SearchKey);
    return pItem;
}
NickNode * NickClass::FindNickNum(long number)
{
	NickNode *nnode;
	long pos = 0;
	ProcessInit();
    for (;;) {
		nnode = ProcessNext(); ++pos;
		if ((number == pos) || (!nnode)) break;
	}
	return nnode;
}

BOOL NickClass::Delete(char *nick)
{
    NickNode *pItem, SearchKey;

    SearchKey.nick = nick;
    pItem=Detach(&SearchKey);
    nicknodeitemnull(&SearchKey);
    if (pItem) {
        delete pItem;
        return 1;
    }
    return 0;
}

ItemNode* ItemClass::Add(char* pitem, char* pdata,DWORD num)
{
    ItemNode *snew = new ItemNode(pitem,pdata,num);
    ItemNode *saux = TryInsert(snew);
    if (saux != snew) {
        /* duplicated item */
        saux->assign(pdata,num);
    }
    return saux;
}

// return node if found otherwise return NULL

ItemNode* ItemClass::Find(char *pitem)
{
    ItemNode *pItem, SearchKey;
    SearchKey.item = pitem;

    pItem=CTTree<ItemNode>::Find(&SearchKey);
    SearchKey.item = NULL;
	SearchKey.data = NULL;
    return pItem;
}

int ItemClass::FindNum(char *pitem)
{
	ItemNode *itemnode;
	int pos = 0;
	ProcessInit();
    for (;;) {
		itemnode = ProcessNext();
		++pos;
		if ((!itemnode) || (!rfc_cmp(pitem, itemnode->item))) break;
	}
	if (!itemnode) return 0; 
	else return pos;
}
ItemNode * ItemClass::FindNodeNum(long number)
{
	ItemNode *itemnode;
	long pos = 0;
	ProcessInit();
    for (;;) {
		itemnode = ProcessNext(); ++pos;
		if ((number == pos) || (!itemnode)) break;
	}
	return itemnode;
}
BOOL ItemClass::Delete(char *pitem)
{
    ItemNode *pItem, SearchKey;

    SearchKey.item = pitem;
    pItem=Detach(&SearchKey);
    SearchKey.item = NULL;
	SearchKey.data = NULL;
    if (pItem) {
        delete pItem;
        return 1;
    }
    return 0;
}
ItemNode * ItemClass::PDelete(char *pitem)
{
    ItemNode *pItem, SearchKey;

    SearchKey.item = pitem;
    pItem=Detach(&SearchKey);
    SearchKey.item = NULL;
	SearchKey.data = NULL;
    return pItem;
}

ItemNode* ItemClass::AddType(char* pitem,DWORD numtype,BOOL overwrite)
{
   ItemNode *saux = Find(pitem);
    if (saux) {
      		if (!overwrite)
				saux->property |= numtype;
			else
				saux->property = numtype;
    }
    return saux;
}
/*
 *----------------------------------------------------------
 * Compact Type Function
 *-----------------------------------------------------------
 */

//set for define type
//p_type: anylyzer parameter, pointer move to next  data item 

inline void p_type(char **data,int &x,kind &k)
{
	char buf[MLEN];
	char *style,*tmp = buf;
	x = 1; k = nitem;

	lstrcpy(buf,*data);
	style = getword(&tmp);
	if (style[0] == '@') 
	{
		CharUpper(style);
		if (isincs(style,'L')) x = 2;
		else
			if (isincs(style,'A')) x = 3;
			if (isincs(style,'S')) k = sdata;
			else
				if (isincs(style,'D')) k = ndata;
		style = getword(data);
	}
}
inline void p_type(char **data,int &x ,char **var)
{
	char buf[MLEN];
	char *style,*tmp = buf;
	*var = NULL;
	x = 1;

	lstrcpy(buf,*data);
	style = getword(&tmp);
	if (style[0] == '@') 
	{
		CharUpper(style);
		if (isincs(style,'L')) x = 2;
		else
			if (isincs(style,'A')) x = 3;
		style = getword(data);
		if (isincs(style,'V')) *var = getword(data);
	}
}
inline void p_type(char **data,int &x ,kind &k,char **var)
{
	char buf[MLEN];
	char *style,*tmp = buf;
	*var = NULL;
	x = 1;k = nitem;

	lstrcpy(buf,*data);
	style = getword(&tmp);
	if (style[0] == '@') 
	{
		CharUpper(style);
		if (isincs(style,'L')) x = 2;
		else
			if (isincs(style,'A')) x = 3;
			if (isincs(style,'S')) k = sdata;
			else
				if (isincs(style,'D')) k = ndata;
		style = getword(data);
		if (isincs(style,'V')) *var = getword(data);
	}
}
// Return TRUE for success ,FALSE for fail
void set_type(int x,SubType *rc,char *tmp)
{
	if (x == 1) {
		if (rc->shorttype) delete rc->shorttype;
		rc->shorttype = new char[lstrlen(tmp) + 1] ;
		lstrcpy(rc->shorttype,tmp); 
	}
	else 
		if (x== 2) {
			if (rc->longtype) delete rc->longtype ;
			rc->longtype = new char[lstrlen(tmp) + 1] ;
			lstrcpy(rc->longtype,tmp);
		}
		else {
			if (rc->shorttype) delete rc->shorttype;
			if (rc->longtype) delete rc->longtype ;
			rc->longtype = new char[lstrlen(tmp) + 1] ;
			lstrcpy(rc->longtype,tmp);	 rc->shorttype = rc->longtype; 
		}
}

//get a number compact nick type , return num

inline void get_num_type(SubType *rc,char *tmp,int x,DWORD &num)
{
	num = 0;
	if (x == 1) str_to_type(rc->shorttype,tmp,num);
	else 
		if (x == 2) str_to_type(rc->longtype,tmp,num);
		else getnumtype(rc,tmp,num);
}
//get a  type from number compact, a buffer must be specific to return result

inline void get_type_num(SubType *rc,DWORD num,int x,char *result)
{
	char *aux,*auxs;

	aux = new char[MLEN];
	*aux = 0;*result = 0;

	if (x == 1) type_to_str(rc->shorttype,&aux,num);
	else 
		if (x == 2) type_to_str(rc->longtype,&aux,num);
		else {
			type_to_str(rc->shorttype,&aux,num);
			auxs = new char[MLEN];
			type_to_str(rc->longtype,&auxs,num);
			lstrcat(aux,auxs);
			delete auxs;
		}
	lstrcpy(result,aux);
	delete aux;
}

//table property compact follow function
// add table property  <type> <userstype>


MircFunc SetTP(FUNCPARMS)
{
	char *tmp = data;
 	int y;
	kind k;

	p_type(&tmp,y,k);
	if (!*tmp) r_err("PARA","Invalid Type")
	if (numtok(tmp) > 32) r_err("PARA","Too Many Types,Max Types is 32")
	if (!AType) AType = new SubType(); 
	set_type(y,AType,tmp);
	r_ok("");
}

MircFunc WriteTP(FUNCPARMS)
{
	char *tmp = data,*var,buf[MLEN];
 	int y;
	kind k;

	p_type(&tmp,y,k,&var);
	if (AType) {
		if (y == 1) lstrcpy(buf,AType->shorttype?AType->shorttype:"");
		else 
				if (y == 2) lstrcpy(buf,AType->longtype?AType->longtype:"");
				else wsprintf(buf,"%s|%s",AType->shorttype?AType->shorttype:""
					,AType->longtype?AType->longtype:"");
			r_var(var,buf);

	}
	else { Unsetvar(var); lstrcpy(data,"-NO Type not set"); }

	return 3;
}

MircFunc DelTP(FUNCPARMS)
{
	if (!AType) lstrcpy(data,"-NO Type not set");
	else {
		delete AType;
		AType  = NULL;
		lstrcpy(data,"+OK");
	}
	return 3;
}

MircFunc GetTPNum (FUNCPARMS)
{
	char *tmp = data,*var,buf[MLEN];
 	int y;
	DWORD num;
	kind k;

	p_type(&tmp,y,k,&var);

	if (AType) 	{
		if (getfirstnum(tmp,num) < 0) lstrcpy(data,"-PARA Invalid type number");
		else {
			get_type_num(AType,num,y,&buf[0]);
			r_var(var,buf);
		}

	}
	else { Unsetvar(var); lstrcpy(data,"-NO Type not set"); }

	return 3;
}

MircFunc GetNumTP (FUNCPARMS)
{
	char *tmp = data,*var;
 	int y;
	DWORD num;
	kind k;

	p_type(&tmp,y,k,&var);

	if (!*tmp) { Unsetvar(var); lstrcpy(data,"-PARA Invalid Change Type"); }
	else {
		if (AType) 	{
			get_num_type(AType,tmp,y,num);
			rnum_var(var,num);
		}	 
		else { 	Unsetvar(var); lstrcpy(data,"-NO Type not set"); }
	}
	return 3;
}



//table compact follow function

TableType * type_table_find(ptable table,kind k)
{
	ListTableType::iterator i;

	for ( i = lttype.begin(); i != lttype.end(); i++ )
		if ((k == (*i).k) && ((*i).table == table)) return &(*i); 
	return NULL;
}

TableType * type_table_find(char* table,kind k)
{
	ListTableType::iterator i;

	for ( i = lttype.begin(); i != lttype.end(); i++ )
		if ((k == (*i).k) && (match((*i).table->table,table,FALSE))) return &(*i); 
	return NULL;
}
// add table <name> <type> <userstype>

int type_table_add (char* data)
{
    char *tmp = data;
 	int err,y;
	TableType *x,h;
	ptable pt;
	BOOL overwrite = TRUE;
	kind k;
	err = currenttable(&tmp,&pt); 
	if (err) return err; //return error
	p_type(&tmp,y,k);
	if (!*tmp) return 64;
	if (numtok(tmp) > 32)  return 9;

	x = type_table_find(pt->table,k);
	if (!x) { 
		x = new TableType(); overwrite = FALSE; 
		x->k = k;
	}
	set_type(y,x,tmp);
	x->table = pt; 
    if (!overwrite) lttype.push_back(*x);
	return 0;
}

// return 0  if at least one has been deleted,delete only 1 nodes 

int type_table_del(ptable table,kind k)
{
	ListTableType::iterator i;

	for ( i = lttype.begin(); i != lttype.end(); i++ )
		if ((k == (*i).k) && ((*i).table == table)) { lttype.erase(i); return 0; }
	return 1;
}

// return 0  if at least one has been deleted,delete only 2 nodes first

int type_table_del(ptable table)
{
	ListTableType::iterator i,j;
	int count = 0,count1 = 0;

	for ( i = lttype.begin();(count < 2) && (i != lttype.end()); i++ ) 
		if ((*i).table == table)  {
			j = i;++i;  lttype.erase(j); ++count;
			if ((i != lttype.end()) && ((*i).table == table)) { lttype.erase(i); break;  }
		} 

	for ( i = lttype2.begin();(count1 < 2) && (i != lttype2.end()); i++ )
		if ((*i).table == table) {
			j = i;++i;  lttype2.erase(i); ++count1;
			if ((i != lttype2.end()) && ((*i).table == table)) { lttype2.erase(i); return 0;  }
		}
	return (count || count1)?0:1;
}

MircFunc SetTIM(FUNCPARMS)
{
 msg_error(data,type_table_add(data));
 return 3;
}

MircFunc WriteTIM(FUNCPARMS)
{
	char *tmp = data,*var,buf[MLEN];
 	int err,y;
	kind k;
	ptable pt;
	TableType *x;

	err = currenttable(&tmp,&pt); 
	if (err) msg_error(data,err); 
	else {
		p_type(&tmp,y,k,&var);
		x = type_table_find(pt,k);
		if (x) {
			if (y == 1) lstrcpy(buf,x->shorttype?x->shorttype:"");
			else 
				if (y == 2) lstrcpy(buf,x->longtype?x->longtype:"");
				else wsprintf(buf,"%s|%s",x->shorttype?x->shorttype:""
					,x->longtype?x->longtype:"");
			r_var(var,buf);

		}
		else { Unsetvar(var); lstrcpy(data,"-NO Type not set"); }
	}
	return 3;
}

MircFunc DelTIM(FUNCPARMS)
{
	char *tmp = data,*style;
 	int err;
	kind k = nitem;
	ptable pt;

	err = currenttable(&tmp,&pt); 
	if (err) msg_error(data,err); 
	else {
		style = getword(&tmp);
		if (style[0] != '@') lstrcpy(data,"-PARA Invalid para,Item , Data or Sub property");
		else {
			CharUpper(style);
			if (isincs(style,'S')) k = sdata;
			else
				if (isincs(style,'D')) k = ndata;
			err = type_table_del(pt,k);
			if (err) lstrcpy(data,"-NO Type not set");
			else lstrcpy(data,"+OK");
		}
	} 
	return 3;
}

MircFunc GetTableTypeNum (FUNCPARMS)
{
	char *tmp = data,*var,buf[MLEN];
 	int err,y;
	DWORD num;
	kind k;
	ptable pt;
	TableType *x;

	err = currenttable(&tmp,&pt); 
	if (err) msg_error(data,err); 
	else {
		p_type(&tmp,y,k,&var);
		x = type_table_find(pt,k);
		if (x) 	{
			if (getfirstnum(tmp,num) < 0) lstrcpy(data,"-PARA Invalid type number");
			else {
				get_type_num(x,num,y,&buf[0]);
				r_var(var,buf);
			}
		}
		else { Unsetvar(var); lstrcpy(data,"-NO Type not set"); }
	}
	return 3;
}

MircFunc GetNumTableType (FUNCPARMS)
{
	char *tmp = data,*var;
 	int err,y;
	DWORD num;
	kind k;
	ptable pt;
	TableType *x;

	err = currenttable(&tmp,&pt); 
	if (err) msg_error(data,err); 
	else {
		p_type(&tmp,y,k,&var);

		if (!*tmp) { rnum_var(var,0); }
		else {
			x = type_table_find(pt,k);
			if (x) 	{
				get_num_type(x,tmp,y,num);
				rnum_var(var,num);
			}	 
			else { 	Unsetvar(var); lstrcpy(data,"-NO Type not set"); }
		}
	}
	return 3;
}

TableType * type_table_find2(ptable table,kind k)
{
	ListTableType::iterator i;

	for ( i = lttype2.begin(); i != lttype2.end(); i++ )
		if ((k == (*i).k) && ((*i).table == table)) return &(*i); 
	return NULL;
}

TableType * type_table_find2(char* table,kind k)
{
	ListTableType::iterator i;

	for ( i = lttype2.begin(); i != lttype2.end(); i++ )
		if ((k == (*i).k) && (match((*i).table->table,table,FALSE))) return &(*i); 
	return NULL;
}
// add table <name> <type> <userstype>

int type_table_add2 (char* data)
{
    char *tmp = data;
 	int err,y;
	TableType *x;
	ptable pt;
	BOOL overwrite = TRUE;
	kind k;

	err = currenttable(&tmp,&pt); 
	if (err) return err; //return error
	p_type(&tmp,y,k);
	if (!*tmp) return 64;
	if (numtok(tmp) > 32) return 9;

	x = type_table_find2(pt->table,k);
	if (!x) { 
		x = new TableType(); overwrite = FALSE; 
		x->k = k;
	}
	set_type(y,x,tmp);
	x->table = pt; 
	if (!overwrite) lttype2.push_back(*x);
	return 0;
}

// return 0  if at least one has been deleted,delete only 1 nodes 

int type_table_del2(ptable table,kind k)
{
	ListTableType::iterator i;

	for ( i = lttype2.begin(); i != lttype2.end(); i++ )
		if ((k == (*i).k) && ((*i).table == table)) { lttype2.erase(i); return 0; }
	return 1;
}



MircFunc SetCTIM(FUNCPARMS)
{
 msg_error(data,type_table_add2(data));
 return 3;
}

MircFunc WriteCTIM(FUNCPARMS)
{
	char *tmp = data,*var,buf[MLEN];
 	int err,y;
	kind k;
	ptable pt;
	TableType *x;

	err = currenttable(&tmp,&pt); 
	if (err) msg_error(data,err); 
	else {
		p_type(&tmp,y,k,&var);
		x = type_table_find2(pt,k);
		if (x) {
			if (y == 1) lstrcpy(buf,x->shorttype?x->shorttype:"");
			else 
				if (y == 2) lstrcpy(buf,x->longtype?x->longtype:"");
				else wsprintf(buf,"%s|%s",x->shorttype?x->shorttype:""
					,x->longtype?x->longtype:"");
			r_var(var,buf);

		}
		else { Unsetvar(var); lstrcpy(data,"-NO Type not set"); }
	}
	return 3;
}

MircFunc DelCTIM(FUNCPARMS)
{
	char *tmp = data,*style;
 	int err;
	kind k = nitem;
	ptable pt;

	err = currenttable(&tmp,&pt); 
	if (err) msg_error(data,err); 
	else {
		style = getword(&tmp);
		if (style[0] != '@') lstrcpy(data,"-PARA Invalid para,Item , Data or Sub property");
		else {
			CharUpper(style);
			if (isincs(style,'S')) k = sdata;
			else
				if (isincs(style,'D')) k = ndata;
			err = type_table_del2(pt,k);
			if (err) lstrcpy(data,"-NO Type not set");
			else lstrcpy(data,"+OK");
		}
	} 
	return 3;
}

MircFunc GetCTableTypeNum (FUNCPARMS)
{
	char *tmp = data,*var,buf[MLEN];
 	int err,y;
	DWORD num;
	kind k;
	ptable pt;
	TableType *x;

	err = currenttable(&tmp,&pt); 
	if (err) msg_error(data,err); 
	else {
		p_type(&tmp,y,k,&var);
		x = type_table_find2(pt,k);
		if (x) 	{
			if (getfirstnum(tmp,num) < 0) lstrcpy(data,"-PARA Invalid type number");
			else {
				get_type_num(x,num,y,&buf[0]);
				r_var(var,buf);
			}
		}
		else { Unsetvar(var); lstrcpy(data,"-NO Type not set"); }
	}
	return 3;
}

MircFunc GetNumCTableType (FUNCPARMS)
{
	char *tmp = data,*var;
 	int err,y;
	DWORD num;
	kind k;
	ptable pt;
	TableType *x;

	err = currenttable(&tmp,&pt); 
	if (err) msg_error(data,err); 
	else {
		p_type(&tmp,y,k,&var);

		if (!*tmp) { rnum_var(var,0); }
		else {
			x = type_table_find2(pt,k);
			if (x) 	{
				get_num_type(x,tmp,y,num);
				rnum_var(var,num);
			}	 
			else { 	Unsetvar(var); lstrcpy(data,"-NO Type not set"); }
		}
	}
	return 3;
}
//network compact follow function

NetType * type_net_find(pnetwork net,kind k)
{
	ListNetType::iterator i;

	for ( i = lntype.begin(); i != lntype.end(); i++ )
		if ((k == (*i).k) && ((*i).net == net)) return &(*i); 
	return NULL;
}

NetType * type_net_find(char* network,kind k)
{
	ListNetType::iterator i;

	for ( i = lntype.begin(); i != lntype.end(); i++ )
		if ((k == (*i).k) && (match((*i).net->network,network,FALSE))) return &(*i); 
	return NULL;
}

int type_net_add (char* data)
{
    char *tmp = data;
 	int err,y;
	NetType *x;
	ptable pt;
	pnetwork net;
	BOOL overwrite = TRUE;
	kind k;

	err = currentnetf(&tmp,&pt,&net); 
	if (err) return err; //return error
	p_type(&tmp,y,k);
	if (!*tmp) return 64;
	if (numtok(tmp) > 32) return 9;

	x = type_net_find(net->network,k);
	if (!x) { 
		x = new NetType(); overwrite = FALSE; 
		x->k = k;
	}
	set_type(y,x,tmp);
	x->table = pt; x->net = net;
	if (!overwrite) lntype.push_back(*x);
	return 0;
}
// return 0  if at least one has been deleted,delete only 1 nodes 

int type_net_del(pnetwork net,kind k)
{
	ListNetType::iterator i;

	for ( i = lntype.begin(); i != lntype.end(); i++ )
		if ((k == (*i).k) && ((*i).net == net)) { lntype.erase(i); return 0; }
	return 1;
}

// return 0  if at least one has been deleted,delete only 2 nodes first

int type_net_del(pnetwork net)
{
	ListNetType::iterator i,j;
	int count = 0;

	for ( i = lntype.begin(); (count < 2) && (i != lntype.end()); i++ )
		if ((*i).net == net) { 
			j = i; i++;	lntype.erase(j);   
			if ((i != lntype.end()) && ((*i).net == net)) { lntype.erase(i); return 0;  }
			++count;
		}
		return count?0:1;
}


MircFunc SetNIM(FUNCPARMS)
{
 msg_error(data,type_net_add(data));
 return 3;
}

MircFunc WriteNIM(FUNCPARMS)
{
	char *tmp = data,*var,buf[MLEN];
 	int err,y;
	kind k;
	pnetwork net;
	NetType *x;

	err = currentnet(&tmp,&net); 
	if (err) msg_error(data,err); 
	else {
		p_type(&tmp,y,k,&var);
		x = type_net_find(net,k);
		if (x) {
			if (y == 1) lstrcpy(buf,x->shorttype?x->shorttype:"");
			else 
				if (y == 2) lstrcpy(buf,x->longtype?x->longtype:"");
				else wsprintf(buf,"%s|%s",x->shorttype?x->shorttype:""
					,x->longtype?x->longtype:"");
			r_var(var,buf);

		}
		else { Unsetvar(var);  lstrcpy(data,"-NO Type not set"); }
	}
	return 3;
}

MircFunc DelNIM(FUNCPARMS)
{
	char *tmp = data,*style;
 	int err;
	kind k = nitem;
	pnetwork net;

	err = currentnet(&tmp,&net); 
	if (err) msg_error(data,err); 
	else {
		style = getword(&tmp);
		if (style[0] != '@') lstrcpy(data,"-PARA Invalid para,Item or Data property");
		else {
			CharUpper(style);
			if (isincs(style,'S')) k = sdata;
			else
				if (isincs(style,'D')) k = ndata;
			err = type_net_del(net,k);
			if (err) lstrcpy(data,"-NO Type not set");
			else lstrcpy(data,"+OK");
		}
	} 
	return 3;
}

MircFunc GetNetTypeNum (FUNCPARMS)
{
	char *tmp = data,*var,buf[MLEN];
 	int err,y;
	DWORD num;
	kind k;
	pnetwork net;
	NetType *x;

	err = currentnet(&tmp,&net); 
	if (err) msg_error(data,err); 
	else {
		p_type(&tmp,y,k,&var);
		x = type_net_find(net,k);
		if (x) 	{
			if (getfirstnum(tmp,num) <0) lstrcpy(data,"-PARA Invalid type number");
			else {
				get_type_num(x,num,y,&buf[0]);
				r_var(var,buf);
			}

		}
		else { Unsetvar(var); lstrcpy(data,"-NO Type not set"); }
	}
	return 3;
}

MircFunc GetNumNetType (FUNCPARMS)
{
	char *tmp = data,*var;
 	int err,y;
	DWORD num;
	kind k;
	pnetwork net;
	NetType *x;

	err = currentnet(&tmp,&net); 
	if (err) msg_error(data,err); 
	else {
		p_type(&tmp,y,k,&var);
		if (!*tmp) { rnum_var(var,0); }
		else {
			x = type_net_find(net,k);
			if (x) 	{
				get_num_type(x,tmp,y,num);
				rnum_var(var,num);
			} 
			else { 	Unsetvar(var); lstrcpy(data,"-NO Type not set"); }
		}
	}
	return 3;
}


//channel compact follow function

ChanType * type_chan_find(pchannel chan,kind k)
{
	ListChanType::iterator i;

	for ( i = lctype.begin(); i != lctype.end(); i++ )
		if ((k == (*i).k) && ((*i).chan == chan)) return &(*i); 
	return NULL;
}

ChanType * type_chan_find(char* channel,kind k)
{
	ListChanType::iterator i;

	for ( i = lctype.begin(); i != lctype.end(); i++ )
		if ((k == (*i).k) && (match((*i).chan->channel,channel,FALSE))) return &(*i); 
	return NULL;
}

int type_chan_add (char* data)
{
    char *tmp = data; 	int err,y;	ChanType *x;
	ptable pt;	pnetwork net; pchannel chan;
	BOOL overwrite = TRUE;
	kind k;

	err = currentchanf(&tmp,&pt,&net,&chan); 
	if (err) return err; //return error
	p_type(&tmp,y,k);
	if (!*tmp) return 64;
	if (numtok(tmp) > 32) return 9;

	x = type_chan_find(chan->channel,k);
	if (k == ndata) k = nitem;
	if (!x) { 
		x = new ChanType(); overwrite = FALSE; 
		x->k = k;
	}
	set_type(y,x,tmp);
	x->table = pt; x->net = net;x->chan = chan;
	if (!overwrite) lctype.push_back(*x);
	return 0;
}
// return 0  if at least one has been deleted,delete only 1 nodes 

int type_chan_del(pchannel chan,kind k)
{
	ListChanType::iterator i;

	for ( i = lctype.begin(); i != lctype.end(); i++ )
		if ((k == (*i).k) && ((*i).chan == chan)) { lctype.erase(i); return 0; }
	return 1;
}

// return 0  if at least one has been deleted,delete only 2 nodes first

int type_chan_del(pchannel chan)
{
	ListChanType::iterator i,j;
	int count = 0;

	for ( i = lctype.begin();(count < 2) && (i != lctype.end()); i++ )
		if ((*i).chan == chan) { 
			j = i; i++;	lctype.erase(j);
			if ((i != lctype.end()) && ((*i).chan == chan)) { lctype.erase(i); return 0;  }
			++count;
		}
		return count?0:1;
}



MircFunc SetCIM(FUNCPARMS)
{
 msg_error(data,type_chan_add(data));
 return 3;
}

MircFunc WriteCIM(FUNCPARMS)
{
	char *tmp = data,*var,buf[MLEN];
 	int err,y;
	kind k;
	pchannel chan;
	ChanType *x;

	err = currentchan(&tmp,&chan); 
	if (err) msg_error(data,err); 
	else {
		p_type(&tmp,y,k,&var);
		if (k == ndata) k = nitem;
		x = type_chan_find(chan,k);
		if (x) {
			if (y == 1) lstrcpy(buf,x->shorttype?x->shorttype:"");
			else 
				if (y == 2) lstrcpy(buf,x->longtype?x->longtype:"");
				else wsprintf(buf,"%s|%s",x->shorttype?x->shorttype:""
					,x->longtype?x->longtype:"");
			r_var(var,buf);

		}
		else { Unsetvar(var); lstrcpy(data,"-NO Type not set"); }
	}
	return 3;
}

MircFunc DelCIM(FUNCPARMS)
{
	char *tmp = data,*style;
 	int err;
	kind k = nitem;
	pchannel chan;

	err = currentchan(&tmp,&chan); 
	if (err) msg_error(data,err); 
	else {
		style = getword(&tmp);
		if (style[0] != '@') lstrcpy(data,"-PARA Invalid para,Item or Data property");
		else {
			CharUpper(style);
			if (isincs(style,'S')) k = sdata;
			err = type_chan_del(chan,k);
			if (err) lstrcpy(data,"-NO Type not set");
			else lstrcpy(data,"+OK");
		}
	} 
	return 3;
}

MircFunc GetChanTypeNum (FUNCPARMS)
{
	char *tmp = data,*var,buf[MLEN];
 	int err,y;
	DWORD num;
	kind k;
	pchannel chan;
	ChanType *x;

	err = currentchan(&tmp,&chan); 
	if (err) msg_error(data,err); 
	else {
		p_type(&tmp,y,k,&var);
		if (k == ndata) k = nitem;
		x = type_chan_find(chan,k);
		if (x) 	{
			if (getfirstnum(tmp,num) <0) lstrcpy(data,"-PARA Invalid type number");
			else {
				get_type_num(x,num,y,&buf[0]);
				r_var(var,buf);
			}

		}
		else { Unsetvar(var); lstrcpy(data,"-NO Type not set"); }
	}
	return 3;
}

MircFunc GetNumChanType (FUNCPARMS)
{
	char *tmp = data,*var;
 	int err,y;
	DWORD num;
	kind k;
	pchannel chan;
	ChanType *x;

	err = currentchan(&tmp,&chan); 
	if (err) msg_error(data,err); 
	else {
		p_type(&tmp,y,k,&var);
		if (k == ndata) k = nitem;
		if (!*tmp) { rnum_var(var,0); }
		else {
			x = type_chan_find(chan,k);
			if (x) 	{
				get_num_type(x,tmp,y,num);
				rnum_var(var,num);
			} 
			else { 	Unsetvar(var); lstrcpy(data,"-NO Type not set"); }
		}
	}
	return 3;
}


int type_net_add_dif (char* data,ptable pt)
{
    char *tmp = data,*network,*buf;
	int k;
	NetType *x;
	CurNode y;

	y.table = pt;
	if (!y.table) return 11;
	network = getnexttokB(&tmp,'|');
	y.net = f_netnode(network,y.table);
	if (!y.net)  return 21;
	buf = getnexttokB(&tmp,'|');
	if (getfirstnum(buf,k) < 0)  return 64;

	x = new NetType(); 
	x->net = y.net;x->table = y.table; 
	if (k == 0)	x->k = nitem ;
	else 
		if (k == 1) x->k = sdata;
		else x->k = ndata;
	
	buf = getnexttokB(&tmp,'|');
	if ((buf) && (*buf)) {
		x->shorttype = new char[lstrlen(buf) + 1];
		lstrcpy(x->shorttype,buf);
	}
	buf = getnexttokB(&tmp,'|');
	if ((buf) && (*buf)) {
		x->longtype = new char[lstrlen(buf) + 1];
		lstrcpy(x->longtype,buf);
	}
	lntype.push_back(*x);
	return 0;
}

int type_table_add_dif (char* data,BOOL type,ptable y)
{
    char *tmp = data,*buf;
	int k;
	TableType *x;

	if (!y) return 11;
	buf = getnexttokB(&tmp,'|');
	if (getfirstnum(buf,k) < 0)  return 64;

	x = new TableType(); 
	x->table = y; 
	if (k == 0)	x->k = nitem ;
	else 
		if (k == 1) x->k = sdata;
		else	x->k = ndata;

	buf = getnexttokB(&tmp,'|');
	if ((buf) && (*buf)) {
		x->shorttype = new char[lstrlen(buf) + 1];
		lstrcpy(x->shorttype,buf);
	}
	buf = getnexttokB(&tmp,'|');
	if ((buf) && (*buf)) {
		x->longtype = new char[lstrlen(buf) + 1];
		lstrcpy(x->longtype,buf);
	}
	if (type) lttype.push_back(*x);
	else lttype2.push_back(*x);
	return 0;
}

int type_chan_add_dif (char* data,ptable pt)
{
    char *tmp = data,*network,*chan,*buf;
	int k;
	ChanType *x;
	CurNode y;

	y.table = pt;
	if (!y.table) return 11;
	network = getnexttokB(&tmp,'|');
	y.net = f_netnode(network,y.table);
	if (!y.net)  return 21;
	chan = getnexttokB(&tmp,'|');
	y.chan = f_channode(chan,y.net);
	if (!y.chan)  return 31;
	buf = getnexttokB(&tmp,'|');
	if (getfirstnum(buf,k) < 0)  return 64;

	x = new ChanType(); 
	x->net = y.net;x->table = y.table; 
	x->chan = y.chan;
	if (k == 0)	x->k = nitem ;
	else x->k = sdata;

	buf = getnexttokB(&tmp,'|');
	if ((buf) && (*buf)) {
		x->shorttype = new char[lstrlen(buf) + 1];
		lstrcpy(x->shorttype,buf);
	}
	buf = getnexttokB(&tmp,'|');
	if ((buf) && (*buf)) {
		x->longtype = new char[lstrlen(buf) + 1];
		lstrcpy(x->longtype,buf);
	}
	lctype.push_back(*x);
	return 0;
}


/*----------------------------------------------------------
				Function for analyze para
 *----------------------------------------------------------
*/
MircFunc SetPara(FUNCPARMS)
{
	char *tmp = data,*source,*st;
	source = getword(&tmp);
	if (!*source) r_err("PARA","Invalid source string")
	st = getword(&tmp);
	if (!*st)  r_err("PARA","Invalid target string")
	Para = creat_para(source,st,TRUE);
	r_ok("");
}

MircFunc GetPara(FUNCPARMS)
{
	char *tmp = data,*source,*pst,buf[BLEN],*var = NULL;
	int success;

	pst = getword(&tmp);
	if (!lstrcmpi(pst,"-v")) {
		var =  getword(&tmp);
		pst = getword(&tmp);
	}
    if (!*pst) r_err("PARA","Invalid switch")
	source = getword(&tmp);
	if (!*source)  {
	 if (Para == NULL)  r_err("PARA","Use SetPara function first or Input source string")
	 source = Para ;
	}
	success = take_para(source,pst,&buf[0],TRUE);
	if (!success) r_err("NO","Switch Not Found")
	else { 
		r_var(var,buf);
		return 3;
	}
}
/*----------------------------------------------------------
 * Table,Network and Channel clean
 *-----------------------------------------------------------
 */
inline BOOL askdel_chan(ptable pt,pnetwork net,pchannel chan)
{
	if ((hs.table && (hs.table == pt)) || (hs.sttable && match(hs.sttable,pt->table)))
	if ((hs.net && (hs.net == net)) || (hs.stnet && match(hs.stnet,net->network)))
	if ((hs.chan && (hs.chan == chan)) || (hs.stchan && match(hs.stchan,chan->channel))) return TRUE;
	return FALSE;
}
inline BOOL askdel_net(ptable pt,pnetwork net)
{
	if ((hs.table && (hs.table == pt)) || (hs.sttable && match(hs.sttable,pt->table)))
	if ((hs.net && (hs.net == net)) || (hs.stnet && match(hs.stnet,net->network))) return TRUE;
	return FALSE;
}
inline BOOL askdel_table(ptable pt)
{
	if ((hs.table && (hs.table == pt)) || (hs.sttable && match(hs.sttable,pt->table))) return TRUE;
	return FALSE;
}
inline void delresultnode(char *item)
{
	ListPointer::iterator i;
	for ( i = hs.lstore.begin(); i != hs.lstore.end() ; i++)
	if (match(((ItemNode*)(*i))->item,item,FALSE)) break;
	if (i != hs.lstore.end()) hs.delitem(i);
}
unsigned int nick_cleanup(ptable pt,pnetwork Net,pchannel Chan)
{
	int count = 0;

	if (Chan->headnick) {
		count = Chan->headnick->GetWeight();
		Chan->headnick->Destroy();
		if ( (hs.type == 40) && (askdel_chan(pt,Net,Chan))) hs.clear();
	}
	return count;
	 
}
unsigned int item_cleanup(ptable pt,pnetwork Net,pchannel Chan)
{
	int count = 0;
	if (Chan->litemc) {
		count = Chan->litemc->GetWeight();
		Chan->litemc->Destroy();
		if  ( (hs.type == 31) && (askdel_chan(pt,Net,Chan))) hs.clear();
	}
	return count;
	 
}

void listnull(CLinkedList * List)
{
	List->m_pFreedata= NULL;
	List->m_pCompdata= NULL;
	List->m_pAddFunction = NULL;
	List->m_pAnchor = NULL;
	List->m_pScanner = NULL;
	List->m_pMark = NULL;
	List->m_Count = 0;
	delete List;
}

unsigned int channel_cleanup(ptable pt,pnetwork Net,BOOL fr)
{
	CLinkedList * list ;
	CDLitem *Item,*i;
	unsigned int count = 0;

	if (Net->listchan) {
		if ((fr) && (hs.type >= 30) && (askdel_net(pt,Net)) )  hs.clear();
		list = Net->listchan ;
		i = list->begin();
		while (i != list->end())
		{
			Item = i; i = i->Next;
			if (fr) del_curchan(pchannel(Item->Data)); 
			type_chan_del(pchannel(Item->Data)) ;
			delete[] Item->Data;
			delete Item;
		}
		delete i;
		count = list->m_Count;
		listnull(Net->listchan);
		Net->listchan = NULL;
	}
	return count;
}

unsigned int item_net_cleanup(ptable pt,pnetwork Net)
{
	int count = 0;
	if (Net->litemn) {
		count = Net->litemn->GetWeight();
		Net->litemn->Destroy();
		if ((hs.type == 21) && (askdel_net(pt,Net)))  hs.clear();
	}
	return count;
	 
}
unsigned int item_table_cleanup(ptable thead)
{
	int count = 0;
	if (thead->litemt) {
		count = thead->litemt->GetWeight();
		thead->litemt->Destroy();
		if ((hs.type == 11) && (askdel_table(thead))) hs.clear();
	}
	return count;
	 
}

unsigned int network_cleanup (ptable Table,BOOL fr)
{
	CLinkedList * list ;
	CDLitem *Item, *i;
	unsigned int count = 0;
	if (Table->listnet) {
		if ( fr && (hs.type >= 20) && (askdel_table(Table))) hs.clear();
		list = Table->listnet; 
		i = list->begin();
		while (i != list->end())
		{
			Item = i; i = i->Next;
			channel_cleanup(Table,pnetwork(Item->Data),FALSE);
			if (fr) { del_curnet(pnetwork(Item->Data));	type_net_del(pnetwork(Item->Data)); }
			delete[] Item->Data;
			delete Item;
		}
		delete i;
		count = list->m_Count;
		listnull(Table->listnet);
		Table->listnet = NULL;
	}
    return count;
}

unsigned int table_cleanup()
{
	CDLitem *Item,*i;
	unsigned int count = 0;

	luse.clear();
	if (listtable) {
		lttype.clear();		lntype.clear(); 
		lttype2.clear();	lctype.clear();		hs.clear();
		i = listtable->begin();
		while (i != listtable->end())
		{
			Item = i; i = i->Next;
			network_cleanup(ptable(Item->Data),FALSE);
			delete[] Item->Data;
			delete Item;
		}
		delete i;
		count = listtable->m_Count;
		listnull(listtable);
		listtable = NULL;
	}
	if (listarray) {
		i = listarray->begin();
		while (i != listarray->end())
		{
			Item = i; i = i->Next;
			delete[] Item->Data;
			delete Item;
		}
		delete i;
		count += listarray->m_Count;
		listnull(listarray);
		listarray = NULL;
		farray = NULL; lresult.clear();
	}
    return count;
}


/*----------------------------------------------------------
 * some functions of Table,Network and Channel (add ,delete)
 * with full paths (....)
 *-----------------------------------------------------------
 */
inline int get_o_para(char ** data)
{
	char *p = *data;
	if (*data[0] == '-') {
		p++;
		while ((*p) && (*p != ' ') && (*p != 'o') && (*p != 'O')) p++;
		if ((*p == 'o') || (*p == 'O')) {
			p++;
			while ((*p) && (*p != ' ')) p++; 
			if (*p == ' ') { p++ ;	*data = p; return 1; }
		}
	}
	return 0;
}
void FreeTable(void ** i) {
	ptable  t = ptable(*i);
	if (t->litemt) t->litemt->Destroy();
	delete t->table;
}
int table_add (char *data,BOOL &create)
{
	char *tmp = data,*table;
	DWORD num = 0 ;
	create = FALSE;
 	ptable s = NULL,T;
	LPVOID result;
	int method = 0;

	if (get_o_para(&tmp)) method = 1 ;
	table = getword(&tmp);
    if (!*table) return 11;

 	if ( (getfirstnum(tmp,num) <0) && AType) getnumtype(AType,tmp,num);
	T = new TableClass(table);
	T->hash =  rfchash(table);
    if (listtable) { 
		if (listtable->m_Sorted) result = listtable->dlbsearch(T);
		else result = listtable->dlfind(T);
		if (result)	s = ptable(result);
	}
	else listtable = new CLinkedList(&NodeClass_comparetable,&FreeTable);
	if (!s) {
		create = TRUE;	T->property |= num;
		if ((method) && listtable->dlsorted()) listtable->dladdins(T);
		else listtable->dladd(T);
	}
	else {
		delete T;
		if (num) s->property |= num;
	}
    return 0;
}
void FreeArray(void ** i) {
	parray  t = parray(*i);
	INTVECTOR::iterator j;
	delete t->arrayname;
	for (j = t->Lang.begin();j != t->Lang.end();j++) delete (*j);
	t->Lang.clear();
}

int array_add (char *data,BOOL &create)
{
	char *tmp = data,*array;
	DWORD num = 0 ;
	create = FALSE;
 	parray s = NULL,T;
	LPVOID result;
	int method = 0;

	if (get_o_para(&tmp)) method = 1 ;
	array = getword(&tmp);
    if (!*array) return 141;

 	getfirstnum(tmp,num); 
	T = new TArrayClass(array);
	T->hash =  rfchash(array);
    if (listarray) { 
		if (listarray->m_Sorted) result = listarray->dlbsearch(T);
		else result = listarray->dlfind(T);
		if (result)	s = parray(result);
	}
	else listarray = new CLinkedList(&NodeClass_comparearray,&FreeArray);
	if (!s) {
		create = TRUE;	T->property |= num;
		if ((method) && listarray->dlsorted()) listarray->dladdins(T);
		else listarray->dladd(T);
	}
	else {
		delete T;
		if (num) s->property = num;
	}
    return 0;
}
void deltablenode(ptable pt)
{
	ptable t,p = NULL;
	ListPointer::iterator i;

	t = ptable(listtable->dlfind(pt));
	if (t) {
		del_curtable(t);
		type_table_del(t);
		network_cleanup(t,TRUE);
		if (askdel_table(t))
			if (hs.type > 10 ) hs.clear();
			else {
				for ( i = hs.lstore.begin(); i != hs.lstore.end() ; i++)
				if (match(((TableClass*)(*i))->table,pt->table,FALSE)) break;
				if (i != hs.lstore.end())	hs.delitem(i);
			}
		listtable->dldelete();
		return;
	}
}
void delarraynode(parray pt)
{
	parray t,p = NULL;
	ListPointer::iterator i;

	t = parray(listarray->dlfind(pt));
	if (t) {
		del_curarray(t);
		listarray->dldelete();
		return;
	}
}
int rename_array(char *data)
{
	char *tmp = data , *newname;
	parray pt;
	DWORD num = 0;
	BOOL overwrite = 0;

	if (isin_fpara(tmp,'o','O')) overwrite = 1;
	int err = currentarray(&tmp,&pt);
	if (err) return err;

    newname = getword(&tmp);
    if (!*newname)  return 11; 
	parray s = f_arraynode(newname);
	if (s == pt) return 0;
	if (s) 
		if (!overwrite) return 150;
		else delarraynode(s);
 	getfirstnum(tmp,num);
	copystr(&(pt->arrayname),newname);
	pt->property = num;
	pt->hash = rfchash(newname);
	return 0;
}
int rename_table(char *data)
{
	char *tmp = data , *newname;
	ptable pt;
	DWORD num = 0;
	BOOL overwrite = 0;

	if (isin_fpara(tmp,'o','O')) overwrite = 1;
	int err = currenttable(&tmp,&pt);
	if (err) return err;

    newname = getword(&tmp);
    if (!*newname)  return 11; 
	ptable s = f_tablenode(newname);
	if (s == pt) return 0;
	if (s) 
		if (!overwrite) return 150;
		else deltablenode(s);
 	if ( (getfirstnum(tmp,num) <0) && AType) getnumtype(AType,tmp,num);
	copystr(&(pt->table),newname);
	pt->property = num;
	pt->hash = rfchash(newname);
	return 0;
}

/*
 desc :  add a network
 INput :- source 
		- ignore table or not
		source format: -D[num]N[PSFAI] [para] [Table] <network>
 Output : error code or success
*/
void FreeNet(void ** i) {
	pnetwork  t = pnetwork(*i);
	if (t->litemn) t->litemn->Destroy();
	delete t->network;
}
int network_add (char *data,ptable itable,BOOL &create)
{
    char *tmp = data, *network;
	ptable thead;
	int err,method = 0;
	DWORD num = 0;
	TableType *x;
	create = FALSE;
	pnetwork s = NULL,N;

	if (!itable) {
	 if (isin_fpara(tmp,'o','O')) method = 1;
	 err = pathtable(&tmp,&network,&thead);
	 if (err) return err;
	}
	else {
		network = getword(&tmp);
		if (!*network) return 21;
		thead = itable;
	}
	if  (getfirstnum(tmp,num) <0) {
			x = type_table_find(thead,sdata);
			if (x) getnumtype(x,tmp,num);
	}
	N = new NetClass(network);
	N->hash = rfchash(network);
	if  (thead->listnet) {
		if (thead->listnet->m_Sorted) s = pnetwork(thead->listnet->dlbsearch(N));
		else s = pnetwork(thead->listnet->dlfind(N));
	}
	else thead->listnet = new CLinkedList(&NodeClass_comparenet,&FreeNet);
	if (!s) {
		create = TRUE; N->property |= num;
		if ((method) && thead->listnet->dlsorted()) thead->listnet->dladdins(N);
		else thead->listnet->dladd(N);
	}
	else {
		delete N;
		if (num) s->property |= num;
	}
    return 0;

}

int delnetnode(ptable pt,pnetwork Net) 
{
	pnetwork t = NULL;
	ListPointer::iterator i;

	if (pt->listnet) t = pnetwork(pt->listnet->dlfind(Net));
     if (t) {
		del_curnet(t);
		type_net_del(t);
		channel_cleanup(pt,t,TRUE);
		if (askdel_net(pt,t))
			switch (hs.type)
			{
				case 21: { hs.clear(); break; }
				case 20: {
						for ( i = hs.lstore.begin(); i != hs.lstore.end() ; i++)
						if (match(((NetClass*)(*i))->network,t->network,FALSE)) break; 
						if (i != hs.lstore.end()) hs.delitem(i);
						 }
			}
		pt->listnet->dldelete();
		return 1;
	}
	return 0;
}

int delchannode(ptable pt,pnetwork Net,pchannel Chan)
{
	pchannel t = NULL;
	ListPointer::iterator i;

	if (Net->listchan) t = pchannel(Net->listchan->dlfind(Chan));
	if (t) {
		del_curchan(t);
		type_chan_del(t);
 		if (askdel_chan(pt,Net,t))
			if (hs.type > 30 ) hs.clear();
			else 
				if (hs.type == 30)
				{ 
					for ( i = hs.lstore.begin(); i != hs.lstore.end() ; i++)
					if (match(((ChanClass*)(*i))->channel,t->channel,FALSE)) break;
					if (i != hs.lstore.end()) hs.delitem(i);
				} 
		Net->listchan->dldelete();
		return 1;
	}
	return 0;
}

int rename_net(char *data)
{
	char *tmp = data , *newname;
	pnetwork Net;
	ptable pt;
	DWORD num = 0;
	BOOL overwrite = 0;
	TableType *x;

	if (isin_fpara(tmp,'o','O')) overwrite = 1;
	int err = currentnetf(&tmp,&pt,&Net);
	if (err) return err;

    newname = getword(&tmp);
    if (!*newname)  return 21; 
	pnetwork s = f_netnode(newname,pt);
	if (s == Net) return 0;
	if (s)
		if (!overwrite) return 250;
		else delnetnode(pt,s);
	if  (getfirstnum(tmp,num) <0) {
			x = type_table_find(pt,sdata);
			if (x) getnumtype(x,tmp,num);
	}
	copystr(&(Net->network),newname);
	Net->property = num;
	Net->hash = rfchash(newname);
	return 0;
}

int rename_chan(char *data)
{
	char *tmp = data , *newname;
	pchannel Chan;
	pnetwork Net;
	ptable pt;
	DWORD num = 0;
	BOOL overwrite = 0;
	SubType *x;

	if (isin_fpara(tmp,'o','O')) overwrite = 1;
	int err = currentchanf(&tmp,&pt,&Net,&Chan);
	if (err) return err;

    newname = getword(&tmp);
    if (!*newname)  return 31; 
	pchannel s = f_channode(newname,Net);
	if (s == Chan) return 0;
	if (s)
		if (!overwrite) return 250;
		else delchannode(pt,Net,s);
	if  (getfirstnum(tmp,num) <0) {
			x = type_net_find(Net,sdata);
			if (!x)  x = type_table_find2(pt,sdata);
			if (x) getnumtype(x,tmp,num);
	}

	copystr(&(Chan->channel),newname);
	Chan->property = num;
	Chan->hash = rfchash(newname);
	return 0;
}
/*
 desc :  add a network
 INput :- source 
		- ignore table or not
		source format: -D[NUM]N[PASFI]C[PTAQFI] [para] [Table] [Network] <channel>
 Output : error code or success
*/
void FreeChan(void ** i) {
	pchannel  t = pchannel(*i);
	if (t->headnick) t->headnick->Destroy();	
	if (t->litemc) t->litemc->Destroy();
	delete t->channel;
	t->vnick.clear();
}
int channel_add (char* data ,ptable Table,pnetwork inet,BOOL &create)
{
    char *tmp = data, *channel;
	pchannel s = NULL,N;	
	pnetwork Net;	
	ptable pt;
	DWORD num = 0;
	int err,method = 0;
	SubType *x;
	create = FALSE;

	if (!inet) {
		if (isin_fpara(tmp,'o','O')) method = 1;
		err = pathnetf(&tmp,&channel,&pt,&Net);
		if (err) return err;
	} 
	else {
		pt = Table; 	Net = inet;
		channel = getword(&tmp);
		if (!*channel)    return 31;
	}

	if  (getfirstnum(tmp,num) <0) {
			x = type_net_find(Net,sdata);
			if (!x)  x = type_table_find2(pt,sdata);
			if (x) getnumtype(x,tmp,num);
	}

	N = new ChanClass(channel);
	N->hash = rfchash(channel);
	if  (Net->listchan) { 
		if (Net->listchan->m_Sorted) s = pchannel(Net->listchan->dlbsearch(N));
		else s = pchannel(Net->listchan->dlfind(N));
	}
	else Net->listchan = new CLinkedList(&NodeClass_comparechan,&FreeChan);
	if (!s) {
		create = TRUE; N->property |= num;
		if ((method) && Net->listchan->dlsorted()) Net->listchan->dladdins(N);
		else Net->listchan->dladd(N);
	}
	else {
		delete N;
		if (num) s->property |= num;
	}
    return 0;
}

int item_net_add (char* data,pnetwork inet)
{
    char *tmp = data, *item;
	pnetwork Net;	
	DWORD num = 0;
	int err;

	if (!inet) {
		err = currentnet(&tmp,&Net);
		if (err) return err;
	}
	else Net = inet;

	item = getword(&tmp);
    if (!*item)  return 134;
	getfirstnum(&tmp,num); 

	if (!Net->litemn) Net->litemn =  new ItemClass();
	Net->litemn->Add(item,tmp,num);
	return 0;
}

int item_net_addB (char* data,ptable ipt,pnetwork iNet)
{
    char *tmp = data, *item,*type;
	pnetwork Net;	
	ptable pt;
	SubType *x;
	DWORD num = 0;
	int err;

	if (!ipt) {
		err = currentnetf(&tmp,&pt,&Net);
		if (err) return err;
	}
	else { pt = ipt ; Net = iNet; }
 
	item = getnexttokB(&tmp,'|');
    if (!*item)  return 134;  
	if (getfirstnumB(&tmp,num) == HaveTokenOnly) {
		type  = getnexttokB(&tmp,'|');
		x = type_net_find(Net,nitem);
		if (!x) x = type_table_find(pt,ndata);
		if (x) getnumtype(x,type,num);
	}

	if (!Net->litemn) Net->litemn =  new ItemClass();
	Net->litemn->Add(item,tmp,num);
	return 0;
}

int add_net_item_type(char *data,BOOL overwrite)
{
	char *tmp = data , *item;
	ptable pt;
	pnetwork Net;
	DWORD num = 0;
	SubType *x;
	ItemNode *itemnode;

	int err = currentnetf(&tmp,&pt,&Net);
	if (err) return err;
    item = getword(&tmp);
    if (!*item)  return 134;  // r_err("PARA", "Invalid item") 
	if (getfirstnum(&tmp,num) < 0 ) {
		if (!*tmp)  return 64;
		x = type_net_find(Net,nitem);
		if (!x) x = type_table_find(pt,ndata);
		if (x) getnumtype(x,tmp,num);
		else  return 64;
	}

	if (!Net->litemn) {
		Net->litemn =  new ItemClass();
		Net->litemn->Add(item,"",num);
	}
	else { 
		itemnode =	Net->litemn->Find(item);
		if (itemnode) { 
			if (overwrite) itemnode->property = num;
			else itemnode->property |= num ; 
		}
		else 	Net->litemn->Add(item,"",num);
	}
	return 0;
}

int add_table_item_type(char *data,BOOL overwrite)
{
	char *tmp = data , *item;
	ptable pt;
	DWORD num = 0;
	TableType *x;
	ItemNode *itemnode;

	int err = currenttable(&tmp,&pt);
	if (err) return err;
    item = getword(&tmp);
    if (!*item)  return 134;  // r_err("PARA", "Invalid item") 
	if (getfirstnum(&tmp,num) < 0 ) {
		if (!*tmp)  return 64;
		x = type_table_find(pt,nitem);
		if (x) getnumtype(x,tmp,num);
		else  return 64;
	}
	if (!pt->litemt) {
		pt->litemt =  new ItemClass();
		pt->litemt->Add(item,"",num);
	}
	else { 
		itemnode =	pt->litemt->Find(item);
		if (itemnode) { 
			if (overwrite) itemnode->property = num;
			else itemnode->property |= num ; 
		}
		else 	pt->litemt->Add(item,"",num);
	}
	return 0;
}
int item_net_del (char* data)
{
	char *tmp = data,*item;
	pnetwork Net;
	ptable pt;
	ItemNode * itemnode;
	int err = currentnetf(&tmp,&pt,&Net);
	if (err) return err;
	if (!Net->litemn)  return 133;
    item = getword(&tmp);
    if (!*item)   return 134; // r_err("Item", "Invalid item")
	itemnode = Net->litemn->PDelete(item);
    if (itemnode) {
		if ((hs.type == 21) && askdel_net(pt,Net)) delresultnode(item);
		delete itemnode;
		return 0;
	}
    else   return 133;
}


int nick_add (char* data,pchannel Chan)
{
    char *tmp = data, *nick, *addy, *type;
    unsigned int tnum;
	DWORD ntype;
	int err ;

	assert(Chan);

	nick = getword(&tmp);
    if (!*nick)  return 41; // r_err("NICK", "Invalid nick") 
    addy = getword(&tmp);
    if (!*addy)  return 54; // r_err("ADDY", "Invalid address")
    type = getword(&tmp);
    if (!*type)  return 64; // r_err("TYPE", "Invalid type")

	err = getfirstnum(&tmp,tnum);
	if (err < 0)  return 74; // r_err("NUM", "Invalid number")
	else
		if (err == HaveNumOnly) return 84;
		else
			if (getfirstnum(&tmp,ntype) < 0) return 84; // r_err("TYPE", "Invalid nick type")

	if (!Chan->headnick) Chan->headnick =  new NickClass() ;
    Chan->headnick->Add(nick, addy, type,tmp,tnum,ntype);
    return 0;
}
int nick_addB (char* data,pchannel Chan)
{
    char *tmp = data, *nick, *addy, *type;
    unsigned int tnum;
	DWORD ntype;
	int err ;
	ptable  pt = NULL;
	pnetwork  Net = NULL;

	if (!Chan) { 
		if (listtable) pt = ptable(listtable->dltolast());
		else return 10;
		if (pt->listnet) Net = pnetwork(pt->listnet->dltolast());
		else return 10;
		if (Net->listchan) Chan = pchannel(Net->listchan->dltolast());
		else return 10;
	}	
    nick = getnexttokB(&tmp,'|');
    if (!nick || (!*nick))     return 41; // r_err("NICK", "Invalid nick") 
    addy = getnexttokB(&tmp,'|');
    if (!addy || (!*addy))     return 54; // r_err("ADDY", "Invalid address")
    type = getnexttokB(&tmp,'|');
  
	err = getfirstnumB(&tmp,tnum);
	if (err < 0)  return 74; // r_err("NUM", "Invalid number")
	else
		if (err == HaveNumOnly) return 84;
		else
			if (getfirstnumB(&tmp,ntype) < 0) return 84; // r_err("TYPE", "Invalid nick type")

	if (!Chan->headnick) Chan->headnick =  new NickClass() ;
    Chan->headnick->Add(nick, addy, type,tmp,tnum,ntype);
    return 0;
}
int vnick_addB (char* data,pchannel Chan)
{
    char *tmp = data, *nick, *addy, *type;
    unsigned int tnum = 0;
	DWORD ntype = 0;
	NickNode *x;
	ptable  pt;
	pnetwork  Net;

	if (!Chan) { 
		if (listtable) pt = ptable(listtable->dltolast());
		else return 10;
		if (pt->listnet) Net = pnetwork(pt->listnet->dltolast());
		else return 10;
		if (Net->listchan) Chan = pchannel(Net->listchan->dltolast());
		else return 10;
		
	}

    nick = getnexttokB(&tmp,'|');
    addy = getnexttokB(&tmp,'|');
    type = getnexttokB(&tmp,'|');
  	if (getfirstnumB(&tmp,tnum) == HaveNumHaveToken) 
		getfirstnumB(&tmp,ntype) ;
	x = new NickNode();
	x->NickNode2(nick,addy,type,tmp,tnum,ntype);
	Chan->vnick.push_back(x);
	return 0;
}
// return number of index ( 0 if not fould)
int vnick_overwrite (char* data,pchannel Chan)
{
    char *tmp = data, *nick, *addy, *type;
    unsigned int tnum = 0,pos = 0;
	DWORD ntype = 0;
	VectorNick::iterator i;
	NickNode *x;

	if (!Chan) { assert(Chan); }
    nick = getnexttokB(&tmp,'|');
    addy = getnexttokB(&tmp,'|');
    type = getnexttokB(&tmp,'|');
  	if (getfirstnumB(&tmp,tnum) == HaveNumHaveToken) 
		getfirstnumB(&tmp,ntype) ;
	for (i = Chan->vnick.begin(); i != Chan->vnick.end();i++) 
	{
		++pos;
		if (match(nick, (*i)->nick, FALSE) && match(addy, (*i)->addy, FALSE))  break;
	}
	if (i != Chan->vnick.end())	(*i)->assign2(nick,addy,type,tmp,tnum,ntype);
	else {
		x = new NickNode();
		x->NickNode2(nick,addy,type,tmp,tnum,ntype);
		Chan->vnick.push_back(x);
		pos = 0;
	}
	return pos;
}

int vnick_pos (char* data,pchannel Chan)
{
    char *tmp = data, *nick, *addy;
    unsigned int pos = 0;
	VectorNick::iterator i;

	if (!Chan) { return 0;	}
    nick = getnexttokB(&tmp,'|');
    addy = getnexttokB(&tmp,'|');
	if ((nick) && (*nick)) {
		if ((addy) && (*addy)) {
			for (i = Chan->vnick.begin(); i != Chan->vnick.end();i++) 
				{  
					++pos;
 					if ((match(nick, (*i)->nick, FALSE)) &&  (match(addy, (*i)->addy, FALSE)))  break;
				} 
		}
		else {
  			for (i = Chan->vnick.begin(); i != Chan->vnick.end();i++) 
			{  
				++pos;
 				if (match(nick, (*i)->nick, FALSE))   break;
			}  
		}
	}
	else
		if ((addy) && (*addy)) {
			for (i = Chan->vnick.begin(); i != Chan->vnick.end();i++) 
			{ 
				++pos;
 				if (match(addy, (*i)->addy, FALSE))  break;
			} 
		}
	return (i != Chan->vnick.end())?pos:0;
}
//HOST TYPE NUM DATA  COMMENT 
nick_add_value (char *data)
{
	char *tmp = data , *nick,*type;
	pchannel Chan;
	pnetwork Net;
	ptable pt;
	SubType *x;

	int err = currentchanf(&tmp,&pt,&Net,&Chan);

	if (err) return err;
    nick = getword(&tmp);
    if (!*nick)  return 41;  // r_err("NICK", "Invalid nick") 
    type = getword(&tmp);
	if (!*type) return 64;
	if (!Chan->headnick) return  43;
	x = type_chan_find(Chan,sdata);
	if (!x)  x = type_table_find2(pt,nitem);
	err = Chan->headnick->AddOther(x,nick,type,tmp);
	return err;
}
int clear_vnick(pchannel Chan)
{
	VectorNick::iterator i;
	int size = Chan->vnick.size();
	for (i = Chan->vnick.begin();i != Chan->vnick.end();i++)
		delete (*i);
	Chan->vnick.clear();
	return size;
}
int item_channel_add (char* data,pchannel ichan)
{
    char *tmp = data, *item;
 	int err;
	DWORD num = 0;
	pchannel Chan;

	if (!ichan) {
		err = currentchan(&tmp,&Chan);
		if (err) return err;
	}
	else Chan = ichan; 

	item = getword(&tmp);
    if (!*item)  return 134; // r_err("item", "Invalid item") 
	getfirstnum(&tmp,num); 

	if (!Chan->litemc) Chan->litemc =  new ItemClass() ;
	Chan->litemc->Add(item,tmp,num);
    return 0;
}
int item_channel_addB (char* data,ptable ipt,pnetwork iNet,pchannel ichan)
{
    char *tmp = data, *item,*type;
 	int err;
	DWORD num = 0;
	SubType *x;
	pchannel Chan;
	ptable pt;
	pnetwork Net;

	if (!ipt) {
		err = currentchanf(&tmp,&pt,&Net,&Chan);
		if (err) return err;
	}
	else { pt = ipt; Net = iNet; Chan = ichan;	}

	item = getnexttokB(&tmp,'|');
    if (!*item)  return 134; // r_err("item", "Invalid item") 

	if (getfirstnumB(&tmp,num) == HaveTokenOnly) {
		type  = getnexttokB(&tmp,'|');
		x = type_chan_find(Chan,nitem);
		if (!x)  x = type_net_find(Net,ndata);
		if (!x)  x = type_table_find2(pt,ndata);
		if (x) getnumtype(x,type,num);
	}
	if (!Chan->litemc) Chan->litemc =  new ItemClass() ;
	Chan->litemc->Add(item,tmp,num);
    return 0;
}

int item_channel_del (char* data)
{ 
	char *tmp = data,*item;
	ItemNode * itemnode;
	pchannel Chan;
	pnetwork Net;
	ptable pt;
	int err = currentchanf(&tmp,&pt,&Net,&Chan);

	if (err) return err;

    item = getword(&tmp);
    if (!*item)   return 134; // r_err("Item", "Invalid item")
	if (!Chan->litemc) return 133;
	itemnode = Chan->litemc->PDelete(item);
    if (itemnode) {
		if ((hs.type == 31) && askdel_chan(pt,Net,Chan)) delresultnode(item);
		delete itemnode;
		return 0;
	}
    else   return 133;
}
int table_del (char* table,BOOL ms)
{
	ptable t,p = NULL;
	ListPointer::iterator i;
	int err = 0;
	
	if (ms) {
		t = f_tablenode(table,err);
		if (err) return err;
	}
	else {
	    if (!*table)      return 11; // r_err("TABLE", "Invalid table name") 
		t = f_tablenode(table);
	}
	if (t) {
		if (askdel_table(t))
			if (hs.type > 10 ) hs.clear();
			else {
				for ( i = hs.lstore.begin(); i != hs.lstore.end() ; i++)
				if (match(((TableClass*)(*i))->table,table,FALSE)) break;
				if (i != hs.lstore.end())	hs.delitem(i);
			}
		del_curtable(t);
		type_table_del(t);
		network_cleanup(t,TRUE);
		listtable->dldelete();
        return 0;
    }
    return 13;
}

int array_del (char* array,BOOL ms)
{
	parray t,p = NULL;
	ListPointer::iterator i;
	int err = 0;
	
	if (ms) {
		t = f_arraynode(array,err);
		if (err) return err;
	}
	else {
	    if (!*array)      return 141; 
		t = f_arraynode(array);
	}
	if (t) {
		del_curarray(t);
		listarray->dldelete();
        return 0;
    }
    return 143;
}
int item_table_add (char* data,ptable itable)
{
    char *tmp = data, *item ;
	ptable pt = NULL;
	DWORD num = 0;
	int err;

	if (!itable) {
		err = currenttable(&tmp,&pt);
	 	if (err) return err;
	} 
	else pt = itable;

	item = getword(&tmp);
    if (!*item)  return 134;
	getfirstnum(&tmp,num);

	if (!pt->litemt) pt->litemt =  new ItemClass();
	pt->litemt->Add(item,tmp,num);
	return 0;
}
int item_table_addB (char* data,ptable itable)
{
    char *tmp = data, *item,*type ;
	ptable pt = NULL;
	DWORD num = 0;
	int err;
	TableType *x;

	if (!itable) {
		err = currenttable(&tmp,&pt);
		if (err) return err;
	} 
	else pt = itable;
    item = getnexttokB(&tmp,'|');
    if (!*item)  return 134;  // r_err("PARA", "Invalid item") 

	if (getfirstnumB(&tmp,num) == HaveTokenOnly) {
		type  = getnexttokB(&tmp,'|');
		x = type_table_find(pt,nitem);
		if (x) getnumtype(x,type,num);
	}
	if (!pt->litemt) pt->litemt =  new ItemClass();
	pt->litemt->Add(item,tmp,num);
	return 0;
}

int item_table_del (char* data)
{
	char *tmp = data,*item;
	ItemNode * itemnode;
	ptable pt;

	int err = currenttable(&tmp,&pt);
	if (err) return err;
    item = getword(&tmp);
    if (!*item)  return 134; // r_err("Item", "Invalid item")
  
	if (!pt->litemt) return 133;
	itemnode = pt->litemt->PDelete(item);
    if (itemnode) {
		if ((hs.type == 11) && askdel_table(pt)) delresultnode(item);
		delete itemnode;
		return 0;
	}
    else   return 133;
}
int item_h_table_del (ListPointer::iterator i)
{
	char *item;
	ptable pt;
	ItemNode *itemnode;

	item = ((ItemNode*)(*i))->item;
	if (hs.table) 
		if ( hs.table->litemt && ( hs.table->litemt->Delete(item))) {
			hs.delitem(i);	return 0;
		} 
		else   return 133;
	else if (listtable) {
		pt = ptable(listtable->dltofirst());
		for ( ;pt ; pt = ptable(listtable->dlgofwd()))
		if (pt->litemt) {
			itemnode = pt->litemt->Find(item);
			if (itemnode && ((ItemNode*)(*i) == itemnode)) {
				pt->litemt->Delete(item);
				hs.delitem(i);return 0;
			}
		} 
	}
		return 133;
}

int item_h_net_del (ListPointer::iterator i)
{
	char *item;
	ptable pt;
	pnetwork Net;
	ItemNode *itemnode;

	item = ((ItemNode*)(*i))->item;
	if (hs.net) 
		if ( hs.net->litemn && ( hs.net->litemn->Delete(item))) {
			hs.delitem(i);	return 0;
		} 
		else   return 133;
	else if (listtable) {
			pt = ptable(listtable->dltofirst());
			for (;pt ; pt = ptable(listtable->dlgofwd())) 
				if (pt->listnet) {
					Net = pnetwork(pt->listnet->dltofirst());
					for (;Net;Net = pnetwork(pt->listnet->dlgofwd()))
						if (Net->litemn) {
							itemnode = Net->litemn->Find(item);
							if (itemnode && ((ItemNode*)(*i) == itemnode)) {
								Net->litemn->Delete(item);
								hs.delitem(i);return 0;
							}
						}
				}
			return 133;
	}
	return 20;
}

int item_h_chan_del (ListPointer::iterator i)
{
	char *item;
	ptable pt;
	pnetwork Net;
	pchannel chan;
	ItemNode *itemnode;

	item = ((ItemNode*)(*i))->item;
	if (hs.chan) 
		if ( hs.chan->litemc && ( hs.chan->litemc->Delete(item))) {
			hs.delitem(i);	return 0;
		} 
		else   return 133;
	else if (listtable) {
		pt = ptable(listtable->dltofirst());
		for (;pt ; pt = ptable(listtable->dlgofwd())) 
			if (pt->listnet) {
			Net = pnetwork(pt->listnet->dltofirst());
			for (;Net;Net = pnetwork(pt->listnet->dlgofwd())) 
				if (Net->listchan)	{
				chan = pchannel(Net->listchan->dltofirst());
				for (;chan; chan = pchannel(Net->listchan->dlgofwd()))
					if (chan->litemc) {
						itemnode = chan->litemc->Find(item);
						if (itemnode && ((ItemNode*)(*i) == itemnode)) {
							chan->litemc->Delete(item);
							hs.delitem(i);return 0;
						}  
					}
				}
			}
		return 133;
	}
	return 20;
}

int item_h_nick_del (ListPointer::iterator i)
{
	char *nick;
	ptable pt;
	pnetwork Net;
	pchannel chan;
	NickNode *itemnode;

	nick = ((NickNode*)(*i))->nick;
	if (hs.chan) 
		if ( hs.chan->headnick && ( hs.chan->headnick->Delete(nick))) {
			hs.delitem(i);	return 0;
		} 
		else   return 43;
	else if (listtable) {
		pt = ptable(listtable->dltofirst());
		for (;pt ; pt = ptable(listtable->dlgofwd()))
			if (pt->listnet) {
			Net = pnetwork(pt->listnet->dltofirst());
			for (;Net;Net = pnetwork(pt->listnet->dlgofwd()))
				if (Net->listchan) {
				chan = pchannel(Net->listchan->dltofirst());
				for (;chan; chan = pchannel(Net->listchan->dlgofwd()))
					if (chan->headnick) {
						itemnode = chan->headnick->Find(nick);
						if (itemnode && ((NickNode*)(*i) == itemnode)) {
							chan->headnick->Delete(nick);
							hs.delitem(i);return 0;
						}  
					}  
				}
			}
		return 43;
	}
	return 20;
}
int item_h_vnick_del (ListPointer::iterator i)
{
	ptable pt;
	pnetwork Net;
	pchannel chan;
	VectorNick::iterator ii;

	if (hs.chan) {
		for ( ii = hs.chan->vnick.begin();ii != hs.chan->vnick.end();ii++)
			if (*ii == *i) break;
		if (ii != hs.chan->vnick.end()) hs.chan->vnick.erase(ii);
		hs.delitem(i); return 0;
	}
	else if (listtable) { 
		pt = ptable(listtable->dltofirst());
		for (;pt ; pt = ptable(listtable->dlgofwd()))
			if (pt->listnet) {
			Net = pnetwork(pt->listnet->dltofirst());
			for (;Net;Net = pnetwork(pt->listnet->dlgofwd()))
				if (Net->listchan) {
					chan = pchannel(Net->listchan->dltofirst());
					for (;chan; chan = pchannel(Net->listchan->dlgofwd()))
					if (!chan->vnick.empty()) {
						for ( ii = chan->vnick.begin();ii != chan->vnick.end();ii++)
							if (*ii == *i) break;
						if (ii != chan->vnick.end()) {
							chan->vnick.erase(ii);
							hs.delitem(i); return 0;
						} 
					}  
				}
			}
		return 43;
	} 
	return 20;
}
int table_del_match (char* table)
{
	int count = 0;
	if (!*table)  return 11; 
    ptable t = NULL;
	if (listtable) {
		hs.clear();
		t = ptable(listtable->dltofirst());
		while (t) {
			if  (match(table,t->table,FALSE))  {
				++count;
				del_curtable(t);
				type_table_del(t);
				network_cleanup(t,TRUE);
				listtable->dldelete();
				t = ptable(listtable->dlget());
			}
			else t = ptable(listtable->dlgofwd());
		}
	}
	return count;
}
int network_del_match (ptable Table,char *network)
{
    int count = 0;
    pnetwork t = NULL;

	if (!*network)  return 21;
	if ((hs.type >= 20) && askdel_table(Table))  hs.clear();
	if (Table->listnet) t = pnetwork(Table->listnet->dltofirst());
    while (t) {
		if  (match(network,t->network,FALSE))  {
			++count;
			channel_cleanup(Table,t,FALSE);
			del_curnet(t);
			type_net_del(t);
			Table->listnet->dldelete();
			t = pnetwork(Table->listnet->dlget());
		}
		else t = pnetwork(Table->listnet->dlgofwd());
    }
    return count;
}
int channel_del_match(ptable pt,pnetwork Net,char *channel)
{
    unsigned int count = 0;
    pchannel t = NULL;

	if (!*channel)  return 31;
	if ((hs.type >= 30) && askdel_net(pt,Net)) hs.clear();
	if (Net->listchan) t = pchannel(Net->listchan->dltofirst());
    while (t) {
		if  (match(channel,t->channel,FALSE))  {
			++count;
			del_curchan(t); 
			type_chan_del(t);
			Net->listchan->dldelete();
			t = pchannel(Net->listchan->dlget());
		}
		else t =  pchannel(Net->listchan->dlgofwd());
    }
    return count;
}
int network_del (char* data)
{
    char *tmp = data, *network;
	ListPointer::iterator i;
	pnetwork t = NULL;
	ptable pt;
	int err;

	err = pathtable(&tmp,&network,&pt);
	if (err) return err;

	t = f_netnode(network,pt);
	if (t) {
		del_curnet(t);
		type_net_del(t);
     	channel_cleanup(pt,t,TRUE);
		if (askdel_net(pt,t))
			switch (hs.type)
			{
				case 21: { hs.clear(); break; }
				case 20: {
						for ( i = hs.lstore.begin(); i != hs.lstore.end() ; i++)
						if (match(((NetClass*)(*i))->network,t->network,FALSE)) break; 
						if (i != hs.lstore.end()) hs.delitem(i);
						 }  
			}
		pt->listnet->dldelete();
		return 0;
    }
    return 23;
}

void delnetnode(char *table,pnetwork Net)
{
	if (listtable) {
		ptable t = ptable(listtable->dltofirst());
		for ( ; t;t = ptable(listtable->dlgofwd()))
			if ((match(table,t->table)) && delnetnode(t,Net)) break;
	}
}
int channel_del (char* data)
{
    char  *tmp = data,*channel;
	ListPointer::iterator i;
	pchannel t = NULL;
	ptable pt;
	pnetwork Net;
	int err;

	err = pathnetf(&tmp,&channel,&pt,&Net);
	if (err) return err;

	t = f_channode(channel,Net);
	if (t) {
		del_curchan(t);
		type_chan_del(t);
		if (askdel_chan(pt,Net,t))
			if (hs.type > 30 ) hs.clear();
			else 
				if (hs.type == 30)
				{ 
					for ( i = hs.lstore.begin(); i != hs.lstore.end() ; i++)
					if (match(((ChanClass*)(*i))->channel,t->channel,FALSE)) break;
					if (i != hs.lstore.end()) hs.delitem(i);
				} 
		Net->listchan->dldelete();
        return 0;
     }
    return 33;
}

void delchannode(char *table,char *network,pchannel Chan)
{
	ptable t = NULL;
	pnetwork Net;
	if (listtable) {
		t = ptable(listtable->dltofirst());
		for (; t; t= ptable(listtable->dlgofwd()))
			if (match(t->table,table) && t->listnet) {
				Net = pnetwork(t->listnet->dltofirst());
			for (; Net; Net = pnetwork(t->listnet->dlgofwd()))
				if ( (match(network,Net->network)) && delchannode(t,Net,Chan)) return;
		}
	}
}


int nick_del (char* data)
{
    char *tmp = data,*nick;
	ListPointer::iterator i;
	ptable pt;
	pnetwork Net;
	pchannel Chan;
	int err = currentchanf(&tmp,&pt,&Net,&Chan);

	if (err) return err;

    nick = getword(&tmp);
    if (!*nick)      return 41; // r_err("NICK", "Invalid nick")
  
	if (!Chan->headnick) return 43;
    if ( Chan->headnick->Delete(nick)) {

		if ((hs.type == 40) && askdel_chan(pt,Net,Chan)) {
			for ( i = hs.lstore.begin(); i != hs.lstore.end() ; i++)
				if (match(((NickNode*)(*i))->nick,nick,FALSE)) break;
			if (i != hs.lstore.end())	hs.delitem(i);
		}
		return 0;
	}
    else   return 43;
}

/*--------------------------------------------------------
			  store function
 *--------------------------------------------------------
*/
unsigned int find_fs(char *aux)
{
	char *auxs = NULL;
	unsigned int mfind = 0;
	ListPointer::iterator i;
	if  (hs.type) {
	for ( i = hs.lstore.begin() ;(i != hs.lstore.end()); i++) 
	{
		++mfind;
		switch (hs.type) 
		{
		case 10:{ auxs = ((ptable)(*i))->table; break; }
		case 20:{ auxs = ((pnetwork)(*i))->network; break; }
		case 30:{ auxs = ((pchannel)(*i))->channel; break; }
		case 40:{ auxs = ((NickNode*)(*i))->nick; break; }
		case 41:{ auxs = ((NickNode*)(*i))->nick; break; }	
		default:{ auxs = ((ItemNode*)(*i))->item; break; }
		}
		if (!lstrcmpi(aux,auxs))  break;
	}
	}
	if (i == hs.lstore.end())  return 0;
	else {
		hs.curpos = mfind;
		hs.curnode = i;
		return mfind;
	}
}
MircFunc FindFS(FUNCPARMS)
{	
	char *tmp = data,*aux;
	unsigned int mfind = 0;

	aux =  getword(&tmp);
	if (!*aux)  RETINVITEM
	mfind = find_fs(aux);
	if (mfind) { nrnum_var(tmp,mfind);  }
	else  { Unsetvar(tmp); lstrcpy(data,"-NO Item not found"); }
	return 3;
}
/*
	FS function must be use number for located an item
	to have  the accuracy , because two items may be the same
	if You use an item , you must ensure there aren't any duplicate items
	or just want to find  the first match item
*/
MircFunc GetFS(FUNCPARMS)
{
	char buf[MLEN],*tmp = data,*aux,*tmpbuf,*var = NULL,sep = '|';
	ListPointer::iterator i;
	NickNode *node;
	unsigned int nfind = 0,mfind = 1,type = 0,naux;
	BOOL isstring = 0,isdelete = 0;

	aux =  getword(&tmp);
	if (aux[0] == '-') {
		tmpbuf = creat_para("XSVP[NUM]G[NUM]C[NUM]",aux);
		if (take_para(tmpbuf,"P",&buf[0])) type = atolp(buf);
		else if (take_para(tmpbuf,"G",&buf[0])) type = atolp(buf);
		if (take_para(tmpbuf,"C",&buf[0])) {
			naux  = atolp(buf);
			if ((naux > 0) && (naux <= 255)) sep = naux;
		}
		if (find_para(tmpbuf,'V')) { var = getword(&tmp);  Unsetvar(var); }
		isstring = find_para(tmpbuf,'S');
		isdelete = find_para(tmpbuf,'X');
		aux =  getword(&tmp);
		delete tmpbuf;
	}
	if (!isstring) isstring = (getfirstnum(aux,nfind) < 0)?1:0;   
	if (isstring) {
		if (*aux) {
			nfind = find_fs(aux);
			if (!nfind) { lstrcpy(data,"-NO Item not found"); return 3; }
		}
		else  nfind = 0;
	}

	if (hs.type) {
		if (nfind == 0) { rnum_var(var,hs.lstore.size()); return 3; }
		if (nfind <= hs.lstore.size()) {
		if (hs.curpos) {
			mfind = hs.curpos; i = hs.curnode;
			if (hs.curpos != nfind) {  
				if (hs.curpos < nfind) 
					for (;((i != hs.lstore.end()) && (mfind < nfind));i++) ++mfind;
				else 
					for (;((i != hs.lstore.begin()) && (mfind > nfind));i--) --mfind;
			}
		}
		else  
			for (i = hs.lstore.begin();((i != hs.lstore.end()) && (mfind < nfind)) ; i++) ++mfind;

		if ((mfind == nfind) && (i != hs.lstore.end())) {
			hs.curnode = i;
			hs.curpos = nfind;
			switch (hs.type) 
			{
			case 10:{ wsprintf(buf,"%s|%lu",((TableClass*)(*i))->table,((ptable)(*i))->property); break; }
			case 20:{ wsprintf(buf,"%s|%lu",((NetClass*)(*i))->network,((pnetwork)(*i))->property); break; }
			case 30:{ wsprintf(buf,"%s|%lu",((ChanClass*)(*i))->channel,((pchannel)(*i))->property); break; }
			case 40:{
				node = ((NickNode*)(*i));
				wsprintf(buf, "%s|%s|%s|%d|%lu|%s", node->nick, node->addy,  node->data?node->data:"$NULL", node->num, node->nicktype , node->msg?node->msg:"");
				break;
			   } 
			case 41:{
				node = ((NickNode*)(*i));
				wsprintf(buf, "%s|%s|%s|%d|%lu|%s", N(node->nick), N(node->addy),N(node->data),node->num,node->nicktype,N(node->msg));
				break;
				}
			default:{ wsprintf(buf,"%s|%lu|%s",((ItemNode*)(*i))->item,
					((ItemNode*)(*i))->property,((ItemNode*)(*i))->data?((ItemNode*)(*i))->data:""); break; 
				} // for 11,21,31
			}  // end switch
			getnthtok(buf,type,sep);
			if (var && *var) { SetVar(var,buf);lstrcpy(data,"+OK"); } 
			else if (isdelete) wsprintf(data, "%s",buf); 
			else wsprintf(data, "+OK %s",buf); 
		} //if has result
		}
	else  RETOoR
	} // if hs.type
	else lstrcpy(data,"-LIST List is empty");
	return 3;
}

MircFunc CountFS(FUNCPARMS)
{
	wsprintf(data,"%d",hs.lstore.size());
	return 3;
}
MircFunc DelFS(FUNCPARMS)
{
	char *tmp = data,*aux;
	ListPointer::iterator i;
	unsigned int nfind = 0,mfind = 1;

	aux =  getword(&tmp);
	if (isnum(aux,FALSE))  nfind = atolp(aux);
	else {
		nfind = find_fs(aux);
		if (!nfind) { lstrcpy(data,"-NO Item not found"); return 3; }
	}

	if (hs.type) {
		if ((hs.curpos) && (hs.curpos <= nfind)) { i = hs.curnode ; mfind = hs.curpos; }
		else { i = hs.lstore.begin(); }

	for (;((i != hs.lstore.end()) && (mfind < nfind)) ; i++) ++mfind;
	if ((mfind == nfind) && (i != hs.lstore.end())) {
		hs.curnode = NULL;
		hs.curpos = 0;
		switch (hs.type) 
		{ 
		case 10:{ 
			deltablenode((ptable)(*i));	lstrcpy(data,"+OK");
			break; }
		case 20:{
			if (hs.table) delnetnode(hs.table,(pnetwork)(*i)); 
			else  delnetnode(hs.sttable,(pnetwork)(*i)); 
			lstrcpy(data,"+OK"); break; 
				}
		case 30:{ 
			if (hs.net) delchannode(hs.table,hs.net,(pchannel)(*i)); 
			else delchannode(hs.sttable,hs.stnet,(pchannel)(*i));
			lstrcpy(data,"+OK");break; 
				}
		case 11:{ 
			if (!item_h_table_del(i))  lstrcpy(data,"+OK"); 
			else lstrcpy(data,"-LIST Invalid List ,Unknow error");
			break;
				}
		case 21:{ 
			if (!item_h_net_del(i))  lstrcpy(data,"+OK"); 
			else lstrcpy(data,"-LIST Invalid List ,Unknow error");
			break;
				}
		case 31:{ 
			if (!item_h_chan_del(i))  lstrcpy(data,"+OK"); 
			else lstrcpy(data,"-LIST Invalid List ,Unknow error");
			break;
				}
		case 40:{ 
			if (!item_h_nick_del(i))  lstrcpy(data,"+OK"); 
			else lstrcpy(data,"-LIST Invalid List ,Unknow error");
			break;
				}
		case 41:{ 
			if (!item_h_vnick_del(i))  lstrcpy(data,"+OK"); 
			else lstrcpy(data,"-LIST Invalid List ,Unknow error");
			break;
				}
		default:{ lstrcpy(data,"-LIST Invalid List,Function not supported");  
				} 
		}  // end switch

	}
	else RETOoR

	} // if hs.type
	else lstrcpy(data,"-LIST List is empty");
	return 3;
}
/*--------------------------------------------------------
 *Export Function
 *--------------------------------------------------------
*/
/*-----------------------------------------
                 Table
 *-----------------------------------------
*/

MircFunc AddTable(FUNCPARMS)
{
	BOOL create;
	int err;
	err = table_add(data,create);
	if (err) msg_error(data,err);
	else wsprintf(data,"%d",create);
	return 3;
}
MircFunc AddArray(FUNCPARMS)
{
	BOOL create;
	int err;
	err = array_add(data,create);
	if (err) msg_error(data,err);
	else wsprintf(data,"%d",create);
	return 3;
}

MircFunc RenameTable(FUNCPARMS)
{
	int err = rename_table(data);
	if (err) msg_error(data,err);
	else lstrcpy(data,"+OK");
	return 3;
}
MircFunc RenameArray(FUNCPARMS)
{
	int err = rename_array(data);
	if (err) msg_error(data,err);
	else lstrcpy(data,"+OK");
	return 3;
}

MircFunc RenameNet(FUNCPARMS)
{
	int err = rename_net(data);
	if (err) msg_error(data,err);
	else lstrcpy(data,"+OK");
	return 3;
}
MircFunc RenameChan(FUNCPARMS)
{
	int err = rename_chan(data);
	if (err) msg_error(data,err);
	else lstrcpy(data,"+OK");
	return 3;
}
MircFunc AddTableItem(FUNCPARMS)
{
	int err;
	if (isin_fpara(data,'b','B')) err = item_table_addB(data,NULL);
	else err = item_table_add(data,0);
	msg_error(data,err);
	return 3;
}
MircFunc DelTableItem(FUNCPARMS)
{  
	msg_error(data,item_table_del(data));
	return 3;
}
MircFunc GetTableItem(FUNCPARMS)
{
	char *tmp = data,*item,*para,ho[BLEN],buf[MLEN],sep = '|';
	ItemNode *itemnode;
	ptable pt;
	unsigned int number,naux,type = 0;
	int err = currenttablefp(&tmp,&pt,&para);
	BOOL isnumber = 0;

	if (err) {
		if (para) delete para;
		msg_error(data,err); return 3; 
	}
	if (pt->litemt) {
		if (para) { 
			lstrcpy(ho,para);
			if (take_para(ho,"G",para)) type = atolp(para);
			if (take_para(ho,"E",para)) {
				naux  = atolp(para);
				if ((naux > 0) && (naux <= 255)) sep = naux;
			}
			if (take_para(ho,"Y",para)) { isnumber = 1 ; number = atolp(para); }
			delete para ; 
		}
		if (isnumber) { 
			getfirstnum(&tmp,number);
			naux = pt->litemt->GetWeight();	
			if (number == 0) { rnum_var(tmp,naux) return 3; }
			if (number > naux) { Unsetvar(tmp); RETOoR  }
			itemnode = pt->litemt->FindNodeNum(number);
		}
		else {
			item = getword(&tmp);
			if (!*item)  RETINVITEM
			itemnode =	pt->litemt->Find(item);
		}
		if (itemnode)  {
			wsprintf(buf,"%s|%lu|%s",itemnode->item,itemnode->property,itemnode->data?itemnode->data:"");
			getnthtok(buf,type,sep);
			r_var(tmp,buf);
		} 
		else { 	Unsetvar(tmp); lstrcpy(data,"-NO Item not found"); }
	}
	else lstrcpy(data,"-List: TableItem List is empty"); 
	return 3;
}
MircFunc CountTableItem (FUNCPARMS) 
{
	char *tmp = data;
	ptable pt;
	int err = currenttable(&tmp,&pt);

	if (err) msg_error(data,err); 
	else  nrnum_var(tmp,pt->litemt?pt->litemt->GetWeight():0)
    return 3;
}
MircFunc DelTable(FUNCPARMS)
{
   char *tmp = data, *table,buf[PLEN],*tmpbuf;
   CurNode x;
   BOOL ms = 0,gw = 0;

	table = getword(&tmp);
	if (table[0] == '-') {
		tmpbuf = creat_para(defpara,table);
		if (take_para(tmpbuf,"D",&buf[0])) {
			x = luse[atolp(buf)];
			if (x.table) { deltablenode(x.table); r_ok(""); }
			else gw = 1;
		}
		if (take_para(tmpbuf,"M",&buf[0])) {
			ms = 1; 
			if (buf[0] != '0') lstrcpy(table,buf);	else gw = 1;
		}
		if (gw) table = getword(&tmp);
		 delete tmpbuf;
	}
	msg_error(data,table_del(table,ms));
	return 3;
}
MircFunc DelArray(FUNCPARMS)
{
   char *tmp = data, *array,buf[PLEN],*tmpbuf;
   CurNode x;
   BOOL ms = 0,gw = 0;

	array = getword(&tmp);
	if (array[0] == '-') {
		tmpbuf = creat_para(defpara,array);
		if (take_para(tmpbuf,"D",&buf[0])) {
			x = luse[atolp(buf)];
			if (x.array) { 	delarraynode(x.array); r_ok(""); }
			else gw = 1;
		}
		if (take_para(tmpbuf,"M",&buf[0])) {
			ms = 1; 
			if (buf[0] != '0') lstrcpy(array,buf);	else gw = 1;
		}
		if (gw) array = getword(&tmp);
		delete tmpbuf;
	}
	msg_error(data,array_del(array,ms));
	return 3;
}

MircFunc CountTable(FUNCPARMS)
{
    unsigned int c = 0;

	if (listtable) c = listtable->m_Count;
	wsprintf(data,"%lu",c);
    return 3;
}
MircFunc CountArray(FUNCPARMS)
{
    unsigned int c = 0;

	if (listarray) c = listarray->m_Count;
	wsprintf(data,"%lu",c);
    return 3;
}
MircFunc SortTable(FUNCPARMS)
{
	if (listtable) {
		if (!listtable->dlsorted()) {
			if (listtable->m_Count > 100) listtable->dlqsort();
			else listtable->dlsort();
		}
		ret("+OK");
	}
	else RETNOLIST
}

MircFunc IsAnyTableItem(FUNCPARMS)
{
  	char *tmp = data;
	ptable pt;
	int err;

	err = currenttable(&tmp,&pt);
	if (err) RETNUL
	else {
		if  (pt->litemt) err = pt->litemt->GetWeight();
		else err = 0;
		RETYN(err);
	}
    return 3;
}
MircFunc ClearTable(FUNCPARMS)
{
	char *tmp = data;
	ptable pt;
	int err;
	err = currenttable(&tmp,&pt);
	if (err) msg_error(data,err);
	else  wsprintf(data, "+OK Nets(%d) Items(%d)", network_cleanup(pt,TRUE),item_table_cleanup(pt));
    return 3;
}
MircFunc ClearArray(FUNCPARMS)
{
	char *tmp = data;
	parray pt;
	int err;
	err = currentarray(&tmp,&pt);
	if (err) msg_error(data,err);
	else {
		err = pt->Lang.size(); 
		INTVECTOR::iterator i;
		for (i = pt->Lang.begin();i != pt->Lang.end();i++) delete (*i);
		pt->Lang.clear();
		if (farray == pt) {	farray = NULL;	lresult.clear();	}
		wsprintf(data, "+OK %d",err);
	}
    return 3;
}
MircFunc ClearTableNet(FUNCPARMS)
{
	char *tmp = data;
	ptable pt;
	int err;
	err = currenttable(&tmp,&pt);
	if (err) msg_error(data,err);
	else  wsprintf(data, "+OK Nets(%d)", network_cleanup(pt,TRUE));
    return 3;
}
MircFunc ClearTableItem(FUNCPARMS)
{
	char *tmp = data;
	ptable pt;
	int err;
	err = currenttable(&tmp,&pt);
	if (err) msg_error(data,err);
	else  wsprintf(data, "+OK Items(%d)", item_table_cleanup(pt));
    return 3;
}
MircFunc DelMatchTable(FUNCPARMS)
{
	char *tmp = data,*table;
	table = getword(&tmp);
    if (!*table)  r_err("PARA","Invalid Table")
	wsprintf(data, "+OK %d",table_del_match(table));
	return 3;
}
MircFunc FindTable(FUNCPARMS)
{
	char *tmp = data , *table,*command,*aux = NULL,buf[MLEN];
	unsigned int tot = 0,maxtable;
	ptable t;
	int store,mod,type;
	DWORD num = 0,mnum = 0;
	char sep = 32;

	table = getword(&tmp);
    if (!*table)  r_err("PARA","Invalid Table")
	get_command(&tmp,&command,type,num,maxtable,FALSE,17,store,mod,sep);

	if ((type == -2) && ((mod == 0) || (mod == 1))) 
		if  ((getfirstnum(command,mnum) < 0 ) && AType) getnumtype(AType,command,mnum);

	if (store) hs.addinit(10,num,table); 
	if (listtable) {
		t = ptable(listtable->dltofirst());
		for (; t; t = ptable(listtable->dlgofwd())) {
		if (((num & t->property)== num)&& (match(table,t->table,FALSE))) {
			++tot;
			if  ((mod == 0) || (mod == 1)) {
				if (type == -2) t->property = mnum;
				else { // aux use separate in two paragraph
					if (type == -1)  aux = eval_exp(command) ;
					else  { 
						wsprintf(buf,"%s %lu",t->table,t->property);
						getnthtok(buf,type);
						aux = eval_exp(command,buf,sep);
					}
					if (aux) {
						getfirstnum(aux,t->property);
						delete aux;
					}
				}
			}
			else
				if (command) { 
					wsprintf(buf,"%s %lu",t->table,t->property);
					Docommand(command,buf,type,sep);
				}  
			if (store) hs.lstore.push_back(t);
		}
		if ((maxtable) && (tot == maxtable)) break;
	}
	}
	if (command) return 1;
	else {
		wsprintf(data, "+OK %d",tot);
		return 3;
	}
} 
MircFunc FindArray(FUNCPARMS)
{
	char *tmp = data , *array,*command,*aux = NULL,buf[MLEN];
	unsigned int tot = 0,maxarray;
	parray t;
	int store,mod,type;
	DWORD num = 0,mnum = 0;
	char sep = 32;

	array = getword(&tmp);
    if (!*array)  r_err("PARA","Invalid Array")
	get_command(&tmp,&command,type,num,maxarray,FALSE,147,store,mod,sep);

	if ((type == -2) && ((mod == 0) || (mod == 1))) 
		getfirstnum(command,mnum);

	if (listarray) {
		t = parray(listarray->dltofirst());
		for (; t; t = parray(listarray->dlgofwd())) {
		if (((num == 0) || (t->property == num))&& (match(array,t->arrayname,FALSE))) {
			++tot;
			if  ((mod == 0) || (mod == 1)) {
				if (type == -2) t->property = mnum;
				else { // aux use separate in two paragraph
					if (type == -1)  aux = eval_exp(command) ;
					else  { 
						wsprintf(buf,"%s %lu",t->arrayname,t->property);
						getnthtok(buf,type);
						aux = eval_exp(command,buf,sep);
					}
					if (aux) {
						getfirstnum(aux,t->property);
						delete aux;
					}
				}
			}
			else
				if (command) { 
					wsprintf(buf,"%s %lu",t->arrayname,t->property);
					Docommand(command,buf,type,sep);
				}  
		}
		if ((maxarray) && (tot == maxarray)) break;
	}
	}
	if (command) return 1;
	else {
		wsprintf(data, "+OK %d",tot);
		return 3;
	}
}
MircFunc IsArray(FUNCPARMS)
{
	char *tmp = data , *array;
	parray t;
	DWORD num = 0;
	BOOL found = FALSE;

	array = getword(&tmp);
    if (!*array)  RETNUL
	getfirstnum(tmp,num);

	if (listarray) {
		t = parray(listarray->dltofirst());
		for (; t; t = parray(listarray->dlgofwd())) 
			if (((num == 0) || (t->property == num)) && (match(array,t->arrayname,FALSE))) {
			found = TRUE; break;
		}
	}
		RETYN(found);
	return 3;
} 
MircFunc IsTable(FUNCPARMS)
{
	char *tmp = data , *table;
	ptable t;
	DWORD num = 0;
	BOOL found = FALSE;

	table = getword(&tmp);
    if (!*table)  RETNUL
	if  ((getfirstnum(tmp,num) == HaveTokenOnly ) && AType) 
		getnumtype(AType,tmp,num);

	if (listtable) {
		t = ptable(listtable->dltofirst());
		for (; t; t = ptable(listtable->dlgofwd())) 
			if (((num & t->property)== num) && (match(table,t->table,FALSE))) {
			found = TRUE; break;
		}
	}
		RETYN(found);
	return 3;
} 
MircFunc ClearAll (FUNCPARMS)
{
    wsprintf(data, "+OK %d",table_cleanup() );
    return 3;
}

MircFunc FindTableItem(FUNCPARMS)
{
	char *tmp = data ,  *item,*command,*aux = NULL,buf[MAXSTRINGLEN];
    ItemNode *itemnode;
    unsigned int  tot = 0,maxitems,err;
	char sep = '|';
	int store,mod,type;
	DWORD num,mnum = 0;
	ptable pt;

	err = currenttable(&tmp,&pt);
	if (err) { msg_error(data,err); return 3; };
	err = get_item_para(&tmp,&item,&command,type,num,maxitems,FALSE,store,mod,sep);
	if (err) { msg_error(data,err); return 3; } ;

	if (store) { hs.additem(11,num,item); hs.table = pt; }
	if ((type == -2) && ((mod == 0) || (mod == 1))) 
		if (getfirstnum(command,mnum) == HaveTokenOnly) {
			SubType *x = type_table_find(pt,nitem);
			if (x) getnumtype(x,command,mnum);
		}

	if (pt->litemt) {
		pt->litemt->ProcessInit();
		for (;;) {
			itemnode = pt->litemt->ProcessNext();
			if (!itemnode)  break;
			if (((num & itemnode->property)== num) && (match(item, itemnode->item, FALSE))) {
				++tot;
				if (store) hs.lstore.push_back(itemnode);
				if (mod >= 0) {
					chfinditem(
     					wsprintf(buf,"%s|%lu|%s",itemnode->item,itemnode->property,itemnode->data?itemnode->data:"")
					);
				}
				else
				if (command)
				{ 
        			wsprintf(buf,"%s|%lu|%s",
					itemnode->item,itemnode->property,itemnode->data?itemnode->data:"");
					DocommandB(command,buf,type,sep);
				} 
				if (maxitems && tot == maxitems) break;
			}   
		}   // for item
	} 
	if (command) return 1;
	else {
		wsprintf(data, "+OK %d", tot);
		return 3;
	}
}
MircFunc IsTableItem(FUNCPARMS)
{
	char *tmp = data , *item;
    ItemNode *itemnode;
	DWORD num = 0;
	ptable pt;
	BOOL found = FALSE;

	int err = currenttable(&tmp,&pt);
	if (err) RETNUL
	item = getword(&tmp);
	if (!*item)  RETNUL
	if (getfirstnum(tmp,num) == HaveTokenOnly) {
		SubType *x = type_table_find(pt,nitem);
		if (x) getnumtype(x,tmp,num);
	} 

	if (pt->litemt) {
		pt->litemt->ProcessInit();
		for (;;) {
			itemnode = pt->litemt->ProcessNext();
			if (!itemnode)  break;
			if (((num & itemnode->property)== num) && (match(item, itemnode->item,FALSE))) {
				found = TRUE; break;
			}   
		}   // for item
	} 
	RETYN(found);
	return 3;
}


MircFunc FindTableItemAll (FUNCPARMS)
{
	char *tmp = data , *item,*table,*command,*aux = NULL,buf[MAXSTRINGLEN];
    ItemNode *itemnode;
    unsigned int  tot = 0,maxitems,err;
	char sep = '|';
	int store,mod,type;
	BOOL change = FALSE;
	DWORD num,mnum = 0;
	ptable pt = NULL;

   	table = getword(&tmp);
    if (!*table)      r_err("PARA","Invalid Table")
	err = get_item_para(&tmp,&item,&command,type,num,maxitems,FALSE,store,mod,sep);
	if (err) { msg_error(data,err); return 3; }

	chgetnum;

	if (store) hs.addinit(11,num,table,NULL,NULL,item);

	if (listtable) pt = ptable(listtable->dltofirst());
    for (; pt; pt = ptable(listtable->dlgofwd())) {
		if ((pt->litemt) && (match(table,pt->table,FALSE))) {
			if (change) {
				SubType *x = type_table_find(pt,nitem);
				if (x) getnumtype(x,command,mnum);
			}  
		pt->litemt->ProcessInit();
		for (;;) {
			itemnode = pt->litemt->ProcessNext();
			if (!itemnode)  break;
			if ( ((num & itemnode->property)== num) && (match(item, itemnode->item, FALSE))) {
				++tot;
				if (store) hs.lstore.push_back(itemnode);
				if (mod >= 0) {
				 chfinditem (
        			wsprintf(buf,"%s|%s|%lu|%s",pt->table,itemnode->item,itemnode->property,itemnode->data?itemnode->data:"")
					 );
				}
				else
				if (command)
				{ 
        			wsprintf(buf,"%s|%s|%lu|%s",pt->table,
					itemnode->item,itemnode->property,itemnode->data?itemnode->data:"");
					DocommandB(command,buf,type,sep);
				} 
				if (maxitems && tot == maxitems) break;
			}   
		}   // for item
		} 
	}  // for table 
	if (command) return 1;
	else {
		wsprintf(data, "+OK %d", tot);
		return 3;
	}
}

MircFunc FindTableItemNum (FUNCPARMS)
{
	char *tmp = data ,*item;
    unsigned int  err,pos = 0;
 	ptable pt;

	err = currenttable(&tmp,&pt);
	if (err) { msg_error(data,err); return 3 ; }
	item = getword(&tmp);
	if (!*item)  r_err("PARA","Invalid item")
	if (pt->litemt)  pos = pt->litemt->FindNum(item);
	
   	if (pos) {
		nrnum_var(tmp,pos);
	}
	else { 	Unsetvar(tmp); lstrcpy(data,"-NO Item not found"); }
	return 3;
}

MircFunc DelMatchTableItem (FUNCPARMS)
{
	char *tmp = data ,*item,*command,buf[MAXSTRINGLEN];
    ItemNode *itemnode;
    unsigned int  tot = 0,maxitems,err;
	int store,mod,type;
	char sep = '|';
	DWORD num;
	ptable pt;
	ListPointer lnick;
	ListPointer::iterator i;

	err = currenttable(&tmp,&pt);
	if (err) { msg_error(data,err); return 3; }
	err = get_item_para(&tmp,&item,&command,type,num,maxitems,TRUE,store,mod,sep);
	if (err) { msg_error(data,err); return 3; }
 
    if (pt->litemt) {
		if (hs.type == 11) {
			if ((hs.table && (hs.table == pt)) || (hs.sttable && match(hs.sttable,pt->table,FALSE))) hs.clear();
		}
  	pt->litemt->ProcessInit();
	for (;;) { 
		itemnode = pt->litemt->ProcessNext();
		if (!itemnode)  break;
		if (((num & itemnode->property)== num) && (match(item, itemnode->item, FALSE))) {
			lnick.push_back(itemnode);
			++tot;
			if (command)
			{  
    			wsprintf(buf,"%s|%lu|%s",
					itemnode->item,itemnode->property,itemnode->data?itemnode->data:"");
				DocommandB(command,buf,type,sep);
			}  
			if (maxitems && tot == maxitems) break;
		}      
	} // for item 
	for ( i = lnick.begin(); i != lnick.end() ; i++)
		pt->litemt->Delete(((ItemNode*)(*i))->item);
	lnick.clear();
	}
	if (command) return 1;
	else {
		wsprintf(data, "+OK %d", tot);
		return 3;
	}
}

int add_table_type(char *data,BOOL overwrite)
{
	char *tmp = data;
	ptable pt;
	DWORD num = 0;

	int err = currenttable(&tmp,&pt);
	if (err) return err;
	if (getfirstnum(&tmp,num) < 0) {
		if ((*tmp) && (AType)) {
			str_to_type(AType->shorttype,tmp,num);
			if ((AType->longtype) && (AType->longtype != AType->shorttype))
				str_to_type(AType->longtype,tmp,num);
		}
		else  return 64;
	}

    if (!overwrite)	pt->property |= num;
	else	pt->property = num;
	return 0;
}

MircFunc SetTableItemType(FUNCPARMS)
{
	msg_error(data,add_table_item_type(data,TRUE));
	return 3;
}
MircFunc AddTableItemType(FUNCPARMS)
{
	msg_error(data,add_table_item_type(data,FALSE));
	return 3;
}
MircFunc UnsetTableItemType(FUNCPARMS)
{
	char *tmp = data , *item,*para,ho[BLEN];
	ptable pt;
	DWORD num = 0;
	TableType *x;
	ItemNode *itemnode;

	int err = currenttablefp(&tmp,&pt,&para);
	if (err) {
		if (para)  delete para;
		RETFERR(err)
	}
	if (para) { lstrcpy(ho,para); delete para; }
	if (!pt->litemt) RETNOLIST
    item = getword(&tmp);
    if (!*item)  RETINVITEM  
	if (getfirstnum(&tmp,num) < 0 ) {
		if (!*tmp)  RETINVT
		x = type_table_find(pt,nitem);
		if (x) getnumtype(x,tmp,num);
		else  RETINVT
	}
	itemnode =	pt->litemt->Find(item);
	if (itemnode) { 
		 itemnode->property ^= (itemnode->property & num) ;
		 if ((itemnode->property == 0) && (find_para(&ho[0],'B'))) {
			 if ((hs.type == 11) && (askdel_table(pt))) delresultnode(item);
			 pt->litemt->Delete(item);
			 lstrcpy(data,"0");
		 }
		 else lstrcpy(data,"1");
	}
	else lstrcpy(data,"-NO Item not Found");

	return 3;
}
MircFunc SetTableType(FUNCPARMS)
{
	msg_error(data,add_table_type(data,TRUE));
	return 3;
}
MircFunc UnsetTableType(FUNCPARMS)
{
	char *tmp = data ,*para,ho[BLEN];
	ptable pt;
	DWORD num = 0;

	int err = currenttablefp(&tmp,&pt,&para);
	if (err) {
		if (para)  delete para; 
		msg_error(data,err); return 3;
	}
	if (para) { lstrcpy(ho,para); delete para; }

	if (getfirstnum(&tmp,num) < 0) {
		if ((*tmp) && (AType)) {
			str_to_type(AType->shorttype,tmp,num);
			if ((AType->longtype) && (AType->longtype != AType->shorttype))
				str_to_type(AType->longtype,tmp,num);
		}
		else  r_err("PARA","Invalid Type")
	}

	pt->property ^= (pt->property & num) ;
	if ((pt->property == 0) && (find_para(&ho[0],'B'))) {
		deltablenode(pt);
		lstrcpy(data,"0");
	}
	else lstrcpy(data,"1");
	return 3;
}
MircFunc AddTableType(FUNCPARMS)
{
	msg_error(data,add_table_type(data,FALSE));
	return 3;
}
MircFunc IsEmptyTable(FUNCPARMS)
{
	char *tmp = data;
	ptable pt;
	int err;

	err = currenttable(&tmp,&pt);
	if (err) RETNUL
	else RETNY((pt->listnet && pt->listnet->m_Count) || (pt->litemt && pt->litemt->GetWeight()))
    return 3;
}
MircFunc IsEmptyArray(FUNCPARMS)
{
	char *tmp = data;
	parray pt;
	int err;

	err = currentarray(&tmp,&pt);
	if (err) RETNUL
	else RETNY(pt->Lang.size()); 
    return 3;
}
MircFunc IsAnyTable(FUNCPARMS)
{
	RETYN(listtable && listtable->m_Count)
    return 3;
}
MircFunc IsAnyArray(FUNCPARMS)
{
	RETYN(listarray && listarray->m_Count)
    return 3;
}
/*-----------------------------------------
                 Network
 *-----------------------------------------
*/
MircFunc AddNet(FUNCPARMS)
{
	BOOL create;
	int err ;
	err = network_add(data,NULL,create);
	if (err) msg_error(data,err);
	else wsprintf(data,"%d",create);
	return 3;
}

MircFunc AddNetItem (FUNCPARMS)
{
	int err;
	if (isin_fpara(data,'b','B')) err = item_net_addB(data,0,0);
	else err = item_net_add(data,0);
	msg_error(data,err);
	return 3;
}


MircFunc DelNet(FUNCPARMS)
{
	msg_error(data,network_del(data));
	 return 3;
}

MircFunc CountNetItem (FUNCPARMS) 
{
	char *tmp = data;
	pnetwork Net;
	int err = currentnet(&tmp,&Net);

	if (err) msg_error(data,err); 
	else {
		if (Net->litemn) err = Net->litemn->GetWeight();
		else err = 0;
		nrnum_var(tmp,err)
	}
    return 3;
}
MircFunc IsAnyNetItem(FUNCPARMS)
{
	char *tmp = data;
	pnetwork Net;
	int err;

	err = currentnet(&tmp,&Net);
	if (err) RETNUL
	else {
		if (Net->litemn) err = Net->litemn->GetWeight();
		else err = 0;
		RETYN(err);
	}
    return 3;
}
MircFunc CountNet(FUNCPARMS)
{
	char *tmp = data;
	ptable pt;
	int err;

	err = currenttable(&tmp,&pt);
	if (err) msg_error(data,err);
	else {
		if (pt->listnet) err = pt->listnet->m_Count;
		nrnum_var(tmp,err);
	}
    return 3;
}

MircFunc IsEmptyNet(FUNCPARMS)
{
	char *tmp = data;
	pnetwork Net;
	int err;

	err = currentnet(&tmp,&Net);
	if (err) RETNUL
	else RETNY((Net->listchan && Net->listchan->m_Count) || (Net->litemn && Net->litemn->GetWeight()))
    return 3;
}
MircFunc IsAnyNet(FUNCPARMS)
{
	char *tmp = data;
	ptable pt;
	int err;

	err = currenttable(&tmp,&pt);
	if (err) RETNUL
	else RETYN(pt->listnet && pt->listnet->m_Count)
    return 3;
}
MircFunc DelMatchNet(FUNCPARMS)
{
	char *tmp = data, *network;
	ptable pt;
	int err;

	err = pathtable(&tmp,&network,&pt);
	if (err) msg_error(data,err);
	else {
		err = network_del_match(pt,network);
		nrnum_var(tmp,err);
	}
	return 3;
}
//clear all channel of a network

MircFunc ClearNet (FUNCPARMS)
{
    char *tmp = data;
	pnetwork Net;
	ptable pt;
	int err;
	err = currentnetf(&tmp,&pt,&Net);
	if (!err) 
	     wsprintf(data, "+OK chans(%d) Items(%d)", channel_cleanup(pt,Net,TRUE),item_net_cleanup(pt,Net));
	else
		msg_error(data,err);
	return 3;
}
MircFunc ClearNetItem (FUNCPARMS)
{
    char *tmp = data;
	pnetwork Net;
	ptable pt;
	int err;
	err = currentnetf(&tmp,&pt,&Net);
	if (!err) 
	     wsprintf(data, "+OK  Items(%d)",item_net_cleanup(pt,Net));
	else
		msg_error(data,err);
	return 3;
}

MircFunc ClearNetChan (FUNCPARMS)
{
    char *tmp = data;
	pnetwork Net;
	ptable pt;
	int err;
	err = currentnetf(&tmp,&pt,&Net);
	if (!err) 
	     wsprintf(data, "+OK chans(%d)", channel_cleanup(pt,Net,TRUE));
	else
		msg_error(data,err);
	return 3;
}
MircFunc FindNetAll(FUNCPARMS)
{
	char *tmp = data , *table , *network, *command,buf[MLEN],*aux = NULL;
	ptable t = NULL;
	pnetwork Net = NULL;
	DWORD num = 0,mnum = 0;
	unsigned int tot = 0 , maxnets;
	int store,mod,type;
	char sep = 32;
	BOOL change = FALSE;
	SubType *x;

	table = getword(&tmp);
    if (!*table)        r_err("PARA","Invalid Table")
 	network = getword(&tmp);
    if (!*network)       r_err("PARA","Invalid Network")
	get_command(&tmp,&command,type,num,maxnets,FALSE,27,store,mod,sep);

	chgetnum;

 	if (store) hs.addinit(20,num,table,network);
	if (listtable) t = ptable(listtable->dltofirst());
    for (; t; t = ptable(listtable->dlgofwd())) {
		if (match(table,t->table,FALSE)) {
			if (change) {
				x = type_table_find(t,sdata);
				if (x) getnumtype(x,command,mnum);
			} 
		if (t->listnet) {
			Net = pnetwork(t->listnet->dltofirst());
			for (;Net;Net = pnetwork(t->listnet->dlgofwd())) {
			 if  (((num & Net->property)== num) && (match(network,Net->network,FALSE))) {
				 ++tot;
				if  ((mod == 0) || (mod == 1)) {
					if (type == -2) Net->property = mnum;
					else {
						if (type == -1)  aux = eval_exp(command) ;
						else  { 
							wsprintf(buf,"%s %s %lu",t->table,Net->network,Net->property);
							getnthtok(buf,type);
							aux = eval_exp(command,buf,sep);
						} 
						if (aux) {
							getfirstnum(aux,Net->property);
							delete aux;
						}
					} 
				} 
				else
					if (command) {
						wsprintf(buf,"%s %s %lu",t->table,Net->network,Net->property);
						Docommand(command,buf,type,sep);
					}    
				if (store) hs.lstore.push_back(Net);
			 } 
		   if ((maxnets) && (tot == maxnets)) goto stop;
		 }
		}
		}  
	}  
	stop : 
	if (command) return 1;
	else {
		wsprintf(data, "+OK %d",tot);
		return 3;
	}
}

MircFunc FindNetPath(FUNCPARMS)
{
	char *tmp = data , *table , *network, *command;
	ptable t = NULL;
	pnetwork Net;
	DWORD num = 0;
	unsigned int tot = 0 , maxnets;
	int store,mod,type;
	char sep = 32;

	table = getword(&tmp);
    if (!*table)          r_err("PARA","Invalid Table")
 	network = getword(&tmp);
    if (!*network)         r_err("PARA","Invalid Network")
	get_command(&tmp,&command,type,num,maxnets,FALSE,27,store,mod,sep);
 
	if (listtable) t = ptable(listtable->dltofirst());
    for (; t; t = ptable(listtable->dlgofwd())) {
		if (match(table,t->table,FALSE)) {
			if (t->listnet) {
				Net = pnetwork(t->listnet->dltofirst());
				for (;Net;Net = pnetwork(t->listnet->dlgofwd()))
				{
				 if  ( ((num & Net->property)== num) && (match(network,Net->network,FALSE))) {
					 ++tot;
					 if (command) sendmsg(command,t->table,sep);
					 if ((maxnets) && (tot == maxnets)) goto End;
				     break;
				 }  
				} // for net
			}
		}  
	}  
End:
	if (command) return 1;
	else  {
		wsprintf(data, "+OK %d",tot);
		return 3;
	}
}

MircFunc FindNet(FUNCPARMS)
{
	char *tmp = data, *network,*command,buf[MLEN],*aux = NULL;
	unsigned int tot = 0 , maxnets;
	DWORD num = 0,mnum = 0;
	ptable pt;
	pnetwork Net = NULL;
	int err,store,mod,type;
	char sep = 32;

	err = pathtable(&tmp,&network,&pt);
	if (err) { msg_error(data,err); return 3; }
	get_command(&tmp,&command,type,num,maxnets,FALSE,27,store,mod,sep);

	if ((type == -2) && ((mod == 1) || (mod == 0))) 
		if (getfirstnum(command,mnum) == HaveTokenOnly) {
			SubType *x = type_table_find(pt,sdata);
	 		if (x) getnumtype(x,command,mnum);
		}

	if (store) { hs.addinit(20,num,NULL,network); hs.table = pt; }
	if (pt->listnet) {
		Net = pnetwork(pt->listnet->dltofirst());
		for (;Net;Net = pnetwork(pt->listnet->dlgofwd())) {
		 if  (((num & Net->property)== num) && (match(network,Net->network,FALSE))) {
			 ++tot;
			 if (store) hs.lstore.push_back(Net);
			 if  ((mod == 0) || (mod == 1)) {
					if (type == -2) Net->property = mnum;
					else {
						if (type == -1)  aux = eval_exp(command) ;
						else  { 
							wsprintf(buf,"%s %lu",Net->network,Net->property);
							getnthtok(buf,type);
							aux = eval_exp(command,buf,sep);
						} 
						if (aux) {
							getfirstnum(aux,Net->property);
							delete aux;
						}
					} 
			 } 
			 else
				if (command) {
					wsprintf(buf,"%s %lu",Net->network,Net->property);
					Docommand(command,buf,type,sep);
				}    
		 } 
	   if ((maxnets) && (tot == maxnets)) break;
	}

	}
	if (command) return 1;
	else {
		wsprintf(data, "+OK %d",tot);
		return 3;
	}
}
MircFunc IsNet(FUNCPARMS)
{
	char *tmp = data, *network;
	DWORD num = 0;
	ptable pt;
	pnetwork Net = NULL;
	int err;
	BOOL found = FALSE;

	err = pathtable(&tmp,&network,&pt);
	if (err) RETNUL

	if (getfirstnum(tmp,num) == HaveTokenOnly) {
			SubType *x = type_table_find(pt,sdata);
	 		if (x) getnumtype(x,tmp,num);
	}
	if (pt->listnet) Net = pnetwork(pt->listnet->dltofirst());
	for (;Net;Net = pnetwork(pt->listnet->dlgofwd()))
		 if  (((num & Net->property)== num) && (match(network,Net->network,FALSE))) {
			 found = TRUE; break;
		 }
	RETYN(found);
	return 3;
}
MircFunc GetTable(FUNCPARMS)
{
	char buf[MLEN],*tmp = data,*aux,*tmpbuf,*var = NULL;
	unsigned int nfind = 0,mfind = 1,type = 0;
	ptable pt = NULL;
	BOOL isnumber = FALSE;
	CurNode x;

	if (listtable) {
	aux =  getword(&tmp);
	if (aux[0] == '-') {
		tmpbuf = creat_para("Y[NUM]VP[NUM]G[NUM]D[NUM]",aux);
		if (take_para(tmpbuf,"P",&buf[0])) type = atolp(buf);
		else if (take_para(tmpbuf,"G",&buf[0])) type = atolp(buf);
		if (find_para(tmpbuf,'V')) var = getword(&tmp);
		if (take_para(tmpbuf,"D",&buf[0])) {
			mfind = atolp(buf);	x = luse[mfind];
			delete tmpbuf;
			if (x.table) { pt = x.table; goto EndGetTable; }
			else { RETFERR(15) }
		}
		if (take_para(tmpbuf,"Y",&buf[0])) { isnumber = TRUE; nfind = atolp(buf); }
		aux =  getword(&tmp);
		delete tmpbuf;
	}
	if (isnumber) { 
		if (*aux) { if (getfirstnum(aux,nfind) < 0) RETINVNth } 
		if (!nfind) { rnum_var(var,listtable->m_Count) return 3; }
		else { 
			if (nfind > listtable->m_Count) RETOoR
			pt = ptable(listtable->dltonum(nfind));
		}
	}
	else {
		if (*aux) pt = f_tablenode(aux);
		else  RETINVITEM
	}
	if (!pt) { lstrcpy(data,"-NO Table not found"); }
	else {
EndGetTable:
		wsprintf(buf,"%s %lu",pt->table,pt->property); 
		getnthtok(buf,type);
		r_var(var,buf);
	}
	return 3;
	} 
	else RETNOLIST
}
MircFunc GetArray(FUNCPARMS)
{
	char buf[MLEN],*tmp = data,*aux,*tmpbuf,*var = NULL;
	ListPointer::iterator i;
	unsigned int nfind = 0,mfind = 1,type = 0;
	parray pt = NULL;
	BOOL isnumber = FALSE;
	CurNode x;

	if (listarray) {
	aux =  getword(&tmp);
	if (aux[0] == '-') {
		tmpbuf = creat_para("Y[NUM]VP[NUM]G[NUM]D[NUM]",aux);
		if (take_para(tmpbuf,"P",&buf[0])) type = atolp(buf);
		else if (take_para(tmpbuf,"G",&buf[0])) type = atolp(buf);
		if (find_para(tmpbuf,'V')) var = getword(&tmp);
		if (take_para(tmpbuf,"D",&buf[0])) {
			mfind = atolp(buf);	x = luse[mfind];
			delete tmpbuf;
			if (x.array) { pt = x.array; goto EndGetArray; }
			else { RETFERR(145) }
		}
		if (take_para(tmpbuf,"Y",&buf[0])) { isnumber = TRUE; nfind = atolp(buf); }
		aux =  getword(&tmp);
		delete tmpbuf;
	}
	if (isnumber) { 
		if (*aux) { if (getfirstnum(aux,nfind) < 0) RETINVNth } 
		if (!nfind) { rnum_var(var,listarray->m_Count) return 3; }
		else { 
			if (nfind > listarray->m_Count) RETOoR
			pt = parray(listarray->dltonum(nfind));
		}
	}
	else {
		if (*aux) pt = f_arraynode(aux);
		else  RETINVITEM
	}
	if (!pt) { lstrcpy(data,"-NO Array not found"); }
	else {
EndGetArray:
		wsprintf(buf,"%s %lu",pt->arrayname,pt->property); 
		getnthtok(buf,type);
		r_var(var,buf);
	}
	return 3;
	} 
	else RETNOLIST
}
MircFunc FindArrayNum(FUNCPARMS)
{
	char *tmp = data, *array;
	unsigned int pos = 0;
	parray pt = NULL;
	hash_t hash;

	array = getword(&tmp);
    if (!*array)  r_err("PARA","Invalid Array")
	hash = rfchash(array);
  
	if (listarray) { 
		pt = parray(listarray->dltofirst());
		for (; pt; pt = parray(listarray->dlgofwd())) {
			 ++pos ;
			 if  ((hash == pt->hash) && (match(array,pt->arrayname,FALSE)))  break;
		}
	}
	 if (pt) {	 nrnum_var(tmp,pos);	 }
	 else {	Unsetvar(tmp); lstrcpy(data,"-NO 0"); }
	 return 3;
}
MircFunc FindTableNum(FUNCPARMS)
{
	char *tmp = data, *table;
	unsigned int pos = 0;
	ptable pt = NULL;
	hash_t hash;

	table = getword(&tmp);
    if (!*table)  r_err("PARA","Invalid Table")
	hash = rfchash(table);
  
	if (listtable) { 
		pt = ptable(listtable->dltofirst());
		for (; pt; pt = ptable(listtable->dlgofwd())) {
			 ++pos ;
			if  ((hash == pt->hash) && (match(table,pt->table,FALSE)))  break;
		}
	}
	 if (pt) {	 nrnum_var(tmp,pos);	 }
	 else {	Unsetvar(tmp); lstrcpy(data,"-NO 0"); }
	 return 3;
}

MircFunc FindNetNum(FUNCPARMS)
{
	char *tmp = data, *network;
	unsigned int pos = 0;
	ptable pt;
	pnetwork Net = NULL;
	int err;
	hash_t hash;

	err = pathtable(&tmp,&network,&pt);
	if (err) { msg_error(data,err); return 3; }
	hash = rfchash(network);
  
	if (pt->listnet) {
		Net = pnetwork(pt->listnet->dltofirst());
		for (;Net;Net = pnetwork(pt->listnet->dlgofwd()))  {	
			 ++pos ;
			if  ((hash == Net->hash) && (match(network,Net->network,FALSE)))  break;
		}
	}

	 if (Net) {	 nrnum_var(tmp,pos);	 }
	 else {	Unsetvar(tmp); lstrcpy(data,"-NO 0"); }
	 return 3;
}
MircFunc FindNetItemAll (FUNCPARMS)
{
	char *tmp = data , *network , *item,*table,*command,buf[MAXSTRINGLEN];
	char *aux = NULL;
    ItemNode *itemnode;
    unsigned int  tot = 0,maxitems,err;
	BOOL change = FALSE;
	int store,mod,type;
	char sep = '|';
	DWORD num,mnum = 0;
	ptable t;
	pnetwork Net;

   	table = getword(&tmp);
    if (!*table)       r_err("PARA","Invalid Table")
	network = getword(&tmp);
    if (!*network)     r_err("PARA","Invalid Network")

	err = get_item_para(&tmp,&item,&command,type,num,maxitems,FALSE,store,mod,sep);
	if (err) { msg_error(data,err); return 3; }

	chgetnum;

	if (store) hs.addinit(21,num,table,network,NULL,item);
	if (listtable) {
		t = ptable(listtable->dltofirst());
		for (; t; t = ptable(listtable->dlgofwd())) {
			if (t->listnet && match(table,t->table,FALSE)) {
				Net = pnetwork(t->listnet->dltofirst());
				for (;Net;Net = pnetwork(t->listnet->dlgofwd()))
		  { 
			 if ((match(network,Net->network,FALSE)) && (Net->litemn)) {
				 if (change) {
					SubType *x = type_net_find(Net,nitem);
					if (!x) x = type_table_find(t,ndata);
					if (x) getnumtype(x,command,mnum);
				 }
				 Net->litemn->ProcessInit();
   for (;;) {
        itemnode = Net->litemn->ProcessNext();
       if (!itemnode)  break;
       if (((num & itemnode->property)== num) && (match(item, itemnode->item, FALSE))) {
            ++tot;
			if (store) hs.lstore.push_back(itemnode);
			if (mod >= 0) {
				chfinditem(
        				wsprintf(buf,"%s|%s|%s|%lu|%s",t->table,Net->network,itemnode->item,itemnode->property,itemnode->data?itemnode->data:"")
					);
			}
			else
			if (command)
			{
        	wsprintf(buf,"%s|%s|%s|%lu|%s",
				t->table,Net->network,itemnode->item,itemnode->property,itemnode->data?itemnode->data:"");
				DocommandB(command,buf,type,sep);
			}
            if (maxitems && tot == maxitems) goto Stopitem;
       } 
    } // for item
			 } 
		  }  // for net
			} 
		}  // for table 
	}
	Stopitem:
	if (command) return 1;
	else {
		wsprintf(data, "+OK %d", tot);
		return 3;
	}
}

MircFunc FindNetItemPath(FUNCPARMS)
{
	char *tmp = data , *table , *network, *command,*item;
	ptable t;
	pnetwork Net;
	DWORD num = 0;
	unsigned int tot = 0 , maxnets,err;
	char sep = '|';
	int store,mod,type;
	ItemNode *itemnode;
	BOOL print = FALSE;

	table = getword(&tmp);
    if (!*table)     r_err("PARA","Invalid Table")
	network = getword(&tmp);
    if (!*network)   r_err("PARA","Invalid Network")
 	err = get_item_para(&tmp,&item,&command,type,num,maxnets,FALSE,store,mod,sep);
	if (err) { msg_error(data,err); return 3; }

	if (listtable) {
		t = ptable(listtable->dltofirst());
		for (; t; t = ptable(listtable->dlgofwd())) {
			if (t->listnet && match(table,t->table,FALSE)) {
				Net = pnetwork(t->listnet->dltofirst());
				for (;Net;Net = pnetwork(t->listnet->dlgofwd()))
				{

				if (Net->litemn) {
					Net->litemn->ProcessInit();
					for (;;) {
						itemnode = Net->litemn->ProcessNext();
						if (!itemnode)  break;
						if (((num & itemnode->property)== num) && (match(item, itemnode->item, FALSE))) {
							++tot;
							if (type == 1) {
								if (command) sendmsg(command,t->table,sep);
								if (maxnets && (maxnets == tot)) goto End;
								goto DoTable;
							}
						    if (command) sendmsg(command,Net->network,sep);
							if (maxnets && (maxnets == tot)) goto End;
							break;
						}  
					} //for net(litemn)
				} 
				} // for net
			}  
		DoTable: ;
		} 
	}
End:
	if (command) return 1;
	else {
		wsprintf(data, "+OK %d",tot);
		return 3;
	}
}

MircFunc DelNetItem(FUNCPARMS)
{  
	msg_error(data,item_net_del(data));
	return 3;
}
MircFunc GetNetItem(FUNCPARMS)
{
	char *tmp = data,*item,*para,buf[MLEN],ho[BLEN],sep = '|';
	ItemNode *itemnode;
	pnetwork Net;
	unsigned int type = 0,naux,number;
	BOOL isnumber = 0;
	int err = currentnetp(&tmp,&Net,&para);
	if (err) { 
		if (para) delete para;
		msg_error(data,err); return 3; 
	}
  	if (Net->litemn) {
		if (para) { 
			lstrcpy(ho,para);
			if (take_para(ho,"G",para)) type = atolp(para);
			if (take_para(ho,"E",para)) {
				naux  = atolp(para);
				if ((naux > 0) && (naux <= 255)) sep = naux;
			}
			if (take_para(ho,"Y",para)) { isnumber = 1 ; number = atolp(para); }
			delete para ; 
		}
		if (isnumber) { 
			getfirstnum(&tmp,number);
			naux = Net->litemn->GetWeight();	
			if (number == 0) { nrnum_var(tmp,naux) return 3; }
			if (number > naux) { Unsetvar(tmp); RETOoR  }
			itemnode = Net->litemn->FindNodeNum(number);
		}
		else {
			item = getword(&tmp);
			if (!*item)  RETINVITEM
			itemnode =	Net->litemn->Find(item);
		}
		if (itemnode) {
			wsprintf(buf,"%s|%lu|%s",itemnode->item,itemnode->property,itemnode->data?itemnode->data:"");
			getnthtok(buf,type,sep);
			r_var(tmp,buf);
		} 
		else { 	Unsetvar(tmp); lstrcpy(data,"-NO Item not found"); }
	}
	else lstrcpy(data,"-List: NetItem List is empty"); 
	return 3;
}
MircFunc GetChan(FUNCPARMS)
{
	char *tmp = data,*item,*para,buf[MLEN],ho[BLEN];
	pnetwork Net;
	pchannel Chan;
	unsigned int type = 0,naux,number;
	BOOL isnumber = 0;
	int err = currentnetp(&tmp,&Net,&para);
	if (err) { 
		if (para) delete para;
		msg_error(data,err); return 3; 
	}
	if (Net->listchan) {
		if (para) { 
			lstrcpy(ho,para);
			if (take_para(ho,"G",para)) type = atolp(para);
			if (take_para(ho,"Y",para)) { isnumber = 1 ; number = atolp(para); }
			delete para ; 
		}
		if (isnumber) { 
			getfirstnum(&tmp,number);
			naux = Net->listchan->m_Count;
			if (number == 0) { nrnum_var(tmp,naux) return 3; }
			if (number > naux) { Unsetvar(tmp); RETOoR  }
			Chan = pchannel(Net->listchan->dltonum(number));
		}
		else {
			item = getword(&tmp);
			if (!*item)  ret("-PARA Invalid Chan Name");
			Chan =  f_channode(item,Net);
		}
		if (Chan) {
			wsprintf(buf,"%s %lu",Chan->channel,Chan->property);
			getnthtok(buf,type);
			r_var(tmp,buf);
		} 
		else { 	Unsetvar(tmp); lstrcpy(data,"-NO Chan not found"); }
	}
	else lstrcpy(data,"-List: Chan List is empty"); 
	return 3;
}
MircFunc FindNetItemNum (FUNCPARMS)
{
	char *tmp = data ,*item;
    unsigned int  err,pos = 0;
 	pnetwork Net;

	err = currentnet(&tmp,&Net);
	if (err) { msg_error(data,err); return 3 ; }
	item = getword(&tmp);
	if (!*item)  r_err("PARA","Invalid item")
	if (Net->litemn) pos = Net->litemn->FindNum(item);
   	if (pos) {
		nrnum_var(tmp,pos);
	}
	else { 	Unsetvar(tmp); lstrcpy(data,"-NO Item not found"); }
	return 3;
}

MircFunc FindNetItem(FUNCPARMS)
{
	char *tmp = data ,  *item,*command,buf[MAXSTRINGLEN];
	char *aux = NULL;
    ItemNode *itemnode;
    unsigned int  tot = 0,maxitems,err;
	char sep = '|';
	int store,mod,type;
	DWORD num,mnum = 0;
	pnetwork Net;
	ptable pt;
	
	err = currentnetf(&tmp,&pt,&Net);
	if (err) { msg_error(data,err); return 3; }
	err = get_item_para(&tmp,&item,&command,type,num,maxitems,FALSE,store,mod,sep);
	if (err) { msg_error(data,err); return 3; }
	if (store) { 
		hs.additem(21,num,item); hs.net = Net;
		hs.table = pt;
	}
    if (Net->litemn) {
		if ((type == -2) && ((mod == 0) || (mod == 1))) 
			if (getfirstnum(command,mnum) == HaveTokenOnly) {
				SubType *x = type_net_find(Net,nitem);
				if (!x) x = type_table_find(pt,ndata);
				if (x) getnumtype(x,command,mnum);
			}
	Net->litemn->ProcessInit();
	for (;;) {
        itemnode = Net->litemn->ProcessNext();
       if (!itemnode)  break;
       if (((num & itemnode->property)== num) && (match(item, itemnode->item, FALSE))) {
            ++tot;
			if (store) hs.lstore.push_back(itemnode);
			if (mod >= 0) {
				chfinditem(
        			wsprintf(buf," %s|%lu|%s",itemnode->item,itemnode->property,itemnode->data?itemnode->data:"")
					);
			}
			else
			if (command)
			{
        	wsprintf(buf," %s|%lu|%s",
				itemnode->item,itemnode->property,itemnode->data?itemnode->data:"");
				DocommandB(command,buf,type,sep);
			}
            if (maxitems && tot == maxitems) break;
       } 
    } // for item
	} 
	if (command) return 1;
	else {
		wsprintf(data, "+OK %d", tot);
		return 3;
	}
}
MircFunc IsNetItem(FUNCPARMS)
{
	char *tmp = data ,  *item;
    ItemNode *itemnode;
    unsigned int  err;
	DWORD num = 0;
	pnetwork Net;
	ptable pt;
	BOOL found = FALSE;
	
	err = currentnetf(&tmp,&pt,&Net);
	if (err) RETNUL
	item = getword(&tmp);
	if (!*item)  RETNUL
	if (getfirstnum(tmp,num) == HaveTokenOnly) {
		SubType *x = type_net_find(Net,nitem);
		if (!x) x = type_table_find(pt,ndata);
		if (x) getnumtype(x,tmp,num);
	}

    if (Net->litemn) {
	Net->litemn->ProcessInit();
	for (;;) {
        itemnode = Net->litemn->ProcessNext();
       if (!itemnode)  break;
       if (((num & itemnode->property)== num) && (match(item, itemnode->item, FALSE))) {
           found = TRUE; break;
       } 
    } // for item
	} 
	RETYN(found);
	return 3;
}


MircFunc DelMatchNetItem (FUNCPARMS)
{
	char *tmp = data ,*item,*command,buf[MAXSTRINGLEN];
    ItemNode *itemnode;
    unsigned int  tot = 0,maxitems,err;
	int store,mod,type;
	char sep = '|';
	DWORD num;
	pnetwork Net;
	ListPointer lnick;
	ListPointer::iterator i;

	err = currentnet(&tmp,&Net);
	if (err) { msg_error(data,err); return 3; }
	err = get_item_para(&tmp,&item,&command,type,num,maxitems,TRUE,store,mod,sep);
	if (err) { msg_error(data,err); return 3; }
 
    if (Net->litemn) {
		if (hs.type == 21) {
			if ((hs.net && (hs.net == Net)) || (hs.stnet && match(hs.stnet,Net->network,FALSE))) hs.clear();
		}
  	Net->litemn->ProcessInit();
	for (;;) { 
		itemnode = Net->litemn->ProcessNext();
		if (!itemnode)  break;
		if (((num & itemnode->property)== num) && (match(item, itemnode->item, FALSE))) {
			lnick.push_back(itemnode);
			++tot;
			if (command)
			{  
    			wsprintf(buf,"%s|%lu|%s",
					itemnode->item,itemnode->property,itemnode->data?itemnode->data:"");
				DocommandB(command,buf,type,sep);
			}  
			if (maxitems && tot == maxitems) break;
		}      
	} // for item 
	for ( i = lnick.begin(); i != lnick.end() ; i++)
		Net->litemn->Delete(((ItemNode*)(*i))->item);
	lnick.clear();
	}
	if (command) return 1;
	else {
		wsprintf(data, "+OK %d", tot);
		return 3;
	}
}

int add_net_type(char *data,BOOL overwrite)
{
	char *tmp = data;
	pnetwork Net;
	ptable pt;
	DWORD num = 0;
	TableType *x;

	int err = currentnetf(&tmp,&pt,&Net);
	if (err) return err;
	if (getfirstnum(&tmp,num) < 0) {
		if (!*tmp) return 64;
		x = type_table_find(pt,sdata);
		if (x) getnumtype(x,tmp,num);
		else  return 64;
	}
	if (!overwrite)	Net->property |= num;
	else	Net->property = num;
	return 0;
}


MircFunc SetNetItemType(FUNCPARMS)
{
	msg_error(data,add_net_item_type(data,TRUE));
	return 3;
}
MircFunc UnsetNetItemType(FUNCPARMS)
{
	char *tmp = data , *item,*para,ho[BLEN];
	ptable pt;
	pnetwork Net;
	DWORD num = 0;
	SubType *x;
	ItemNode *itemnode;

	int err = currentnetfp(&tmp,&pt,&Net,&para);
	if (err) { 
		if (para) delete para;
		RETFERR(err)
	}
	if (para) { lstrcpy(ho,para); delete para; }
	if (!Net->litemn) RETNOLIST
    item = getword(&tmp);
    if (!*item)  RETINVITEM
	if (getfirstnum(&tmp,num) < 0 ) {
		if (!*tmp)  RETINVT
		x = type_net_find(Net,nitem);
		if (!x) x = type_table_find(pt,ndata);
		if (x) getnumtype(x,tmp,num);
		else  RETINVT
	}
	itemnode =	Net->litemn->Find(item);
	if (itemnode) { 
		 itemnode->property ^= (itemnode->property & num) ;
		 if ((itemnode->property == 0) && (find_para(&ho[0],'B'))) {
			 if ((hs.type == 21) && askdel_net(pt,Net)) delresultnode(item);
			 Net->litemn->Delete(item);
			 lstrcpy(data,"0");
		 }
		 else  lstrcpy(data,"1");
	}
	else lstrcpy(data,"-NO Item not Found");
	return 3;
}
MircFunc AddNetItemType(FUNCPARMS)
{
	msg_error(data,add_net_item_type(data,FALSE));
	return 3;
}
MircFunc SetNetType(FUNCPARMS)
{
	msg_error(data,add_net_type(data,TRUE));
	return 3;
}
MircFunc AddNetType(FUNCPARMS)
{
	msg_error(data,add_net_type(data,FALSE));
	return 3;
}
MircFunc UnsetNetType(FUNCPARMS)
{
	char *tmp = data ,*para,ho[BLEN];
	pnetwork Net;
	ptable pt;
	DWORD num = 0;
	TableType *x;

	int err = currentnetfp(&tmp,&pt,&Net,&para);
	if (err) {
		if (para)  delete para; 
		msg_error(data,err); return 3;
	}
	if (para) { lstrcpy(ho,para); delete para; }
	if (getfirstnum(&tmp,num) < 0) {
		if (!*tmp) 	RETINVT
		x = type_table_find(pt,sdata);
		if (x) 
			getnumtype(x,tmp,num);
		else  RETINVT  
			
	}
	Net->property ^= (Net->property & num) ;
	if ((Net->property == 0) && (find_para(&ho[0],'B'))) {
		lstrcpy(data,"0");
		delnetnode(pt,Net);
	}
	else lstrcpy(data,"1");
	return 3;
}
// clear all Network = clear table
/*-----------------------------------------
                 Channel
 *-----------------------------------------
*/

MircFunc AddChan (FUNCPARMS)
{
	BOOL create;
	int err ;
	err = channel_add(data,NULL,NULL,create);
	if (err) msg_error(data,err);
	else wsprintf(data,"%d",create);
	return 3;
}


MircFunc DelChan (FUNCPARMS)
{
   msg_error(data,channel_del(data));
   return 3;
}
MircFunc DelMatchChan (FUNCPARMS)
{
	char *tmp = data,*channel;
	ptable pt;
	pnetwork Net;
	int err;
	err = pathnetf(&tmp,&channel,&pt,&Net);
	if (err) msg_error(data,err);
	else wsprintf(data, "+OK %d", channel_del_match(pt,Net,channel));
	return 3;
}
MircFunc CountChan(FUNCPARMS)
{
    unsigned long c = 0;
	pnetwork Net;
	char *tmp = data;
	int err;

	err = currentnet(&tmp,&Net);
	if (err) msg_error(data,err);
	else {
		if (Net->listchan) c = Net->listchan->m_Count;
		nrnum_var(tmp,c)
	}
    return 3;
}
MircFunc IsEmptyChan(FUNCPARMS)
{
	pchannel Chan;
	char *tmp = data;
	int err;

	err = currentchan(&tmp,&Chan);
	if (err) RETNUL
	else RETNY((Chan->headnick) || (Chan->litemc && Chan->litemc->GetWeight()))
    return 3;
}
MircFunc IsAnyChan(FUNCPARMS)
{
	char *tmp = data;
	pnetwork Net;
	int err;

	err = currentnet(&tmp,&Net);
	if (err) RETNUL
	else RETYN(Net->listchan && Net->listchan->m_Count)
    return 3;
}
// clear all nick of a chan

MircFunc ClearChan (FUNCPARMS)
{
    char *tmp = data;
	pchannel Chan;
	ptable pt;
	pnetwork Net;
	int err;
	err = currentchanf(&tmp,&pt,&Net,&Chan);
	if (err) msg_error(data,err);
	else  wsprintf(data, "+OK Nicks(%d) VNicks(%d) Items(%d)",
		nick_cleanup(pt,Net,Chan),clear_vnick(Chan),item_cleanup(pt,Net,Chan));
    return 3;
}
MircFunc SortChan (FUNCPARMS)
{
    char *tmp = data;
	pnetwork Net;
	int err;
	err = currentnet(&tmp,&Net);
	if (err) msg_error(data,err);
	else {
		if (Net->listchan) {
			if (!Net->listchan->dlsorted()) {
				if (Net->listchan->m_Count > 100) Net->listchan->dlqsort();
				else Net->listchan->dlsort();
			}
			ret("+OK");
		}
		else RETNOLIST
	}
    return 3;
}

MircFunc SortNet (FUNCPARMS)
{
    char *tmp = data;
	ptable pt;
	int err;
	err = currenttable(&tmp,&pt);
	if (err) msg_error(data,err);
	else {
		if (pt->listnet) {
			if (!pt->listnet->dlsorted()) {
				if (pt->listnet->m_Count > 100) pt->listnet->dlqsort();
				else pt->listnet->dlsort();
			}
			ret("+OK");
		}
		else RETNOLIST
	}
    return 3;
}

MircFunc ClearChanNick (FUNCPARMS)
{
    char *tmp = data;
	pchannel Chan;
	ptable pt;
	pnetwork Net;
	int err;
	err = currentchanf(&tmp,&pt,&Net,&Chan);
	if (err) msg_error(data,err);
	else  wsprintf(data, "+OK Nicks(%d)",nick_cleanup(pt,Net,Chan));
    return 3;
}
MircFunc ClearChanVNick (FUNCPARMS)
{
    char *tmp = data;
	pchannel Chan;
	int err = currentchan(&tmp,&Chan);
	if (err) msg_error(data,err);
	else  wsprintf(data, "+OK VNicks(%d)",clear_vnick(Chan));
    return 3;
}
MircFunc ClearChanItem (FUNCPARMS)
{
    char *tmp = data;
	pchannel Chan;
	ptable pt;
	pnetwork Net;
	int err;
	err = currentchanf(&tmp,&pt,&Net,&Chan);
	if (err) msg_error(data,err);
	else  wsprintf(data, "+OK Items(%d)",item_cleanup(pt,Net,Chan));
    return 3;
}
MircFunc FindChanAll (FUNCPARMS)
{
	char *tmp , *network , *channel,*table,*command,buf[MLEN],*aux = NULL;
    unsigned int  tot = 0,maxchan;
	int store,mod,type;
	char sep = 32;
	DWORD num = 0,mnum = 0;
	BOOL change = FALSE;
	ptable t = NULL;
	pnetwork Net = NULL;
	pchannel chan = NULL;
   
	tmp = data;
   	table = getword(&tmp);
    if (!*table)           r_err("PARA","Invalid Table")
 	network = getword(&tmp);
    if (!*network)         r_err("PARA","Invalid Network")
 	channel = getword(&tmp);
    if (!*channel)         r_err("PARA","Invalid Channel")
  
	get_command(&tmp,&command,type,num,maxchan,FALSE,37,store,mod,sep);

	chgetnum;

	if (store) { hs.addinit(30,num,table,network,channel); }
	if (listtable) {
		t = ptable(listtable->dltofirst());
	    for (; t; t = ptable(listtable->dlgofwd())) {
		if (match(table,t->table,FALSE)) {
			if (t->listnet) {
				Net = pnetwork(t->listnet->dltofirst());
				for (;Net;Net = pnetwork(t->listnet->dlgofwd()))
		  { 
			 if (match(network,Net->network,FALSE)) {
				 if (change) {
					SubType *x = type_net_find(Net,sdata);
					if (!x)  x = type_table_find2(t,sdata);
	 				if (x) getnumtype(x,command,mnum);
				 }
				 if (Net->listchan) chan = pchannel(Net->listchan->dltofirst());
				 for (;chan; chan = pchannel(Net->listchan->dlgofwd())) {
					 if (((num & chan->property)== num) && (match(channel,chan->channel,FALSE))) {
						++tot;
						if (store) hs.lstore.push_back(chan);
						 if  ((mod == 0) || (mod == 1)) {
							if (type == -2) chan->property = mnum;
							else { 
								if (type == -1)  aux = eval_exp(command) ;
								else  { 
									wsprintf(buf,"%s %s %s %lu",t->table,Net->network,chan->channel,chan->property);
									getnthtok(buf,type);
									aux = eval_exp(command,buf,sep);
								}  
								if (aux) {
									getfirstnum(aux,chan->property);
									delete aux;
								}
							}  
						 }  
						 else 
							if (command) {
								wsprintf(buf,"%s %s %s %lu",t->table,Net->network,chan->channel,chan->property);
								Docommand(command,buf,type,sep);
							} 
					 } 
					 if (maxchan && (maxchan == tot)) goto StopChan;
					
				 }
			 } 
		  }  
			}
		}
	}  
	}
	StopChan:
	if (command) return 1;
	else {
		wsprintf(data, "+OK %d", tot);
		return 3;
	}
}


MircFunc FindChanPath (FUNCPARMS)
{
	char *tmp , *network , *channel,*table,*command;
    unsigned int  tot = 0,maxchan;
	int store,mod,type;
	char sep = 32;
	DWORD num = 0;
	ptable t;
	pnetwork Net;
	pchannel chan;
   
	tmp = data;
   	table = getword(&tmp);
    if (!*table)         r_err("PARA","Invalid Table")
	network = getword(&tmp);
    if (!*network)       r_err("PARA","Invalid Network")
 	channel = getword(&tmp);
    if (!*channel)       r_err("PARA","Invalid Channel")
	get_command(&tmp,&command,type,num,maxchan,FALSE,37,store,mod,sep);

	if (listtable) {
 		t = ptable(listtable->dltofirst());
		for (; t; t = ptable(listtable->dlgofwd())) {

		if (t->listnet && match(table,t->table,FALSE)) {
		Net = pnetwork(t->listnet->dltofirst());
		for (;Net;Net = pnetwork(t->listnet->dlgofwd()))
		  {  
			 if (match(network,Net->network,FALSE)) {
				 chan = pchannel(Net->listchan->dltofirst());
				 for (;chan; chan = pchannel(Net->listchan->dlgofwd())) {
					 if (((num & chan->property)== num) && (match(channel,chan->channel,FALSE))) {
						 ++tot;
						 if (type == 1) {
							 if (command) sendmsg(command,t->table,sep);
							 if (maxchan && (maxchan == tot)) goto End;
							 goto DoTable;
						 }
						 if (command) sendmsg(command,Net->network,sep);
						 if (maxchan && (maxchan == tot)) goto End;
						 break;
					 }
				 } // for chan
			 } 
		  }  // for net
		} 
	 	 DoTable:;
	}  // for table
	}
End:
	if (command) return 1;
	else {
		wsprintf(data, "+OK %d", tot);
		return 3;
	}
}

MircFunc FindChan(FUNCPARMS)
{
	char *tmp = data ,*channel,*command,buf[MLEN],*aux = NULL;
    unsigned int  tot = 0,maxchan,err;
	int store,mod,type;
	char sep = 32;
	DWORD num = 0,mnum =0;
	pnetwork Net;
	pchannel chan;
	ptable pt;
   
	err = pathnetf(&tmp,&channel,&pt,&Net);
	if (err) { msg_error(data,err); return 3; }

	get_command(&tmp,&command,type,num,maxchan,FALSE,37,store,mod,sep);
	if (store) { 
		hs.addinit(30,num,NULL,NULL,channel); hs.net = Net; 
		hs.table = pt;
	}
	if ((type == -2) && ((mod == 1) || (mod == 0))) 
		if (getfirstnum(command,mnum) == HaveTokenOnly) {
			SubType *x = type_net_find(Net,sdata);
			if (!x)  x = type_table_find2(pt,sdata);
	 		if (x) getnumtype(x,command,mnum);
		}
	if (Net->listchan) {
		 chan = pchannel(Net->listchan->dltofirst());
		for (;chan; chan = pchannel(Net->listchan->dlgofwd())) 
		 {
		 if (((num & chan->property)== num) && (match(channel,chan->channel,FALSE))) {
			 ++tot;
			 if (store) hs.lstore.push_back(chan);
			 if  ((mod == 0) || (mod == 1)) {
				if (type == -2) chan->property = mnum;
				else { 
					if (type == -1)  aux = eval_exp(command) ;
					else  { 
						wsprintf(buf,"%s %lu",chan->channel,chan->property);
						getnthtok(buf,type);
						aux = eval_exp(command,buf,sep);
					}  
					if (aux) {
						getfirstnum(aux,chan->property);
						delete aux;
					}
				}  
			 }  
			 else 
				 if (command) {
					wsprintf(buf,"%s %lu",chan->channel,chan->property);
					Docommand(command,buf,type,sep);
				 } 
			 } 
			 if (maxchan && (maxchan == tot)) break;
	 }

	}
	if (command) return 1;
	else {
		wsprintf(data, "+OK %d", tot);
		return 3;
	}
}
MircFunc IsChan(FUNCPARMS)
{
	char *tmp = data ,*channel;
    unsigned int  err;
	DWORD num = 0;
	pnetwork Net;
	pchannel chan;
	ptable pt;
	BOOL found = FALSE;
   
	err = pathnetf(&tmp,&channel,&pt,&Net);
	if (err) RETNUL

	if (getfirstnum(tmp,num) == HaveTokenOnly) {
		SubType *x = type_net_find(Net,sdata);
		if (!x)  x = type_table_find2(pt,sdata);
	 	if (x) getnumtype(x,tmp,num);
	}
	if (Net->listchan) {
		chan = pchannel(Net->listchan->dltofirst());
		for (;chan; chan = pchannel(Net->listchan->dlgofwd())) 
			if (((num & chan->property)== num) && (match(channel,chan->channel,FALSE))) {
				 found = TRUE; break;
			} 
	}
	RETYN(found);
	return 3;
}

MircFunc FindChanNum (FUNCPARMS)
{
	char *tmp = data,*channel;
    unsigned int  pos = 0,err;
	pnetwork Net;
	pchannel chan;
   
	err = pathnet(&tmp,&channel,&Net);
	if (err) { msg_error(data,err); return 3; }

	if (Net->listchan) {
		chan = pchannel(Net->listchan->dltofirst());
		for (;chan; chan = pchannel(Net->listchan->dlgofwd())) {
			 ++pos;
			if (match(channel,chan->channel,FALSE)) break;
		}
	}
	 if (chan) nrnum_var(tmp,pos)
	 else { Unsetvar(tmp); lstrcpy(data,"-NO 0"); }
	 return 3;
}

MircFunc DelMatchChanItem (FUNCPARMS)
{
	char *tmp = data ,*item, *command,buf[MAXSTRINGLEN];
    unsigned int  tot, maxnicks,err;
	int store,mod,type;
	char sep = '|';
	DWORD num;
    ItemNode *itemnode;
 	pchannel Chan;
	ListPointer lnick;
	ListPointer::iterator i;

	err = currentchan(&tmp,&Chan);
	if (err) { msg_error(data,err); return 3 ; }
	err = get_item_para(&tmp,&item,&command,type,num,maxnicks,TRUE,store,mod,sep);
	if (err) { msg_error(data,err); return 3; }

    tot = 0;
	if (Chan->litemc) {
		if (hs.type == 31) {
			if ((hs.chan && (hs.chan == Chan)) || (hs.stchan && match(hs.stchan,Chan->channel,FALSE))) hs.clear();
		}
	Chan->litemc->ProcessInit();
    for (;;) {
        itemnode = Chan->litemc->ProcessNext();
       if (!itemnode)  break;
       if ( ((num & itemnode->property)== num) && (match(item, itemnode->item, FALSE))) {
            ++tot;
			lnick.push_back(itemnode);
			if (command)
			{
        	wsprintf(buf,"%s|%lu|%s",
				itemnode->item,itemnode->property,itemnode->data?itemnode->data:"");
				DocommandB(command,buf,type,sep);
			}
            if (maxnicks && tot == maxnicks) break;
       } 
    } //for nick 
	for ( i = lnick.begin(); i != lnick.end() ; i++)
		Chan->litemc->Delete(((ItemNode*)(*i))->item);
	lnick.clear();
	}
   	if (command) return 1;
	else {
		wsprintf(data, "+OK %d", tot);
		return 3;
	}
}

MircFunc FindChanItem (FUNCPARMS)
{
	char *tmp = data ,*item, *command,buf[MAXSTRINGLEN],*aux = NULL;
    unsigned int  tot, maxnicks,err;
	char sep = '|';
	int store,mod,type;
    ItemNode *itemnode;
	DWORD num,mnum = 0;
	pchannel Chan;
	ptable pt;
	pnetwork Net;

	err = currentchanf(&tmp,&pt,&Net,&Chan);
	if (err) { msg_error(data,err); return 3 ; }
	err = get_item_para(&tmp,&item,&command,type,num,maxnicks,FALSE,store,mod,sep);
	if (err) { msg_error(data,err); return 3 ; }

    tot = 0;
	if (store) { 
		hs.additem(31,num,item); hs.chan = Chan;
		hs.table = pt; hs.net = Net;
	}
	if (Chan->litemc) {
		if ((type == -2) && ((mod == 1) || (mod == 0))) 
			if (getfirstnum(command,mnum) == HaveTokenOnly) {
				SubType *x = type_chan_find(Chan,nitem);
				if (!x)  x = type_net_find(Net,ndata);
				if (!x)  x = type_table_find2(pt,ndata);
	 			if (x) getnumtype(x,command,mnum);
			}

	Chan->litemc->ProcessInit();
    for (;;) {
        itemnode = Chan->litemc->ProcessNext();
       if (!itemnode)  break;
       if (((num & itemnode->property)== num) && (match(item, itemnode->item, FALSE))) {
            ++tot;
			if (store) hs.lstore.push_back(itemnode);
			if (mod >= 0) {
				chfinditem(
        			wsprintf(buf," %s|%lu|%s",itemnode->item,itemnode->property,itemnode->data?itemnode->data:"")
					);
			}
			else
			if (command)
			{
        	wsprintf(buf,"%s|%lu|%s",
				itemnode->item,itemnode->property,itemnode->data?itemnode->data:"");
				DocommandB(command,buf,type,sep);
			}
            if (maxnicks && tot == maxnicks) break;
       } 
    } //for nick 
	}
   	if (command) return 1;
	else {
		wsprintf(data, "+OK %d", tot);
		return 3;
	}
}
MircFunc IsChanItem (FUNCPARMS)
{
	char *tmp = data ,*item;
    unsigned int  err;
    ItemNode *itemnode;
	DWORD num = 0 ;
	pchannel Chan;
	ptable pt;
	pnetwork Net;
	BOOL found = FALSE;

	err = currentchanf(&tmp,&pt,&Net,&Chan);
	if (err) RETNUL
	item = getword(&tmp);
	if (!*item)  RETNUL
	if (Chan->litemc) {
		if (getfirstnum(tmp,num) == HaveTokenOnly) {
			SubType *x = type_chan_find(Chan,nitem);
			if (!x)  x = type_net_find(Net,ndata);
			if (!x)  x = type_table_find2(pt,ndata);
	 		if (x) getnumtype(x,tmp,num);
		}  
		Chan->litemc->ProcessInit();
		for (;;) {
			itemnode = Chan->litemc->ProcessNext();
			if (!itemnode)  break;
			if (((num & itemnode->property)== num) && (match(item, itemnode->item, FALSE))) {
				found = TRUE; break;
			} 
			
		} //for chan 
	}
	RETYN(found)
	return 3;
}
MircFunc FindChanItemPath (FUNCPARMS)
{
	char *tmp = data, *network , *channel,*table,*command,*item;
    unsigned int  tot = 0,maxchan,err;
	char sep = '|';
	int store,mod,type;
	ItemNode *itemnode;
	DWORD num = 0;
	ptable t;
	pnetwork Net;
	pchannel chan;
   
   	table = getword(&tmp);
    if (!*table)        r_err("PARA","Invalid Table")
	network = getword(&tmp);
    if (!*network)      r_err("PARA","Invalid Network")
	channel = getword(&tmp);
    if (!*channel)      r_err("PARA","Invalid Channel")
	err = get_item_para(&tmp,&item,&command,type,num,maxchan,FALSE,store,mod,sep);
	if (err) { msg_error(data,err); return 3 ; }

	if (listtable) {
		t = ptable(listtable->dltofirst());
		for (; t; t = ptable(listtable->dlgofwd())) {	
		if (t->listnet && match(table,t->table,FALSE)) {
			Net = pnetwork(t->listnet->dltofirst());
			for (;Net;Net = pnetwork(t->listnet->dlgofwd()))  {
				if (Net->listchan && match(network,Net->network,FALSE)) {
					chan = pchannel(Net->listchan->dltofirst());
					for (;chan; chan = pchannel(Net->listchan->dlgofwd())) {
if ((match(channel,chan->channel, FALSE)) && (chan->litemc)) {
 chan->litemc->ProcessInit();
 for (;;) {
    itemnode = chan->litemc->ProcessNext();
    if (!itemnode)  break;
    if (((num & itemnode->property)== num) && (match(item, itemnode->item, FALSE))) {
	   ++tot;
	   if (type == 1) {
		   if (command) sendmsg(command,t->table,sep);
		   if (maxchan && (maxchan == tot)) goto End;
		   goto DoTable;
	   }
	   if (type == 2) {
		   if (command) sendmsg(command,Net->network,sep);
		   if (maxchan && (maxchan == tot)) goto End;
		   goto DoNet;
	   }
	   if (command) sendmsg(command,chan->channel,sep);
	   if (maxchan && (maxchan == tot)) goto End;
	   break;

	} 
 } //for chan(litemc)
}

				 } // for chan
					DoNet:;
			 } 
		  }  // for net
			DoTable:;
		}
	}  // for table

	}
End:
	if (command) return 1;
	else {
		wsprintf(data, "+OK %d", tot);
		return 3;
	}
}
MircFunc FindChanItemAll (FUNCPARMS)
{
	char *tmp = data,*table,*network , *channel, *item,*command,buf[MLEN];
	char *aux = NULL;
    unsigned int  tot, maxchan,err;
    ItemNode *itemnode;
	int store,mod,type;
    char sep = '|';
    pnetwork Net;
	pchannel chan;
	ptable t;
	DWORD num = 0,mnum = 0;
	BOOL change = FALSE;

   	table = getword(&tmp);
    if (!*table)		  r_err("PARA","Invalid Table")
	network = getword(&tmp);
    if (!*network)		  r_err("PARA","Invalid Network")
	channel = getword(&tmp);
    if (!*channel)        r_err("PARA","Invalid Channel")
	err = get_item_para(&tmp,&item,&command,type,num,maxchan,FALSE,store,mod,sep);
	if (err) { msg_error(data,err); return 3 ; }

    tot = 0;
	if (store) hs.addinit(31,num,table,network,channel,item);
	
	chgetnum;

	if (listtable) {
		t = ptable(listtable->dltofirst());
		for (; t; t = ptable(listtable->dlgofwd())) {
		if (t->listnet && match(table,t->table,FALSE)) {
		Net = pnetwork(t->listnet->dltofirst());
		for (;Net;Net = pnetwork(t->listnet->dlgofwd()))
		  {  
			  if (Net ->listchan && match(network,Net->network,FALSE)) {
				 chan = pchannel(Net->listchan->dltofirst());
				 for (;chan; chan = pchannel(Net->listchan->dlgofwd())) {
if ((match(channel,chan->channel, FALSE)) && (chan->litemc)) {
 if (change) {
	SubType *x = type_chan_find(chan,nitem);
	if (!x)  x = type_net_find(Net,ndata);
	if (!x)  x = type_table_find2(t,ndata);
 	if (x) getnumtype(x,command,mnum);
 }
 chan->litemc->ProcessInit();
 for (;;) {
    itemnode = chan->litemc->ProcessNext();
    if (!itemnode)  break;
    if (((num & itemnode->property)== num) && (match(item, itemnode->item, FALSE))) {
	   ++tot;
			if (store) hs.lstore.push_back(itemnode);
			if (mod >= 0) {
				chfinditem(
        	wsprintf(buf,"%s|%s|%s|%s|%lu|%s",
				t->table,Net->network,chan->channel,
				itemnode->item,itemnode->property,itemnode->data?itemnode->data:"")
					);
			}
			else
			if (command) 
			{
        	wsprintf(buf,"%s|%s|%s|%s|%lu|%s",
				t->table,Net->network,chan->channel,
				itemnode->item,itemnode->property,itemnode->data?itemnode->data:"");
				DocommandB(command,buf,type,sep);
			}
            if (maxchan && tot == maxchan) goto stopm;            			
	}  
 } //for item 

}  
				 } //for channel
			 } //if net
		  } //for network 
		}
 	} //for table
	}
stopm:
	if (command) return 1;
	else  {
		wsprintf(data, "+OK %d", tot);
		return 3;
	}
} 
MircFunc FindChanItemNum (FUNCPARMS)
{
	char *tmp = data ,*item;
    unsigned int  err,pos = 0;
 	pchannel Chan;

	err = currentchan(&tmp,&Chan);
	if (err) { msg_error(data,err); return 3 ; }
	item = getword(&tmp);
	if (!*item)  r_err("PARA","Invalid item")
	if (Chan->litemc)  pos = Chan->litemc->FindNum(item);
	if (pos) rnum_var(tmp,pos)
	else { 	Unsetvar(tmp); lstrcpy(data,"-NO Item not found"); }
	return 3;
}
int add_chan_item_type(char *data,BOOL overwrite)
{
	char *tmp = data , *item;
	pchannel Chan;
	DWORD num = 0;
	SubType *x;
	ItemNode *itemnode;
	ptable pt;
	pnetwork net;

	int err = currentchanf(&tmp,&pt,&net,&Chan);
	if (err) return err;
    item = getword(&tmp);
    if (!*item)  return 134;  // r_err("PARA", "Invalid item") 
	if (getfirstnum(&tmp,num) < 0) {
		if (!*tmp) return 64;
		x = type_chan_find(Chan,nitem);
		if (!x)  x = type_net_find(net,ndata);
		if (!x)  x = type_table_find2(pt,ndata);
		if (x) getnumtype(x,tmp,num);
		else  return 64;
	}

	if (!Chan->litemc) {
		Chan->litemc =  new ItemClass();
		Chan->litemc->Add(item,"",num);
	}
	else { 
		itemnode =	Chan->litemc->Find(item);
		if (itemnode) { 
			if (overwrite) itemnode->property = num;
			else itemnode->property |= num ; 
		}
		else 	Chan->litemc->Add(item,"",num);
	}
	return 0;
}

int add_chan_type(char *data,BOOL overwrite)
{
	char *tmp = data;
	pchannel Chan;
	pnetwork Net;
	ptable pt;
	DWORD num = 0;
	SubType *x;

	int err = currentchanf(&tmp,&pt,&Net,&Chan);
	if (err) return err;

	if (getfirstnum(&tmp,num) < 0) {
		if (!*tmp) return 64;
		x = type_net_find(Net,sdata);
		if (!x)  x = type_table_find2(pt,sdata);
		if (x) getnumtype(x,tmp,num);
		else  return 64;
	}
	if (!overwrite)	Chan->property |= num;
	else	Chan->property = num;
	return 0;
}

MircFunc SetChanItemType(FUNCPARMS)
{
	msg_error(data,add_chan_item_type(data,TRUE));
	return 3;
}
MircFunc AddChanItemType(FUNCPARMS)
{
	msg_error(data,add_chan_item_type(data,FALSE));
	return 3;
}
MircFunc UnsetChanItemType(FUNCPARMS)
{
	char *tmp = data , *item,*para,ho[BLEN];
	pchannel Chan;
	DWORD num = 0;
	SubType *x;
	ItemNode *itemnode;
	ptable pt;
	pnetwork net;

	int err = currentchanfp(&tmp,&pt,&net,&Chan,&para);
	if (err) {
		if (para)  delete para; 
		msg_error(data,err); return 3;
	}
	if (para) { lstrcpy(ho,para); delete para; }
	if (!Chan->litemc)  RETNOLIST 
    item = getword(&tmp);
    if (!*item)  RETINVITEM
	if (getfirstnum(&tmp,num) < 0) {
		if (!*tmp) RETINVT 
		x = type_chan_find(Chan,nitem);
		if (!x)  x = type_net_find(net,ndata);
		if (!x)  x = type_table_find2(pt,ndata);
		if (x) getnumtype(x,tmp,num);
		else  RETINVT 
	}

	itemnode =	Chan->litemc->Find(item);
	if (itemnode) { 
		 itemnode->property ^= (itemnode->property & num) ;
		 if ((itemnode->property == 0) && (find_para(&ho[0],'B'))) {
			 if ((hs.type == 31) && askdel_chan(pt,net,Chan)) delresultnode(item);
			 Chan->litemc->Delete(item);
			 lstrcpy(data,"0");
		 }
		 else lstrcpy(data,"1");
	}
	else lstrcpy(data,"-NO Item Not Found");
	return 3;
}
MircFunc SetChanType(FUNCPARMS)
{
	msg_error(data,add_chan_type(data,TRUE));
	return 3;
}
MircFunc UnsetChanType(FUNCPARMS)
{
	char *tmp = data ,*para,ho[BLEN];
	pchannel Chan;
	pnetwork Net;
	ptable pt;
	DWORD num = 0;
	SubType *x;

	int err = currentchanfp(&tmp,&pt,&Net,&Chan,&para);
	if (err) {
		if (para)  delete para; 
		msg_error(data,err); return 3;
	}
	if (para) { lstrcpy(ho,para); delete para; }
	if (getfirstnum(&tmp,num) < 0) {
		if (!*tmp) RETINVT
		x = type_net_find(Net,sdata);
		if (!x)  x = type_table_find2(pt,sdata);
		if (x) getnumtype(x,tmp,num);
		else  RETINVT
	}
	Chan->property ^= (Chan->property & num) ;
	if ((Chan->property == 0) && (find_para(&ho[0],'B'))) {
		lstrcpy(data,"0");
		delchannode(pt,Net,Chan);
	}
    else lstrcpy(data,"1");
	return 3;
}
MircFunc AddChanType(FUNCPARMS)
{
	msg_error(data,add_chan_type(data,FALSE));
	return 3;
}

MircFunc AddChanItem(FUNCPARMS)
{
	int err;
	if (isin_fpara(data,'b','B')) err = item_channel_addB(data,0,0,0);
	else err = item_channel_add(data,0);
	msg_error(data,err);
	return 3;
}


MircFunc DelChanItem(FUNCPARMS)
{  
	msg_error(data,item_channel_del(data));
	return 3;
}

MircFunc GetChanItem(FUNCPARMS)
{
	char *tmp = data,*item,buf[MAXSTRINGLEN],*para,ho[BLEN],sep = '|';
	ItemNode *itemnode;
	pchannel Chan;
	unsigned int type = 0,naux = 0,number;
	int err = currentchanp(&tmp,&Chan,&para);
	BOOL isnumber = FALSE;

	if (err) { 
		if (para)  delete para ;
		msg_error(data,err); return 3; 
	}
	if (Chan->litemc) {
		if (para) { 
			lstrcpy(ho,para);
			if (take_para(ho,"G",para)) type = atolp(para);
			if (take_para(ho,"E",para)) {
				naux  = atolp(para);
				if ((naux > 0) && (naux <= 255)) sep = naux;
			}
			if (take_para(ho,"Y",para)) { isnumber = 1 ; number = atolp(para); }
			delete para ; 
		}
		if (isnumber) { 
			getfirstnum(&tmp,number);
			naux = Chan->litemc->GetWeight();	
			if (number == 0) { rnum_var(tmp,naux) return 3; }
			if (number > naux) { Unsetvar(tmp); RETOoR }
			itemnode = Chan->litemc->FindNodeNum(number);
		}
		else {
			item = getword(&tmp);
			if (!*item)  RETINVITEM
			itemnode =	Chan->litemc->Find(item);
		}
		if (itemnode) { 
			wsprintf(buf,"%s|%lu|%s",itemnode->item,itemnode->property,itemnode->data?itemnode->data:"");
			getnthtok(buf,type,sep);
			r_var(tmp,buf);
		} 
		else { 	Unsetvar(tmp); lstrcpy(data,"-NO Item not found"); }
	}
	else lstrcpy(data,"-List: ChanItem List is empty"); 
	return 3;
}
MircFunc IsAnyChanItem(FUNCPARMS)
{
	char *tmp = data;
	pchannel Chan;
	int err;

	err = currentchan(&tmp,&Chan);
	if (err) RETNUL
	else {
		if  (Chan->litemc) err = Chan->litemc->GetWeight();
		else err = 0;
		RETYN(err);
	}
    return 3;
}
/*-----------------------------------------
                 Nick
 *-----------------------------------------
*/

//Add Network Nick


MircFunc AddNick(FUNCPARMS)
{  
	char *tmp = data,*para;
	pchannel Chan;
	int err,k = 1;

	err = currentchanp(&tmp,&Chan,&para);
	if (err) { 
		if (para)  delete para ;
		msg_error(data,err); return 3;
	} 
	if (para) { 
		if (find_para(para,'B')) k = 0;
		delete para ; 
	}
	if (k) 	msg_error(data,nick_add(tmp,Chan));
	else msg_error(data,nick_addB(tmp,Chan));

	return 3;
}

MircFunc DelNick(FUNCPARMS)
{  
	msg_error(data,nick_del(data));
	return 3;
}

// add nick type : table network channel nickname type string


MircFunc SetNickValue(FUNCPARMS)
{  
 	msg_error(data,nick_add_value(data));
	return 3;
}


MircFunc GetNick(FUNCPARMS)
{
	char *tmp = data,*nick,*para,ho[BLEN],buf[MLEN],sep = '|';
	NickNode *node;
	pchannel Chan;
	unsigned int type = 0,naux,number;
	BOOL isnumber = 0;

	int err = currentchanp(&tmp,&Chan,&para);
	if (err) {
		if (para) delete para;
		msg_error(data,err); return 3;
	}
	if (Chan->headnick) {
		if (para) { 
			lstrcpy(ho,para);
			if (take_para(ho,"G",para)) type = atolp(para);
			if (take_para(ho,"E",para)) {
				naux  = atolp(para);
				if ((naux > 0) && (naux <= 255)) sep = naux;
			}
			if (take_para(ho,"Y",para)) { isnumber = 1 ; number = atolp(para); }
			delete para ; 
		}
		if (isnumber) { 
			getfirstnum(&tmp,number);
			naux = Chan->headnick->GetWeight();
			if (number == 0) { rnum_var(tmp,naux) return 3; }
			if (number > naux) { Unsetvar(tmp); RETOoR  }
			node = Chan->headnick->FindNickNum(number);
		}
		else {
			nick = getword(&tmp);
			if (!*nick)  r_err("PARA", "Invalid nick name")
			node = Chan->headnick->Find(nick);
		}
       if (node) {
			wsprintf(buf, "%s|%s|%s|%d|%lu|%s", node->nick, node->addy,  node->data?node->data:"$NULL", node->num, node->nicktype , node->msg?node->msg:"");
			getnthtok(buf,type,sep);
			r_var(tmp,buf);
	    } 
	   else { 
	 	Unsetvar(tmp);
		lstrcpy(data,"-No nick not found");
		}
	}
	else lstrcpy(data,"-List: NickList is empty");
    return 3;
}

MircFunc CountNick (FUNCPARMS) 
{
	char *tmp = data;
	pchannel Chan;
	int err = currentchan(&tmp,&Chan);

	if (err) msg_error(data,err); 
	else {   
		if (Chan->headnick) err = Chan->headnick->GetWeight();
		else err = 0;
		nrnum_var(tmp,err);
	}
    return 3;
}
MircFunc IsAnyNick(FUNCPARMS)
{
	char *tmp = data;
	pchannel Chan;
	int err;

	err = currentchan(&tmp,&Chan);
	if (err) RETNUL
	else {
		if  (Chan->headnick) err = Chan->headnick->GetWeight();
		else err = 0;
		RETYN(err)
	}
    return 3;
}
MircFunc CountChanItem (FUNCPARMS) 
{
	char *tmp = data;
	pchannel Chan;
	int err = currentchan(&tmp,&Chan);

	if (err) 
		msg_error(data,err); 
	else 
		nrnum_var(tmp,Chan->litemc?Chan->litemc->GetWeight():0)
    return 3;
}

/*
 * MatchAllNickNet <table> <network> <channel> <*nick*|*> <*uhost*|*>  <nicktype> <maxnicks> <command to fill>
 */
inline int getpara(char **tmp,char **table,char **network,char **channel,char **nick,char **addy,DWORD& nicktype,unsigned int & maxnicks,char **command,int &type,BOOL del,int &more,int &mod,char &sep)
{
    *table = getword(tmp);
	if (!**table) return 11;
   	*network = getword(tmp);
	if (!**network)	return 21;
	*channel = getword(tmp);
    if (!**channel)  return 31;
    *nick = getword(tmp);
    if (!**nick)   return 41;
    *addy = getword(tmp);
    if (!**addy)  return 54;
	get_command(tmp,command,type,nicktype,maxnicks,del,47,more,mod,sep);
	return 0;
 }

inline int get_nick_para(char **tmp,char **nick,char **addy,int& type,DWORD& nicktype,unsigned int & maxnicks,char **command,BOOL del,int &more,int &mod,char &sep)
{

    *nick = getword(tmp);
    if (!**nick) return 41;
      *addy = getword(tmp);
    if (!**addy) return 54;
 	get_command(tmp,command,type,nicktype,maxnicks,del,47,more,mod,sep);
	return  0;
}

MircFunc FindNickAll (FUNCPARMS)
{
	char *tmp = data, *network , *channel, *nick, *addy, *command,*table,buf[MLEN],*aux = NULL;
    unsigned int  tot, maxnicks,err;
    NickNode *item;
	int store,mod,type,itype = 0;
	char sep = '|';
    pnetwork s;
	pchannel hchan;
	ptable pt;
	DWORD ntype,mnum = 0;
	BOOL change = FALSE;

	err = getpara(&tmp,&table,&network,&channel,&nick,&addy,ntype,maxnicks,&command,type,FALSE,store,mod,sep) ;
	if (err) { msg_error(data,err); return 3; }
    tot = 0;
if (store) hs.addinit(40,ntype,table,network,channel,nick);
if (type == -2)  {
	if (mod == 3) 	getfirstnum(command,itype);
	else 
		if ((mod == 0) || (mod == 4)) 
			change = (getfirstnum(command,mnum)  == HaveTokenOnly)?TRUE:FALSE;
}
if (listtable) {
	pt = ptable(listtable->dltofirst());
    for (; pt; pt = ptable(listtable->dlgofwd())) {
		if (pt->listnet && match(table,pt->table,FALSE)) {
		s = pnetwork(pt->listnet->dltofirst());
			for (;s;s = pnetwork(pt->listnet->dlgofwd())) {
	if (s->listchan && match(network,s->network, FALSE)) {
hchan = pchannel(s->listchan->dltofirst());
for (;hchan; hchan = pchannel(s->listchan->dlgofwd())) {
	if ((match(channel,hchan->channel, FALSE)) && (hchan->headnick)) {
		if (change) {
			SubType *x = type_chan_find(hchan,sdata);
			if (!x)  x = type_table_find2(pt,nitem);
			if (x) getnumtype(x,command,mnum);
		}
	hchan->headnick->ProcessInit();
    for (;;) {
        item = hchan->headnick->ProcessNext();
       if (!item) {
            break;
        }
        if (((ntype & item->nicktype)== ntype) && match(nick, item->nick, FALSE) && match(addy, item->addy, FALSE)) {
            ++tot;
			if (store) hs.lstore.push_back(item);
			if (mod >= 0) {
				if (type > -2) { 
					if (type == -1)  aux = eval_exp(command) ; 
					else {   
						wsprintf(buf,"%s|%s|%s|%s|%s|%s|%d|%lu|%s",pt->table,s->network,hchan->channel,item->nick,item->addy,item->data?item->data:"$NULL",item->num,item->nicktype , item->msg?item->msg:"");
						getnthtok(buf,type,'|'); 
						aux = eval_exp(command,buf,sep); 
					}    
				}	 
				else aux = command;
				if  ((mod == 0) || (mod == 4)) {
					if (type == -2) item->nicktype = mnum; 
					else getfirstnum(aux,item->nicktype); 
				}   
				else 
				switch (mod) {
					case 3: {
						if (type == -2) item->num = itype; 
						else  getfirstnum(aux,item->num);  
						break;
							}   
					case 1:{ copystr(&(item->addy),aux); break; }
					case 2:{ copystr(&(item->data),aux); break; }
					case 5:{ copystr(&(item->msg),aux); break; }
				} 
				if ((aux) && (type > -2)) delete aux;
			}
			else
				if (command) 
				{ 
        			wsprintf(buf,"%s|%s|%s|%s|%s|%s|%d|%lu|%s",pt->table,s->network,hchan->channel,
						item->nick,item->addy,item->data?item->data:"$NULL",item->num,item->nicktype , item->msg?item->msg:"");
					DocommandB(command,buf,type,sep);
				} 
            if (maxnicks && tot == maxnicks) goto stopm;            			
        }  
    } //for nick 

	} 
} //for channel
		}
	} //for network 
		}
	} //for table
}
stopm:
	if (command) return 1;
	else {
		wsprintf(data, "+OK %d", tot);
		return 3;
	}
} 
 
 
MircFunc FindNickTable (FUNCPARMS)
{
	char *tmp , *network , *channel, *nick, *addy, *command,buf[MAXSTRINGLEN],*aux = NULL;
    unsigned int  tot, maxnicks,err;
	int store,mod,type,itype = 0;
	char sep = '|';
    NickNode *item;
	ptable thead;
    pnetwork s;
	pchannel hchan;
	DWORD ntype,mnum = 0;
	tmp = data;
	BOOL change = FALSE;

	err = pathtable(&tmp,&network,&thead);
	if (err) { msg_error(data,err); return 3 ; }
	channel = getword(&tmp);
	if (!*channel) r_err("PARA","Invalid channel") 
	err = get_nick_para(&tmp,&nick,&addy,type,ntype,maxnicks,&command,FALSE,store,mod,sep) ;
	if (err) { msg_error(data,err); return 3 ; }

    tot = 0;
if (store) { hs.addinit(40,ntype,NULL,network,channel,nick); hs.table = thead; }
if (type == -2)  {
	if (mod == 3) 	getfirstnum(command,itype);
	else 
		if ((mod == 0) || (mod == 4)) 
			change = (getfirstnum(command,mnum)  == HaveTokenOnly)?TRUE:FALSE;
}
if (thead->listnet) {
	s = pnetwork(thead->listnet->dltofirst());
	for (;s;s = pnetwork(thead->listnet->dlgofwd())) {
	if (s->listchan && match(network,s->network, FALSE)) {
	hchan = pchannel(s->listchan->dltofirst());
	 for (;hchan; hchan = pchannel(s->listchan->dlgofwd())) {
	if ((match(channel,hchan->channel, FALSE)) && (hchan->headnick)) {
		if (change) {
			SubType *x = type_chan_find(hchan,sdata);
			if (!x)  x = type_table_find2(thead,nitem);
			if (x) getnumtype(x,command,mnum);
		}
	hchan->headnick->ProcessInit();
    for (;;) {
        item = hchan->headnick->ProcessNext();
       if (!item) {
            break;
        }
        if (((ntype & item->nicktype)== ntype) && match(nick, item->nick, FALSE) && match(addy, item->addy, FALSE)) {
            ++tot;
			if (store) hs.lstore.push_back(item);
			if (mod >= 0) {
				if (type > -2) { 
					if (type == -1)  aux = eval_exp(command) ; 
					else {   
        				wsprintf(buf,"%s|%s|%s|%s|%s|%d|%lu|%s ",s->network,hchan->channel,item->nick,item->addy,item->data?item->data:"$NULL",item->num,item->nicktype , item->msg?item->msg:""); 
						getnthtok(buf,type,'|'); 
						aux = eval_exp(command,buf,sep); 
					}    
				}	 
				else aux = command;
				if  ((mod == 0) || (mod == 4)) {
					if (type == -2) item->nicktype = mnum; 
					else getfirstnum(aux,item->nicktype); 
				}   
				else 
				switch (mod) {
					case 3: {
						if (type == -2) item->num = itype; 
						else  getfirstnum(aux,item->num);  
						break;
							}   
					case 1:{ copystr(&(item->addy),aux); break; }
					case 2:{ copystr(&(item->data),aux); break; }
					case 5:{ copystr(&(item->msg),aux); break; }
				} 
				if ((aux) && (type > -2)) delete aux;
			}
			else
			if (command) {
        	wsprintf(buf,"%s|%s|%s|%s|%s|%d|%lu|%s ",
				s->network,hchan->channel,
				item->nick,item->addy,item->data?item->data:"$NULL",item->num,item->nicktype , item->msg?item->msg:"");
			DocommandB(command,buf,type,sep);
			}
            if (maxnicks && tot == maxnicks)  goto stopmt;
            		
        } 
    } //for nick 

	} 
} //for channel
		}
	} //for network 
}
stopmt:
    if (command) return 1;
	else {
		wsprintf(data, "+OK %d", tot);
		return 3;
	}
}

MircFunc FindNickNet (FUNCPARMS)
{
	char *tmp = data ,*channel, *nick, *addy, *command,buf[MAXSTRINGLEN],*aux = NULL;
    unsigned int  tot, maxnicks,err;
	int store,mod,type,itype = 0;
	char sep = '|';
    NickNode *item;
   	pchannel hchan;
	pnetwork Net;
	ptable  pt;
   	DWORD ntype,mnum = 0;
	BOOL change = FALSE;
		
	err = pathnetf(&tmp,&channel,&pt,&Net);
	if (err) { msg_error(data,err); return 3 ; }
	err = get_nick_para(&tmp,&nick,&addy,type,ntype,maxnicks,&command,FALSE,store,mod,sep) ;
	if (err) { msg_error(data,err); return 3 ; }

    tot = 0;
	if (store) { 
		hs.addinit(40,ntype,NULL,NULL,channel,nick); hs.net = Net; 
		hs.table = pt;
	}
if (type == -2)  {
	if (mod == 3) 	getfirstnum(command,itype);
	else 
		if ((mod == 0) || (mod == 4)) 
			change = (getfirstnum(command,mnum)  == HaveTokenOnly)?TRUE:FALSE;
}
if (Net->listchan) {
hchan = pchannel(Net->listchan->dltofirst());
 for (;hchan; hchan = pchannel(Net->listchan->dlgofwd())) {
	if ((match(channel,hchan->channel, FALSE)) && (hchan->headnick)) {
		if (change) {
			SubType *x = type_chan_find(hchan,sdata);
			if (!x)  x = type_table_find2(pt,nitem);
			if (x) getnumtype(x,command,mnum);
		}
	hchan->headnick->ProcessInit();
    for (;;) {
        item = hchan->headnick->ProcessNext();
       if (!item) {
            break;
        }
	    if (((ntype & item->nicktype)== ntype) && match(nick, item->nick, FALSE) && match(addy, item->addy, FALSE)) {
            ++tot;
			if (store) hs.lstore.push_back(item);
			if (mod >= 0) {
				if (type > -2) { 
					if (type == -1)  aux = eval_exp(command) ; 
					else {   
        		       	wsprintf(buf,"%s|%s|%s|%s|%d|%lu|%s ",hchan->channel,item->nick,item->addy,item->data?item->data:"$NULL",item->num,item->nicktype , item->msg?item->msg:"");
						getnthtok(buf,type,'|'); 
						aux = eval_exp(command,buf,sep); 
					}    
				}	 
				else aux = command;
				if  ((mod == 0) || (mod == 4)) {
					if (type == -2) item->nicktype = mnum; 
					else getfirstnum(aux,item->nicktype); 
				}   
				else 
				switch (mod) {
					case 3: {
						if (type == -2) item->num = itype; 
						else  getfirstnum(aux,item->num);  
						break;
							}   
					case 1:{ copystr(&(item->addy),aux); break; }
					case 2:{ copystr(&(item->data),aux); break; }
					case 5:{ copystr(&(item->msg),aux); break; }
				} 
				if ((aux) && (type > -2)) delete aux;
			}
			else
			if (command) 
			{
        	wsprintf(buf,"%s|%s|%s|%s|%d|%lu|%s ",
				hchan->channel,
				item->nick,item->addy,item->data?item->data:"$NULL",item->num,item->nicktype , item->msg?item->msg:"");
			DocommandB(command,buf,type,sep);
			}
            if (maxnicks && tot == maxnicks) goto stopmn;
      
        } 
    } //for nick 

	} 
} //for channel
}
stopmn:
   	if (command) return 1;
	else {
		wsprintf(data, "+OK %d", tot);
		return 3;
	}
}


MircFunc FindNick(FUNCPARMS)
{
	char *tmp = data,*nick, *addy, *command,buf[MAXSTRINGLEN],*aux = NULL;
    unsigned int  tot, maxnicks,err;
	int store,mod,type,itype = 0;
	char sep = '|';
    NickNode *item;
	DWORD ntype,mnum = 0;
	pchannel Chan;
	ptable pt; 
	pnetwork Net;

	err = currentchanf(&tmp,&pt,&Net,&Chan);
	if (err) { msg_error(data,err); return 3 ; }
	err = get_nick_para(&tmp,&nick,&addy,type,ntype,maxnicks,&command,FALSE,store,mod,sep) ;
	if (err) { msg_error(data,err); return 3 ; }
	  
    tot = 0;
	if (store) { 
		hs.additem(40,ntype,nick); hs.chan = Chan;
		hs.table = pt; hs.net = Net;
	}
	if (Chan->headnick) {
if (type == -2)  {
	if (mod == 3) 	getfirstnum(command,itype);
	else 
		if ((mod == 0) || (mod == 4)) 
			if (getfirstnum(command,mnum)  == HaveTokenOnly) {
				SubType *x = type_chan_find(Chan,sdata);
				if (!x)  x = type_table_find2(pt,nitem);
				if (x) getnumtype(x,command,mnum);
			} 
}
	Chan->headnick->ProcessInit();
    for (;;) {
        item = Chan->headnick->ProcessNext();
       if (!item)  break;
       if (((ntype & item->nicktype)== ntype) && match(nick, item->nick, FALSE) && match(addy, item->addy, FALSE) ) {
            ++tot;
			if (store) hs.lstore.push_back(item);
		if (mod >= 0) {
				if (type > -2) { 
					if (type == -1)  aux = eval_exp(command) ; 
					else {   
        		       	wsprintf(buf,"%s|%s|%s|%d|%lu|%s ",item->nick,item->addy,item->data?item->data:"$NULL",item->num,item->nicktype , item->msg?item->msg:"");
						getnthtok(buf,type,'|'); 
						aux = eval_exp(command,buf,sep); 
					}    
				}	 
				else aux = command;
				if  ((mod == 0) || (mod == 4)) {
					if (type == -2) item->nicktype = mnum; 
					else getfirstnum(aux,item->nicktype); 
				}   
				else 
				switch (mod) {
					case 3: {
						if (type == -2) item->num = itype; 
						else  getfirstnum(aux,item->num);  
						break;
							}   
					case 1:{ copystr(&(item->addy),aux); break; }
					case 2:{ copystr(&(item->data),aux); break; }
					case 5:{ copystr(&(item->msg),aux); break; }
				} 
				if ((aux) && (type > -2)) delete aux;
			}
			else
			if (command)
			{
        	wsprintf(buf,"%s|%s|%s|%d|%lu|%s ",
				item->nick,item->addy,item->data?item->data:"$NULL",item->num,item->nicktype , item->msg?item->msg:"");
			DocommandB(command,buf,type,sep);
			}
            if (maxnicks && tot == maxnicks) break;
       } 
    } //for nick 
	}
   	if (command) return 1;
	else {
		wsprintf(data, "+OK %d", tot);
		return 3;
	}
}

MircFunc IsNick (FUNCPARMS)
{
	char *tmp = data,*nick, *addy;
    unsigned int  err;
    NickNode *item;
	DWORD ntype = 0;
	pchannel Chan;
	ptable pt; 
	pnetwork Net;
	BOOL found = FALSE;

	err = currentchanf(&tmp,&pt,&Net,&Chan);
	if (err) RETNUL
    nick = getword(&tmp);
    if (!*nick) RETNUL
    addy = getword(&tmp);
    if (!*addy) RETNUL

    if (Chan->headnick) {
			if (getfirstnum(tmp,ntype)  == HaveTokenOnly) {
				SubType *x = type_chan_find(Chan,sdata);
				if (!x)  x = type_table_find2(pt,nitem);
				if (x) getnumtype(x,tmp,ntype);
			} 
		Chan->headnick->ProcessInit();
		for (;;) {
			item = Chan->headnick->ProcessNext();
			if (!item)  break;
			if (((ntype & item->nicktype)== ntype) && match(nick, item->nick, FALSE) && match(addy, item->addy, FALSE)) {
				found = TRUE;break;
			}  
		} //for nick  
	}
	RETYN(found)
	return 3;
}

MircFunc DelMatchNick (FUNCPARMS)
{
	char *tmp ,*nick, *addy, *command,buf[MAXSTRINGLEN];
    unsigned int  tot, maxnicks,err;
	char sep = '|';
	int store,mod,type;
	ListPointer lnick;
	ListPointer::iterator i;
    NickNode *item,*aux;
    DWORD ntype;
	tmp = data;
	pchannel Chan;

	err = currentchan(&tmp,&Chan);
	if (err) { msg_error(data,err); return 3 ; }
	err = get_nick_para(&tmp,&nick,&addy,type,ntype,maxnicks,&command,TRUE,store,mod,sep) ;
	if (err) { msg_error(data,err); return 3 ; }
	  
    tot = 0; aux = NULL;
	if (Chan->headnick) {
		if (hs.type == 40) {
			if ((hs.stchan && match(hs.stchan,Chan->channel,FALSE)) ||
				(hs.chan && (hs.chan == Chan))) hs.clear();
		}
	Chan->headnick->ProcessInit();
    for (;;) {
        item = Chan->headnick->ProcessNext();
       if (!item)  break;
       if (((ntype & item->nicktype)== ntype) && match(nick, item->nick, FALSE) && match(addy, item->addy, FALSE)) {
            ++tot;
			lnick.push_back(item);
			if (command)
			{
        	wsprintf(buf,"%s|%s|%s|%d|%lu|%s ",
				item->nick,item->addy,item->data?item->data:"$NULL",item->num,item->nicktype , item->msg?item->msg:"");
			DocommandB(command,buf,type,sep);
			}
            if (maxnicks && tot == maxnicks) break;
       } 
    } //for nick 
  	for ( i = lnick.begin(); i != lnick.end() ; i++)
		Chan->headnick->Delete(((NickNode*)(*i))->nick);
	lnick.clear();
	}
   	if (command) return 1;
	else {
		wsprintf(data, "+OK %d", tot);
		return 3;
	}
}
//---------------------------------------------------------------
//-----------------Array Functions------------------------------

MircFunc AddVNick(FUNCPARMS)
{  
	char *tmp = data;
	pchannel Chan;
	int err;

	err = currentchan(&tmp,&Chan);
	if (err) 	msg_error(data,err); 
	else {
		vnick_addB(tmp,Chan);
		lstrcpy(data,"+OK");
	}
	return 3;
}
MircFunc AddOVNick(FUNCPARMS)
{  
	char *tmp = data;
	pchannel Chan;
	int err,b;

	b = isin_fpara(data,'x','X');
	err = currentchan(&tmp,&Chan);
	if (err) 	msg_error(data,err); 
	else {
		err = vnick_overwrite(tmp,Chan);
		if (b) wsprintf(data,"%d",err);
		else wsprintf(data,"+OK %d",err);
	}
	return 3;
}
MircFunc GetNthVNick(FUNCPARMS)
{  
	char *tmp = data,*var = NULL,*para;
	pchannel Chan;
	int err;

	err = currentchanp(&tmp,&Chan,&para);
	if (err) {
		if (para) delete para;
		msg_error(data,err); return 3;
	}
	if (para) { 
		if (find_para(para,'V')) var = getword(&tmp);
		delete para ;
	}
	if (err) 	msg_error(data,err); 
	else rnum_var(var,vnick_pos(tmp,Chan))
	return 3;
}
MircFunc GetNet(FUNCPARMS)
{
	char *tmp = data,*item,*para,ho[BLEN],buf[MLEN];
	ptable pt;
	pnetwork net;
	unsigned int number,naux,type = 0;
	int err = currenttablefp(&tmp,&pt,&para);
	BOOL isnumber = 0;

	if (err) {
		if (para) delete para;
		msg_error(data,err); return 3; 
	}
	if (pt->listnet) {
		if (para) { 
			lstrcpy(ho,para);
			if (take_para(ho,"G",para)) type = atolp(para);
			if (take_para(ho,"Y",para)) { isnumber = 1 ; number = atolp(para); }
			delete para ; 
		}
		if (isnumber) { 
			getfirstnum(&tmp,number);
			naux = pt->listnet->m_Count;	
			if (number == 0) { rnum_var(tmp,naux) return 3; }
			if (number > naux) { Unsetvar(tmp); RETOoR  }
			net = pnetwork(pt->listnet->dltonum(number));
		}
		else {
			item = getword(&tmp);
			if (!*item)  ret("-PARA Invalid Net Name");
			net  =	f_netnode(item,pt);
		}
		if (net)  {
			wsprintf(buf,"%s %lu",net->network,net->property);
			getnthtok(buf,type);
			r_var(tmp,buf);
		} 
		else { 	Unsetvar(tmp); lstrcpy(data,"-NO Network not found"); }
	}
	else lstrcpy(data,"-List: Net List is empty"); 
	return 3;
}
MircFunc GetVNick(FUNCPARMS)
{
	char *tmp = data,*para,ho[BLEN],buf[MLEN];
	NickNode *node;
	pchannel Chan;
	unsigned int type = 0,index;

	int err = currentchanp(&tmp,&Chan,&para);
	if (err) {
		if (para) delete para;
		msg_error(data,err); return 3;
	}
	if (para) { 
		lstrcpy(ho,para);
		if (take_para(ho,"G",para)) type = atolp(para);
		delete para ; 
	}
	if  (getfirstnum(&tmp,index) < 0) r_err("PARA", "Invalid Index")
	if (Chan->vnick.empty()) RETNULL

	if ((index == 0) || (index > Chan->vnick.size())) lstrcpy(data,"$FALSE");
	else {
		--index;
		node = Chan->vnick[index];
	    wsprintf(buf, "%s|%s|%s|%d|%lu|%s", N(node->nick), N(node->addy),N(node->data),node->num,node->nicktype,N(node->msg));
		getnthtok(buf,type,'|');
		r_var(tmp,buf);
		node = NULL;
	}
	return 3;
}

MircFunc DelVNick(FUNCPARMS)
{  
	char *tmp = data;
	ptable pt;
	pnetwork Net;
	pchannel Chan;
	VectorNick::iterator i;
	ListPointer::iterator ii;

	int num = 0;
	int err = currentchanf(&tmp,&pt,&Net,&Chan);

	if (err) { msg_error(data,err); return 3; }
	if ((Chan->vnick.empty()) || (getfirstnum(&tmp,num) < 0)) RETNULL
		--num;
	if ((num < 0) || (num >= Chan->vnick.size())) lstrcpy(data,"$FALSE");
	else {
		i = Chan->vnick.begin() + num;
		if ((hs.type == 41) && askdel_chan(pt,Net,Chan)) {
			for ( ii = hs.lstore.begin(); ii != hs.lstore.end() ; ii++)
				if (*ii == *i) break;
			if (ii != hs.lstore.end())	hs.delitem(ii);
		}
		delete (*i);
		Chan->vnick.erase(i);
		lstrcpy(data,"+OK");
	}
	return 3;
}
MircFunc CountVNick (FUNCPARMS) 
{
	char *tmp = data;
	pchannel Chan;
	int err = currentchan(&tmp,&Chan);

	if (err) msg_error(data,err); 
	else {   
		err  = Chan->vnick.size();
		nrnum_var(tmp,err);
	}
    return 3;
}
/*
@V: type == -2 ; default: type == -1 ; @p[Num] : type >= 0
@M[Num] : mod >= 0 ; default: mod == -1
*/
void vnick_inp(char **tmp,char **command,int &first,int &last,int &mod,int &type,char &sep)
{ 
	char *aux,*tmpbuf,buf[PLEN];
	last = -1;mod = -1;first = -1;type = -1; *command = NULL;
	int tm = 0;

	if (getfirstnum(tmp,first) == HaveNumHaveToken)	
			getfirstnum(tmp,last);
	aux = *tmp;
	aux_getcommand(&aux,command);
	if (aux) {
		tmpbuf = creat_para("VM[NUM]P[NUM]C[NUM]",aux + 1);
		if (take_para(tmpbuf,"P",&buf[0])) type = atolp(buf);  
		if (find_para(tmpbuf,'V')) type = -2;
		if (take_para(tmpbuf,"M",&buf[0])) mod = atolp(buf);
		if (take_para(tmpbuf,"C",&buf[0])) { 
				tm = atolp(buf); 
				if ((tm <= 255) && (tm > 0)) sep = tm;
		}
		delete tmpbuf; 
	}
	if (*command && (!**command) && (mod < 0)) *command = NULL;
}
//vnick same as nick ,use same properties 

MircFunc RVNick(FUNCPARMS)
{	
	VectorNick::iterator i,j;
	int  first,last,mod,type,stmp,itype = 0;
	char sep = '|';
	char *command,*tmp = data,*aux = NULL,buf[MLEN];
	DWORD mnum = 0;
	pchannel Chan;
	pnetwork Net;
	ptable pt;

	int err = currentchanf(&tmp,&pt,&Net,&Chan);
	if (err) { msg_error(data,err); return 3; }
	if (Chan->vnick.empty()) RETNULL
	vnick_inp(&tmp,&command,first,last,mod,type,sep);
	if (!command) return 1;

	if (first > last) { stmp = first ; first = last ; last = stmp; }
	if (first <= 1) i = Chan->vnick.begin();
	else 
		if (first <= Chan->vnick.size()) i = Chan->vnick.begin() + first - 1;
		else RETNULL
	if ((last == -1) || (last >= Chan->vnick.size())) j = Chan->vnick.end();
	else j = Chan->vnick.begin() + last;

	if (type == -2)  {
		if (mod == 4) 	getfirstnum(command,itype);
		else 
			if ((mod == 0) || (mod == 5)) 
				if (getfirstnum(command,mnum)  == HaveTokenOnly) {
					SubType *x = type_chan_find(Chan,sdata);
					if (!x)  x = type_table_find2(pt,nitem);
					if (x) getnumtype(x,command,mnum);
				}  
	} 

	while (i != j) {
		if (mod >= 0) {
				if (type > -2) { 
					if (type == -1)  aux = eval_exp(command) ; 
					else {   
        		       	wsprintf(buf,"%s|%s|%s|%d|%lu|%s",N((*i)->nick),N((*i)->addy),N((*i)->data),(*i)->num,(*i)->nicktype ,N((*i)->msg));
						getnthtok(buf,type,'|'); 
						aux = eval_exp(command,buf,sep); 
					}  
				}	  
				else aux = command;
				if  ((mod == 0) || (mod == 5)) {
					if (type == -2) (*i)->nicktype = mnum; 
					else getfirstnum(aux,(*i)->nicktype); 
				}   
				else 
				switch (mod) {
					case 4: {
						if (type == -2) (*i)->num = itype; 
						else  getfirstnum(aux,(*i)->num);  
						break;
							}   
					case 1:{ copystr(&((*i)->nick),aux); break; }
					case 2:{ copystr(&((*i)->addy),aux); break; }
					case 3:{ copystr(&((*i)->data),aux); break; }
					case 6:{ copystr(&((*i)->msg),aux); break; }
				} 
				if ((aux) && (type > -2)) delete aux;
		} 
		else
		if (command)
		{
        wsprintf(buf,"%s|%s|%s|%d|%lu|%s ", N((*i)->nick),N((*i)->addy),N((*i)->data),(*i)->num,(*i)->nicktype ,N((*i)->msg));
		DocommandB(command,buf,type,sep);
		}
		i++;
	}
	return 1;
}
//NICK HOST TYPE NUM DATA  COMMENT 
int Add_vfnick(SubType *x,NickNode *saux,char *ptype, char *data)
{
	DWORD num = 0;
	if (saux) {
		if (!lstrcmpi(ptype,"NICK")) {
			if (!*data) return 124 ;
			copystr(&(saux->nick),data);
		}
		else 
		if (!lstrcmpi(ptype,"COMMENT")) {
			if (!*data) return 124 ;
			if (saux->msg) delete saux->msg;
			saux->msg = new char[lstrlen(data) + 1];
			lstrcpy(saux->msg,data);
		}
		else 
			if (!lstrcmpi(ptype,"TYPE")) {
				if (!*data)  return 84;
				if (getfirstnum(data,num) < 0)  {
					if (x) getnumtype(x,data,num);
					else return 64;
				}
				saux->nicktype = num;
			}
			else
				if (!lstrcmpi(ptype,"NUM")) {
					if (getfirstnum(data,saux->num) < 0 )  return 74;
				}
				else 
					if (!lstrcmpi(ptype,"HOST")) {
						if (!*data) return 54;
						if (saux->addy) delete saux->addy;
						saux->addy = new char[lstrlen(data) + 1];
						lstrcpy(saux->addy,data);
					}
					else
						if (!lstrcmpi(ptype,"DATA")) {
							if (saux->data) delete saux->data;
							if ((data) && (*data)) {
								saux->data = new char[lstrlen(data) + 1];
								lstrcpy(saux->data,data);
							}
							else saux->data = NULL;
						} 
						else return 64;
		return 0;
	}
	else return 43;
}
MircFunc SetVNick(FUNCPARMS)
{  
	char *tmp = data ,*type;
	pchannel Chan;
	pnetwork Net;
	ptable pt;
	SubType *x;
	VectorNick::iterator i;
	int num = 0;
	int err = currentchanf(&tmp,&pt,&Net,&Chan);
	if (err) { msg_error(data,err); return 3; }
	err = getfirstnum(&tmp,num) ;

	if (err < 0) r_err("PARA","Invalid Index")
		else if (err == HaveNumOnly) r_err("PARA","Invalid Set Field")

	if (Chan->vnick.empty()) RETNULL
		--num;
	if ((num < 0) || (num >= Chan->vnick.size())) lstrcpy(data,"$FALSE");
	else {
		i = Chan->vnick.begin() + num;
		type = getword(&tmp);
		x = type_chan_find(Chan,sdata);
		if (!x)  x = type_table_find2(pt,nitem);
		err = Add_vfnick(x,*i,type,tmp);
		if (err)  msg_error(data,err); 
		else lstrcpy(data,"+OK");
	}
	return 3;
}
MircFunc UnsetVNickType(FUNCPARMS)
{  
	char *tmp = data ,*para,ho[BLEN];
	pchannel Chan;
	pnetwork Net;
	ptable pt;
	SubType *x;
	VectorNick::iterator i;
	ListPointer::iterator ii;
	DWORD ntype = 0;
	int num = 0;
	int err = currentchanfp(&tmp,&pt,&Net,&Chan,&para);

	if (err) {
		if (para)  delete para; 
		msg_error(data,err); return 3;
	}
	if (para) { lstrcpy(ho,para); delete para; }
	err = getfirstnum(&tmp,num) ;

	if (err < 0) r_err("PARA","Invalid Index")
		else if (err == HaveNumOnly) r_err("PARA","Invalid Set Field")

	if (Chan->vnick.empty()) RETNULL
		--num;
	if ((num < 0) || (num >= Chan->vnick.size())) lstrcpy(data,"$FALSE");
	else {
		x = type_chan_find(Chan,sdata);
		if (!x)  x = type_table_find2(pt,nitem);
		if (!*tmp)  msg_error(data,84); 
		else {
			if (getfirstnum(tmp,ntype) < 0)  {
				if (x) getnumtype(x,tmp,ntype);
				else { msg_error(data,64); return 3; }
			}
			i = Chan->vnick.begin() + num;
			(*i)->nicktype ^= ((*i)->nicktype & ntype);
			if (((*i)->nicktype == 0) && (find_para(&ho[0],'B'))) {
				
				if ((hs.type == 41) && askdel_chan(pt,Net,Chan)) {
					for ( ii = hs.lstore.begin(); ii != hs.lstore.end() ; ii++)
						if (*ii == *i) break;
					if (ii != hs.lstore.end())	hs.delitem(ii);
				} 
				delete (*i);
				Chan->vnick.erase(i);
				lstrcpy(data,"0");
			} 
			else lstrcpy(data,"1");
		}
	}
	return 3;
}
MircFunc IsAnyVNick(FUNCPARMS)
{
	char *tmp = data;
	pchannel Chan;
	int err;

	err = currentchan(&tmp,&Chan);
	if (err) RETNUL
	else RETYN(Chan->vnick.empty());
    return 3;
}
MircFunc IsVNick (FUNCPARMS)
{
	char *tmp = data,*nick, *addy;
    unsigned int  err;
	DWORD ntype = 0;
	pchannel Chan;
	ptable pt; 
	pnetwork Net;
	BOOL found = FALSE;
	VectorNick::iterator i;

	err = currentchanf(&tmp,&pt,&Net,&Chan);
	if (err) RETNUL
    nick = getword(&tmp);
    if (!*nick) RETNUL
    addy = getword(&tmp);
    if (!*addy) RETNUL

    if (!Chan->vnick.empty()) {
			if (getfirstnum(tmp,ntype)  == HaveTokenOnly) {
				SubType *x = type_chan_find(Chan,sdata);
				if (!x)  x = type_table_find2(pt,nitem);
				if (x) getnumtype(x,tmp,ntype);
			} 
		for (i = Chan->vnick.begin(); i != Chan->vnick.end();i++)
			if (((ntype & (*i)->nicktype)== ntype) && match(nick, (*i)->nick, FALSE) && match(addy, (*i)->addy, FALSE)) {
				found = TRUE;break;
			}
	}
	RETYN(found);
	return 3;
}
MircFunc FindVNick(FUNCPARMS)
{
	char *tmp = data,*nick, *addy, *command,buf[MAXSTRINGLEN],*aux = NULL;
    unsigned int  tot, maxnicks,err;
	int store,mod,type,itype = 0;
	char sep = '|';
    NickNode *item;
	DWORD ntype,mnum = 0;
	pchannel Chan;
	ptable pt; 
	pnetwork Net;
	VectorNick::iterator i;

	err = currentchanf(&tmp,&pt,&Net,&Chan);
	if (err) { msg_error(data,err); return 3 ; }
	err = get_nick_para(&tmp,&nick,&addy,type,ntype,maxnicks,&command,FALSE,store,mod,sep) ;
	if (err) { msg_error(data,err); return 3 ; }
	  
    tot = 0;
	if (store) { 
		hs.additem(41,ntype,nick); hs.chan = Chan;
		hs.table = pt; hs.net = Net;
	}
	if (!Chan->vnick.empty()) {
if (type == -2)  {
	if (mod == 4) 	getfirstnum(command,itype);
	else 
		if ((mod == 0) || (mod == 5)) 
			if (getfirstnum(command,mnum)  == HaveTokenOnly) {
				SubType *x = type_chan_find(Chan,sdata);
				if (!x)  x = type_table_find2(pt,nitem);
				if (x) getnumtype(x,command,mnum);
			} 
}
	for (i = Chan->vnick.begin();i != Chan->vnick.end();i++)
	{ 
        item = *i;
       if (((ntype & item->nicktype)== ntype) && match(nick, item->nick, FALSE) && match(addy, item->addy, FALSE)) {
            ++tot;
			if (store) hs.lstore.push_back(item);
		if (mod >= 0) {
				if (type > -2) { 
					if (type == -1)  aux = eval_exp(command) ; 
					else {   
        		       	wsprintf(buf,"%s|%s|%s|%d|%lu|%s ",item->nick,item->addy,item->data?item->data:"$NULL",item->num,item->nicktype , item->msg?item->msg:"");
						getnthtok(buf,type,'|'); 
						aux = eval_exp(command,buf,sep); 
					}    
				}	 
				else aux = command;
				if  ((mod == 0) || (mod == 5)) {
					if (type == -2) item->nicktype = mnum; 
					else getfirstnum(aux,item->nicktype); 
				}   
				else 
				switch (mod) {
					case 4: {
						if (type == -2) item->num = itype; 
						else  getfirstnum(aux,item->num);  
						break;
							}   
					case 1:{ copystr(&(item->nick),aux); break; }
					case 2:{ copystr(&(item->addy),aux); break; }
					case 3:{ copystr(&(item->data),aux); break; }
					case 6:{ copystr(&(item->msg),aux); break; }
				} 
				if ((aux) && (type > -2)) delete aux;
			}
			else
			if (command)
			{
        	wsprintf(buf,"%s|%s|%s|%d|%lu|%s ",
				item->nick,item->addy,item->data?item->data:"$NULL",item->num,item->nicktype , item->msg?item->msg:"");
			DocommandB(command,buf,type,sep);
			}
            if (maxnicks && tot == maxnicks) break;
       } 
    } //for nick 
	}
   	if (command) return 1;
	else {
		wsprintf(data, "+OK %d", tot);
		return 3;
	}
}
MircFunc DelMatchVNick (FUNCPARMS)
{
	char *tmp = data,*nick, *addy, *command,buf[MAXSTRINGLEN];
    unsigned int  tot, maxnicks,err;
	int store,mod,type,count = 0;
	char sep = '|';
	list<int> lnick;
	list<int>::iterator i;
    NickNode *item,*aux;
    DWORD ntype;
	pchannel Chan;
	VectorNick::iterator ii;

	err = currentchan(&tmp,&Chan);
	if (err) { msg_error(data,err); return 3 ; }
	nick = getnexttokB(&tmp,'|');
    addy = getnexttokB(&tmp,'|');
	get_command(&tmp,&command,type,ntype,maxnicks,TRUE,47,store,mod,sep);
	tot = 0; aux = NULL;
	if (!Chan->vnick.empty()) {
		if (hs.type == 41) {
			if ((hs.stchan && match(hs.stchan,Chan->channel,FALSE)) ||
				(hs.chan && (hs.chan == Chan))) hs.clear();
		}
	for (ii = Chan->vnick.begin();ii != Chan->vnick.end();ii++)
	{ 
        item = *ii;
		if ( (match(nick, item->nick, FALSE)|| ((!nick) && (!item->nick)) ) &&
			(match(addy, item->addy, FALSE) || ((!addy) && (!item->addy))) && 
			((ntype & item->nicktype)== ntype)) {
            ++tot;
			lnick.push_back(count);
			if (command)
			{
        	wsprintf(buf,"%s|%s|%s|%d|%lu|%s ",
				item->nick,item->addy,item->data?item->data:"$NULL",item->num,item->nicktype , item->msg?item->msg:"");
			DocommandB(command,buf,type,sep);
			}
            if (maxnicks && tot == maxnicks) break;
       } 
	   ++count;
    } //for nick 
	count = 0;
  	for ( i = lnick.begin(); i != lnick.end() ; i++)
	{
		Chan->vnick.erase(Chan->vnick.begin() + (*i) - count);
		++count; 
	}
	lnick.clear();
	}
   	if (command) return 1;
	else {
		wsprintf(data, "+OK %d", tot);
		return 3;
	}
}

MircFunc DelMatchVNickAll (FUNCPARMS)
{
	char *tmp = data,*nick, *addy,*table,*network,*channel,*command,buf[MAXSTRINGLEN];
    unsigned int  tot, maxnicks;
	int store,mod,type,count = 0;
	char sep = '|';
	list<int> lnick;
	list<int>::iterator i;
    NickNode *item,*aux;
    DWORD ntype;
	pchannel Chan;
	ptable pt;
	pnetwork s;
	VectorNick::iterator ii;

   table = getword(&tmp);
	if (!*table) r_err("PARA","Invalid Table")
   	network = getword(&tmp);
	if (!*network) r_err("PARA","Invalid Network")
	channel = getword(&tmp);
    if (!*channel) r_err("PARA","Invalid Channel")

	nick = getnexttokB(&tmp,'|');
    addy = getnexttokB(&tmp,'|');
	get_command(&tmp,&command,type,ntype,maxnicks,TRUE,47,store,mod,sep);
	tot = 0; aux = NULL;

	if (hs.type == 41) hs.clear();
	if (listtable) {
		pt = ptable(listtable->dltofirst());
		for (; pt; pt = ptable(listtable->dlgofwd())) {
			if (pt->listnet && match(table,pt->table,FALSE)) {
				s = pnetwork(pt->listnet->dltofirst());
				for (;s;s = pnetwork(pt->listnet->dlgofwd()))   {
					if (s->listchan && match(network,s->network, FALSE)) {
						Chan = pchannel(s->listchan->dltofirst());
	for (;Chan; Chan = pchannel(s->listchan->dlgofwd())) {
	if ((match(channel,Chan->channel, FALSE)) && (!Chan->vnick.empty())) {
	
	for (ii = Chan->vnick.begin();ii != Chan->vnick.end();ii++)
	{ 
        item = *ii;
		if ( (match(nick, item->nick, FALSE)|| ((!nick) && (!item->nick)) ) &&
			(match(addy, item->addy, FALSE) || ((!addy) && (!item->addy))) && 
			((ntype & item->nicktype)== ntype)) {
            ++tot;
			lnick.push_back(count);
			if (command)
			{
        	wsprintf(buf,"%s|%s|%s|%d|%lu|%s ",
				item->nick,item->addy,item->data?item->data:"$NULL",item->num,item->nicktype , item->msg?item->msg:"");
			DocommandB(command,buf,type,sep);
			}
            if (maxnicks && tot == maxnicks) break;
       } 
	   ++count;
    } //for nick 
	count = 0;
  	for ( i = lnick.begin(); i != lnick.end() ; i++)
	{
		Chan->vnick.erase(Chan->vnick.begin() + (*i) - count);
		++count; 
	}
	lnick.clear();
	count = 0;
	} // if match chan
}
	}
	}
		}
	}
	}
   	if (command) return 1;
	else {
		wsprintf(data, "+OK %d", tot);
		return 3;
	}
}
MircFunc FindVNickAll(FUNCPARMS)
{
	char *tmp = data,*nick, *addy,*table,*network,*channel,*command,buf[MAXSTRINGLEN],*aux = NULL;
    unsigned int  tot, maxnicks,err;
	int store,mod,type,itype = 0;
	char sep = '|' ;
    NickNode *item;
	DWORD ntype,mnum = 0;
	pchannel hchan;
	ptable pt; 
	pnetwork s;
	VectorNick::iterator i;
	BOOL change = FALSE;

	err = getpara(&tmp,&table,&network,&channel,&nick,&addy,ntype,maxnicks,&command,type,FALSE,store,mod,sep) ;
	if (err) { msg_error(data,err); return 3; }
    tot = 0;
	if (store) hs.addinit(41,ntype,table,network,channel,nick);

if (type == -2)  {
	if (mod == 4) 	getfirstnum(command,itype);
	else 
		if ((mod == 0) || (mod == 5)) 
			change = (getfirstnum(command,mnum)  == HaveTokenOnly)?TRUE:FALSE;
}
if (listtable) {
	pt = ptable(listtable->dltofirst());
    for (; pt; pt = ptable(listtable->dlgofwd())) {
		if (pt->listnet && match(table,pt->table,FALSE)) {
	s = pnetwork(pt->listnet->dltofirst());
	for (;s;s = pnetwork(pt->listnet->dlgofwd())) {
	if (s->listchan  && match(network,s->network, FALSE)) {
hchan = pchannel(s->listchan->dltofirst());
for (;hchan; hchan = pchannel(s->listchan->dlgofwd())) {
	if ((match(channel,hchan->channel, FALSE)) && (!hchan->vnick.empty())) {
		if (change) {
			SubType *x = type_chan_find(hchan,sdata);
			if (!x)  x = type_table_find2(pt,nitem);
			if (x) getnumtype(x,command,mnum);
		} 
	for (i = hchan->vnick.begin();i != hchan->vnick.end();i++)
	{ 
        item = *i;
       if (((ntype & item->nicktype)== ntype) && match(nick, item->nick, FALSE) && match(addy, item->addy, FALSE)) {
            ++tot;
			if (store) hs.lstore.push_back(item);
		if (mod >= 0) {
				if (type > -2) { 
					if (type == -1)  aux = eval_exp(command) ; 
					else {   
        		       	wsprintf(buf,"%s|%s|%s|%d|%lu|%s ",item->nick,item->addy,item->data?item->data:"$NULL",item->num,item->nicktype , item->msg?item->msg:"");
						getnthtok(buf,type,'|'); 
							aux = eval_exp(command,buf,sep); 
					}    
				}	 
				else aux = command;
				if  ((mod == 0) || (mod == 5)) {
					if (type == -2) item->nicktype = mnum; 
					else getfirstnum(aux,item->nicktype); 
				}   
				else 
				switch (mod) {
					case 4: {
						if (type == -2) item->num = itype; 
						else  getfirstnum(aux,item->num);  
						break;
							}   
					case 1:{ copystr(&(item->nick),aux); break; }
					case 2:{ copystr(&(item->addy),aux); break; }
					case 3:{ copystr(&(item->data),aux); break; }
					case 6:{ copystr(&(item->msg),aux); break; }
				} 
				if ((aux) && (type > -2)) delete aux;
			}
			else
			if (command)
			{
        	wsprintf(buf,"%s|%s|%s|%s|%s|%s|%d|%lu|%s ",pt->table,s->network,hchan->channel,
				item->nick,item->addy,item->data?item->data:"$NULL",item->num,item->nicktype , item->msg?item->msg:"");
			DocommandB(command,buf,type,sep);
			}
            if (maxnicks && tot == maxnicks) goto stopm;            			
        }  
    } //for nick 

	} 
} //for channel
		}
	} //for network 
		}
	} //for table
}
stopm:
   	if (command) return 1;
	else {
		wsprintf(data, "+OK %d", tot);
		return 3;
	}
}
// Save a table to a File 

MircFunc SaveTable (FUNCPARMS)
{
    char *tmp ,line[4096];
    unsigned int tnum;
    NickNode *item;
	ItemNode *item1;
	ListTableType::iterator ti;
	ListChanType::iterator ci;
	ListNetType::iterator ni;
	VectorNick::iterator vn;
    HANDLE hfile;
	ptable pt;
	pnetwork s = NULL;
	pchannel hchan = NULL;

    tmp = data;
    hfile = NULL;
	int err = currenttable(&tmp,&pt);
	if (err) { msg_error(data,err); return 3; }
	if (!*tmp) r_err("FILE","Invalid File Name")
    switch (file_open_write(&hfile,tmp)) {
		case ERR_NICELIB_BADFILEBUFFER:r_err("FILE", "Invalid File")
		case ERR_NICELIB_COULDNTOPENFILE:r_err("OPEN", "Couldn't open file.")
	} 

	file_write(&hfile,"Nicedll : STructure");
	file_write(&hfile,"-------------Please do not modify This File-----------------------");
	file_write(&hfile,"------------------- Or It Could Not Be Read ----------------------");
	tnum = 0;
	wsprintf(line,"[%s]",pt->table);
	file_write(&hfile, line);

	if (pt->property) {
		wsprintf(line,"~5 %lu",pt->property);
		file_write(&hfile, line);
	}

	if (pt->litemt) {
	pt->litemt->ProcessInit();
    for (;;) {
        item1 = pt->litemt->ProcessNext();
       if (!item1)  break;
	   wsprintf(line,"#1 %s|%d|%s",item1->item,item1->property,item1->data?item1->data:"");
       if (file_write(&hfile, line))  ++tnum;
			
	} //for item
	}


	if (pt->listnet){
		s = pnetwork(pt->listnet->dltofirst());
		for (;s;s = pnetwork(pt->listnet->dlgofwd())) {
	 wsprintf(line,"[[%s]]",s->network);
	 file_write(&hfile, line);
	 if (s->property) {
		wsprintf(line,"~6 %lu",s->property);
		file_write(&hfile, line);
	 }
	 if (s->litemn) {
		s->litemn->ProcessInit();
		for (;;) {
		  item1 = s->litemn->ProcessNext();
		  if (!item1)  break;
		  wsprintf(line,"#2 %s|%d|%s",item1->item,item1->property,item1->data?item1->data:"");
		  if (file_write(&hfile, line))  ++tnum;
		} //for item
	 }
	 if (s->listchan) hchan = pchannel(s->listchan->dltofirst());
for (;hchan; hchan = pchannel(s->listchan->dlgofwd())) {
	wsprintf(line,"[[[%s]]]",hchan->channel);
	file_write(&hfile, line);

	if (hchan->property) {
		wsprintf(line,"~7 %lu",hchan->property);
		file_write(&hfile, line);
	}

	if (hchan->headnick) {
	hchan->headnick->ProcessInit();
    for (;;) {
        item = hchan->headnick->ProcessNext();
       if (!item) break;
       	wsprintf(line,"!1 %s|%s|%s|%d|%lu|%s",
				item->nick,item->addy,
				item->data?item->data:"",item->num,item->nicktype , item->msg?item->msg:" ");
       if (file_write(&hfile, line))  ++tnum;
		
	} //for nick 
	}

	if (!hchan->vnick.empty()) {
    for (vn = hchan->vnick.begin(); vn != hchan->vnick.end();vn++) {
       	wsprintf(line,"!2 %s|%s|%s|%d|%lu|%s",
			(*vn)->nick?(*vn)->nick:"",(*vn)->addy?(*vn)->addy:"",
				(*vn)->data?(*vn)->data:"",(*vn)->num,(*vn)->nicktype , (*vn)->msg?(*vn)->msg:"" );
       if (file_write(&hfile, line))  ++tnum;
		
	} //for nick 
	}
	if (hchan->litemc) {
	hchan->litemc->ProcessInit();
    for (;;) {
        item1 = hchan->litemc->ProcessNext();
       if (!item1)  break;
	   wsprintf(line,"#3 %s|%d|%s",item1->item,item1->property,item1->data?item1->data:"");
       if (file_write(&hfile, line))  ++tnum;
			
	} //for item
	}

} //for channel
	} //for network 


	}
	file_write(&hfile,"-------------Type for structure-----------");
	int count = 0;
	for ( ti = lttype.begin();(count < 2) && (ti != lttype.end()); ti++ ) 
		if ((*ti).table == pt)  {
			wsprintf(line,"/1 %d|%s|%s",(*ti).k,
				(*ti).shorttype,((*ti).shorttype != (*ti).longtype)?(*ti).longtype:"");
			file_write(&hfile, line);
			++count;
		} 
    for ( ni = lntype.begin();ni != lntype.end(); ni++ )
	{	
		if ((*ni).table == pt) {
			wsprintf(line,"/2 %s|%d|%s|%s",
				(*ni).net->network,(*ni).k,
				(*ni).shorttype,((*ni).shorttype != (*ni).longtype)?(*ni).longtype:"");
			file_write(&hfile, line);
		}
	}
    for ( ci = lctype.begin();ci != lctype.end(); ci++ )
	{
		if ((*ci).table == pt) {
			wsprintf(line,"/3 %s|%s|%d|%s|%s",
				(*ci).net->network,(*ci).chan->channel,(*ci).k,
				(*ci).shorttype,((*ci).shorttype != (*ci).longtype)?(*ci).longtype:"");
			file_write(&hfile, line);
		}
	}
	count = 0;
	for ( ti = lttype2.begin();(count < 2) && (ti != lttype2.end()); ti++ )
		if ((*ti).table == pt) {
			wsprintf(line,"/4 %d|%s|%s",(*ti).k,
				(*ti).shorttype,((*ti).shorttype != (*ti).longtype)?(*ti).longtype:"");
			file_write(&hfile, line);
			++count;

		}
    CloseHandle(hfile);
    wsprintf(data, "+OK %d", tnum);
    return 3;
}

MircFunc LoadTable (FUNCPARMS)
{
    char *tmp,*auxl,*auxb,buff[4096 + 1], line[MAXSTRINGLEN], aux[4096];
    DWORD  bytesread;
    unsigned int wpos = 0, totalread = 0, nline, bytestoread = 4096;
    register int itmp;
    HANDLE hfile;
	BOOL create;
	ptable current;
	pnetwork cnet;
	pchannel chan;

    tmp = data;
    hfile = NULL; 

	int err = currenttable(&tmp,&current);
	if (err) { msg_error(data,err); return 3; }

	if (!*tmp) 	r_err("FILE","Invalid File Name")
	switch (file_open_read(&hfile, tmp)) {
		case ERR_NICELIB_BADFILEBUFFER:
			r_err("FILE", "Invalid File")
		case ERR_NICELIB_COULDNTOPENFILE:
			r_err("OPEN", "Couldn't open file.")
		case ERR_NICELIB_FILENOTFOUND:
			r_err("NOFILE", "File not found or invalid")
	}  
    network_cleanup(current,TRUE);

    auxl = line;
    nline = 0;
    do {
        if (ReadFile(hfile, buff, bytestoread, &bytesread, NULL)) {
	        for (auxb = buff, itmp = 0;itmp < bytesread; auxb++, ++itmp) {
                if (*auxb == 10) {
                    *auxl = 0;
					// use !: nicks ; #:item table ,@ channel
                    if (++nline > 3) {
                        if (line[0] == '!') {
							if (line[1] == '1') {
								if (!nick_addB(line + 3 ,chan)) {
                         			++totalread;
								} 
							}
							else 
							if (line[1] == '2') {
								vnick_addB(line + 3 ,chan);
                         		totalread++;
							}
                        }
						else
                        if (line[0] == '#') {
							if (line[1] == '1') {
								if (!item_table_addB(line + 3 ,current)) {
                         			++totalread;
								} 
							}
							else
							if (line[1] == '2') {
								if (!item_net_addB(line + 3 ,current,cnet)) {
									++totalread;
								}
							}
							else
							if (line[1] == '3') {
								if (!item_channel_addB(line + 3,current,cnet,chan)) {
                         				 ++totalread;
								}
							}
                        }
						else
						if (line[0] == '/' ) { 
							if (line[1] == '1') type_table_add_dif(line + 3,TRUE,current);
							else 
								if (line[1] =='2') type_net_add_dif(line + 3,current);
								else
									if (line[1] == '3') type_chan_add_dif(line + 3,current);
									else
										if (line[1] == '4') type_table_add_dif(line + 3,FALSE,current);
						} 
						else
						if (line[0] == '~') {
							if (line[1] == '5') { 
								current->property = atolp(line + 3); 
							}
							else
								if (line[1] == '6') { 
									cnet->property = atolp(line + 3); 
								} 
								else 
									if (line[1] == '7') {
										chan->property = atolp(line + 3); 
									} 
						}
						else {
							if (line[0] == '[') {
						if (line[1] == '[') {

							if (line[2] == '[') {
							 lstrcpyn(aux,line,lstrlen(line) - 2);
							 if (channel_add(aux + 3,current,cnet,create)) 
								r_err("CHANNEL","Could Not create Channel")
								chan = pchannel(cnet->listchan->dltolast());
							} 
							else {
								lstrcpyn(aux,line,lstrlen(line) - 1);
								 if (network_add(aux + 2,current,create)) 
									r_err("NETWORK","Could Not create Network")
									cnet = pnetwork(current->listnet->dltolast());
							}
						} 	 				
							}  
																	 
						}  
                    } else { 
					 if (nline == 1) {
					   if (lstrcmp(line,"Nicedll : STructure")) {
                            CloseHandle(hfile);
                            r_err("OPTFILE", "Invalid File Structure")
                        }
					 }
                    }
                    auxl = line;
                } 
				else if (*auxb != 13) {
                    *auxl++ = *auxb;
                }
            }
        }
    } while (bytesread == bytestoread);
    CloseHandle(hfile);
    wsprintf(data, "+OK %d", totalread);
    return 3;
}
MircFunc LoadArray (FUNCPARMS)
{
	char *tmp,*para,*sname,*mname,*name,*auxl,buff[4096 + 1], line[MLEN],aux[MLEN],cbuf[BLEN];
	char *use,*auxb;
	unsigned int bytestoread = 4096,wpos,nline = 0;
    register int itmp;
	BOOL style = 0,beginadd = 0,removeline = 0,hschemes = 0;
    HANDLE hfile = NULL; 
    DWORD  bytesread;
	parray pt;
    tmp = data;
	mname = sname = 0;
	INTVECTOR::iterator i,j;

	int err = currentarrayfp(&tmp,&pt,&para);
	if (err) {
		if (para) delete para;
		msg_error(data,err); return 3; 
	}
	if (para) {
		style = find_para(para,'H');
		removeline = find_para(para,'C');
		if (find_para(para,'X')) {
			for (j = pt->Lang.begin();j != pt->Lang.end();j++) delete (*j);
			pt->Lang.clear();
			if (farray == pt) {	farray = NULL;	lresult.clear();	}
		}
		delete para;
	}
	auxl = getnexttokB(&tmp,'>'); if (!auxl || !*auxl) RETINVP
	name = new char[lstrlen(auxl) + 1];lstrcpy(name,auxl);
	auxl = getnexttokB(&tmp,'>');
	if (auxl && *auxl) {
		mname = new char[lstrlen(auxl) + 1];lstrcpy(mname,auxl); 
		auxl = getnexttokB(&tmp,'>');
		if (auxl && *auxl) {
			sname = new char[lstrlen(auxl) + 1];lstrcpy(sname,auxl); 
		}
		hschemes = TRUE;
	}
	else beginadd = 1;
	if (!style) {
		switch (file_open_read(&hfile,name)) {
			case ERR_NICELIB_BADFILEBUFFER:
				lstrcpy(data,"-FILE Invalid File");
				goto endfmts;
			case ERR_NICELIB_COULDNTOPENFILE:
				lstrcpy(data,"-FILE Couldn't open file.");
				goto endfmts;
			case ERR_NICELIB_FILENOTFOUND:
				lstrcpy(data,"-FILE File not found or invalid");
				goto endfmts;
		}  
    auxl = line; wpos = 0;
beginread:
    do {
        if (ReadFile(hfile, buff, bytestoread, &bytesread, NULL)) {
            for (auxb = buff, itmp = 0;itmp < bytesread; auxb++, ++itmp) {
                if (*auxb == 10) {
lastprocess:
 					*auxl = 0;
  					if (removeline) {
						for (char *ch = &line[0]; *ch && (*ch == 32); ch++);
						if ((*ch == 0) || (*ch == ';')) goto continueread;
					}
					if (hschemes && (line[0] == '[') && (line[wpos - 1] == ']')) {
						lstrcpyn(aux,line + 1,wpos - 1);
						if (beginadd) {
							if (beginadd == 2) { wpos = bytesread = 0; break; }
							if (sname) {
								if (!lstrcmpi(aux,sname)) beginadd = 2; 
								else if (beginadd != -2) beginadd = -1;
								else if (!lstrcmpi(aux,mname)) { 
									lstrcpy(data,"-Error couldn't Located scheme name");
									CloseHandle(hfile);
									goto endfmts;
								}
							}
							else { wpos = bytesread = 0; break; }
						}
						else if (!lstrcmpi(aux,mname)) beginadd = 1;
					}
					else if (beginadd == 1) {
						++nline;
						char * x = new char[wpos + 1];
						lstrcpy(x,line);
						pt->Lang.push_back(x);
					}
					else if (beginadd == 2) {
						auxl = line; use =  getword(&auxl);
						for (i = pt->Lang.begin(); i != pt->Lang.end();i++) {
							char * source = get_a_part(&cbuf[0],(char*)(*i),32);
							if (!lstrcmpi(cbuf,use)) {
								if (*source != 32) *source = 32; ++source;
								lstrcpy(source,auxl); 
								goto continueread;
							}
						}
						char * x = new char[wpos + 1];
						wsprintf(x,"%s %s",use,auxl);
						pt->Lang.push_back(x);
						++nline;
					}
continueread:
					auxl = line; wpos = 0;
                  } 
				else if (*auxb != 13) {
                    *auxl++ = *auxb; ++wpos;
                }

            }
        }
    } while (bytesread == bytestoread);
	if (wpos)  goto lastprocess; 
	if (beginadd == -1) {
		DWORD dwPtr = SetFilePointer (hfile, 0,0, FILE_BEGIN) ; 
		if (dwPtr == INVALID_SET_FILE_POINTER) { 
			lstrcpy(data,"-Error Invalid File Operation"); 
			CloseHandle(hfile);	goto endfmts;
		}
		else { beginadd = -2 ; goto beginread; }
	}
    CloseHandle(hfile);
	}
	else {
		wsprintf(mData,"$hget(%s)",name);
		if ((mIRC_evalute) && *mData) {
			for (int cc = 1;;cc++) {
				wsprintf(mData,"$hget(%s,%d).item",name,cc);
				if (mIRC_evalute) {
					if (*mData) {
						lstrcpy(line,mData);
						wsprintf(mData,"$hget(%s,%s)",name,line);
						mIRC_evalute;
						char * nx = new char[MLEN];
						wsprintf(nx,"%s %s",line,mData);
						pt->Lang.push_back(nx);
						++nline;
					}
					else break;
				}
				else { lstrcpy(data,"-ERROR couldn't Access Hash Table"); goto endfmts; }
			}
		}
		else { lstrcpy(data,"-ERROR Invalid Hash Table"); goto endfmts; }
	}
    wsprintf(data, "+OK %d",nline);
endfmts:
	delete name;
	if (mname) delete mname;
	if (sname) delete sname;
	return 3;
}
MircFunc GetArrayItem(FUNCPARMS)
{
	char *tmp = data;
	parray pt;
	int num = 0;

	int err = currentarray(&tmp,&pt);
	if (err) { msg_error(data,err); return 3; }

	if  (getfirstnum(&tmp,num,TRUE) < 0) RETINVP
	if ((pt->Lang.empty()) && (num)) RETNOLIST
	if (num < 0) { num += pt->Lang.size(); } 
	else
		if (num == 0 ) { nrnum_var(tmp,pt->Lang.size()); return 3; }
		else --num;
	if ((num < 0) || (num >= pt->Lang.size())) { 
		if (*tmp) Unsetvar(tmp);
		RETOoR
	}
	else r_var(tmp,pt->Lang[num])
	return 3;
}
MircFunc DelArrayItem(FUNCPARMS)
{
	char *tmp = data,Tbuf[100],T1buf[MLEN];
	parray pt;
	int num = 0,result,size,j;
	int err = currentarray(&tmp,&pt);
	if (err) { msg_error(data,err); return 3; }
	INTVECTOR::iterator i;
	int a[200];

	if ((pt->Lang.empty()) || (!*tmp)) RETNULL
	size = pt->Lang.size(); result = 2;
	T1buf[0] = 0;j = 0;
	while (result == 2) {
		result = getfirstnum(&tmp,num,TRUE);
		if (result > 0) {
			if (num < 0) { num += size; } 
			else --num;
			if ((num >= 0) && (num < size))  {
				a[j] = num; j++;
				if (j == 200) break;
			}
		}
	}
	j--;
	for (int k = 1;k <= j;k++)
		for (num = j; num >= k;--num) 
			if (a[num - 1] > a[num]) {
				result = a[num - 1];
				a[num - 1] = a[num];
				a[num] = result;
			}
	num = -1;
	for (k = 0;k <= j;k++) {
		if (num != a[k]) {
			num = a[k];
			i = pt->Lang.begin() + num - k;
			delete (*i);
			pt->Lang.erase(i);
			wsprintf(Tbuf,"%ld ",num + 1);
			lstrcat(T1buf,Tbuf);
		}
	}
	if (j >= 0)  { 
		wsprintf(data,"+OK %ld - %s",j + 1,T1buf);
		return 3;
	}
	else RETINVP
}

MircFunc ModArrayItem(FUNCPARMS)
{
	char *tmp = data;
	INTVECTOR::iterator i;
	parray pt;
	int num = 0;

	int err = currentarray(&tmp,&pt);
	if (err) { msg_error(data,err); return 3; }
	if ((pt->Lang.empty()) || (getfirstnum(&tmp,num,TRUE) < 0)) RETNULL
	if (num < 0) { num += pt->Lang.size(); } 
	else --num;
	if ((num < 0) || (num >= pt->Lang.size())) lstrcpy(data,"$FALSE");
	else {
		i = pt->Lang.begin() + num;
		copystr(&(*i),tmp);
		lstrcpy(data,"+OK");
	}
	return 3;
}
MircFunc InsArrayItem(FUNCPARMS)
{
	char *tmp = data,*aux;
	parray pt;
	int num = 0;
	INTVECTOR::iterator i;
	int err = currentarray(&tmp,&pt);
	if (err) { msg_error(data,err); return 3; }

	if (getfirstnum(&tmp,num) != HaveNumHaveToken) RETINVP
	if (num) {
		if (num < 0) { num += pt->Lang.size(); } 
		else --num;
	}
	if (num >= pt->Lang.size()) i = pt->Lang.end();
	else i = pt->Lang.begin() + num;
	aux = new char[lstrlen(tmp) + 1];
	lstrcpy(aux,tmp);
	pt->Lang.insert(i,aux);
	lstrcpy(data,"+OK");
	return 3;
}
MircFunc AddArrayItem(FUNCPARMS)
{
	char *aux;
	parray pt;
	char *tmp = data;

	int err = currentarray(&tmp,&pt);
	if (err) { msg_error(data,err); return 3; }
	if (!*tmp) r_err("PARA","Data is empty");
	aux = new char[lstrlen(tmp) + 1];
	lstrcpy(aux,tmp);
	pt->Lang.push_back(aux);
	lstrcpy(data,"+OK");
	return 3;
}

MircFunc CountArrayItem(FUNCPARMS)
{	
	parray pt;
	char *tmp = data;
	int err = currentarray(&tmp,&pt);
	if (err) { msg_error(data,err); return 3; }
	wsprintf(data,"%ld",pt->Lang.size());
    return 3;
}

/* input [first] [last] [@MVP] [command]
   type = 0 : fill para ,-2 : just value 
   mod = 0 : modify value
   last = -1 : to the end
*/

void array_inp(char **tmp,char **command,int &first,int &last,int &mod,int &type,LONG &count,char &sep)
{ 
	char *aux,*tmpbuf,buf[PLEN];
	last = -1;mod = -1;first = -1;type = -1; *command = NULL; sep = ' ';
	count = 0;
	UINT tm;

	if (getfirstnum(tmp,first) == HaveNumHaveToken)	
			getfirstnum(tmp,last);

	aux = *tmp;
	aux_getcommand(&aux,command);
	if (aux) {
		tmpbuf = creat_para("VMP[NUM]C[NUM]N[NUM]",aux + 1);
		if (take_para(tmpbuf,"P",&buf[0])) type = atolp(buf); 
		if (take_para(tmpbuf,"N",&buf[0])) count = atolp(buf); 
		if (find_para(tmpbuf,'V')) type = -2;
		if (find_para(tmpbuf,'M')) mod = 0;
		if (take_para(tmpbuf,"C",&buf[0])) { 
					tm = atolp(buf); 
					if ((tm <= 255) && (tm > 0)) sep = tm;
		}
		delete tmpbuf; 
	} 
}
MircFunc RArray(FUNCPARMS)
{	
	INTVECTOR::iterator i,j;
	int  first,last,mod,type,stmp;
	LONG count;
	char *command,*tmp = data,*aux = NULL;
	char buf[900];
	char sep = ' ';
	parray pt;

	int err = currentarray(&tmp,&pt);
	if (err) { msg_error(data,err); return 3; }

	if (pt->Lang.empty()) RETNULL
	array_inp(&tmp,&command,first,last,mod,type,count,sep);
	if ((!command) || ((!*command) && (mod < 0))) return 1;
	if (first > last) { stmp = first ; first = last ; last = stmp; }
	if (first <= 1) i = pt->Lang.begin();
	else 
		if (first <= pt->Lang.size()) i = pt->Lang.begin() + first - 1;
		else RETNULL
	if ((last == -1) || (last >= pt->Lang.size())) j = pt->Lang.end();
	else j = pt->Lang.begin() + last;
	while (i != j) {
		if  (mod == 0) {
			if (type == -2) copystr(&(*i),command);
			else {
				if (type == -1)  aux = eval_exp(command) ;
				else {
					lstrcpy(buf,(*i));
					getnthtok(buf,type);
					aux = eval_exp(command,buf,sep);
				}
				if (aux) {
					copystr(&(*i),aux);
					delete aux;
				}
			} 
		 } 
		 else
		if (command) {
			lstrcpy(buf,(*i));
			Docommand(command,buf,type,sep);
		}   
		i++;
	}
	return 1;
}
int find_array_item(char * data,parray * pa) 
{
	INTVECTOR::iterator i,j;
	int  first,last,mod,type,stmp,ydel,count = 0,isempty;
	LONG maxresult;
	char *command,*tmp = data,*aux = NULL;
	char buf[900];
	char sep = ' ';
	parray pt;

	int err = currentarray(&tmp,&pt);
	if (err) { msg_error(data,err); return 3; }

	if (pt->Lang.empty()) RETNULL
	array_inp(&tmp,&command,first,last,mod,type,maxresult,sep);
	isempty = *command?0:1;
	if ((!command) || ((isempty) && (type > -2))) RETINVP
	if (first > last) { stmp = first ; first = last ; last = stmp; }
	if (first <= 1) i = pt->Lang.begin();
	else 
		if (first <= pt->Lang.size()) {
			i = pt->Lang.begin() + first - 1;
			count = first - 1;
		}
		else RETINVNth
	if ((last == -1) || (last >= pt->Lang.size())) j = pt->Lang.end();
	else j = pt->Lang.begin() + last;
	lresult.clear();
	for (;i != j;i++,count++) {
		if (type == -2) {
			if (isempty) {
				if ((!*(*i)) || (*(*i) == 32)) ydel = 1;
				else ydel = 0;
			}
			else ydel = match(command,*i,FALSE);
		}
		else {
			if (type == -1) aux = eval_exp(command) ;
			else {
				lstrcpy(buf,(*i));
				getnthtok(buf,type);
				aux = eval_exp(command,buf,sep);
			}
			ydel = 0;
			if (aux) {
				switch (getfirstnum(aux,ydel)) {
					case HaveNumHaveToken:
						ydel = 1;
						break;
					case HaveTokenOnly:
						if (lstrcmpi(aux,"$false") && lstrcmpi(aux,"$null")) ydel = 1;
						break;
				}
				delete aux;
			}

		} 
		if (ydel) {
			lresult.push_back(count);
			if (maxresult == lresult.size()) break;
		}
	}
	*pa = pt;
	return 0;
}

MircFunc MarkArrayItem(FUNCPARMS) {
	parray pt;
	char *tmp = data;
	LONG num = 0,size;
	int result;
	vector<int>::iterator i;

	int b = isin_fpara(data,'x','X');
	int err = currentarray(&tmp,&pt);
	if (err) { msg_error(data,err); return 3; }

	if ((pt->Lang.empty()) || (!*tmp)) RETNULL
	size = pt->Lang.size(); result = 2;
	if (b) lresult.clear(); 
	farray = pt;
	while (result == 2) {
		result = getfirstnum(&tmp,num);
		if (result > 0) {
			if ((num > 0) && (num <= size)) {
				num--;
				for (i = lresult.begin();i != lresult.end();i++) 
					if (*i >= num) break;
				if (i == lresult.end()) lresult.push_back(num);
				else if (*i > num)	lresult.insert(i,num);	
			}
		}
	}
	r_ok("");
}
MircFunc FindArrayItem(FUNCPARMS) {
	parray pt;
	int b = isin_fpara(data,'x','X');
	int err = find_array_item(data,&pt);
	if (!err) {
		farray = pt;
		if (b) wsprintf(data,"%ld",lresult.size()); 
		else wsprintf(data, "+OK %ld",lresult.size()); 
		return 3;
	}
	else return err;
}

MircFunc DFArray(FUNCPARMS) {
	char *tmp = data,*aux,*tmpbuf,buf[BLEN];
	int mod,type,first,last,count,stmp,iaux;
	char sep = 32;
	vector<int>::iterator  i,j,k;
	INTVECTOR::iterator node;
	BOOL isdelete,cutok,islast,isfirst,isc;

	if ((!farray) || (lresult.empty())) RETNOLIST
	mod = type = -1; 
	isc = isdelete = cutok = first = last = isfirst = islast = 0;
	if (data[0] == '-') {
		aux =  getword(&tmp);
		tmpbuf = creat_para("MDXVP[NUM]G[NUM]C[NUM]N",aux + 1);
		if (take_para(tmpbuf,"P",&buf[0])) type = atolp(buf);
		else if (take_para(tmpbuf,"G",&buf[0])) type = atolp(buf);
		if (find_para(tmpbuf,'V')) type = -2;
		if (find_para(tmpbuf,'M')) mod = 0;
		if (take_para(tmpbuf,"C",&buf[0])) { 
					int tm = atolp(buf); 
					if ((tm <= 255) && (tm > 0)) sep = tm;
		}
		isdelete = find_para(tmpbuf,'D');
		cutok = find_para(tmpbuf,'X');
		isc = find_para(tmpbuf,'N');
		delete tmpbuf;
	}
	isfirst = getfirstnum(&tmp,first);
	if (isfirst > 0) {
		if (isfirst == HaveNumHaveToken) {
			islast = getfirstnum(&tmp,last);
			if ((islast > 0) && (first > last)) { stmp = first ; first = last ; last = stmp; }
		}
		isfirst = 1;
		if (!first) i = lresult.begin();
		else if (first <= lresult.size()) i = lresult.begin() + first - 1;
		else RETINVNth
		if (islast > 0) {
			islast = 1;
			if ((!last) || (last >= lresult.size())) j = lresult.end();
			else j = lresult.begin() + last;
		}
		else islast = 0;
	}
	else  { i = lresult.begin(); isfirst = 0; }
	if (isdelete) {
		if (isfirst ^ islast) {
			node = farray->Lang.begin() + (*i);
			delete (*node);	farray->Lang.erase(node);
			lstrcpy(data,"+OK");
		}
		else {
			if (!islast) j = lresult.end();
			count = 0; k = i;
			for (;i != j;i++,count++)  {
				node = farray->Lang.begin() + (*i) - count;
				delete (*node);	farray->Lang.erase(node);
			}
			lresult.erase(k,j);
			if (cutok)	 wsprintf(data,"%ld",count); 
			else wsprintf(data, "+OK %ld",count); 
		}
	}
	else {
		if (islast ^ isfirst) j = i + 1;
		else if (!isfirst) j = lresult.end();
		if (!mod) {
			iaux = ((type > -2) && (*tmp))?1:0;
			for (;i != j;i++)  {
				node = farray->Lang.begin() + (*i); 
				if (iaux) { 
					if (type == -1)  aux = eval_exp(tmp) ; 
					else {   
						lstrcpy(buf,*node);
						aux = eval_exp(tmp,buf,sep); 
					}  
					copystr(&(*node),aux); 
					if (aux)  delete aux;
				}	
				else copystr(&(*node),tmp); 
			}
			lstrcpy(data,"+OK");
		}
		else if (isc) {
			if (*tmp) {
				for (;i != j;i++)  {
					wsprintf(buf,"%ld",(*i) + 1);
					Docommand(tmp,buf,type,sep);
				}
				lstrcpy(data,"+OK");
			}
			else {
				if (cutok)	 wsprintf(data,"%ld",(*i) + 1); 
				else wsprintf(data, "+OK %ld",(*i) + 1); 
			}
		}
		else	{
			if (*tmp) {
				for (;i != j;i++)  {
					node = farray->Lang.begin() + (*i); 
					lstrcpy(buf,*node);
					Docommand(tmp,buf,type,sep);
				}
				lstrcpy(data,"+OK");
			}
			else {
				node = farray->Lang.begin() + (*i); 
				if (cutok)	 wsprintf(data,"%s",*node); 
				else wsprintf(data, "+OK %s",*node); 
			}
		}
	}
	return 3;
}
static int array_order(const void *p1, const void *p2)
{
	char *Item1,*Item2;
	int result;
	if ((!dfarray) && (!gbls_column)) {
		Item1 = (char *)p1;		Item2 = (char *)p2;
	}
	else {
		char buf1[MLEN],buf2[MLEN];
		lstrcpy(buf1,(char *)p1); Item1 = buf1;
		lstrcpy(buf2,(char *)p2); Item2 = buf2;
		if (gbls_column) {
			getnthtok(Item1,gbls_column,gbls_char);
			getnthtok(Item2,gbls_column,gbls_char);
		}
	}
	if (!dfarray) {
		if (!gbls_numeric) result = rfc_cmp(Item1,Item2); 
		else result = atols(Item1) - atols(Item2);
		return gbls_sorttype?-result:result;
	}
	else {
		if ((!*Item1) ||(!*Item2))  return 0;
		if (!replacecomma(Item1)) return 0;
		if (!replacecomma(Item2)) return 0;
		int num = 0;
		wsprintf(mData,"$%s(%s,%s)",dfarray,Item1,Item2);
		if (SendMessage(MIRC, WM_USER + 201,0,0))	{
			getfirstnum(mData,num,1);
			return gbls_sorttype?-num:num;
		}
		else return 0;
	}
}

static int array_qorder(const void *p1, const void *p2)
{
	LPVOID Item1 = *(char **)(p1);
	LPVOID Item2 = *(char **)(p2);
	return array_order(Item1,Item2);
}
void array_sort(parray pt) {
	LPVOID d1, d2;
    BOOL Sorting = TRUE;
	INTVECTOR::iterator i,j,k;

	while ( Sorting ) {
		Sorting = FALSE;
  		for (i = ib; i != je;i++) {
			j = i + 1;
			if (j == je) break;
			d1 = (*i); d2 = (*j);
			if (array_order(d1,d2) > 0) {
				Sorting = TRUE;
				(*i) = INTVECTOR::value_type(d2);
				(*j) = INTVECTOR::value_type(d1);
            }
		}
    }
}
int array_qsort(parray pt,int Count,int first) {

	INTVECTOR::iterator j;
	vector<int>::iterator k,begin = NULL;
    int i = 0,cp,cm = 0;
	LPVOID * Sort;

	Sort = new LPVOID [ Count  ];
	if (!Sort)  return 1;
	if ((farray) && (gbls_filter)) {
		first = first - 1;
		for (k = lresult.begin(); k != lresult.end();k++)
			if (*k >= first) { begin = k; break; }
		j = ib; 
		if (begin != NULL) cp = *k - first; else cp = -1;
		while (j != je) {
			if  (cp != cm) Sort[i++] = *j;
			else { 
				k++;
				if (k != lresult.end()) cp = *k - first;
				else cp = -1;
			}
			++j;++cm;
		}
		Count = i;
	}
	else for (j = ib;j != je;j++) Sort[i++] = *j;

	qsort(Sort,(size_t)Count,sizeof(LPVOID),array_qorder);
    i = 0;
	if ((farray) && (gbls_filter)) {
		j = ib; cm = 0;
		if (begin != NULL) { k = begin; cp = *k - first; } 
		else cp = -1;
		while (j != je) {
			if  (cp != cm) (*j) = INTVECTOR::value_type(Sort[i++]);
			else { 
				k++;
				if (k != lresult.end()) cp = *k - first;
				else cp = -1;
			}
			++j;++cm;
		}
	}
	else 
		for (j = ib;j != je;j++) 
            (*j) = INTVECTOR::value_type(Sort[i++]);
    delete[] Sort;
    return 0;
}

MircFunc SortArray(FUNCPARMS) {
	char *tmp = data,*aux,*tmpbuf,buf[PLEN];
	int  first = -1,last = -1,stmp,result = 1;
	parray pt = NULL;

	int err = currentarray(&tmp,&pt);
	if (err) { msg_error(data,err); return 3; }
	if (pt->Lang.empty()) RETNOLIST;
	if (getfirstnum(&tmp,first) == HaveNumHaveToken)	
			getfirstnum(&tmp,last);
	if (first > last) { stmp = first ; first = last ; last = stmp; }
	if (first <= 1) { ib = pt->Lang.begin(); first = 1; }
	else 
		if (first <= pt->Lang.size()) ib = pt->Lang.begin() + first - 1;
		else RETINVP
	if ((last == -1) || (last >= pt->Lang.size())) { je = pt->Lang.end(); last = pt->Lang.size(); }
	else je = pt->Lang.begin() + last;
	gbls_column = gbls_sorttype = gbls_filter = gbls_numeric = 0;
	gbls_char = 32; dfarray =  0;
	aux = tmp;
	aux_getcommand(&aux,&tmp);
	if (aux) {
		tmpbuf = creat_para("NC[NUM]DPF",aux + 1);
		if (take_para(tmpbuf,"C",&buf[0])) gbls_column = atolp(buf);
		if (find_para(tmpbuf,'D')) gbls_sorttype = 1;
		if (find_para(tmpbuf,'P')) result = 2;
		if (find_para(tmpbuf,'N')) gbls_numeric = 1;
		if (find_para(tmpbuf,'F')) gbls_filter = 1;
		delete tmpbuf; 
	} 
	if (gbls_column) {
		if (abs(getfirstnum(&tmp,gbls_char)) == 2) {
			dfarray = tmp;
			if ((gbls_char < 0) || (gbls_char > 255)) gbls_column = 0;
		}
	}
	else if (*tmp)  dfarray = tmp;
	if (((pt->Lang.size() > 100) && (result != 2)) || (gbls_filter)) result = array_qsort(pt,last - first + 1,first);
	if (result) array_sort(pt);
	lstrcpy(data,"+OK");
	return 3;
}
MircFunc DelMatchArrayItem (FUNCPARMS)
{
	vector<int>::iterator k;
	INTVECTOR::iterator st;
	parray pt;

	int b = isin_fpara(data,'x','X');
	int err = find_array_item(data,&pt);
	int count = 0;
	if (!err) {
		count = 0;
  		for ( k = lresult.begin(); k != lresult.end() ; k++)
		{
			st = pt->Lang.begin() + (*k) - count;
			delete (*st);
			pt->Lang.erase(st);
			++count; 
		}
		lresult.clear();
		if (b) wsprintf(data,"%ld",count); 
		else wsprintf(data, "+OK %ld",count); 
		return 3;
	}
	else return err;
}

MircFunc SaveArray (FUNCPARMS)
{
	#define MAX_LONG 2147483648
	char *tmp = data,*mname = 0,*name,*auxl,*auxb,buff[4096 + 1], line[MLEN];
	unsigned int bytestoread = 4096;
    register int itmp;
	BOOL beginadd = 0;
    HANDLE hfile = NULL; 
    DWORD  bytesread,Attribute = CREATE_ALWAYS,fSize,dwPtr;
	LONG Fpos,Lpos,Minus,wpos;
	parray pt;
	INTVECTOR::iterator i,j;
	LPVOID buf = 0;

	if (isin_fpara(data,'a','A')) Attribute = OPEN_ALWAYS;
	int err = currentarray(&tmp,&pt);
	if (err) {	msg_error(data,err); return 3; 	}

	auxl = getnexttokB(&tmp,'>'); if (!auxl || !*auxl) RETINVP
	name = new char[lstrlen(auxl) + 1];lstrcpy(name,auxl);
	auxl = getnexttokB(&tmp,'>');
	if (auxl && *auxl) {
		mname = new char[lstrlen(auxl) + 4];
		wsprintf(mname,"[%s]",auxl);
	}
	else beginadd = 1;
	hfile = CreateFile(name,GENERIC_READ | GENERIC_WRITE, 0, NULL, Attribute, FILE_ATTRIBUTE_NORMAL, NULL);
	if  (hfile == INVALID_HANDLE_VALUE) {
		lstrcpy(data,"-FILE Couldn't open/create file.");
		goto endfmts;
	}
	if ((GetLastError() == ERROR_ALREADY_EXISTS) && (Attribute == OPEN_ALWAYS)) { 
		fSize = GetFileSize (hfile, NULL) ; 
		if ((fSize == INVALID_FILE_SIZE) || (fSize >= MAX_LONG)) { lstrcpy(data,"File size is too big"); goto endfmts; }
		if (mname) {
			auxl = line; Lpos = 0;wpos = 0;
			do {
				if (ReadFile(hfile, buff, bytestoread, &bytesread, NULL)) {
					for (auxb = buff, itmp = 0;itmp < bytesread; auxb++, ++itmp) {
						if (*auxb == 10)  {
lastprocess:
							*auxl = 0;
							if ((line[0] == '[') && (line[wpos - 1] == ']')) {
								if (beginadd) { 
									Lpos += itmp - wpos - 1;
									beginadd = 2 ; goto finishwhile; 
								}
								else if (!lstrcmpi(line,mname)) {
									beginadd = 1;
									Fpos = Lpos + itmp - lstrlen(mname) - 1;
								}
							}
							auxl = line; wpos = 0;
						} 
						else if (*auxb != 13) {
							*auxl++ = *auxb; ++wpos;
						}
					}
					Lpos += bytesread;
				}
			} while (bytesread == bytestoread);
			if (wpos) { bytesread = 0; goto lastprocess; }
		finishwhile:
			if (!beginadd) { if (*auxb != 10) file_write(&hfile,""); }
			else if (beginadd == 1) {
				dwPtr = SetFilePointer (hfile, Fpos,0, FILE_BEGIN) ; 
				if (dwPtr == INVALID_SET_FILE_POINTER) { 
					lstrcpy(data,"-Error Invalid File Operation"); 
					goto endfmts;
				}
				SetEndOfFile(hfile);
			}
			else {
				dwPtr = SetFilePointer (hfile, Lpos,0, FILE_BEGIN) ; 
				if (dwPtr == INVALID_SET_FILE_POINTER) { 
					lstrcpy(data,"-Error Invalid File Operation"); 
					goto endfmts;
				}
				if (fSize > 1024 * 1024) {
					bytestoread = 1024 * 512;
					buf = smalloc(bytestoread);
				}
				if (!buf) { buf = buff; bytestoread = 4096; }
				Minus = Lpos - Fpos;
				do {
					if (ReadFile(hfile, buf, bytestoread, &bytesread, NULL)) {
						SetFilePointer (hfile, -Minus - bytesread ,0, FILE_CURRENT) ; 
						WriteFile(hfile,buf, bytesread, &dwPtr, NULL);
						if (bytesread == bytestoread) SetFilePointer (hfile, Attribute,0, FILE_CURRENT) ; 
						else SetEndOfFile(hfile);
					}
				} while (bytesread == bytestoread);
				file_write(&hfile,""); 
			}
		}
		else {
			SetFilePointer (hfile, 0,0, FILE_END) ; 
			file_write(&hfile,""); 
		}
	}
	if (!pt->Lang.empty()) {
		j = pt->Lang.end(); j--;
		if (mname) file_write(&hfile,mname);
		for (i = pt->Lang.begin();i != j;i++) file_write(&hfile,*i);
		WriteFile(hfile,*j, lstrlen(*j), &bytesread, NULL);
	}
	lstrcpy(data,"+OK");
endfmts:
    if  (hfile != INVALID_HANDLE_VALUE) CloseHandle(hfile);
	delete name;
	if (mname) delete mname;
	return 3;
}

MircFunc DLLInfo (FUNCPARMS)
{
  MessageBox (mWnd , DLLINFO , "NICE DLL" , MB_OK | MB_ICONINFORMATION );
  return 1;
}
MircFunc Version (FUNCPARMS)
{
	lstrcpy(data,VERSION);
	return 3;
}

MircFunc MTSPreCompile (FUNCPARMS)
{
	char *tmp,*auxl,*use,*ms,sname[BLEN],name[BLEN],*auxb,buff[4096 + 1], line[MLEN], aux[4096];
	char * color = 0,*comm = 0,*cstore = 0, *pstore = 0;
    DWORD  bytesread;
    unsigned int bytestoread = 4096,len;
    register int itmp;
    HANDLE hfile;
	BOOL beginadd = 0,removeline = 0;
	ListPointer::iterator i;
	ListPointer process;
	int j = 0,kk = 0,wpos;
	char style = 'F',style2 = 'F';

    tmp = data;
    hfile = NULL; 
	ccolor[0][1] = 0;ccolor[1][1] = 0; ccolor[2][1] = 0;
	ccolor[3][1] = 0;cprefix[0] = '*';  cprefix[1] = 0; 
	cprefixlen = 1; sname[0] = 0; cAddColor = 0;

	auxl = getnexttokB(&tmp,'>');
	if (!auxl || !*auxl) 	r_err("FILE","Invalid File Name")
	if (auxl[0] == '@') {
		CharUpper(auxl); ++auxl;
		if (*auxl) { 
			style = *auxl++;
			if (*auxl) style2 = *auxl++;
			if (isincs(auxl,'S')) {
				use = getnexttokB(&tmp,'>'); if (!use || !*use) RETINVP
				lstrcpy(sname,use);
			}
			if (isincs(auxl,'C')) removeline = 1;
			if (isincs(auxl,'N')) cAddColor = 1;
		}
		auxl = getnexttokB(&tmp,'>'); if (!auxl || !*auxl) RETINVP
	}
	lstrcpy(name,auxl);
	auxl = getnexttokB(&tmp,'>');
	if (!auxl || !*auxl) { lstrcpy(data,"-Error your Action ?"); return 3; }
	else { comm = new char[lstrlen(auxl) + 1]; lstrcpy(comm,auxl); }
	auxl = getnexttokB(&tmp,'>');
	if (auxl && *auxl) { color = new char[lstrlen(auxl) + 20]; lstrcpy(color,auxl); kk = 4; }
	if (*tmp) { lstrcpy(cprefix,tmp); ++kk;	}
	if (style == 'F') {
		switch (file_open_read(&hfile,name)) {
			case ERR_NICELIB_BADFILEBUFFER:
				lstrcpy(data,"-FILE Invalid File");
				goto endfmts;
			case ERR_NICELIB_COULDNTOPENFILE:
				lstrcpy(data,"-FILE Couldn't open file.");
				goto endfmts;
			case ERR_NICELIB_FILENOTFOUND:
				lstrcpy(data,"-FILE File not found or invalid");
				goto endfmts;
		}  
    auxl = line;wpos = 0;
beginread:
    do {
        if (ReadFile(hfile, buff, bytestoread, &bytesread, NULL)) {
            for (auxb = buff, itmp = 0;itmp < bytesread ; auxb++, ++itmp) {
                if (*auxb == 10) {
lastprocess:
                    *auxl = 0;
					if (removeline) {
						for (char *ch = &line[0]; *ch && (*ch == 32); ch++);
						if ((*ch == 0) || (*ch == ';')) goto continueread;
					}
					if ((line[0] == '[') && (line[wpos - 1] == ']')) {
						lstrcpyn(aux,line + 1,wpos - 1);
						if (beginadd) {
							if (beginadd == 2) { wpos = bytesread = 0; break; }
							if (sname[0] != 0) {
								if (!lstrcmpi(aux,sname)) beginadd = 2; 
								else if (beginadd != -2) beginadd = -1;
								else if (!lstrcmpi(aux,"MTS")) { 
									lstrcpy(data,"-Error couldn't Located scheme name");
									CloseHandle(hfile);
									goto Errorfmts;
								}
							}
							else { wpos = bytesread = 0; break; }
						}
						else if (!lstrcmpi(aux,"MTS")) beginadd = 1;
					}
					else if (beginadd == 1) {
						char * x = new char[MLEN];
						lstrcpy(x,line);
						process.push_back(x);
						if (j < 5) { 
							auxl = line; use = getword(&auxl);
							if ((j < 2) && (!lstrcmpi(use,"BaseColors"))) {
								if (kk < 2) {
									color = new char[lstrlen(auxl) + 20];
									lstrcpy(color,auxl);
								}
								cstore = x;j = 4;
							}
							if ((j != 1) && (!lstrcmpi(use,"PREFIX"))) { if ((kk != 1) && (kk != 5)) lstrcpy(cprefix,auxl); ++j; pstore = x; }
						}
					}
					else if (beginadd == 2) {
						auxl = line; use =  getword(&auxl);
						for (i = process.begin(); i != process.end();i++) {
							char * source = get_a_part(&sname[0],(char*)(*i),32);
							if (!lstrcmpi(sname,use)) {
								if (*source != 32) *source = 32; ++source;
								lstrcpy(source,auxl); ms = (char *)(*i);
backcheck:
								if (j < 10) { 
									if ((j < 9) && (!lstrcmpi(use,"BaseColors"))) {
										if (kk < 2) {
											if (j < 2) color = new char[lstrlen(auxl) + 20];
											lstrcpy(color,auxl);
										}
										if (j < 2) cstore = ms; 
										if (j == 7) j = 10; else j = 9;
									}
									if ((j != 7) && (!lstrcmpi(use,"PREFIX"))) { 
										if ((kk != 1) && (kk != 5)) lstrcpy(cprefix,auxl);
										pstore = ms; 
										if (j == 9) ++j ; else j = 7; 
									}
								}
								goto continueread;
							}
						}
						ms = new char[MLEN];
						wsprintf(ms,"%s %s",use,auxl);
						process.push_back(ms);
						goto backcheck;
					}
continueread:
					auxl = line;wpos = 0;
                  } 
				else if (*auxb != 13) {
                    *auxl++ = *auxb; wpos++;
                }
            }
        }
    } while (bytesread == bytestoread);
	if (wpos) goto lastprocess;
	if (beginadd == -1) {
		DWORD dwPtr = SetFilePointer (hfile, 0,0, FILE_BEGIN) ; 
		if (dwPtr == INVALID_SET_FILE_POINTER) { 
			lstrcpy(data,"-Error Invalid File Operation"); 
			goto Errorfmts;
		}
		else { beginadd = -2 ; goto beginread; }
	}
    CloseHandle(hfile);
	}
	else if (style == 'H') {
		wsprintf(mData,"$hget(%s)",name);
		if ((mIRC_evalute) && *mData) {
			for (int cc = 1;;cc++) {
				wsprintf(mData,"$hget(%s,%d).item",name,cc);
				if (mIRC_evalute) {
					if (*mData) {
						lstrcpy(line,mData);
						wsprintf(mData,"$hget(%s,%s)",name,line);
						mIRC_evalute;
						char * nx = new char[MLEN];
						wsprintf(nx,"%s %s",line,mData);
						process.push_back(nx);
						if (j < 5) {
							if ((j < 2) && (!lstrcmpi(line,"BaseColors"))) {
								if (kk < 2) {
								color = new char[lstrlen(mData) + 20];
								lstrcpy(color,mData);
								}
								cstore = nx;j = 4;
							}
							if ((j != 1) && (!lstrcmpi(line,"PREFIX"))) { 
								if ((kk != 1) && (kk != 5)) lstrcpy(cprefix,mData); ++j; pstore = nx;
							}
						}
					}
					else break;
				}
				else { lstrcpy(data,"-ERROR couldn't Access Hash Table"); goto Errorfmts; }
			}
		}
		else { lstrcpy(data,"-ERROR Invalid Hash Table"); goto endfmts; }
	}
	else { lstrcpy(data,"-ERROR Invalid Style(H or F)"); goto endfmts; }
	if (color) {
		auxl = color;
		for (j = 0;j < 4;j++) {
			use = getnexttokB(&auxl,','); len = lstrlen(use) ;
			if (isnum(use,FALSE) && ((len <= 2) && (len > 0))) {
				if (len == 1) { ccolor[j][0] = '0'; lstrcat(ccolor[j],use); }
				else lstrcpy(ccolor[j],use);
			}
			else { lstrcpy(data,"-Error BaseColors"); goto Errorfmts; }
		}
		int cj = 0;
		for (j = 0;j < 4;j++) { 
			color[cj++] = ccolor[j][0];
			color[cj++] = ccolor[j][1];
			color[cj++] = ',';
		}
		color[--cj] = 0;
		if (!cstore) {
			cstore = new char[30];
			process.push_back(cstore);
		}
		wsprintf(cstore,"BASECOLORS %s",color);
	}
	if (!pstore) { pstore = new char[10]; process.push_back(pstore); }
	else {	
		Npc_variable(cprefix,0); cprefixlen = lstrlen(cprefix);
	}
	wsprintf(pstore,"PREFIX %s",cprefix);

	if (style2 == 'F') {
		switch (file_open_write(&hfile,comm)) {
			case ERR_NICELIB_BADFILEBUFFER:
				lstrcpy(data,"-FILE Invalid File");
				goto endfmts;
			case ERR_NICELIB_COULDNTOPENFILE:
				lstrcpy(data,"-FILE Couldn't open file.");
				goto endfmts;
		} 
	}
	else if (style2 == 'H') {
		wsprintf(mData,"$hget(%s)",comm);
		if ((!(mIRC_evalute)) || !*mData) {
			lstrcpy(data,"-ERROR Invalid Hash Table"); goto Errorfmts;
		}
	}
	for (i = process.begin(); i != process.end();i++) {
		Npc_variable((char*)(*i),0);
		if (style2 == 'F') { file_write(&hfile,(char*)(*i)); }
		else if (style2 == 'H') {
			wsprintf(mData,"/Hadd %s %s",comm,(char*)(*i));
			SendMessage(MIRC, WM_USER + 200,0,0);
		}
		else {
			lstrcpy(Paratransfer,(char*)(*i));
			lstrcpy(buff,comm);
			if (Npc_eval(buff,' ',FALSE)) {
				lstrcpy(mData,buff);
				SendMessage(MIRC, WM_USER + 200,0,0);
			}
		}
		delete ((char*)(*i));
	}
	if (style2 == 'F') CloseHandle(hfile);
	process.clear();
    lstrcpy(data, "+OK");
	goto endfmts;
Errorfmts:
	for (i = process.begin(); i != process.end();i++) {
		delete ((char*)(*i));
	}
	process.clear();
endfmts:
	if (color) delete color;
	return 3;
} 

void scandir(char *dir,char *sdir,char *adir,int depth)
{
	char searchdir[500];
	char ssearchdir[500];
	char asearchdir[500];
	char output[MLEN],buf[MLEN];
	UINT64 size;

	wsprintf(searchdir,"%s\\*",dir);
    WIN32_FIND_DATA finddata;
	HANDLE hfind = FindFirstFile(searchdir,&finddata);

	if (hfind != INVALID_HANDLE_VALUE)
		do
		{ 
			if ((!lstrcmp(finddata.cFileName,".")) || (!lstrcmp(finddata.cFileName,".."))) { continue; }
			else if (finddata.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			{
				if (depth == gbl_maxdepth) continue;
				wsprintf(searchdir,"%s\\%s",dir,finddata.cFileName);
				
				if ((finddata.cAlternateFileName)[0]) wsprintf(ssearchdir, "%s\\%s", sdir, finddata.cAlternateFileName);
				else wsprintf(ssearchdir, "%s\\%s", sdir, finddata.cFileName);
							
				if (strstr(finddata.cFileName,"  ")) wsprintf(asearchdir, "%s\\%s", adir, finddata.cAlternateFileName);
				else wsprintf(asearchdir, "%s\\%s", adir, finddata.cFileName);
				scandir(searchdir, ssearchdir, asearchdir,++depth);
			}
			else
			{
				BOOL doexclude = FALSE;
				int type = 0;
				char * temp;
				if ((finddata.cAlternateFileName)[0]) temp = finddata.cAlternateFileName;
				else temp = finddata.cFileName;
                while (*temp && (*temp != '.')) ++temp;
				char * last = temp;
				if (*last) {
					last++;
					for (int i = 0; i != gbl_numberoftypes; i++)
					if (!lstrcmpi(gbl_types[i],last)) { type = i+1; break; }
					if (!type) {
						for (i = 0; i != gbl_numberofexclude; i++)
						if (!lstrcmpi(gbl_exclude[i],last)) { doexclude = TRUE; break; }
					}
				}
				if ((type || gbl_ALL) && !doexclude)
				{
					size = UInt32x32To64(finddata.nFileSizeHigh, MAXDWORD);
					size += finddata.nFileSizeLow;
					gbl_bytes += size;
					gbl_files++;
					switch(abs(gbl_format)) {
						case 1: { wsprintf(buf,"%s>%s",sdir,finddata.cAlternateFileName[0]?finddata.cAlternateFileName:finddata.cFileName); break; }
						default: { wsprintf(buf,"%s>%s",adir,(strstr(finddata.cFileName,"  ")&& finddata.cAlternateFileName[0])?finddata.cAlternateFileName:finddata.cFileName); break; }
					}
					if (gbl_format < 0) wsprintf(output,"%s>%s",buf,finddata.cFileName);
					else lstrcpy(output,buf);
					if (gbl_command) {
						wsprintf(Paratransfer,"%s>%ld>%d",output,size,type);
						lstrcpy(gbl_buffer,gbl_command);
						if (Npc_eval(gbl_buffer,'>',FALSE)) {
							lstrcpy(mData,gbl_buffer);
							SendMessage(MIRC, WM_USER + 200,0,0);
						}
					}
					if (gbl_saveff) {
						wsprintf(buf,"%s>%ld>%d",output,size,type);
						char * auxh = new char[lstrlen(buf) + 1];
						lstrcpy(auxh,buf);
						gbl_listname->Lang.push_back(auxh);
 					}
				}
			}
		} while (FindNextFile(hfind, &finddata)); 
	FindClose(hfind);
}
MircFunc FindFile(FUNCPARMS)
{
	char dir[500],sdir[BLEN];
	char *tmp = data;
	char *aux,*fx,*auxx;
	BOOL create;
	INTVECTOR::iterator j;

	aux = getnexttokB(&tmp,'>');
	if (aux && *aux)  gbl_command = aux; 
	else gbl_command = 0;

	aux = getnexttokB(&tmp,'>');
	gbl_format = 0; gbl_maxdepth = 0;gbl_saveff = 0;
	gbl_listname = 0;
	if (aux && *aux) {
		aux = creat_para("ASOD[NUM]",aux);
		if (find_para(aux,'S')) {
			gbl_format = 1;
			if (find_para(aux,'O')) gbl_format = -gbl_format;
		}
		if (take_para(aux,"D",&sdir[0])) gbl_maxdepth = atolp(sdir); 
		if (find_para(aux,'A')) {
			gbl_saveff = 1;
			auxx = getnexttokB(&tmp,'>');
			if (!auxx || !*auxx) ret("-PARA insufficient parameters")
		}
		if (aux) delete aux;
	}
	if ((!gbl_command) && !(gbl_saveff)) ret("-PARA must enter an alias or choose fill array option");
	aux = getnexttokB(&tmp,'>');
	if (aux && *aux) lstrcpy(dir,aux);
	else {
		lstrcpy(mData,"$scriptdir");
		if (SendMessage(MIRC, WM_USER + 201,0,0)) lstrcpy(dir,mData);
		else { ret("-PARA insufficient parameters"); }
	}
	UINT dirlen = UINT(lstrlen(dir));
	if (dir[dirlen-1] == '\\')   dir[--dirlen] = 0; 
	if (!GetShortPathName(dir, sdir, 255))  sdir[0] = 0;
	aux = getnexttokB(&tmp,'>');
	gbl_numberoftypes = 0;
	if (aux && *aux) {
		gbl_ALL = 0;
	 	fx = getnexttok(&aux,'|');
		do {
			if (!lstrcmp(fx, "*")) gbl_ALL = TRUE;
			lstrcpy(gbl_types[gbl_numberoftypes],fx);
			gbl_numberoftypes++;
			fx = getnexttok(&aux,'|');
		} while (*fx);
	}
	else gbl_ALL = 1 ;
	aux = tmp;
	if (*aux == '>') aux++ ;

	gbl_numberofexclude = 0;
	if (aux && *aux) {
		while (gbl_numberofexclude <= 100)
		{
			fx = getnexttok(&aux,'|');
			if (!*fx) break;
			lstrcpy(gbl_exclude[gbl_numberofexclude],fx);
			gbl_numberofexclude++;
		}
	}
    gbl_files = 0;  gbl_bytes = 0;
	if (gbl_command) gbl_buffer = new char [2000] ;
	if (gbl_saveff) { 
		array_add(auxx,create); 
		gbl_listname = f_arraynode(auxx);
		assert(gbl_listname);
		if (!create) {
			for (j = gbl_listname->Lang.begin();j != gbl_listname->Lang.end();j++) delete (*j);
			gbl_listname->Lang.clear();
			if (farray == gbl_listname) {	farray = NULL;	lresult.clear(); }
		}
	}
	scandir(dir, sdir, dir,1);
	if (gbl_command) delete gbl_buffer;
	wsprintf(data, "+OK %d %I64i", gbl_files, gbl_bytes);
	return 3;
}