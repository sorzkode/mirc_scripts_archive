/*
 * NICELIB.h 
 * File header of nicelib.cpp
 * Copyright (C) 2003-2004 Niceboy-DvD
 *
*/

#ifndef _NICELIB_H_
#define _NICELIB_H_

#ifdef __cplusplus
extern "C" {
#endif


#ifdef NICELIB_USE_TIME
	#include <time.h>
#endif


/*
 * #defines & typedefs
 */

#define ERR_NICELIB_BADFILEBUFFER   1
#define ERR_NICELIB_COULDNTOPENFILE 2
#define ERR_NICELIB_FILENOTFOUND    3
#define BLEN 255

typedef unsigned char tbool;
typedef unsigned int hash_t;

/*
 * Prototypes
 */
char *cmalloc (int);
void *smalloc (int);
tbool mfree (void *);
char *getword (char **);
char *getnexttok (char **, int);
char *getnexttokB (char **, int );
int findpostok (char *, char *);
char *creat_para(char *psource,char *pst,const BOOL upsource = FALSE);
int take_para(char *psource,char *pst1,char *result,const BOOL notcs = FALSE);
void SendMirc(char *st,int num);
void nicelib_onload ();
int atolp (char *);
tbool isnum (char *, int);
tbool isincs (char *, char);
unsigned int countchar (char *, int);
char *removechar (char *, int);
char *removelf (char *);
char *mirchar (char *);
unsigned int now ();
tbool ishostmask (register char *);
int match (register char *m, register char *n, const BOOL cs = FALSE);
tbool iswm (char *, char *);
tbool iswmcs (char *, char *);
hash_t myhash (char *);
hash_t rfchash (char *);
tbool isfile (char *);
char *file_get (char *);
int file_open_read (HANDLE *, char *);
int file_open_write (HANDLE *, char *);
tbool file_write (HANDLE *, char *);
void cmdrun (char *, char *);
char *fixpath (char *, char *, char *);
int rfc_cmp (char *, char *);
int rfc_tolower (int);
int rfc_toupper (int);
char *rfc_strtoupper (char *);
char *rfc_strtolower (char *);
int msetbit(unsigned long int &num,unsigned int pos);
void str_to_type(char *source, char *str , unsigned long int &num);
void type_to_str(char *source,char **str , unsigned long int num);
void getnthtok (char *p,int num,const char sep = ' ');
int find_para(char *source, char pt); 
int numtok (char *p,const char sep = ' ');
BOOL isind (char *pal, char up,char lo);
char * get_af_para(char ** data,char yw,const BOOL cs = FALSE);
void getmidtok (char **p,int num,const int finish = 0,const char sep = ' ');
void getmidtokB (char **p,int num,const int finish = 0,const char sep = ' ');
char *getpnthtok (char *p,char * head,int postok,int numtok, int c);
int isin_fpara(char * data,char lc,char hc);
int isin_fcpara(char ** data,char lc,char hc);
int atols(char *p);
char *getpretok (char **p,char * head, int c);
char * get_a_part(char *dest, char *src, char chr); 

#ifdef __cplusplus
}
#endif

#endif /* _NICELIB_H_ */

