/*
 * NICELdll.h
 * File header of nicedll.cpp
 * Copyright (C) 2003-2004 Niceboy-DvD
 *
 */

#include "common.h"
#include "ttree.h"
#include "LinkedList.h"

/* 
 * type
 */
typedef list<LPVOID> ListPointer;
class SubType;


/*
 * Classes
 */

class NickNode
{
public:
    NickNode()    { 
		nick = NULL; addy = NULL; msg = NULL;data = NULL;
		nicktype = 0;		num = 0;
	}
    NickNode(char *pnick, char *paddy, char *ptype, char *pmsg, unsigned int pnum,DWORD pnicktype)
    {
        nick = new char[lstrlen(pnick) + 1];
        lstrcpy(nick, pnick);
        addy = new char[lstrlen(paddy) + 1];
        lstrcpy(addy, paddy);
		if ((ptype) && (*ptype)) {
			data = new char[lstrlen(ptype) + 1];
			lstrcpy(data, ptype);
		}
		else data = NULL;
        msg = new char[lstrlen(pmsg) + 1];
        lstrcpy(msg, pmsg);
        num = pnum;
		nicktype = pnicktype;
    }
    ~NickNode()
    {
        if (nick) delete nick;
        if (addy) delete addy;
        if (data) delete data;
        if (msg)  delete msg;
		nick = NULL; addy = NULL; data = NULL; msg = NULL;
    }
    void assign(char *paddy, char *ptype,
      char *pmsg, unsigned int pnum,DWORD numtype)
    {
		if (addy) delete addy;
		if (msg)  delete msg;
		if (data) delete data;
        addy = new char[lstrlen(paddy) + 1];
        lstrcpy(addy, paddy);
        if ((ptype) && (*ptype)) {
			data = new char[lstrlen(ptype) + 1];
			lstrcpy(data, ptype);
		} 
		else  data = NULL;
		msg = new char[lstrlen(pmsg) + 1];
        lstrcpy(msg, pmsg);
        num = pnum;
		nicktype = numtype;
	}
    void NickNode2(char *pnick, char *paddy, char *ptype, char *pmsg, unsigned int pnum,DWORD pnicktype)
    { 
		if ((pnick) && (*pnick)) {
			nick = new char[lstrlen(pnick) + 1];
			lstrcpy(nick, pnick);
		}
		if ((paddy) && (*paddy)) {
			addy = new char[lstrlen(paddy) + 1];
			lstrcpy(addy, paddy);
		}
		if ((ptype) && (*ptype)) {
			data = new char[lstrlen(ptype) + 1];
			lstrcpy(data, ptype);
		}
		if ((pmsg) && (*pmsg)) {
			msg = new char[lstrlen(pmsg) + 1];
			lstrcpy(msg, pmsg);
		}
        num = pnum;
		nicktype = pnicktype;
    }
    void assign2(char *pnick, char *paddy, char *ptype, char *pmsg, unsigned int pnum,DWORD pnicktype)
    { 
		if (nick) delete nick;
        if (addy) delete addy;
        if (data) delete data;
        if (msg)  delete msg; 
		nick = NULL; addy = NULL; data = NULL; msg = NULL;
		if ((pnick) && (*pnick)) {
			nick = new char[lstrlen(pnick) + 1];
			lstrcpy(nick, pnick);
		}
		else nick = NULL;
		if ((paddy) && (*paddy)) {
			addy = new char[lstrlen(paddy) + 1];
			lstrcpy(addy, paddy);
		}
		else addy = NULL;
		if ((ptype) && (*ptype)) {
			data = new char[lstrlen(ptype) + 1];
			lstrcpy(data, ptype);
		}
		else data = NULL;
		if ((pmsg) && (*pmsg)) {
			msg = new char[lstrlen(pmsg) + 1];
			lstrcpy(msg, pmsg);
		}
		else msg = NULL;
        num = pnum;
		nicktype = pnicktype;
    }
   	char *nick, *addy, *data, *msg;
    unsigned int num;
	DWORD nicktype;
};
class ItemNode {
public:
	char *item;
	char *data;
	DWORD property;
	ItemNode() { item = NULL; data = NULL;property = 0; }
	~ItemNode()
	{
		if (item) delete item;
		if (data) delete data; 
	}
	ItemNode(char *pitem, char *pdata,DWORD num)
    {
        item = new char[lstrlen(pitem) + 1];
        lstrcpy(item, pitem);
        data = new char[lstrlen(pdata) + 1];
        lstrcpy(data, pdata);
		property = num;
	} 
  	void assign (char *pdata,DWORD num)
    {
		if (data)  delete data;
		 data = new char[lstrlen(pdata) + 1];
        lstrcpy(data, pdata);
		property = num;
	}
 	void assign (char *pdata)
    {
		if (data)  delete data;
		if (pdata) {
			data = new char[lstrlen(pdata) + 1];
			lstrcpy(data, pdata);
		}
		else data = NULL;
	}
};
class ItemClass : public CTTree<ItemNode> {
public:
    static int ItemClass_comparenicks(const ItemNode *i1, const ItemNode *i2)
	{
		return rfc_cmp(i1->item, i2->item);
	}
	ItemClass() : CTTree<ItemNode>(ItemClass_comparenicks)
    {};
    ~ItemClass(void)
    {};
	ItemNode * Add(char* pitem, char* pdata,DWORD num);
	ItemNode * FindNodeNum(long number);
	ItemNode * PDelete(char *pitem);
	ItemNode * AddType(char* pitem,DWORD numtype,BOOL overwrite);
	ItemNode * Find(char *pitem);
	int FindNum(char *pitem);
    BOOL Delete(char *pitem);
};
class NickClass : public CTTree<NickNode>
{
public:
    static int NickClass_comparenicks(const NickNode *i1, const NickNode *i2)
	{
		return rfc_cmp(i1->nick, i2->nick);
	}
   
    NickClass() : CTTree<NickNode>(NickClass_comparenicks)
    {};
    ~NickClass(void)
    {};
	NickNode* Add(char* pnick, char* paddy, char* ptype, char* pmsg, unsigned int num, DWORD numtype);
	NickNode* AddType(char* pnick,DWORD numtype,BOOL overwrite);
	int AddOther(SubType *x,char *pnick,char *ptype, char *data);
	NickNode * FindNickNum(long number);
    NickNode* Find(char *nick);
    BOOL Delete(char *nick);
};

typedef struct {
    DWORD mVersion;
    HWND mHwnd;
    BOOL mKeep;
} LOADINFO;

typedef struct {
	DWORD property;
    char *name;
    hash_t id;
} BasicNode ;
typedef vector<NickNode*> VectorNick;

class ChanClass {
public:
    NickClass *headnick;
	ItemClass *litemc;
	VectorNick vnick;
	DWORD property;
    char *channel;
    hash_t hash;
	~ChanClass() {
		if (headnick) 	headnick->Destroy();	
		if (litemc) litemc->Destroy();
		delete channel;
	}
	ChanClass(char *chan) {
		channel = new char[lstrlen(chan) + 1];
		lstrcpy(channel, chan);
		headnick = NULL;
		litemc = NULL;
		property = 0;
	}
	ChanClass() {
		channel = NULL;		headnick = NULL;
		litemc = NULL;		property = 0;
	}
};

class  NetClass {
public:
	ItemClass *litemn;
	CLinkedList * listchan;
	char *network;
	DWORD property;
	hash_t hash;
	~NetClass() {
		if (litemn) litemn->Destroy();
		delete network;
	}
	NetClass(char *net)
	{
		network = new char[lstrlen(net) + 1];
		lstrcpy(network, net);
		litemn = NULL;
		property = 0;
		listchan = NULL;
	}
	NetClass() {
		network = NULL; litemn = NULL;
		property = 0;	listchan = NULL;
	}
};

class  TableClass {
public:
	ItemClass *litemt;
	CLinkedList * listnet;
	char* table;
	DWORD property;
	hash_t hash;
	~TableClass() {
		if (litemt) litemt->Destroy();
		delete table;
	}
	TableClass(char *pt) {
		table = new char[lstrlen(pt) + 1];
		lstrcpy(table, pt);
		litemt = NULL;
		property = 0;
		listnet = NULL;
	}
	TableClass() {
		table = NULL;	litemt = NULL;
		property = 0;	listnet = NULL;
	}
};
class TArrayClass {
public:
	INTVECTOR Lang;
	DWORD property;
    char *arrayname;
    hash_t hash;
	~TArrayClass() {
		delete arrayname;
		INTVECTOR::iterator i;
		for (i = Lang.begin();i != Lang.end();i++) delete (*i);
		Lang.clear();
	}
	TArrayClass(char *array) {
		arrayname = new char[lstrlen(array) + 1];
		lstrcpy(arrayname,array);
		property = 0;
	}
	TArrayClass() {
		arrayname = NULL; property = 0;
	}
};
typedef TArrayClass* parray;
typedef NetClass* pnetwork;
typedef ChanClass* pchannel;
typedef TableClass *ptable;

class CurNode {
public:
	CurNode() {  chan = NULL; net = NULL; table = NULL;array = NULL;	}
	~CurNode() { chan = NULL; net = NULL; table = NULL;array = NULL;	}
	parray array;
	pchannel chan;
	pnetwork net;
	ptable table;
};

typedef map<int,CurNode> MapCurNode;
enum kind { nitem ,sdata , ndata} ;

class SubType  {
public:
	char *shorttype;
	char *longtype;
	~SubType() { 
		if ((shorttype == longtype) && (shorttype)) delete shorttype;
		else {
			if (shorttype)  delete shorttype; 
			if (longtype) delete longtype;
		}
	}
	SubType(){ longtype = NULL ; shorttype = NULL; k = nitem; }
	kind k;
};
class TableType : public SubType {
public:
	ptable table;
	~TableType() { table = NULL ; }
	TableType() { table = NULL; }
};
class NetType : public TableType {
public:
	pnetwork net;
	~NetType() { net = NULL ; }
	NetType() { net = NULL; }
};

class ChanType : public NetType {
public:
	pchannel chan;
	~ChanType() { chan = NULL ; }
	ChanType() { chan = NULL; }
};
struct Dstore {
	unsigned int curpos,type;
	ptable table;
	pnetwork net;
	pchannel chan;
	char *sttable,*stnet,*stchan,*item;
	DWORD property;
	ListPointer::iterator curnode;
	ListPointer lstore;
	void init() {
		table = NULL;net = NULL; chan = NULL; curnode = NULL;
		sttable = NULL; stnet = NULL; stchan = NULL;item = NULL;
		type = 0; curpos = 0; property = 0;
	}
	void clear() {
		if (sttable) delete sttable;
		if (stnet) delete stnet;
		if (stchan) delete stchan;
		if (item) delete item;
		lstore.clear();
		init();
	}
	void delitem(ListPointer::iterator i) 
	{
		if (i == curnode) { curpos = 0; curnode = NULL; }
		lstore.erase(i);
	}
	void addinit(unsigned int ptype,const DWORD num = 0,const char *ptable = NULL,const char *pnet = NULL,const char *pchan = NULL,const char *pitem = NULL)
	{
		clear();
		type = ptype;
		property = num;
		if (ptable) {
			sttable = new char[lstrlen(ptable) + 1];
			lstrcpy(sttable, ptable);
		}
        if (pnet) {
			stnet = new char[lstrlen(pnet) + 1];
			lstrcpy(stnet, pnet);
		}
		if (pchan) {
			stchan = new char[lstrlen(pchan) + 1];
			lstrcpy(stchan, pchan);
		}
		if (pitem) {
			item = new char[lstrlen(pitem) + 1];
			lstrcpy(item, pitem);
		}
	}
	void additem(unsigned int ptype,const DWORD num = 0,const char *pitem = NULL)
	{ 
		clear();
		type = ptype;
		property = num;
		if (pitem) {
			item = new char[lstrlen(pitem) + 1];
			lstrcpy(item, pitem);
		}
	} 

};

typedef list<TableType> ListTableType;
typedef list<NetType> ListNetType;
typedef list<ChanType> ListChanType;

//some procedure
unsigned int table_cleanup();
void savemenubar(HWND, tbool);
void unlock_title();

 UINT gbl_files,gbl_maxdepth,gbl_ALL,gbl_numberoftypes,gbl_numberofexclude;
 char gbl_types[100][10];
 char gbl_exclude[100][10];
 char * gbl_command = 0;
 char * gbl_buffer = 0;
 parray gbl_listname = 0;
 UINT64 gbl_bytes;
 BOOL gbl_saveff;
 int gbl_format;
