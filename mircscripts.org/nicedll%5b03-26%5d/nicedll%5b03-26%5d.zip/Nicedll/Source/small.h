/*
 * small.h 
 * File header of small.cpp
 * Copyright (C) 2003-2004 Niceboy-DvD
 *
*/
#include <shlobj.h>
#include <commdlg.h>
#include "common.h"

char *matchtokaux (char *, int, char *, tbool);
void SetVar(char *var,char *st);
void SetVar(char *var,int num);
void Unsetvar(char *var);
void copystr(char **target,char *source);
char *eval_exp(char *st);
char *eval_exp(char *st,char *para,char sep);
void SendMirc(char *st,int num);
inline void Docommand(char *command,char *buf,int type,char sep);
int isin_fpara(char * data,char lc,char hc);
void aux_getcommand(char ** para, char ** command);

HMENU menubar = NULL;
char matchtok_tokens[MAXSTRINGLEN];
char mTitlebar[900] = "mIRC";
int VBtitlebar = -3;
BOOL Vtitlebar = FALSE;

extern LPSTR mData;
extern HWND MIRC;
extern HHOOK mIRC_Hook;
extern WNDPROC mIRC_OldProc;
extern char Paratransfer[1024];
extern PMIB_IFTABLE ifMIB ;
INTVECTOR Lang;

//declare variables
 ULONG gbb_o_get,gbb_o_snd,gbb_get,gbb_snd,gbb_s;
 ULONG gbb_gets = 0;
 ULONG gbb_snds = 0;