/*
 * Eval.cpp
 *	
 * Copyright (C) 2003-2004 Niceboy-DvD  . email dvd21us@yahoo.com
 *
 * Speacial Thanks Kamek for some code and ideas 
 *
 * This program is free software; you can redistribute it
 * and/or modify  it under the terms of the GNU General Public 
 * License as published by  the Free Software Foundation; either 
 * version 2 of the License, or  (at your option) any later version.   
 */


#include "Eval.h"

char *pc_eval(char *tok,char *startpos,char *function,const BOOL Findstartpos = TRUE);
BOOL Npc_eval(char *str,const char BType = ' ',const BOOL comma = FALSE);
BOOL Npc_variable(char *str,const BOOL comma = FALSE);

MircFunc NoParse(FUNCPARMS)
{
	char text[BUF_SIZE];
	char * function = NULL;
	char *p = &text[0];

	text[0] = '\0';
	if (data[0]) {
		lstrcpy(text, data);
		if (*p == '-') {
			function = get_af_para(&p,'f');
			if (!function) {
				if (isind(getword(&p),'D','d')) function = (char *)(1);
			}
		}
		pc_eval(p,NULL,function);
		lstrcpy(data,p);
	}
	return 3;
}

MircFunc TryParse(FUNCPARMS)
{
	lstrcpy(mData, data);
	if (SendMessage(MIRC, WM_USER + 201,0,0)) {
		lstrcpy(data,mData);
		return 3;
	}
	else return 1;
}
MircFunc Ccom(FUNCPARMS)
{
	return 2;
}

/* str-"chr-or-null"
		if chr is found in str, a pointer to it is returned
		if not, a pointer to the string's NULL char is returned */

char *Kstrchr(char *str, char chr) {
	char *p = str;

	while (TRUE) {
		if (*p == chr) return p;
		if (!*p) return NULL;
		p++;
	}
}

char *Kstrchrn(char *str, char chr) {
	char *p = str;

	while (*p && (*p != chr)) p++;
	return p;
}

void Kstrncpy(char *dest, const char *src, int len) {
	int i;

	for (i = 0; i < len; i++) dest[i] = src[i];
}

char *pc_fixglitches(char *str) {
	char *tok = str, *ntok, buf[BUF_SIZE];

	while (tok) {
		ntok = Kstrchrn(tok, ' ');
		if (ntok - tok == 1) {
			switch (tok[0]) {
				case '#': case '[': case ']':
				case '|': case '{': case '}':
					wsprintf(buf, "$chr(%u)%s", tok[0], &tok[1]);
					lstrcpy(tok, buf);
					ntok = Kstrchrn(tok, ' ');
			}
		}
		else if (ntok - tok > 1) {
			if (tok[0] == '$') {
				lstrcpy(&buf[2], &tok[1]);
				buf[0] = '$';
				buf[1] = '!';
				lstrcpy(tok, buf);
				ntok++;
			}
			else if (tok[0] == '%') {
				lstrcpy(buf, &tok[1]);
				lstrcpy(tok, "% $+ ");
				lstrcat(tok, pc_fixglitches(buf));
				return str;
			}
		}
		if (*ntok) tok = &ntok[1];
		else tok = NULL;
	}

	return str;
}

// find closing '>'
char *pc_findclose(char *str, tbool inside) {
	char *p = &str[2];
	UINT type, blvl = 0;

	if (inside) {
		type = 0;
		p = &str[1];
	}
	else
		switch (str[1]) {
			case '\0':	return NULL;
			case '$':		type = 2; break;
			case '%':		type = 1; break;
			default:		type = 0; p = &str[1];
		}
	// type 3: inside an identifier's parameters
	// type 4: after an identifier's parameters (can't open again)

	while (TRUE) {
		if (*p == '<') {
			p = pc_findclose(p, (type != 3)? TRUE : FALSE);
			if (!p) return NULL;
		}
		else if ((*p == '>') && !blvl) return p;
		else if (*p == '(') {
			if (type == 2) type = 3;
			blvl++;
		}
		else if (*p == ')') {
			if (blvl > 0) blvl--;
			else return NULL;
			if (!blvl && (type == 3)) type = 4;
		}
		else if ((*p == ' ') && (type != 3))
			return NULL;
		else if (!*p) return NULL;
		p++;
	}
}

// find the character that closes current parameter (')' or ',')
char *pc_findcloseparm(char *str) {
	char *p = str;
	UINT blvl = 1;

	while (TRUE) {
		if (*p == '(')
			blvl++;
		else if (*p == ')') {
			if (blvl > 0) blvl--;
			else return NULL;
			if (!blvl) return p;
		}
		else if ((*p == ',') && (blvl == 1))
			return p;
		else if (!*p) return NULL;
		p++;
	}
}

// parse identifier
void pc_parseid(char *id,char * function) {
	char parms[BUF_SIZE], *p = Kstrchr(id, '('), *ep, epc, *lparm;
	UINT i;

	if (!p) return;
	*p++ = 0;
	ep = pc_findcloseparm(p);
	if (!ep) return;
	for (i = 0; i < sizeof(parms); i++) parms[i] = '\0';
	while (TRUE) {
		epc = *ep;
		*ep = '\0';
		lparm = &parms[lstrlen(parms)];
		lstrcat(parms, p);
		pc_eval(lparm,NULL,function);
		//            <$gettok(<%shit>, 1, 32)>
		//     return  $gettok(%shit, 1, 32)
		i = lstrlen(parms);
		parms[i] = epc;
		parms[i + 1] = '\0';
		// end fix
		p = &ep[1];
		if (epc == ')') break;
		ep = pc_findcloseparm(p);
		if (!ep) return;
	}
	lstrcat(parms, p);
	lstrcat(id, "(");
	lstrcat(id, parms);
}

char *pc_eval(char *tok,char *startpos,char *function,const BOOL Findstartpos) 
{
	char left[BUF_SIZE], parm[BUF_SIZE], right[BUF_SIZE], *p, *np;

	// checking for <***>
	if (Findstartpos) p = Kstrchr(tok, '<');
	else p = startpos;

	if (!p) return pc_fixglitches(tok);
	np = pc_findclose(p, FALSE);
	if (!np) return pc_fixglitches(tok); 

	// middle (the <var>), known as "parm" here
	Kstrncpy(parm, &p[1], np - p - 1);
	parm[np - p - 1] = 0;

	// check for <lt> and <gt>
	// does it have CharLower(parm) ? or use like this;
	if (!lstrcmpi(parm, "lt")) {
		lstrcpy(&p[1], &np[1]);
		return pc_eval(tok, Kstrchr(&p[1], '<'),function,FALSE);
	}
	else if (!lstrcmpi(parm, "gt")) {
		*p = '>';
		lstrcpy(&p[1], &np[1]);
		return pc_eval(tok, Kstrchr(&p[1], '<'),function,FALSE);
	}

	// if there's "left"...
	if (p - tok > 0) {
		Kstrncpy(left, tok, p - tok);
		left[p - tok] = 0;
        pc_fixglitches(left);
	}
	else left[0] = 0;

	// if  there's "right"...
	//   warning: this pc_eval recursive call here is messing with np,
	//   which is a substring of tok (the original parameter)
	if (np[1]) lstrcpy(right, pc_eval(&np[1],NULL,function));
	else right[0] = 0;

	if (parm[0] == '$') pc_parseid(parm,function);
	if (function) {
		if (int(function) == 1) wsprintf(mData,"%c::%s",'%',parm);
		else wsprintf(mData,"$%s(%s)",function,parm);
		if (SendMessage(MIRC, WM_USER + 201,0,0)) lstrcpy(parm,mData);
	}
	if (np[1] == 32) wsprintf(tok, "%s%s%s",left,parm,right);
	else wsprintf(tok, "%s%s $+ %s",left,parm,right);
	return tok;
}
char *Npc_findclose(char *str,BOOL &error,const char sep = '>') {
	char *p = &str[1];
	UINT  blvl = 0;
	error = FALSE;

	while (TRUE) {
		if ((sep == '>') && (*p == '<')) {
			p = Npc_findclose(p,error,'>');
			if (error) return NULL;
			if (!p) { error = TRUE ; return NULL; }
		}
		else if ((*p == sep) && !blvl) return p;
		else if (*p == '(') {
			blvl++;
		}
		else if (*p == ')') {
			if (blvl > 0) blvl--;
			else { error = TRUE ; return NULL; }
		}
		else if (!*p) { error = TRUE ; return NULL; }
		p++;
	}
}
char * Npc_findbracket(char *str,BOOL &error) 
{
	char *p = str,f = str[0];
	UINT blvl = 0;
	error = FALSE;

	while (TRUE) {
		if (*p == '(') blvl++;
		else if (*p == ')') {
			if (blvl > 0) blvl--;
			else { error = TRUE ; return NULL; }
			if (!blvl) { 
				if (f == '$')  ++p;
				return p;
			}
		}
		else  if ((*p == ' ') && (!blvl) && (f == '$')) {
			return NULL;
		}
		else if (!*p) return NULL;
		p++;
	}
}
inline BOOL check_nreplace(char p) 
{
	const char buf[] = "}{[]|%#";
	for (int i = 0;i < 8;i++) {
		if (p == buf[i])  return 1;
	}
	return 0;
}
inline BOOL check_mreplace(char p) 
{
	if ((p == ',') || (p == ')') || (p == '(')) return 1;
	return 0;
}
UINT replacecomma(char * parm)
{
	char *p = parm;
	char buf[BUF_SIZE];
	char aux[30],chr[30];
	int i = 0, sp = 0;
	BOOL o,n,c;

	if (!parm) return FALSE;
	buf[0] = 0;
	if (*parm) {
		n = ((*(p + 1) == ' ') || (!*(p + 1)))?1:0; c = (*p == ' ')?1:0;
		if (check_mreplace(*p) || (check_nreplace(*p) && n))  {
			wsprintf(chr,"%d",*p);i = lstrlen(chr);
			if (!n) { wsprintf(buf,"$chr(%s) $+ ",chr); i +=10; c = 1; }
			else { wsprintf(buf,"$chr(%s)",chr); i += 6; }
		}
		else if ((*p == '$') && !n) { lstrcpy(buf,"$!"); i += 2; }
		else buf[i++] = *p; 
		p++;buf[i] = 0;
		while (*p) {
			o = c; c = n; n = ((*(p + 1) == ' ') || (!*(p + 1)))?1:0;
			if ((sp || (check_mreplace(*p))) || (check_nreplace(*p) && o && n))  {
				aux[0] = 0;sp = 0;
				if (!o) { lstrcat(aux," $+ "); i += 4; c = 1; 	}
                wsprintf(chr,"%s$chr(%d)",aux,*p); 
				if (*p > 99) i +=9; else i +=8;
				if (check_mreplace(*(p + 1)))  sp = 1;
				else { 
					if (*(p + 1) && !n) { lstrcat(chr," $+ ");  i += 4; c = 1; }
				}
				lstrcat(buf,chr); 
			}
			else if ((*p == '$') && !n && o) { lstrcat(buf,"$!"); i += 2; }
			else { 	buf[i++] = *p; buf[i] = 0;		}
			if (i >= 900)  return FALSE; 
			p++;
		}
	}
	lstrcpy(parm,buf);
	return Success;
}

int Npc_parseid(char *id,const char BType = ' ') {
	char parms[MBUF], *p = Kstrchr(id, '('), *ep, epc, *lparm;
	UINT i;

	*p++ = 0;
	ep = pc_findcloseparm(p);
	if (!ep) { return Fail; }
	for (i = 0; i < sizeof(parms); i++) parms[i] = '\0';
	while (TRUE) {
		epc = *ep;
		*ep = 0;
		lparm = &parms[lstrlen(parms)];
		lstrcat(parms, p);
		if (!Npc_eval(lparm,BType,TRUE)) return Fail;
		i = lstrlen(parms);
		parms[i] = epc;
		parms[i + 1] = '\0';
		// end fix
		p = &ep[1];
		if (epc == ')') break;
		ep = pc_findcloseparm(p);
		if (!ep) { return Fail; }
	}
	lstrcat(parms, p);
	lstrcat(id, "(");
	lstrcat(id, parms);
	return Nsuccess;
}
int Npc_replacepara(char * parm,const char BType = ' ',const BOOL comma = FALSE)
{
	char *aux = parm;
	char st[BUF_SIZE];
	int fnum,faux,swap;
	BOOL through = FALSE ,takereverse = 0,left = 0;

	if (aux[0] == '~') {
		fnum = 0; faux = 0;aux++;
		if ((*aux == 'R') || (*aux == 'r') || (*aux == '-')) { takereverse  = 1; aux++; }
		if ((*aux == 'L') || (*aux == 'l')) { left = 1; aux++; }
		while ((*aux) && (*aux >= '0') && (*aux <= '9')) {
			fnum *= 10 ; fnum += *aux - '0';aux++;
		}
		if (*aux == '-') {
GLOOP:
			through = TRUE;aux++;
			while ((*aux) && (*aux >= '0') && (*aux <= '9')) {
				faux *= 10 ; faux += *aux - '0';aux++;
			} 
		}
		else if ((left) && ((*aux == 'R') || (*aux == 'r'))) {
			left = -1; goto GLOOP;
		}
		if (!*aux) {
			lstrcpy(st,Paratransfer);
			aux = &st[0];
			if (through) { 
				if (left >= 0) {
					if (!takereverse) {
						if ((faux) && (!left)) {
							if (fnum > faux) {swap = fnum ; fnum = faux; faux = swap;   }	
							faux -= fnum - 1 ;	
						}
						getmidtok(&aux,fnum,faux,BType); 
					}
					else  aux = getpnthtok(aux,0,fnum,faux,BType);
				}
				else {
					swap = numtok(st,BType) - fnum - faux;
					if (swap <= 0) aux[0] = 0;
					else getmidtok(&aux,fnum + 1,swap,BType);
				}
				lstrcpy(parm,aux);
				if (comma)
					if (!replacecomma(parm)) return Fail;
				return Nsuccess;
			}
			else {
				if (fnum == 0) {
					wsprintf(parm,"%d", numtok(st,BType));
					return Nsuccess;
				}
				if (!takereverse) getnthtok(aux,fnum,BType);  
				else aux = getpnthtok(aux,0,fnum,1,BType);
				lstrcpy(parm,aux);
				if (comma)
					if (!replacecomma(parm)) return Fail;
				return Nsuccess;
			}
		}
	}
	else if (aux[0] == '$') {
		if (Kstrchr(parm, '(')) return  Npc_parseid(parm,BType);
		else return Success;
	}
	return Success;
}

inline int Npc_evalute(char * parm)
{
	lstrcpy(mData,parm);
	if (SendMessage(MIRC, WM_USER + 201,0,0)) {
		wsprintf(parm,"~%s",mData);
		return Success;
	}
	return Fail;
}

BOOL Npc_eval(char *str,const char BType,const BOOL comma) {
	char *tok = str, *ntok, buf[MBUF];
	char  parm[MBUF];
	BOOL error = FALSE;
	int result;

	while (tok) {
		ntok = NULL;
		if (tok[0] == '<') ntok = Npc_findclose(tok,error);
		else 
			if ((tok[0] == '$') || (tok[0] == '(')) ntok = Npc_findbracket(tok,error);
			else if ((tok[0] == '~') && (tok[1] == '(')) ntok = Npc_findbracket(&tok[1],error);
		if(error) return FALSE;
		if (!ntok)  {
			 ntok = get_a_part(parm,&tok[0],' ');
			if (parm[0] != 0) {
				result = Npc_replacepara(parm,BType,comma);
				if (!result) return FALSE;
				if (result == Nsuccess) {
					wsprintf(buf,"%s%s",parm,ntok);
					lstrcpy(tok,buf);
					ntok = tok + lstrlen(parm);
				}
			}
		}
		else {
			if ((tok[0] == '$') || (!*ntok)) {
				parm[0] = 0;
				Kstrncpy(parm,&tok[0], ntok - tok);
				parm[ntok - tok] = 0;
				if (parm[0] != 0) {
					result = Npc_replacepara(parm,BType,comma);
					if (!result) return FALSE;
					if (lstrlen(parm) > 1000) return FALSE;
					if (result == Nsuccess) {
						wsprintf(buf,"%s%s",parm,ntok);
						lstrcpy(tok,buf);
						ntok = tok + lstrlen(parm);
					}
				}
			}
			else if (tok[0] == '~') {
				Kstrncpy(parm,&tok[2], ntok - tok - 1);
				parm[ntok - tok - 2] = 0;
				if (!Npc_eval(parm,BType)) return FALSE;
				if (Npc_evalute(parm)) {
					result = Npc_replacepara(parm,BType,comma);
					if (!result) return FALSE;
				}
				wsprintf(buf,"%s%s",parm,++ntok);
				lstrcpy(tok,buf);
				ntok = tok + lstrlen(parm);
			}
			else {
				Kstrncpy(parm,&tok[1], ntok - tok - 1);
				parm[ntok - tok -1] = 0;
				if (tok[0] == '<') {
					if (!lstrcmpi(parm, "lt")) {
						wsprintf(buf,"%c%s",'<',++ntok);
						ntok = tok + 1;
					}
					else if (!lstrcmpi(parm, "gt")) {
						wsprintf(buf,"%c%s",'>',++ntok);
						ntok = tok + 1;
					}
					else {
						if (!Npc_eval(parm,BType)) return FALSE;
						wsprintf(buf,"%s%s",parm,++ntok);
						ntok = tok + lstrlen(parm);
					}
				}
				else if (tok[0] == '(') {
					if (!Npc_eval(parm,BType)) return FALSE;
					wsprintf(buf,"(%s%s",parm,ntok);
					ntok = tok + lstrlen(parm) +1;
				}
				lstrcpy(tok,buf);
			}
		}
		if (*ntok) tok = &ntok[1];
		else tok = NULL;
	}
	return TRUE;
}

int Vpc_parseid(char *id) {
	char parms[MBUF], *p = Kstrchr(id, '('), *ep, epc, *lparm;
	UINT i;

	*p++ = 0;
	ep = pc_findcloseparm(p);
	if (!ep) { return Fail; }
	for (i = 0; i < sizeof(parms); i++) parms[i] = '\0';
	while (TRUE) {
		epc = *ep;
		*ep = 0;
		lparm = &parms[lstrlen(parms)];
		lstrcat(parms, p);
		if (!Npc_variable(lparm,TRUE)) return Fail;
		i = lstrlen(parms);
		parms[i] = epc;
		parms[i + 1] = '\0';
		// end fix
		p = &ep[1];
		if (epc == ')') break;
		ep = pc_findcloseparm(p);
		if (!ep) { return Fail; }
	}
	lstrcat(parms, p);
	lstrcat(id, "(");
	lstrcat(id, parms);
	return Nsuccess;
}
inline int Vpc_replacepara(char * parm)
{
	if (parm[0] == '$') {
		if (Kstrchr(parm, '(')) return  Vpc_parseid(parm);
		else return Success;
	}
	return Success;
}
BOOL Npc_variable(char *str,const BOOL comma) {
	char *tok = str, *ntok, buf[MBUF];
	char  parm[MBUF];
	BOOL error = FALSE;
	int result;

	while (tok) {
		ntok = NULL;
		if (tok[0] == 0) break;
		if (tok[0] == '<') {
			ntok = Npc_findclose(tok,error);
			if(error) return FALSE;
		}
		else 
			if ((tok[0] == '$') || (tok[0] == '(')) {
				ntok = Npc_findbracket(tok,error);
				if(error) return FALSE;
			}
		if (ntok)  {
			if ((tok[0] == '$') || (!*ntok)) {
				parm[0] = 0;
				Kstrncpy(parm,&tok[0], ntok - tok);
				parm[ntok - tok] = 0;
				if (parm[0] != 0) {
					result = Vpc_replacepara(parm);
					if (!result) return FALSE;
					if (lstrlen(parm) > 1000) return FALSE;
					if (result == Nsuccess) {
						wsprintf(buf,"%s%s",parm,ntok);
						lstrcpy(tok,buf);
						ntok = tok + lstrlen(parm);
					}
				}
			}
			else {
				Kstrncpy(parm,&tok[1], ntok - tok - 1);
				parm[ntok - tok -1] = 0;
				if (tok[0] == '<') {
					if (!lstrcmpi(parm, "lt")) {
						wsprintf(buf,"%c%s",'<',++ntok);
						ntok = tok;
					}
					else if (!lstrcmpi(parm, "gt")) {
						wsprintf(buf,"%c%s",'>',++ntok);
						ntok = tok;
					}
					else if (!lstrcmpi(parm, "c1")) {
						if (cAddColor) {
							wsprintf(buf,"\3%s%s",ccolor[0],++ntok);
							if (ccolor[0][0] != 0) ntok = tok + 2;
							else ntok = tok;
						}
						else {
							wsprintf(buf,"%s%s",ccolor[0],++ntok);
							if (ccolor[0][0] != 0) ntok = tok + 1;
							else ntok = tok - 1;
						}
					}
					else if (!lstrcmpi(parm, "c2")) {
						if (cAddColor) {
							wsprintf(buf,"\3%s%s",ccolor[1],++ntok);
							if (ccolor[1][0] != 0)	ntok = tok + 2;
							else ntok = tok;
						}
						else {
							wsprintf(buf,"%s%s",ccolor[1],++ntok);
							if (ccolor[1][0] != 0)	ntok = tok + 1;
							else ntok = tok - 1;
						}
					}
					else if (!lstrcmpi(parm, "c3")) {
						if (cAddColor) {
							wsprintf(buf,"\3%s%s",ccolor[2],++ntok);
							if (ccolor[2][0] != 0)	ntok = tok + 2;
							else ntok = tok;
						}
						else {
							wsprintf(buf,"%s%s",ccolor[2],++ntok);
							if (ccolor[2][0] != 0)	ntok = tok + 1;
							else ntok = tok - 1 ;
						}
					}
					else if (!lstrcmpi(parm, "c4")) {
						if (cAddColor) {
							wsprintf(buf,"\3%s%s",ccolor[3],++ntok);
							if (ccolor[3][0] != 0)	ntok = tok + 2;
							else ntok = tok;
						}
						else {
							wsprintf(buf,"%s%s",ccolor[3],++ntok);
							if (ccolor[3][0] != 0)	ntok = tok + 1;
							else ntok = tok - 1;
						}
					}
					else if (!lstrcmpi(parm, "pre")) {
						wsprintf(buf,"%s%s",cprefix,++ntok);
						ntok = tok + cprefixlen;
					}
					else {
						int tlen = lstrlen(parm);
						if (comma) { wsprintf(buf," $+ %c::%s $+ %s",'%',parm,++ntok); tlen += 10; }
						else {
							if ((tok == str) || (tok[-1] == 32))  { wsprintf(buf,"%c::%s",'%',parm); tlen += 2;	 }
							else { wsprintf(buf," $+ %c::%s",'%',parm); tlen += 6; }
							lstrcpy(parm,buf);	
							if ((ntok[1] == 32) || (ntok[1] == 0)) wsprintf(buf,"%s%s",parm,++ntok);
							else { wsprintf(buf,"%s $+ %s",parm,++ntok); tlen += 4; }
						}	
						ntok = tok + tlen;
					}
				}
				else if (tok[0] == '(') {
					if (!Npc_variable(parm,1)) return FALSE;
					wsprintf(buf,"(%s%s",parm,ntok);
					ntok = tok + lstrlen(parm) +1;
				}
				lstrcpy(tok,buf);
			}
			if (*ntok) tok = &ntok[1];
			else tok = NULL;
		}
		else tok++;
	}
	return TRUE;
}