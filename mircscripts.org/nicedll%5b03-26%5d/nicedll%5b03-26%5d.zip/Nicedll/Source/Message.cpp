

MircFunc SetMark(FUNCPARMS)
{
	if (data) {
		lstrcpy(mark,data);
		mmark = lstrlen(mark);
	}
	return 1;
}
MircFunc Retext(FUNCPARMS)
{	
	char buf[MLEN] = "";
	char result[MLEN] = "";
	char token[MLEN] = "";
	char *begintok = data;
	char *aux = &buf[0];
	char *amark = &mark[0];

	do {
		begintok = headtok(&begintok,&aux,&amark,mmark);
		lstrcat(result,buf);
        if (begintok) {
			token[0] =0;
			begintok = headtok(&begintok,&aux,&amark,mmark);
			if ((begintok) && (buf)) { 
				wsprintf(mData,GetFrom,buf);
				if (SendMessage(MIRC,WM_MEVALUATE,0,0L)) {
					if (mData[0] != 0) { 
						lstrcpy(token,mData);
						wsprintf(mData,"$replace(%s,@me,$me,@chan,#,@nick,$iif($query($active),$ifmatch))",token);
						if (SendMessage(MIRC,WM_MEVALUATE,0,0L)) lstrcpy(token,mData);
					}
				}
				if (token[0] == 0) wsprintf(token,"%s%s%s",mark,buf,mark);
			}
			else wsprintf(token,"%s%s",mark,buf);
			lstrcat(result,token);
		}
	}
	while (begintok != NULL);
	ret(result);
}

MircFunc NoTitle(FUNCPARMS)
{
	if (OldStyle) ret("ERROR Already done")
	OldStyle = GetWindowLong(mWnd,GWL_STYLE);
	SetWindowLong(mWnd,GWL_STYLE,WS_VISIBLE|WS_CLIPCHILDREN|WS_SYSMENU|WS_OVERLAPPED|WS_EX_LEFT|WS_THICKFRAME);
	Hidewin(mWnd);
	ret("+OK");
}

MircFunc NoMenu(FUNCPARMS)
{
	if (OldMenu) ret("ERROR Already done")
	OldMenu = GetMenu(mWnd);
	SetMenu(mWnd,NULL);
	Hidewin(mWnd);
	ret("+OK");

MircFunc ReTitle(FUNCPARMS)
{
	if (!OldStyle) ret("ERROR")
	SetWindowLong(mWnd,GWL_STYLE,OldStyle);
	Hidewin(mWnd);
	OldStyle = NULL;
	ret("OK")
}

MircFunc ReMenu(FUNCPARMS)
{
	if (!OldMenu) ret("ERROR")
	SetMenu(mWnd,OldMenu);
	Hidewin(mWnd);
	OldMenu = NULL;
	ret("OK")
}





