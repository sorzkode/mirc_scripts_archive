Name : NiceDLL
Author : Niceboy
Product Version : 1.6R-4
File Version 1.20.3.5

Description :It has some useful functions and  mIRC data Structure with a lot of options so you can easily process your data and make a script easier 

To know more about  Dll , open file (nicedll.chm) 

contacts me for any bugs/sugesstions/questions
 email: dvd21us@yahoo.com
 webpage: http://risedvd.tripod.com

20/3/2005 (dd/mm/yy)
Niceboy-DvD