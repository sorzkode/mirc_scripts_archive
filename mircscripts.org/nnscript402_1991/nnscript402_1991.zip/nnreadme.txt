NoNameScript version 4.02 readme
================================

If   you   have   trouble   using   the   script,   check  out  our  forums  at
http://www.nnscript.de.


That's all, have fun.
