===============================================================================
 Megapack #2 Icon Collection
-------------------------------------------------------------------------------
 Copyright �2002 Greg Fleming of Dark Project Studios.
===============================================================================

	ICON PACK NAME:         Megapack #2
        DATE RELEASED:          24/05/2002
        ICON FORMAT:            Win .ico - 24bit colour depth (16x16 only)
        # OF ICONS in pack:     131

	AUTHOR:                 Greg Fleming (aka Hell Dragon)
	e-MAIL:                 helldragon@darkproject.com
	WEB:                    http://www.darkproject.com	


[-- Tools Used: --]
-------------------------------------------------------------------------------

  [ x ] Adobe PhotoShop
  [   ] JASC's Paint Shop Pro
  [ x ] Microangelo Icon Studio
  [ x ] Icon Collector Graphics Editor
  [   ] Adobe Illustrator


[-- Icon Description: --]
-------------------------------------------------------------------------------

My second Megapack icon set, this pack includes a large collection of over 130 small
16x16 glyph icons ranging from drinks and food to mini-PC hardware, tanks, graphics related icons, and other useful symbols.

Some good uses for them might be in your Quick Launch menu or a similar application
launcher, or even in your own personal software/themes, but please remember these
icons are Freeware ONLY for Personal use on your own PC - if you want to use them
in other ways please contact me. Thank you.


[-- Copyright & Legal Information: --]
-------------------------------------------------------------------------------

a) ALL of these ICONS were created solely by Greg Fleming (aka Hell Dragon) of
   darkproject.com.

b) The icons are Freeware for PERSONAL USE only.

c) The icons may NOT be re-distributed on download sites without my permission
   and when they are I must be given FULL credit for the work, as the original
   creator of the icons.

d) This readme file must also be KEPT intact and unaltered with any of the icons
   that are distributed and the icons may NOT be CHANGED, RENAMED or ALTERED
   in any way.

e) Feel free to use my icons for your own individual projects and needs - but 
   my permission MUST be acquired before any money may be made from the icons.
   
f) Therefore, YOU may NOT use my icons in any THEMES, SKINS, SOFTWARE,
   WEBSITES, Books, CD's or in any COMMERCIAL way... without my PERMISSION first.

g) If you want to use them in your software applications, or to use them as graphics
   for your personal web page, please drop me an e-mail with the details and the URL.

-------------------------------------------------------------------------------