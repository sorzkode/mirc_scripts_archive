## QueryBlocker v1.0 by digitalmy ###
##### Support: #aTum @ QuakeNet #####
### more scripts @ www.atum.de.ms ###
### Copyright � 2003 by digitalmy ###

--------------------------------------------------

English:

This is a simple query blocker for mIRC.

Install:
 - copy all files to your mIRC directory
 - open your mIRC and type in: /load -rs QueryBlocker.mrc

After having loaded the script successfully there will pop up a window, where you 
can define many options of the QueryBlocker. To open the window again go to the MenuBar, 
which can be found on the top of your mIRC (File, Tools, DCC, >>MenuBar<<, Window, Help),
and click on the button QueryBlocker.

Options:

 - enable QueryBlocker : if this checkbox is enabled, the QueryBlocker will be activated (standard: on)
 - enable AntiFlood    : if enabled, the QueryBlocker won't flood the Network (standard: on)
 - accept text         : this is the text wich will inform the user (person who queries you) that the query has been accepted
 - block text          : if you block the query, the user will receive this information, that the Query has been blocked.
 - autoblock text      : if you have blocked a query and a user tries to query you within 5 minutes after block, he will receive this text, to be informed that the query has automatically been blocked because he's trying to query you too fast.
 - busy text           : if somebody queries you and there's already a query on queue he'll be informed by this message that he should wait till the query in queue was answered.
 - query open text     : this text will be send to a User when he opens a new query window with you.
 - ignore text         : if somebody who's on the ignore list queries you, the query will automatically be blocked and he'll get this message, so the User knows that he has been ignored

channel exceptions
 - voice : if the User is voiced on the channel you typed in, the Query with him will be automatically accepted
 - op    : if the User has op on the channel you typed in, the Query with him will be automatically accepted
 - reg   : if the User is on the channel you typed in (op, voice,... doesn't matter), the Query with him will be automatically accepted

 - and  : if this option is enabled, the User must fulfil all the requirements, that are listet in the channel exceptions, then the query will automatically accepted
 - or   : if this option is enabled, the User must fulfil at least one of the listet requirements in the channel exceptions, then the query will automatically accepted

!BUT! you can only define ONE channel for each textbox (2x voice, 2x op, 2x reg) and you have to idle all channels which are listed in the channel exceptions, because the QueryBlocker won't work perfectly if you don't do.

 - nick exceptions : here you can list all nicknames of the User whose query will be automatcally accepted (separate the nicks with spaces(blanks))
 - ignore list     : if somebody who's in the ignore list tries to query you, the query will automatically be blocked.

You also can add or remove a nick to/from those lists by right-clicking on his nickname in the nicklist, then go to QueryNicks, then choose the list (exceptions/ignore) and finally click add/remove to add/remove the User to this list..

--------------------------------------------------

German:

Dies ist ein einfacher QueryBlocker f�r mIRC:

Installation:
 - kopiere alle dateien in dein mIRC Verzeichnis
 - gib in irgendeinem mIRC window folgendes ein: /load -rs QueryBlocker.mrc

Nachdem das Script erfolgreich geladen wurde �ffnet sich ein Fenster, indem du einige  Einstellungen 
bez�glich des QueryBlockers vornehmen kannst. Um dieses Fenster erneut aufzurufen�klick auf deine 
MenuBar, welche sich am oberen Rand deines mIRC's befindet (File, Tools, DCC, >>MenuBar<<, Window, Help),
und klick auf die Schaltfl�che QueryBlocker.

Optionen:

 - enable QueryBlocker : wenn die Checbox an ist ist der QueryBlocker aktiv (standard: an)
 - enable AntiFlood    : ist die Checkbox aktiv, wird der QueryBlocker das Network nicht flooden (standard: an)
 - accept text         : dieser Text erscheint beim User (person die dir eine Query schickt) wenn du das Query angenommen hast
 - block text          : solltest du die Query ablehnen wird der User durch diesen Text �ber die Ablehnung des Querys informiert
 - autoblock text      : wenn du das Query eines Users abgelehnt hast wird das Query mit ihm 5 Minuten lang automatisch abgelehnt und er erh�lt beim automatischen ablehnen diese Nachricht
 - busy text           : sobald eine Query noch nicht angenommen oder abgelehnt wurde und sich noch in der Warteschleife befindet wird das Query jeden weiteren Users automatisch abgelehnt er bekommt diese Nachricht
 - query open text     : dieser text wird an jeden User gesendet, der ein neues Query mit dir �ffnet
 - ignore text         : wenn ein User, der auf der ignore list steht, dich queryt so wird das Query automatisch geblockt und er bekommt diese Nachricht, welche ihn dar�ber informiert, dass er ignoriert wird.

channel exceptions
 - voice : wenn der User voice in dem eingegebenen channel hat so wird das Query mit ihm automatisch angenommen
 - op    : wenn der User op in dem eingegebenen channel hat so wird das Query mit ihm automatisch angenommen
 - reg   : wenn der User sich in dem eingegebenen channel (egal ob er op, voice,.... hat) wird das Query mit ihm automatisch angenommen

 - and  : wenn diese Option aktiviert ist, so muss der User allen Anforderungen gen�gen, die in den channel exceptions aufgelistet sind, um das Query automatisch zu akzeptieren
 - or   : sollte diese Option jedoch aktiviert sein, so gen�gt es, dass der User nur einer der aufgelisteten Anforderungen gen�gt, um das Query automatisch zu akzeptieren.

!ABER! es kann f�r jede Text-Box nur EIN channel angegeben werden (2x voice, 2x op, 2x reg) und du musst jeden channel betreten, der in den channel exceptions aufgelistet ist, denn sonst wird der QueryBlocker nicht vollst�ndig funktionieren.

 - nick exceptions : hier kannst du alle Nicknamen auflisten, von denen das Query automatisch angenommen werden soll (die Nicknamen mit einem leerzeichen trennen)
 - ignore list     : wenn jemand aus der ignore list dich zu queryn versucht wird das Query automatisch geblockt.

Du kannst ebenso User zu dieser liste hinzuf�gen bzw. l�schen, indem du auf ihren Nicknamen in der Nicklist rechts-klickst dann QueryNicks ausw�hlst dann exceptions oder ignore ausw�hlst und hier auf add bzw. remove um den Nick der ausgew�hlten Liste hinzuzuf�gen bzw. ihn von der Liste zu l�schen.

--------------------------------------------------

haw phun ;)

