 mIRC(R) v5.81 Incest(is) Really Cool
 Copyright (c) 1995-2000 mIRC Co. Ltd.
 All Rights Reserved
                       __  .__            __  .__        
   _________.__. _____/  |_|  |__   _____/  |_|__| ____  
  /  ___<   |  |/    \   __\  |  \_/ __ \   __\  |/ ___\ 
  \___ \ \___  |   |  \  | |   Y  \  ___/|  | |  \  \___ 
 /____  >/ ____|___|  /__| |___|  /\___  >__| |__|\___  >	
      \/ \/         \/          \/     \/             \/ 

	alpha release 	/ 	a01
	timbob 		/	timbob@ameritech.net
	mirc 5.81

 timmy is back at it again cuz hes really fucking bored.
 just because  im cool,  this  script  will  not contain 
 a help system, themes or formats or  anything  of  that 
 nature, dialogs, or anything  else  that  timmy  really 
 doesnt give a fuck about. timmy  just  got  bored  with 
 mirc 5.7 and reflux so he  decided  to  make  something 
 new  for  himself.  dont  expect  anything  spectacular 
 as far as the code is concerned,  timmy  has  been  out 
 of the game for quite a  while  and  doesnt  have  much 
 left as far as style  goes.  timmy  still  has  yet  to 
 explore the new wonders of the latest version of  mirc.
	

 complete command list for synthetic/a01	
 as of 11.27.00

	
	addchan		add channel to autojoin		/addchan [channel] - optional
	addmail		add mail account		/addmail
	addpack		add xdcc pack			/addpack
	autojoin	autojoin control		/autojoin [add|rem]
	b		ban user			/b [nick]
	back		set back			/back [msg]
	c		send ctcp			/c [nick] [msg] 
	chat		dcc chat			/chat [nick]
	chkmail		check all accounts		/chkmail
	cls		clear screen			/cls
	cm		change channel mode		/cm +/-[modes]
	cpy		copy spec line from the window	/cpy [#] (f5)
	cycle		part/join channel		/cycle
	d		deop users			/d [nick1-8]
	dccauth		add user to dcc auth. list	/dccauth [nick]
	dlfile		del last rcvd file		/dlfile (f12)
	dv		devoice users			/dv [nick1-8]
	edit		edit file			/edit
	gone		set away			/gone [msg]
	j		join channel			/j [channel]
	k		kick user			/k [nick] [msg]
	kb		kickban user			/kb [nick] [msg]
	m		send msg			/m [nick] [msg]
	mail		email controls			/mail [add|rem(#)|chk]
	mdop		mass deop			/mdop
	modpack		modify xdcc pack		/modpack [#]
	mop		mass op				/mop
	mp3		mp3 conrtols			/mp3 [spec(string)|rand]
	n		send notice			/n [nick] [msg]
	nlist		offer xdcc l			/nlist [nick]
	ns		nickserv control		/ns
	o		op users			/o [nick1-8]
	olfile		open last rcvd file		/olfile (f11)
	packnfo		xdcc pack information		/packnfo [#]
	ping		ctcp ping			/ping [nick] (/ping for channel)
	plist		offer xdcc list			/plist
	qt		quote database			/qt [quote|*string*]
	readlog		view msg log			/readlog
	remchan		remove channel from autojoin	/remchan [channel]
	remlog		clear msg log			/remlog
	remmail		remove mail account		/remmail
	rempack		remove xdcc pack		/rempack [#]
	s		server				/s [server]
	send		dcc send			/send [nick]
	sendpack	(force) send xdcc pack 		/sendpack [#] [nick]
	setslots	set xdcc slot limit		/setslots [#]
	t		change topic			/t [topic]
	ub		unban user			/ub [nick] (uses ial, dont worry)
	um		change user mode		/um +/-[modes]
	unauth		remove dcc authorization	/unauth [#|mask]
	v		voice users			/v [nick1-8]
	ver		ctcp version			/ver [nick] (/ver for channel)
	wall		channel op notice		/wall [msg]
	wi		whois				/wi [nick]
	wii		whois (idle/oper info)		/wii [nick]
	xdcc		xdcc controls			/xdcc [add|rem|mod|list]

		
	