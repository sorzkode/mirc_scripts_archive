TaskBar.dll
author: Matthew
email: the_g33k@yahoo.com

With TaskBar.dll you can press, hide, and show the Start Button for windows.
You can hide and show the taskbar. And you can also hide and show mIRC.

To use:

Extract TaskBar.dll into a folder and remember where you put it.

In mIRC type:
/dll <dll path> <StartButton | TaskBar | mIRC> <press | show | hide>
(press only works for the StartButton function)

examples:
/dll C:\mIRC\dlls\TaskBar.dll TaskBar hide
/dll C:\mIRC\dlls\TaskBar.dll TaskBar show
/dll C:\mIRC\dlls\TaskBar.dll mIRC hide
/dll C:\mIRC\dlls\TaskBar.dll mIRC show (see the "Notes" section for this function)
/dll C:\mIRC\dlls\TaskBar.dll StartButton press
/dll C:\mIRC\dlls\TaskBar.dll StartButton hide
/dll C:\mIRC\dlls\TaskBar.dll StartButton show

Notes:
When hiding mIRC you will need to set a timer or some ctcp or msg event
so that you can show it again. First set a timer like this:
/timer 1 30 /dll C:\mIRC\dlls\TaskBar.dll mIRC show
(this timer waits 30 seconds and it show mIRC)
or
/timer 13:30 1 1 /dll C:\mIRC\dlls\TaskBar.dll mIRC show
(this will show mIRC at 1:30pm)

Then type /dll C:\mIRC\dlls\TaskBar.dll mIRC hide. If you set the timer correctly
then it will eventually come back when the timer executes.