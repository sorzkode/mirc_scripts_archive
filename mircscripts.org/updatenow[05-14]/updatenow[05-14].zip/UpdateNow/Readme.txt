###################################
# UpdateNow!		  	  #
#      by cLeuS		  	  #
#				  #
# www.turkeychat.net		  #
# eldorben@hotmail.com (MSN)	  #
###################################


Introduction
--------------------------------------

  This addon lets you to put an updater
  to your scripts. It is very simple.
  You are free to modify if you put
  a copyright line :)


Installing
--------------------------------------

  1- UnZip UpdateNow.zip file to your
     mIRC folder.

  2- Type /load -rs UpdateNow.mrc

  3- /uNow to test :)


Example unow.txt
--------------------------------------
-Start-
uurl http://www.turkeychat.net/tchat/tchat736net.exe
urem http://www.turkeychat.net/tchat/
uverr 1.1
usize 1674714
uozl Here is script info $crlf $+ this may be multi $crlf $+ line :)
uver2 101
-End-

  1- don't remove any of lines (-Start- and -End- too)
  2- look at 'example unow.txt' to more info.


Variables
--------------------------------------

  %downloadlength	byte value of file size
  %unow.ver2		plain value of current version
  %downloadoffset	returns size of the header

Credits
--------------------------------------

  This addon includes Andy^'s
  example socket download snippet.
  Dialog design and other things are
  free to modify.

  This addon made by cLeuS
  www.mircscripts.org
  www.scriptsdb.org.
  eldorben@hotmail.com

  Thanks.