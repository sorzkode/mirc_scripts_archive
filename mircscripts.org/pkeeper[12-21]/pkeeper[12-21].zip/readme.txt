; English (UK)

 -----------------------------------------------------
/ intro                                              /
-----------------------------------------------------

The Password Keeper is created to store the certain 
password onto the .txt file via the dialog box 
and avoid from missing password for the registered
web or stuff.

 ----------------------------------------------------
/ install                                           /
----------------------------------------------------

1. copy all unzipped files onto your mirc directory.
2. open your mirc and type: //load -rs pkeeper.mrc
3. finish! open the dialog by right-click on 
   your status window / menu bar / channel window.

 ----------------------------------------------------
/ usage                                             /
----------------------------------------------------

The're no active event on this script. It's only to 
store the password from missing or confuse. Please 
take not that this is not a auto identify script 
and it's only keep the password.

- Function

Add - add the related password.
Remove - remove the selected password and note.

- Tips

* the're no modify/edit function because the 
  password is permanent and i think you never 
  change it. if you wish to modify it, just remove 
  the old password add the new one.

* if you double click on the password, 
  it's automatically copy it. it's easy to log-in.

* you can add the same password via the dialog 
  because this script use the .txt file and not
  .ini file that it will replace the currently 
  password. (leave this is you a beginner user)

* you can edit manually by open the password.txt 
  file and write using this syntax.

  syntax: <password><tab><note>
  e.g.  : password	note

 ----------------------------------------------------
/ credit                                            /
----------------------------------------------------

> mirc.hlp (original mirc help file)
> #batch89 (webchat) crew
> www.mircmalaysia.com
> DragonZap for mdx.dll & views.mdx

> send bug or comments to xtertech@gmail.com

    !!!! Made In Malaysia by Malaysian !!!!!
(c) 2004 www.scriptsite.cjb.net, all right reserved.


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

; Bahasa Malaysia (MY)

 -----------------------------------------------------
/ pengenalan                                         /
-----------------------------------------------------

'Password Keeper' dibuat untuk menyimpan kata laluan
kedalam fail .txt melalui kotak dialog dan dapat
mengelakkan kehilangan kata laluan untuk kata laluan 
laman web atau lain-lain.

 ----------------------------------------------------
/ pemasangan                                        /
----------------------------------------------------

1. salin semua fail yang di-unzipped ke dalam 
   direktori mIRC anda
2. buka mIRC dan taip: //load -rs pkeeper.mrc
3. siap! klik kanan dalam tetingkap status / bar menu / 
   tetingkap channel untuk membuka kekotak dialog.

 ----------------------------------------------------
/ penggunaan                                        /
----------------------------------------------------

Skrip ini tidak aktif dalam sebarang 'event'. Skrip
ini hanya digunakan untuk menyimpan kata laluan 
daripada hilang atau keliru. Sila ambil perhatian 
bahawa skrip ini adalahbukan 'auto identify' dan 
hanya digunakan untuk menyimpan kata laluan.

- Fungsi
Add - simpan kata laluan yang ditetapkan.
Remove - buang kata laluan yang dipilih.

- Tips

* skrip ini tiada fungsi 'modify/edit'kerana 
  kata laluan adalah sesuatu yang kekal dan jarang 
  diubah. jika anda telah mengubah kata laluan tersebut,
  anda boleh buang kata laluan yang lama dan tambah 
  yang baru.

* jika anda dwi-klik pada kata laluan, skrip akan
  menyalin kata laluan tersebut untuk memudahkan
  proses log-masuk.

* anda boleh menambah kata laluan yang sama melalui
  kotak dialog kerana skrip ini menggunakan fail .txt
  dan bukan fail .ini yang akan menukar sebarang perkataan
  yang sama. (abaikan jika anda pengguna tahap permulaan)

* anda boleh menukar secara manual dengan membuka fail
  password.txt dan gunakan sintax seperti berikut:

  sintax: <password><tab><note>
  contoh: password	note

 ----------------------------------------------------
/ kredit                                            /
----------------------------------------------------

> mirc.hlp (original mirc help file)
> #batch89 (webchat) crew
> www.mircmalaysia.com
> DragonZap untuk mdx.dll & views.mdx
> hantarkan masalah dan pendapat ke xtertech@gmail.com

    !!!! Made In Malaysia by Malaysian !!!!!
(c) 2004 www.scriptsite.cjb.net, all right reserved.