- Install
  1. Unzip the .zip file to a directory another directory;
  2. If you downloaded ur script without mirc.exe, place a mirc.exe (version 6.03) in the same directory of extracted files;
  3. Run mirc.exe

- Systems
  I'll explain all systems here, with a maximum details.

  1. Auto Identify [/aid]
     - Networks: The button 'Add' added a network, and 'Del' remove. To set a network, write it in the 'combo' and press 'Add' (The 'Add' and 'Del' buttons are on top of dialog)
     - On/Off: Set the status of this system
     - Button 'Add' (right side of the list): Open a dialog to added nicks in list
     - Button 'Del' (right side of the list): Remove the selected nick from the list
     - Button 'Edit': Edit the selected nick
     - 'Identify on...': You can choose 'Connect', 'Notice' or 'Both'
     - 'NickServ Notice': Notice from nickserv to answer with the 'Message to Nickserv' (text is a wildcard)
     - 'Restore Guest Nick': If your nick is changed to set (text is a wildcard)
     - 'Message to NickServ': It's your reply from 'NickServ Notice'
     These options are differently in distinct networks

  2. Auto Join [/aj]
     - Networks: works same of Auto Identify
     - On/Off: Set the status of this system
     - Button 'Add' (right side of the list): Open a dialog to added channels in list
     - Button 'Del' (right side of the list): Remove the selected channel from the list
     - Button 'Edit': Edit the selected channel
     - 'Join on...': You can choose 'Connect' or 'Identify'. Auto Join is triggered when you connect or when you receive mode +r
     - 'Command': If it's enabled you should use a command to trigger Auto Join (the command is edited in 'edit' in right side of the checkbox 'Command'
     These options are differently in distinct networks (exception to 'Command')

  3. Away System [/daway]
     - 'Reason': The button 'Add' added a reason, and 'Del' remove. To set a reason, write it in the 'combo' and press 'Add'
     - 'Minimize mIRC': mIRC minimize when you go away
     - 'Place mIRC in tray': mIRC's placed in tray (this option's disabled if 'Minimize mIRC' isn't checked)
     - 'Deop in channels': set mode -o to you in channels
     - 'Op when back of away': take op when you go back of away (this option's disabled if 'Deop in channels' isn't checked)
     - 'Close pvts': close all pvts when you go away (/closemsg)
     - 'Report away in pvts': when you go away, the system send message to pvts
     - 'Save pages': /ctcp PAGE to you are saved in a *.txt file. To read pages, click in button '...'
     - 'Ignore DCCs': ignore all DCCs (/dcc ignore only)
     - 'Leave all the channels': leave channels when go away
     - 'Return when back': return to channels when go back
     - 'Ignore pvts': ignore pvt messages
     - 'Report in channels': send message with away reason (the message's edited in dialog). You can choose to send message to all channels or to selected channels (click in '...' to open a dialog with these options)
     - 'Nick': change nick to selected nick in 'combo'. It works same of 'Reason'.
     - 'Pager': if it is checked, when you receive a '/ctcp PAGE' it's play a sound. To select the sound click in '...', and to play this sound, click in '!'. If the sound file doesn't exist, it play a 'beep' sound.
     - 'Idle away': if you don't use mIRC per N minutes, you go away automatic (N is set in the 'edit' with arrows)
     - 'Request confirmation': after go away for idle, it ask you.
     - 'Report in pvt when...': it send a message to nick when 'open a pvt', 'quote any word', 'quote your nick' or 'quote listed words'. To set the words, use the 'combo' and the buttons 'Add' and 'Del', same of 'Reason'
     - 'Messages': you set the format to away messages ('When go away', 'During away' and 'When back of away'). You should use <awaymsg> to return the reason of away, <awaytime> to duration of away, and <awayinit> to return the time of the beginning of away
     - 'Message with...': you can choose /msg, /me or /notice to send the away messages
     - Radios 'Away in active network' and 'Away in all networks': you go away (or back of away) in active network or in all networks
     - Button 'Go away': You go away, or back if the button is 'Go back'
     You can go away in all networks and before you can go back in the active network

  4. Control Panel [/panel]
    It's a very sample control panel. It have only 'Addon - /command'. A double click on a line open the selected 'addon'.

  5. Fkeys [/fkeys]
     In the 'combo', you select the Fkey. 'Shift' and 'Ctrl' can be checked to use Shift+Fkey or Ctrl+Fkey. The command is edited in the 'edit'. To added or remove an item, use 'Add' and 'Del' buttons. The F2 and F3 don't is enabled to create an Fkey because it's used in protection system, but Shift+F2, Shift+F3, Ctrl+F2 and Ctrl+F3 can be used.

  6. Lag Bar [/lag]
     To open lag bar options use '/lag -c'. To check lag you can do a double click on lag bar or use '/lagcheck'.
     Lag Bar options
       - Radios 'One color' and 'Degrade': is used only one color or a degrade with green, yellow and red in lag bar
       - 'Smooth': the lag bar is smooth
       - Trackbar: it change the bright of the degrade
       - 'Open Lag Bar on start': open lag bar on start if it's checked
       - Button 'Open': Open/Refresh the lag bar

  7. Language [/lang]
     It has only a 'combo' to change language (portuguese or english). You can change language with '/lang N' (N is 0 [english] or 1 [portuguese]). You should close all dialogs to change language in it.

  8. Logs Manager [/logs]
     - Button 'Read': open the selected log (double click in list trigger the same command)
     - Button 'Del': remove selected logs (you can select various lines)
     - Button 'Rename': you can rename the selected log

  9. Mp3 Player [/mp3]
     - Button 'pause': pause/resume mp3
     - Button 'stop': stop mp3
     - Button 'play': play a mp3 (if mode is 'random', play a random mp3, else play the next in list)
     - Button 'rewind': skip to beginning of the mp3
     - Button 'forward': skip to end of the mp3
     - Button with an arrow (up or down): compact or expand the mp3 player
     - Trackbar: it progress next to the mp3 length. You can set the mp3 position with the trackbar (dragging the thumb) 
     - Mp3 time: the time is in the format 'nn:ss' (position/length)
     - Mp3 playing: it's in format 'artist - title' or the filename if 'artist' or 'title' doesn't exist
     - Volume: you can set the volume dragging the volume trackbar
     - Mode: you can choose 'Random' (play random mp3), 'Order' (play in playlist order) or 'Repeat'
     - 'Msgs': you can set the sent message to channels and the type of message (/amsg, /ame, /echo or off)
     - 'Search': find mp3 in playlist using this search system

  10. Protections [/prot]
    It has a lot of options, and if I'll explain all, I won't finish this readme file.

  11. Script News [/snews]
    To get news, click on the button 'Connect'. It delay a few time. When the download of news is completed, it's shown to you.

  12. Theme System [/themes]
     You should choose the directory of themes clicking in '...'. Before this, the themes are listed, and can be load.
     - Buttons 'Info', 'Preview' and 'Options': it's show diferent options to view/change
     'Info' you can see the info of the theme
     'Preview' show the preview of the theme (click in 'Generate Preview' to create preview if isn't exist)
     'Options' have options to change the themes. In the 'combo' you choose 'Fonts', 'Images', 'Nicklist Colors' or 'Timestamp'
        - Fonts: you can use the default font of the theme ('Use default theme fonts'), use the current font  ('Don't change fonts') or select other fonts ('Use selected fonts'). If you select 'Use selected fonts', you should configure the fonts in format '<fontname>, <fontsize>, [B]', if [B] is used, the font is bold, example: 'Tahoma, 11, B'. FontDefault is obliged to set. FontChan and FontQuery are set equal FontDefault if 'checks' isn't checked.
        - Images: you can use the default images of the theme ('Use default theme images'), use the current images ('Don't change images'), don't use images ('Don't use images'), or select other images.
        - Nicklist Colors: you can use the default nicklist colors of the theme ('Use default theme nicklist colors'), use the current nicklist colors ('Don't change nicklist colors') or select other nicklist colors ('Use selected nicklist colors'). To set the nicklist colors, click on the rectangle icons and select a color.
        - Timestamp: you can use the default timestamp of the theme ('Use default theme timestamp'), use the current timestamp ('Don't change timestamp'), don't use timestamp ('Don't use timestamp (/timestamp off)') or select other timestamp ('Use this timestamp:').
        You can load themes/schemes with commands:
           - /theme.load [-sN] <filename> - if you can load a scheme with the theme, set the [-sN] (N is the scheme number or name, and <filename> is the filename (with path) of the *.mts file
           - /theme.scheme <N> - you load a scheme of the actual theme. <N> is the number or the name of the scheme

  13. Theme System - Downloader [/themes -d]
    - Button 'List Themes': get themes list from the server and show in the 'list'
    - Button 'Download': download selected theme. Before the download, the system will decompress the file in the directory 'themes\' do script

  14. Toolbar [/tb] and Toolbar Editor [/tbedit]
    The Toolbar works very similar to the original toolbar. The Toolbar Editor's very sample. To added an item, you should select an icon, and type the name and the command to this button. If you want, it have a list with a some buttons to added. The button 'connect/disconnect' can be added checking the check 'Connect'.

  15. Users [/users] and 'Logon' [open on start]
    This system have a few options, but is a little complicated. You can added or remove users (to remove, you need the password of the user), except to user 'ur' because it's the default user. To 'logoff' user, use '/logoff' or '/logout'. On start mIRC or on 'logoff'. You can change password of users before you're logged with this user in popups. The dialog of 'Logon' will open if has more one user or if has one user and it need password to 'logon'.