MP3Icons by MTec89 http://mtec89net.com

these are 8 icons for mirc mp3 players

(or any other purpose)

[previous][play][pause][stop][next][open][sound][shuffle]

Includes bmp & ICO:)

you dont have to ask to use these for anything..

just dont rip them ;)

[Updated 9/3/2004]
added two icons (snd & shuff) created by [K]LiNeD


[Updated 9/5/03]
added depressed buttons
added playlist and equilizer buttons

