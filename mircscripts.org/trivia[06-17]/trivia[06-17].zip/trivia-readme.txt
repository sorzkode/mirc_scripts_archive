TriviaPimp v 1.0 by Shikkie
Date: 06/16/2001

---Installing

Unzip the triviapimp.zip file to a folder on your hard drive.
Open mIRC. 
Go to the remotes editor (Alt +R) and select File-Load-Script. 
Browse to the trivia.mrc file that you extracted from the .zip.
Press "Open." 
Press "Yes" if asked to run setup routines.

---Features

Customizable questions and timer settings.

---For the future

A "Theme" system where the user of the script can enter how to display output to the channel.

-----Contact

contact shikkie@mircscripts.org with comments/suggestions