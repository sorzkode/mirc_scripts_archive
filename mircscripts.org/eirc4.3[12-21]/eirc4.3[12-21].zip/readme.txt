
  ,-------------------------------------------------
  | eIRC 4.3                              [ReadMe]
  | Author: Eric^^ (EricN@accesswave.ca)
  | URL: http://accesswave.ca/~ericn/
  | ICQ: 125162277
  |
  | * * *
  |
  | Instalation:
  | Install eIRC to whichever directory you prefer
  | Then copy mirc32.exe to the folder. Run it and
  | eIRC will set itself up from there ;)
  |
  | If you're having problems check out the /help
  | and /faq on the script. If you've found a bug
  | send me /feedback or email me.
  |
  | Control Panel: /cpanel
  | Themes: /themes
  | Mp3 player: /mp3player
  | Command list: /commands
  `---------------------------[eIRC 4.3]-----------
 
  ,-------------------------------------------------
  | What's new in 4.3:
  | - Switchbar icons customizable. /sbarsetup
  | - Protect dialog now has popup instead of buttons
  | - Made fkey dialog bigger
  | - Resizeable notepad thing
  | - Resizeable Notify window
  | - Resizeable DCC window
  | - Resizeable Control Panel
  | - Switchbar can now go on left, top, right and bottom.
  | - Switchbar/toolbar enhanced greatly
  | - Added "Save to HTML..." playlist thing in MP3 player
  | - Fixed services for DALnet
  | - Custom file server messages
  `--------------------------[eIRC 4.3]------------

  ,-------------------------------------------------
  | Credits:
  |               Everyone :)
  |                                    ...Thanks! 
  `--------------------------[eIRC 4.3]------------