
Next v1.00  



###--------------------------- Information -------------------------------------------###


Next is an all around mIRC script which was created by YA-HA (formaly known as Miranda).
The main theme behind creating Next was to create an all around functionality script
for my liking, for the ego, for the fun, and mostly for the challange.

Next can be used both by experts and newbies to the IRC.
The script is easy to use and comes with highly customizeable abilities.



###--------------------------- Installation ------------------------------------------###


After you downloaded the zipped archive file, you have to 
extract the zip file first. to do so you need
any compression handeling application such as Winzip(www.winzip.com), 
WinRAR (www.rarsoft.com), WinACE (www.winace.com) or any other compression program that 
supports the zip extension (windows XP supports this without any program, 
just open the file and it'll open it in a file browser).

Second, you should download the last version of mIRC which 
available at www.mirc.com and copy "mIRC.exe" to the 
extracted script directory. 

Now, all you have to do is to double click on "mIRC.exe" and enjoy yourself.  
 

###--------------------------- Known Issues ------------------------------------------###
 

 1) Rightclick Beeping - Merely mIRC bug rather than
                         being actually *Next* bug.

    To stop this funky sound you may do the following:
    
    * Open the "sounds" under control panel       
    * drop down to Deafult sound which is under
      "Windows" Application icon in the Events list
    * Select "(None)" from the combo box
    * Click OK and you are all set!
  

###--------------------------- Changes -----------------------------------------------###


  1) v1.00 (17th Merch 2005)

     (*) First public version 
   

  2) v1.01 (27th April 2005)

     (+) Modules: Query Manager.
     (+) Interface / Toolbar: Added .icl,dll,exe support.
     (!) General / Various: Replaced UpDown controls with standart edits.
     (!) Miscellaneous / Startup Password: Show the password table only when it should.      
     (!) Core: Changed a bit the script popups.


  3) v1.02 (25th May 2005)

      (+) General / Away settings: Rebuild "change user-mode" option that's codeline disappeared somehow.
      (+) Interface / Toolbar: Added toolbar size option  (16 x 16 / 24 x 24 / 32 x 32 / 48 x 48).
      (!) Interface / Toolbar:  dll change (mDock61.dll -> hOSDock.dll) due to the new option above. 
      (!) General / Away settings: Fixed the auto away option. 
      (!) Modules: Fixed the Query Manager module.


  4) v1.03 / Next v1.00 (2st September 2006)
     
      (!) Script name changed to "Next".
      (-) Core / Popups: Removed popups icons.
      (-) Core / Toolbar: Removed toolbar size option.
      (!) General / Startup Password: Changed design.
      (!) General / Auto Connect: Changed list management design.
      (!) General / Network settings: Changed management design.
      (!) Core / Popups: Rewrote the script recent popups       
      (!) Various: Lots of other fixes, changes and modifications.
     

###--------------------------- What's next? ------------------------------------------###


  (+) Add Multi server away support (?).
  (+) Themes.
 

###--------------------------- Website -----------------------------------------------###


For any other information visit "Next" website at:
www.teremolo.net/poddy
