#include "..\mIRC.h"

extern	HINSTANCE	hInstance;
extern	HWND		hApp;
extern	HWND		hToolbar;
extern	HWND		hSwitchbar;
extern	HWND		hMDI;
