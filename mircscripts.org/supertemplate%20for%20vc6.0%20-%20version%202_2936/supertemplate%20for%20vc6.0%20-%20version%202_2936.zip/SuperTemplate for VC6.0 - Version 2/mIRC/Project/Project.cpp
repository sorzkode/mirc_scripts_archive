#include "Project.h"
/* Everything Below this point is here to demo the templates abilities and can be removed */

// Need to test subclassing of mIRC hwnd
// Need to try WM_DESTROY
//


#ifdef SAFE_SUBCLASSING
// A subclassed WinProc for the Toolbar
mProc(ToolbarProc)
{
	switch (uMsg) {
		case (WM_LBUTTONUP):
			// Lets send a signal to mirc that there has been a right click on the toolbar
			Signal("TOOLBAR_LCLICK", "%d",hwnd);
			// We are going to use that signal to create out own popup menu,
			// so stop mIRC's popup by returning 0L
			return 0L;
		case WM_DESTROY:
			//UnSubclassWindow(hInstance, hwnd);
			UnSubclassWindow((HINSTANCE)1, hwnd);
			PostMessage(hwnd, uMsg, wParam, lParam);
			break;
	}
	//return NextWndProc(hInstance, hwnd, uMsg, wParam, lParam);
	return NextWndProc(hInstance, hwnd, uMsg, wParam, lParam);
}

// Echo enumerations to the status window
BOOL CALLBACK SubclassEnum(HINSTANCE hInst, HWND hwnd, WNDPROC nextProc, LPARAM lParam)
{
	mCmd("echo -s EnumSubclassing: %ld %ld %ld", hInst, hwnd, nextProc);
	return TRUE;
}

// This test will show the super-subclassing ability
// It will subclass the Toolbar three times, then remove the subclassing
// reporting information as it goes...
mFunc(SubClassTest)
{
	WNDPROC		orig;
	// This is the correct way to subclass
	// SafeSubclassWindow(hInstance, hToolbar, lToolbarProc);

	orig = (WNDPROC)GetWindowLong(hToolbar, GWL_WNDPROC);
	
	// Safely subclass the toolbar window procedure
	SafeSubclassWindow(hInstance, hToolbar, ToolbarProc);
	// Enumerate all subclassing for the toolbar
	EnumSubclassing(hInstance, hToolbar, SubclassEnum, NULL);
	// Unsubclass the Toolbar
	UnSubclassWindow(hInstance, hToolbar);

	mReturn(data, "OK");
}

#endif

#ifdef INCLUDE_MIRC_PRINTF

// Some functions needs to be called for mLoad() to happen
// Always returns "OK"
mFunc(Load)
{
	mReturn(data, "OK");
}

// Included to show you how handy mCmd() and mEval() are
mFunc(Test)
{
	char	buffer[MAXSTR];
	int		index = 1;
	int		c = 32;
	StrCpy(buffer, "***\"T h i s\" \"i s\" \"a\" \"t e s t\"");
	mCmd("echo -a GetTok(%s, %d, %d) = %s", buffer, index, c, GetTok(buffer, index, c));
	index++;
	mCmd("echo -a GetTok(%s, %d, %d) = %s", buffer, index, c, GetTok(buffer, index, c));
	index++;
	mCmd("echo -a GetTok(%s, %d, %d) = %s", buffer, index, c, GetTok(buffer, index, c));
	index++;
	mCmd("echo -a GetTok(%s, %d, %d) = %s", buffer, index, c, GetTok(buffer, index, c));
	mReturn(data, "echo -a The current time %s", mEval("$asctime"));
}

// mIRC's access for Rand(), see mIRC-DLL.mrc
#ifdef INCLUDE_RAND
mFunc(mIRC_Rand)
{
	int		seed	= T_INT(1);
	int		min		= T_INT(2);
	int		max		= T_INT(3);
	mReturn(data, "%d", Rand(seed, min, max)); 
}
#endif

// mIRC's access for StrMid(), see mIRC-DLL.mrc
mFunc(mIRC_strMid)
{
	int		n				= T_INT(1);
	int		c				= T_INT(2);
	char	str[MAXSTR];	  T_STR(str, 3, TO_END);
	mReturn(data, "%s", StrMid(str, n, c)); 
}

// mIRC's access for StrLeft(), see mIRC-DLL.mrc
mFunc(mIRC_strLeft)
{
	int		n				= T_INT(1);
	char	str[MAXSTR];	  T_STR(str, 2, TO_END);
	mReturn(data, "%s", StrLeft(str, n));
}

// mIRC's access for StrRight(), see mIRC-DLL.mrc
mFunc(mIRC_strRight)
{
	int		n				= T_INT(1);
	char	str[MAXSTR];	  T_STR(str, 2, TO_END);
	mReturn(data, "%s", StrRight(str, n));
}

// mIRC's access for IsNum(), see mIRC-DLL.mrc
mFunc(mIRC_IsNum)
{
	char	str[MAXSTR];	T_STR(str, 1, NULL);
	mReturn(data, "%s", IsNum(str) ? "$true" : "$false");
}

// mIRC's access for IsIn(), see mIRC-DLL.mrc
// Use quotes to separate strings "abc" "abc123"
mFunc(mIRC_IsIn)
{
	char	is[MAXSTR];		T_STR(is, 1, NULL);
	char	in[MAXSTR];		T_STR(in, 2, NULL);
	mReturn(data, "%s-%s-%s", RemoveQuotes(is), RemoveQuotes(in),
		IsIn(RemoveQuotes(is), RemoveQuotes(in)) ? "$true" : "$false");
}

// mIRC's access for GetTok()
// Inorder to not double nest quotes (example: "123 "1 2" 123")
//     the mIRC_GetTok function uses '|' to separate it's arguments, specify with $chr(124)
// $gettok(1 2 3 4, 2, 32)		== 2
// $gettok(1 2 3 4, 2-, 32)		== 2 3 4
// $gettok(1 2 3 4, 2-3, 32)	== 2 3
// $gettok(1 2 3 4, -1, 32)		== 1 2 3
mFunc(mIRC_GetTok)
{
	const int	sep = 124;
	signed int	n;
	int			c, start, end;
	char		str[MAXSTR], range[MAXSTR];

	// Use ASCII value specified, in $2
	c = atoi(GetTok(data, 2, sep));

	// Use $3 as the input string
	StrCpy(str, GetTok(data, 3, sep, TO_END));

	// Determine range of tokens, in $1
	StrCpy(range, GetTok(data, 1, sep));
	if (range[0] == '-') {
		n = AtoI(GetTok(str, 0, c)) + AtoI(range);
		mReturn(data, "%s", GetTok(str, 1, n, c));
	}
	else if (IsIn("-", range)) {
		start = AtoI(GetTok(range, 1, 45));
		end = AtoI(GetTok(range, 2, 45));
		if (end == 0) end = AtoI(GetTok(str, 0, c));
		if (start == 0) mReturn(data, "Error: Bad Arguments: %d %d", start, end);
		mReturn(data, "%s", GetTok(str, start, end, c));
	}
	else if (IsNum(range)) {
		n = AtoI(range);
		mReturn(data, "%s", GetTok(str, n, c));
	}

	// if getting here, $1 had bad syntax
	mReturn(data, "Error: Bad Syntax Argument $ $+ 1: %s", range);
}

// Replacement for mIRC's $numtok
mFunc(mIRC_NumTok)
{
	mReturn(data, GetTok(GetTok(data, 2, 32, TO_END), 0, AtoI(GetTok(data, 1, 32))));
}

#ifdef UNSUPPORT_ATM

//	If anyone wants to rewrite the String Token handling abilities feel free to...
//	I will one day when I have too much time on my hands.
//	If you do write an entire new group of functions for token handling and would
//	like to include them in this template, mail to: qserve-support@excite.com.
//	I will leave credits to your work. I would like a complete rewrite of all functions
//	on mIRC's "Token Identifiers" help page.  Anything I add to this template must be
//	written compatible with this template.
//		Step 1: Write and general purpose function in "mIRC-Utils.cpp"
//		Step 2: Add an extern for this function in "mIRC.h"
//		Step 3: Add mIRC functions to "Project.cpp" for interfacing with the C++ functions
//		Step 4: Add all mIRC functions to "mIRC.def"

// Replacement for mIRC's $addtok
// Appends a token to a tokenized string
mFunc(mIRC_AddTok)
{
	mReturn(data, "");
}

// Replacement for mIRC's $deltok
// Deletes a specific token from a tokenized string
mFunc(mIRC_DelTok)
{
	mReturn(data, "");
}
#endif

#endif //INCLUDE_MIRC_PRINTF
