#include "mIRC-Init.h"

// Global Variables
HWND		hToolbar;
HWND		hSwitchbar;
HWND		hMDI;
HINSTANCE	hInstance;
HANDLE		hMap;
HWND		hApp;
WNDPROC		oldProc;
LPSTR		mData;
LPVOID		heap;

// This function is called when the DLL is open by mIRC (call from system, not mIRC)
DllStartup()
{
	// hInstance is need for safe subclassing and other Win32 API functions
	// It is the DLL's instance not the mirc app
	hInstance = (HINSTANCE)hInstDLL;
	heap = GetProcessHeap();
	return 1;
}

// The function that is called when mIRC initially loads this DLL
mLoad()
{
	// Let's setup our communications with mIRC
	hMap = CreateFileMapping(INVALID_HANDLE_VALUE,0,PAGE_READWRITE,0,4096,"mIRC");
	mData = (LPSTR)MapViewOfFile(hMap,FILE_MAP_ALL_ACCESS,0,0,0);
	// Let's save mIRC's HWND in a global variable
	hApp = load->mHwnd;
	// Let's set mKeep to TRUE so this DLL says loaded
	load->mKeep = TRUE;
	// Find some commonly used windows handles
	hToolbar = FindWindowEx(hApp,NULL,"mIRC_Toolbar",NULL);
	hSwitchbar = FindWindowEx(hApp,NULL,"mIRC_SwitchBar",NULL);
	hMDI = FindWindowEx(hApp,NULL,"MDIClient",NULL);
}

// The function mIRC calls when it want to unload this DLL
mUnload()
{
	if (!timeout) {
		// Restore the Toolbars original WinProc
		SetWindowLong(hToolbar,GWL_WNDPROC,(LONG)oldProc);
		// Close communications withs mIRC
		UnmapViewOfFile(mData);
		CloseHandle(hMap);
		return 1;
	}
	return 0;
}
