#include	"mIRC-Utils.h"

//*******************************//
//* String Comparison Functions *//
//*******************************//
#ifdef INCLUDE_STRING_COMP

// Appends s2 to the end of s1
void StrCat(char *s1, const char *s2, int max)
{
	int i, j;
	for (i=0;i<max;i++)
		if (s1[i] == 0) break;
	if (i >= max) return;
	for (j=0;i<max;i++) {
		s1[i] = s2[j];
		if (s2[j] == 0) break;
		j++;
	}
}

// Checks the length of string 's'
int StrLen(const char *s, int max)
{
	int	i;
	for (i=0;i<max;i++) { if (s[i] == 0) break; }
	return i;
}

// Returns true if strings match, else false
bool StrCmp(const char *s1, const char *s2, int max)
{
	int	i;
	for (i=0;i<max;i++) {
		if (s1[i] != s2[i]) return false;
		if (s2[i] == 0) return true;
	}
	return false;
}

// IsIn(const char *is, const char *in)
bool IsIn(const char *is, const char *in, int max)
{
	bool	match = false;
	int		iin, iis = 0;
	for (iin=0;iin<max;iin++) {
		if ((match) && (is[iis] == 0)) return true;
		if (in[iin] == 0) return false;
		if (is[iis] == in[iin]) { match = true; iis++; }
		else if ((match) && (is[iis] != in[iin])) { match = false; iis = 0; }
	}
	return false;
}

// Returns true/false, If input string is a number
bool IsNum(const char *s, int max)
{
	int	i;
	for (i=0;i<max;i++) {
		if ((i == 0) && (s[i] == '-')) continue; 
		if ((i > 0) && (s[i] == 0)) return true;
		else if (s[i] == 0) return false;
		if (s[i] < '0') return false;
		if (s[i] > '9') return false;
	}
	return false;
}
#endif


//***********************************//
//* My Sting Manipulation Functions *//
//***********************************//
#ifdef INCLUDE_STRING_HAND

// An array of character arrays used by StrFunctions (except StrCpy) and mEval().
// Have a pointer index to the next element (so nesting functions is possible)
#define	MAXBUF	100
int		nStringBuf = 0;
char	StringBuf[MAXBUF][MAXSTR];

// Copies 's2' into 's1' at a max of 'max' characters
void StrCpy(char *s1, const char *s2, int max)
{
	int	i;
	for (i=0;i<max;i++) { s1[i] = s2[i]; if (s2[i] == 0) break; }
}

// The following is used to return strings without hassels
// if advance, Increments nStringBuf and returns a pointer to the previous character array
// else, simple return current pointer and zero the character string.
char *SetNextString(bool advance) {
	if (advance) {
		// Get a new string ready for next use
		char *x = StringBuf[nStringBuf];
		nStringBuf++;
		if (nStringBuf >= MAXBUF) nStringBuf = 0;
		StringBuf[nStringBuf][0] = 0;
		return x;
	}
	else {
		// Initialize first use, nStringBuf is -1 on load
		StringBuf[nStringBuf][0] = 0;
		return StringBuf[nStringBuf];
	}
}

// StrMid("123456789", 1, 3) - returns "123"
char *StrMid(char *string, int start, int len)
{
	int i, j = 0;
	char *ret = SetNextString(false);
	start--; if (start < 0) start = 0;
	for (i=start;(i<MAXSTR && len>0);i++) {
		ret[j] = string[i]; j++;
		if (j == len) { j++; ret[j] = 0; break; }
		if (string[i] == 0) break;
	}
	if (j >= MAXSTR) j = MAXSTR-1;
	ret[j] = 0;
	return SetNextString(true);
}

// StrLeft("123456789", 1) - returns "1"
// StrLeft("123456789", -1) - returns "12345678"
char *StrLeft(char *string, int len)
{
	int		strlen, i;
	char	*ret = SetNextString(false);
	for (i=0;i<MAXSTR;i++) if (string[i] == 0) break; strlen = i;
	if (len < 0) len = strlen + len;
	if (len >= MAXSTR) len = MAXSTR-1;
	for (i=0;i<len;i++) ret[i] = string[i];
	return SetNextString(true);
}

// StrRight("123456789", 1) - returns "9"
// StrRight("123456789", -1) - returns "23456789"
char *StrRight(char *string, int len)
{
	int		strlen, start = 0, i, j = 0;
	char	*ret = SetNextString(false);
	for (i=0;i<MAXSTR;i++) if (string[i] == 0) break; strlen = i;
	if (len > 0) start = strlen - len;
	if (len < 0) { start = len * -1; len = strlen + len; }
	for (i=start;(i<(start+len) && len!=0);i++) { ret[j] = string[i]; j++; }
	return SetNextString(true);
}

// Replacement for $gettok/strtok(), acts much like mIRC's $gettok EXCEPT
// this function supports quotes and null tokens
// If toend is true, all tokens after index are included in the return string
char *GetTok(char *string, int index, int ntoken, bool toend)
{
	bool	quote = false;
	int		count = 0, i, j, k, last = 0;
	char	*ret = SetNextString(false);

	// by definition quotes can not be a valid token
	if (ntoken == 34) { return SetNextString(true); }

	for (i=0;i<MAXSTR-1;i++) {
		if (string[i] == 34) {
			if (quote == false) { quote = true; }
			else if (quote == true) { quote = false; }
		}
		if ((string[i] == 0) || ((string[i] == ntoken) && (quote == false))) {
			count++;
			if (count == index) {
				if (toend) i=MAXSTR-1;
				k = 0; for (j=last;j<i;j++) { ret[k] = string[j]; k++; }
				ret[k] = 0;
				return SetNextString(true);
			}
			else { last = i+1; }
			if (string[i] == 0) break;
		}

	}
	if (index == 0) wsprintf(ret, "%d", count);
	return SetNextString(true);
}

// Overloaded function that supports a starting and ending token
char *GetTok(char *string, int startTok, int endTok, int ntoken)
{
	bool	quote = false;
	int		count = 0, i, j, k, last = 0;
	int		clipStart = 0;
	char	*ret = SetNextString(false);

	// by definition quotes can not be a valid token
	if (ntoken == 34) { return SetNextString(true); }

	// If endTok is less than startTok, return an empty string
	if (endTok < startTok) { return SetNextString(true); }

	for (i=0;i<MAXSTR-1;i++) {
		if (string[i] == 34) {
			if (quote == false) { quote = true; }
			else if (quote == true) { quote = false; }
		}
		if ((string[i] == 0) || ((string[i] == ntoken) && (quote == false))) {
			count++;
			if ((count == startTok) && (i > 0)) clipStart = last;
			if (count == endTok) {
				k = 0;
				for (j=clipStart;j<=i;j++) { ret[k] = string[j]; k++; }
				ret[k] = 0;
				return SetNextString(true);
			}
			else { last = i+1; }
			if (string[i] == 0) break;
		}

	}
	return SetNextString(true);
}

// By default GetTok returns quotes intacted, use this function to remove quotes when
// string is needed for a comparison.
char *RemoveQuotes(char *string, int max)
{
	int i, j;
	for (i=j=0;i<max;i++) {
		if (string[j] == '\"') j++;
		string[i] = string[j];
		if (string[i] == 0) break;
		j++;
	}
	return string;
}
#endif


//*****************************//
//* Type Conversion Functions *//
//*****************************//
#ifdef INCLUDE_STRING_CONV

// Converts from mIRC $true/$false to C++ 'true'/'false'
bool AtoB(char *data) {
	if (StrCmp(data, "$true", MAXSTR)) return true;
	return false;
}

// atoi() replacement
signed int AtoI(char *data)
{
 	signed int	x;
	int			j, i;
	for (x=i=0;i<MAXSTR;i++) {
		if ((i == 0) && (data[0] == '-')) continue;
		else if ((data[i] < '0') || (data[i] > '9')) break;
	}
	i--;
	for (j=1;i>=0;i--) {
		if ((i == 0) && (data[0] == '-')) x *= -1; 
		else x += ((data[i] - '0') * j);
		j *= 10;
	}
	return x;
}

// ASCII to HWND conversion
HWND AtoH(char *Window) { return (HWND)AtoI(Window); }
#endif


//*******************************************************//
//* mIRC Communication Functions that work like prinf() *//
//*******************************************************//
#ifdef INCLUDE_MIRC_PRINTF

// mCmd("echo -a Test"); 
void mCmd(const char *format, ...)
{
	char Results[900];
	char	*out;
	out = Results;
    va_list args;    
    va_start( args, format );
    print(&out, format, args);
	wsprintf(mData, "//%s", Results);
	SendMessage(hApp, WM_USER + 200,0,0);
}

// example: Signal("TEST", "");
// example: Signal("-n Test", "Now");
void Signal(const char *signal, const char *format, ...)
{
	char Results[900];
	char	*out;
	out = Results;
    va_list args;    
    va_start( args, format );
    print(&out, format, args);
	wsprintf(mData, "//.signal %s %s", signal, Results);
	SendMessage(hApp, WM_USER + 200,0,0);
}

// example: version = atof(mEval("$version"));
char *mEval(const char *format, ...)
{
	char	*out = SetNextString(false);
    va_list args;    
    va_start( args, format );
    print(&out, format, args);
	StrCpy(mData, StringBuf[nStringBuf], MAXSTR);
	SendMessage(hApp, WM_USER + 201,0,0);
	StrCpy(StringBuf[nStringBuf], mData, MAXSTR);
	return SetNextString(true);
}

int mReturn(char *data, const char *format, ...)
{
	if (format == NULL) return 3;
	char	*out = SetNextString(false);
    va_list args;    
    va_start( args, format );
    print(&out, format, args);
	StrCpy(mData, StringBuf[nStringBuf], MAXSTR);
	SendMessage(hApp, WM_USER + 201,0,0);
	StrCpy(StringBuf[nStringBuf], mData, MAXSTR);
	StrCpy(data, StringBuf[nStringBuf], MAXSTR);
	SetNextString(true);
	return 3;
}

char *mEvalCid(int cid, const char *format, ...)
{
	char	*out = SetNextString(false);
    va_list args;    
    va_start( args, format );
    print(&out, format, args);

	// Get the info
	mCmd("scid %d | set %%~DLL~Eval %s", cid, StringBuf[nStringBuf]);
	wsprintf(mData,"%%~DLL~Eval");
	SendMessage(hApp, WM_USER + 201,0,0);
	StrCpy(StringBuf[nStringBuf], mData, MAXSTR);
	mCmd("unset %%~DLL~Eval");

	// Return the info
	return SetNextString(true);
}

// Returns an 'hwnd' of a window that has a name 'name'
HWND mHwnd(int cid, char *name)
{
	char	wName[MAXSTR];
	char	Eval[MAXSTR];
	HWND	hwnd;
	int		max, i;
	StrCpy(Eval, mEvalCid(cid, "$window(*,0)"), MAXSTR);
	max = AtoI(Eval);
	for (i=1;i<=max;i++) {
		StrCpy(wName, mEvalCid(cid, "$window(*, %d)", i), MAXSTR); 
		hwnd = AtoH(mEvalCid(cid, "$window(*, %d).hwnd", i));
		if ((IsWindow(hwnd)) && (!strcmp(name, wName))) return hwnd;
	}
	return NULL;
}

// Returns the window name of HWND hwnd
// if hwnd == NULL, returns total number of windows
char *mWindow(HWND hwnd, int *pcid)
{
	HWND	h;
	char	buf[MAXSTR];
	int		max = AtoI(mEval("$scon(0)"));
	int		i, imax, cid, con, total = 0;

	if (pcid) *pcid = 0;
	for (con=1;con<=max;con++) {
		cid = AtoI(mEval("$scon(%d).$cid", con));
		total += imax = atoi(mEvalCid(cid, "$chan(0)"));
		// Look for a matching hwnd in channel and query windows
		if (IsWindow(hwnd)) {
			for (i=1;i<=imax;i++) {
				h = AtoH(mEvalCid(cid, "$chan(%d).hwnd", i));
				if (hwnd == h) {
					*pcid = cid;
					StrCpy(buf, mEvalCid(cid, "channel %d $chan(%d)", cid, i), MAXSTR);
					SetNextString(false);
					StrCpy(StringBuf[nStringBuf], buf, MAXSTR);
					return SetNextString(true);
				}
			}
		}
		total++; // This is for the status window
		total += imax = atoi(mEvalCid(cid, "$query(0)"));
		if (IsWindow(hwnd)) {
			for (i=1;i<=imax;i++) {
				h = AtoH(mEvalCid(cid, "$query(%d).hwnd", i));
				if (hwnd == h) {
					if (pcid) *pcid = cid;
					StrCpy(buf, mEvalCid(cid, "query %d $query(%d)", cid, i), MAXSTR);
					SetNextString(false);
					StrCpy(StringBuf[nStringBuf], buf, MAXSTR);
					return SetNextString(true);
				}
			}
			imax = atoi(mEvalCid(cid, "$window(*, 0)"));
			for (i=1;i<=imax;i++) {
				h = AtoH(mEvalCid(cid, "$window(*, %d).hwnd", i));
				if (hwnd == h) {
					if (pcid) *pcid = cid;
					StrCpy(buf, mEvalCid(cid, "$window(*, %d).type $window(*, %d).cid $window(*, %d)", i, i, i), MAXSTR);
					SetNextString(false);
					StrCpy(StringBuf[nStringBuf], buf, MAXSTR);
					return SetNextString(true);
				}
			}
		}
	}
	total += AtoI(mEval("$calc($get(0) + $send(0) + $chat(0) + $fserv(0) + $window(0))"));
	if (hwnd == NULL) wsprintf(buf, "%d", total);
	SetNextString(false);
	StrCpy(StringBuf[nStringBuf], buf, MAXSTR);
	return SetNextString(true);
}

char *mWindow(HWND hwnd)
{
	return mWindow(hwnd, NULL);
}

// Returns the cid for a window, specifing HWND
int mWinCid(HWND hwnd)
{
	int cid;
	mWindow(hwnd, &cid);
	return cid;

}
#endif

//******************//
//* Windows Styles *//
//******************//
#ifdef INCLUDE_WINSTYLES
void RemoveWinStyles(HWND window,int style,long RemStyles)
{
	LONG Styles = GetWindowLong(window, style);
	Styles &= ~RemStyles;
	SetWindowLong(window, style, Styles);
}

void AddWinStyles(HWND window,int style,long AddStyles)
{
	LONG Styles = GetWindowLong(window, style);
	Styles |= AddStyles;
	SetWindowLong(window, style, Styles);
}
#endif


//*************************//
//* Clone of mIRC's $rand *//
//*************************//
#ifdef INCLUDE_RAND
int	Rand(int seed, int min, int max)
{
	srand((unsigned)seed);
	return ((rand()%(max-min)) + min);
}
#endif

