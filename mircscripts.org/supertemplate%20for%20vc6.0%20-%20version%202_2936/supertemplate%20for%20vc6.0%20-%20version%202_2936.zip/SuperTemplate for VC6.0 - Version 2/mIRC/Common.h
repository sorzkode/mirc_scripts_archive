// This file is included in all other header files
#include "Conf.h"

#define	MAXSTR			900
#define	TO_END			true

// Dependencies
#ifdef INCLUDE_RAND
#ifndef	INCLUDE_MIRC_PRINTF
#define	INCLUDE_MIRC_PRINTF
#endif	//INCLUDE_MIRC_PRINTF
#endif	//INCLUDE_RAND

#ifdef INCLUDE_MIRC_PRINTF
#ifndef	INCLUDE_STRING_CONV
#define	INCLUDE_STRING_CONV
#endif	//INCLUDE_STRING_CONV
#endif	//INCLUDE_MIRC_PRINTF

#ifdef	INCLUDE_STRING_CONV
#ifndef	INCLUDE_STRING_COMP
#define	INCLUDE_STRING_COMP
#endif	//INCLUDE_STRING_COMP
#ifndef	INCLUDE_STRING_HAND
#define	INCLUDE_STRING_HAND
#endif	//INCLUDE_STRING_HAND
#endif	//INCLUDE_STRING_CONV
