//***********************************************************************
//* Use this file to include/exclude parts of this template.			*
//*																		*
//* You may also need to modify mIRC.def exports if you #undef these.	*
//* By default everything is defined.									*
//* Some includes have dependencies, see Common.h						*
//***********************************************************************

// PLEASE USE IF YOU USE ANY SUBCLASING
#define SAFE_SUBCLASSING
//#undef SAFE_SUBCLASSING

// Include the String Handling functions (StrRight, GetTok, etc...)
#define INCLUDE_STRING_HAND
//#undef INCLUDE_STRING_HAND

// Include the String Comparing functions (StrLen, IsNum, etc...)
#define INCLUDE_STRING_COMP
//#undef INCLUDE_STRING_COMP

// Include the String Type Conversions (AtoI, AtoH, etc...)
#define INCLUDE_STRING_CONV
//#undef INCLUDE_STRING_HAND

// Include the printf like mIRC Communications functions (mEval, mReturn, etc...)
#define INCLUDE_WINSTYLES
//#undef INCLUDE_WINSTYLES

// Include the printf like mIRC Communications functions (mEval, mReturn, etc...)
// Will generate linking errors if you undef without modifing mIRC.def
#define INCLUDE_RAND
//#undef INCLUDE_RAND

// Include the printf like mIRC Communications functions (mEval, mReturn, etc...)
// Will generate linking errors if you undef without modifing mIRC.def
#define INCLUDE_MIRC_PRINTF
//#undef INCLUDE_MIRC_PRINTF
