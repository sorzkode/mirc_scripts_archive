#pragma check_stack(off)
#pragma comment(linker,"/OPT:NOWIN98")

#include "Common.h"
#include <stdarg.h>
#define WIN32_LEAN_AND_MEAN
#define WINVER 0x0400
#define _X86_
#define _WIN32_WINNT 0x0500
#include <stdlib.h>
#include <stdio.h>
#include <windows.h>

#ifdef SAFE_SUBCLASSING
#include "MonitorAccess.h"
#endif

#define DllStartup()	extern "C" int WINAPI _DllMainCRTStartup(HANDLE hInstDLL, DWORD, void*)
#define mLoad()			extern "C" void WINAPI LoadDll(LOADINFO *load)
#define mUnload()		extern "C" int WINAPI UnloadDll(int timeout)
#define mFunc(x)		extern "C" int WINAPI x(HWND mWnd,HWND aWnd,char *data,char *parms,BOOL show,BOOL nopause)
#define mProc(x)		LRESULT CALLBACK x(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam)

// return values
#define M_HALT		0
#define M_CONTINUE	1
#define M_PERFORM	2
#define M_RETURN	3

typedef struct {
	DWORD  mVersion;
	HWND   mHwnd;
	BOOL   mKeep;
} LOADINFO;

// My String Comparison Functions
#ifdef INCLUDE_STRING_COMP
extern	int			StrLen(const char *s, int max = MAXSTR);
extern	bool		StrCmp(const char *s1, const char *s2, int max = MAXSTR);
extern	bool		IsIn(const char *is, const char *in, int max = MAXSTR);
extern	bool		IsNum(const char *s, int max = MAXSTR);
#endif

// My String Handling Functions
#ifdef INCLUDE_STRING_HAND
extern	void		StrCat(char *s1, const char *s2, int max = MAXSTR);
extern	void		StrCpy(char *s1, const char *s2, int max = MAXSTR);
extern	char		*StrMid(char *string, int start, int len);
extern	char		*StrLeft(char *string, int len);
extern	char		*StrRight(char *string, int len);
extern	char		*GetTok(char *string, int index, int ntoken, bool toend = false);
extern	char		*GetTok(char *string, int startTok, int endTok, int ntoken);
extern	char		*RemoveQuotes(char *string, int max = MAXSTR);
#endif

// mIRC Communications Functions
#ifdef INCLUDE_MIRC_PRINTF
extern	void		Signal(const char *signal, const char *fmt, ...);
extern	void		mCmd(const char *fmt, ...);
extern	char		*mEval(const char *fmt, ...);
extern	char		*mEvalCid(int cid, const char *format, ...);
extern	char		*mWindow(HWND hwnd, int *pcid);
extern	char		*mWindow(HWND hwnd);
extern	int			mWinCid(HWND hwnd);
extern	HWND		mHwnd(int cid, char *name);
extern	int			mReturn(char *data, const char *format, ...);

// This #defines simplifies the use of mReturn
#define mReturn		return mReturn
#endif

// ASCII Type Conversions
#ifdef INCLUDE_STRING_CONV
extern	bool		AtoB(char *Window);
extern	signed int	AtoI(char *Window);
extern	HWND		AtoH(char *Window);

// These defs make argument processing a snap if you use spaces to separate arguments
#define	T_STR(cpt,x,y)	StrCpy(cpt, (y == NULL) ? GetTok(data, x, 32) : (y == TO_END) ? GetTok(data, x, 32, TO_END) : GetTok(data, x, y, 32))
#define T_INT(x)		AtoI(GetTok(data, x, 32))
#define T_HWND(x)		AtoH(GetTok(data, x, 32))
#define T_BOOL(x)		AtoB(GetTok(data, x, 32))
#endif


// Used for changing WinStyles
#ifdef INCLUDE_WINSTYLES
extern void RemoveWinStyles(HWND window,int style,long RemStyles);
extern void AddWinStyles(HWND window,int style,long AddStyles);
#endif

// $rand Replacement, accepts a seed value 
#ifdef INCLUDE_RAND
extern int	Rand(int seed, int min, int max);
#endif