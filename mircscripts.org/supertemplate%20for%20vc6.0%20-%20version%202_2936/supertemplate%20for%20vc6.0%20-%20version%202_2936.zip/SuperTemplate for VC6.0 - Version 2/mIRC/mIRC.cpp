#include "mIRC.h"

HWND		hToolbar;
WNDPROC		oldProc;
HINSTANCE	hInstance;
HANDLE		hMap;
LPSTR		mData;
HWND		mIRC_hwnd;
LPVOID		heap;


DllStartup()
{
	hInstance = (HINSTANCE)hInstDLL;
	heap = GetProcessHeap();
	return 1;
}


mProc(ToolbarProc)
{
	switch (uMsg) {
		case (WM_RBUTTONUP):
			// Lets send a signal to mirc that there has been a right click on the toolbar
			Signal("TOOLBAR_RCLICK", "%d",hwnd);
			// We are going to use that signal to create out own popup menu,
			// so stop mIRC's popup by returning 0L
			return 0L;
			break;
	}
	return CallWindowProc(oldProc,hwnd,uMsg,wParam,lParam);
}

mLoad()
{
	hMap = CreateFileMapping(INVALID_HANDLE_VALUE,0,PAGE_READWRITE,0,4096,"mIRC");
	mData = (LPSTR)MapViewOfFile(hMap,FILE_MAP_ALL_ACCESS,0,0,0);
	mIRC_hwnd = load->mHwnd;
	load->mKeep = TRUE;

	if (!opout) {
		hToolbar = FindWindowEx(mIRC_hwnd,NULL,"mIRC_Toolbar",NULL);
		if (IsWindow(hToolbar)) oldProc = (WNDPROC)SetWindowLong(hToolbar,GWL_WNDPROC,(LONG)ToolbarProc);
	}
}

mUnload()
{
	if (!timeout) {
		SetWindowLong(hToolbar,GWL_WNDPROC,(LONG)oldProc);
		UnmapViewOfFile(mData);
		CloseHandle(hMap);
		return 1;
	}
	return 0;
}
