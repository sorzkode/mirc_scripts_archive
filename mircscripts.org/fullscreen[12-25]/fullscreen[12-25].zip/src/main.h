#ifndef __MAIN_H__
#define __MAIN_H__

#define		WIN32_LEAN_AND_MEAN
#include	<windows.h>
#include	<stdlib.h>
#include	"mirc.h"

BOOL		SetFullScreen		( HWND, int, int, int, int );
void		RemStyles			( HWND, int, long );
void		AddStyles			( HWND, int, long );
void		ResetWindow			( HWND );

#define		FS_FREQUENCY		0x3C
#define		FS_BPS				0x20

#define		FS_SMALL_WIDTH		0x280
#define		FS_SMALL_HEIGHT		0x1E0
#define		FS_LARGE_WIDTH		0x320
#define		FS_LARGE_HEIGHT		0x258

HRGN		BitmapToRegion		( HBITMAP, COLORREF, COLORREF );

#endif
