

	mIRC Fullscreen DLL

	-------------------

	Author:		Str3iber
	Version:	1.3
	Contact:	str3iber@gmx.de

	-------------------

	I did this because I like to sit on my couch, watch TV and can chat with my
	friends without having problems to read text because of the distance.

	So I created this DLL to make it as easy as possible to switch windows into
	fullscreen and back. 

	Of course you could change the Fontsize everytime but there are more things you can do
	with this DLL. Ever wanted to develope a mIRC Game with fullscreen mode? :o)

	--------------------

	Updates:
			Reduced filesize
			Frequency bug should be fixed
			Added short version of Fullscreen command you can do now /dll Fullscreen.dll Fullscreen HWND > WIDTH > HEIGHT > BITS > FREQUENCY instead of using all those single commands
			-
			Added support for custom frequencys
			-
			Added custom resolution support.
			Added windwow regions directly by a bitmap (missed this in WinRgn.dll)

	--------------------

	Reference:
		
		Command: Fullscreen [HWND]
			 Fullscreen [HWND] > [WIDTH] > [HEIGHT] > [BITS] > [FREQUENCY]
		Example: /dll fullscreen.dll Fullscreen $window(@bleh).hwnd
			 /dll fullscreen.dll Fullscreen $window(@bleh).hwnd > 640 > 480 > 16 > 60
		Returns: -

		Displays a window in custom resolution



		Command: SetFrequency [FREQUENCY]
		Example: /dll fullscreen.dll SetFrequency 60
		Returns: -

		Set your own personal custom frequency...StanZ :o)



		Command: LoadRegion [BITMAP]
		Example: //echo -a region: $dll(fullscreen.dll,LoadRegion,bitmap.bmp)		
		Returns: $true/$false
		
		Load region from a bitmap. The default transparent color is black (#000000) with a tolerance of 16 (#101010)
		You may change this with SetTolerance and SetTransparent



		Command: SetRegion [HWND]
		Example: /dll fullscreen.dll SetRegion $window(@bleh).hwnd
		Returns: -
	
		Apply the loaded region to a window :o)



		Command: SetTransparent [COLOR]
		Example: /dll fullscreen.dll SetTransparent $base(FF00FF,16,10)
		Returns: -



		Command: SetTolerance [TOLERANCE]
		Example: /dll fullscreen.dll SetTolerance $base(101010,16,10)
		Returns: -

		Set the tolerance for red green and blue from 0 to 255


		
		Command: SetBits [8|16|32]
		Example: /dll fullscreen.dll SetBits 16
		Returns: -
		
		Set the bits for custom fullscreen mode



		Command: SetWidth [NUMBER]
		Example: /dll fullscreen.dll SetWidth 320
		Returns: -

		Set the width for custom fullscreen mode



		Command: SetHeight [NUMBER]
		Example: /dll fullscreen.dll SetHeight 200
		Returns: -

		Set the height for custom fullscreen mode




		Command: Fullscreen640x480 [HWND]
		Example: /dll fullscreen.dll Fullscreen640x480 $window(@bleh).hwnd
		Returns: -
		
		Displays a window in 640x480x32



		Command: Fullscreen800x600 [HWND]
		Example: /dll fullscreen.dll Fullscreen800x600 $window(@bleh).hwnd
		Returns: -

		Displays a window in 800x600x32



		Command: inFullscreen
		Example: //echo -a fullscreen: $dll(fullscreen.dll,inFullscreen,)
		Returns: $true/$false


		
		Command: OnTop [|HWND]
		Example: /dll fullscreen.dll OnTop $window(@bleh).hwnd
		Returns: $true/$false		

		If you don't call this command with a HWND it will use the current window which
		is in fullscreen. If there is no window it returns $false



		Command: Reset
		Example: /dll fullscreen.dll Reset
		Returns: -

		Resets the display settings and the window


		
		Command: ShowMouse
		Example: /dll fullscreen.dll ShowMouse
		Returns: -

		Shows the cursor



		Command: HideMouse
		Example: /dll fullscreen.dll HideMouse
		Returns: -

		Hides the cursor



		Command: DLLInfo
		Example: /dll fullscreen.dll DLLInfo
		Returns: -