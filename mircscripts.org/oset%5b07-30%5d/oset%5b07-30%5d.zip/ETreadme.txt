-----[ Installation ]-------------------------------------------

1. Unzip the contents of osET.zip into your mIRC root directory.
2. Type //load -rs $shortfn(etload.mrc) at the mIRC command line.
3. Click 'Yes' (do not press enter), when a dialog box popups up to ask if you want 
   to run the initialization.  If you do NOT click yes, the
   script will not be loaded.
   
Note: This addon requires mIRC 5.9 and above.  To get the 
      latest version of mIRC, visit http://www.mirc.co.uk/

-----[ Description ]--------------------------------------------

Enhanced Text v1.20 is an acronym addon with some extra goodies.  It turn the usuall "lol" to "Laughing Out Loud" etc., but with the option of choosing the style and colour.  Some acronyms can be turned on while others are off (all on by default).  Also has a feature which automatically changes any input text to the specified colour.  Simple Auto Welcome and Hurry Back feature is included. This addon has more words than any other acronym system that I have come across. eNjOy
-=oUTSIDEr=-