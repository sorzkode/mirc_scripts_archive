                                                 
   ___   __ _  ___    The
  / _ \ / _` |/ __|        Online
 | (_) | (_| | (__             Quizzing
  \___/ \__, |\___|                   Cheat
           | |     
           |_|     

v1.7 � by Gumby



Inhalt
- 1. Installation
- 2. Changelog
- 3. Datenbanken
- 4. FAQ - H�ufige Fragen
- 5. ToDo




 -- 1 Installation ------------------------------------------------------------------------------------

Alle Dateien in den mIRC Ordner entpacken und das Script mit /load -rs oqc\oqc.mrc laden.
(Bei WinZip bzw. Winrar muss "Use folder names" aktiviert sein!)
Die Frage beim Laden _MUSS_ mit "Ja" beantwortet werden, ansonsten kann es zu Fehlern im Script kommen.
Mit "/oqc" ruft ihr das Men� auf, "/oqc 0" schaltet das komplette Script aus, "/oqc 1" wieder an.
Au�erdem kann man "/oqc debug" benutzen um den DebugModus anzuschalten, wers brauch!
Die Sprache k�nnt ihr einstellen mit der Option "/oqc lang <datei.lng>".
Beispiel: /oqc lang deutsch.lng
oder:     /oqc lang english.lng
Standard ist es auf englisch eingestellt.
Um das Script zu entladen einfach "/oqc unload" eingeben. Danach kann der oqc Ordner gel�scht werden.



PS:  Danke an #quiz und #quizkanal im QuakeNet f�r die netten Q Bans.
     Hab euch ganz dolle lieb! Keine Angst, ich lass mir was Besonderes
     ganz alleine nur f�r euch einfallen, gelle CptnKiff? :)
     Denkbar w�re zum Beispiel ein online System f�r Datenbanken - eine
     Frage fehlt? Macht nichts, OQC Benutzer k�nnen sie automatisch hochladen
     lassen und f�r die Allgemeinheit bereit stellen. H�rt sich das gut an?!

PPS: Wer mich mal besuchen m�chte findet mich in #ficken300 im QuakeNet.




 -- 2 Changelog ---------------------------------------------------------------------------------------

1.7 - 28.12.2004
+ Readme.txt neu gestaltet
+ kurze englische Readme hinzugef�gt
+ das Script ist nun multilingual
* kleinere Fixes im on Text Event

1.6 - 26.12.2004
* irgendwie hat sich ein alter Fehler in die quiz.ini eingeschlichen - gefixt
* Neu hinzugef�gte Fragen werden nun richtig verifiziert
* Ebenso werden nun ge�nderte Fragen richtig verifiziert
* Unset Bug gefixt (verursacht durch gleichnamige Channelanf�nge getrennt durch ein .)
  Beispiel: #quiz und #quiz.de
* kleinere Ver�nderungen und Fixes am Code

1.5 - 26.12.2004
+ falsche Antworten in der Datenbank werden nun behoben
+ Verifizierung hinzugef�gt. Es wird nun gespeichert wann eine Frage zuletzt gesichtet wurde.
  Bei der Ausgabe der Antwort wird dieses Datum angezeigt sofern vorhanden
* quiz.ini aktualisiert (zb #bundesliga)
+ angefangen die Release Dates mit einem Datum zu versehen

1.4b
* beenden umbenannt zu schlie�en im Dialog
* man kann nun unbegrenzt Zeichen in die Editboxen einf�gen

1.4
* Bugfixes, der Miniripschutz ist drau�en

1.3b
* kleine Bugfixes (Moxquizz)

1.3
+ #quizkanal Support =)
+ Updates der Datenbanken

1.2
+ sollte jemand vor dir die richtige Antwort gesagt haben, so wird ein laufender Timer nun angehalten.
* kleine �nderungen an der quiz.ini

1.1
* kleine Bugfixes am Script, das KewlQuiz sollte jetzt auch gehen!

1.0
* erstes Release (private!)




 -- 3 Datenbanken -------------------------------------------------------------------------------------

Datenbank-Versionen:

#quiz.dat	-	21.08.2004
kewl.dat	-	30.07.2003
mox.dat		-	29.07.2003
#quizkanal.dat	-	21.08.2004 (hat ein paar Fehler in der Datenbank z. B. bei Sch�tzfragen)




 -- 4 FAQ - H�ufige Fragen ----------------------------------------------------------------------------

Frage:   Bekomm ich vom cheaten nen kleinen Puller?
Antwort: Nein. Da du mit OQC nicht cheatest, kannst du auch keinen kleinen Puller bekommen.
         Au�erdem machts die Technik, nicht die Gr��e ;)

Frage:   AHHH ich wurde in #lmaa gebannt, weil ich nicht rechtzeitig rausgefunden habe wo man
         den Cheat ausschaltet!
Antwort: Readme.txt lesen, rettet Leben!
         PS: /oqc 0




 -- 5 ToDo --------------------------------------------------------------------------------------------

- Button im Dialog um das komplette Script aus zu schalten
- sobald man als Cheater beschimpft wird eine Notice einblenden
- Timer selbst einstellen
- Verschreiber
- Signale weiter ausbauen

- #quiz/#quizkanal/#quiz.de �rgern - ganz wichtig :P


EOF