                                                 
   ___   __ _  ___    The
  / _ \ / _` |/ __|        Online
 | (_) | (_| | (__             Quizzing
  \___/ \__, |\___|                   Cheat
           | |     
           |_|     

v1.7 � by Gumby



Index
- Installation



 -- Installation --------------------------------------------------------------------------------------
 
Extract all files to you mIRC directory and load the script with /load -rs oqc\oqc.mrc.
(In WinZip or Winrar check "Use folder names"!)
Answer the question with "Yes" or otherwise the script will not work as intended.
Use "/oqc" to popup the dialog, "/oqc 0" completly deactivates the script, "/oqc 1" reenables it.
You can also use "/oqc debug" to activate DebugMode.
You can set your language with "/oqc lang <file.lng>".
i. e.:  /oqc lang deutsch.lng
or:     /oqc lang english.lng
Default language is set to english.
If you want to unload the script type "/oqc unload". You can delete the oqc folder afterwards.


There is more info about the script in german available. See readme.txt for german Changelog, Database
versions and Frequently Asked Questions. If you have any further questions feel free to contact me on
irc. Just /join #ficken300 at irc.quakenet.org and /query Gumby.


EOF