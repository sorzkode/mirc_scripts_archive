;-----------------------------------
;  D-mp3 Player - Verson 1
;  By jel/DND
;-----------------------------------

Unzip all the files in the zip file to your mIRC directory.  Open mIRC and type:

/load -rs dmp3/dmp3.mrc
or...type
//load -rs $shortfn($findfile(C:\,dmp3.mrc,1)) 

After Loading the helpfile will open to explain how to use the addon.
Openning the mp3 player itself, go to your menu bar at the top of mIRC
and there you will see an entry for D-mp3 Player
Note - this addon plays mp3's only.

Hopefully everything else on using the addon is contained in the helpfile.
Any probs/bugs either post them on the site where you downloaded this addon or contact me:
email: dnd@skylinebbs.com
msn: spab_sfw@hotmail.com
IRC: irc.skylineirc.com port 7000

jel/DND
