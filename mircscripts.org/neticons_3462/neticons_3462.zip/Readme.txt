There isn't much to say really these icon libraries and animations 
are compiled from the images supplied with VS Studio 2005 in the 
VS2005ImageLibrary folder.

I hope you enjoy them i find alot of them complement the silk icon set found at 
http://www.famfamfam.com :)

