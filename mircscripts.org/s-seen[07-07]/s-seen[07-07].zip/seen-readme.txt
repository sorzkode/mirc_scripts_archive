;======================================================
;S!Seen v 1.1 by Shikkie
;Date: 7/07/2001
;======================================================

---Installing

Unzip the seen.zip file to a folder on your hard drive.
Open mIRC. 
Go to the remotes editor (Alt +R) and select File-Load-Script. 
Browse to the seen.mrc file that you extracted from the .zip.
Press "Open." 
Press "Yes" if asked to run setup routines.

****** If you have a previous copy, to preserve your previous settings DO NOT extract seen.ini. However you will then have to manually set options for new features as your older seen.ini file will not support the new features ****

---Updates
v1.1 - 7/07/2001
added !uhostseen search for searching by nick!user@host
added &type, &itemnum, &maxresults vars
added results limit feature
added item seperator
Removed default limit on 3 characters in addition to wildcards. The reason for that was to prevent sending very long result messages. The new fix for that is the user-customizeable results limit feature.


---Features

Local Search of seen list. 
Highly configurable options for what events to track and !seen requests to accept.
Uses hash tables for more speed.

---Use

Pretty Self explanatory.

Themes: Click on "Vars" to get a list of the variables you can insert into the theme.
You can use colors, bold, underlines etc, and the &Vars you place will be replaced
with their value when the process is run.

-----Legal Jargon

-This script is � The Author, Shikkie. 
-Use of source code without The Author's permission is not allowed. 
-This script may not be distributed with copies of mIRC. 
-This script may not be distributed with any other scripts unless those scripts are by The Author. 
-This script may not be distributed if it has been modified at all. 
-Any other questions? Contact The Author. 
-This script is provided as-is. The Author is not responsible for any problems incured with the use of this script. 


-----Contact

contact shikkie@mircscripts.org with comments/suggestions