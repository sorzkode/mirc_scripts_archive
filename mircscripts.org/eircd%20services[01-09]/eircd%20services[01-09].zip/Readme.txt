######################################
#######/  _____/    \#/ __ \ ___ \####
######/  /###| | |#\ | /##\_\|##\ \###
#####/  /####| | |#/ |/####| |###\ \##
####/       /| |    / |####| |####| |#
###/  /######| | |\ \ \####| |###/ /##
##/  /#######| | |#\ \ \##/�/|##/ /###
#/_______/###|_|_|##\_\____/_____/####
#Services#Services##Services#Services#
######################################
#              /�\   /|              #
#         \  /   <    |              #
#          \/  \_/ . _|_             #
######################################
# Best viewed with Fixedsys or any
#  other monospace font.
######################################
# This is not a totally ironed out
#  version but i thought it was good
#  enough for public release.
######################################
# Contents
######################################
# Changes
# 1) Installation
# 2) Configuration
# 3) Accounts and Channels
#   a. Accounts
#   b. Channels
# 4) After all that
#   a. Starting the services
#   b. Turning the services off
#   c. Available commands
#     I. ChanServ
#     II. HelpServ
# 5) Credits
# 6) Contact
######################################
# Changes (- is Fix, + is Add)
######################################
# EIRCD Services v3.1
#  + !modelock to have certain modes
#     allways set/unset.
#  + Easier help setup, its now
#     /cs help topic/command.
#  - Helpers not being added/removed 
#     to/from helpers list.
#  - Signal debug echo
#  - Bug with server name not being
#     irc.*.net when connecting.
#  - Bug with unregistering main
#     channel.
#  - Errors in /help including:
#     !deftopic
#  - Bug with !deftopic and !topicmask
#     with deftopic set.
#  - !a not returning account
#     sometimes.
######################################
# 1) Installation
######################################
# Extract all the files in the .ZIP
#  file to your mIRC directory or
#  sub-directory. After all files have
#  been extracted, you can do one of
#  2 things:
#   Open the mIRC and type:
#    /load -rs "C:Path\to\EIRCD
#     services.mrc"
#              Or
#   Open the mIRC, hit alt+r, then
#    go to file, load and find the
#    EIRCD Services.mrc file and load 
#    it
######################################
# 2) Configuration
######################################
# Before starting the services, you
#  should change the configuration to
#  what you want. If you wish to edit
#  the configuration open settings.ini
#  with any text editor. The settings
#  are in the other catagory. Here is
#  an explanation of all the settings:
#   mainchan:
#    Where HelpServ is, people come
#    to register channels or get help,
#    whatever you want.
#   hskick:
#    After someone is finished being
#    helped, they get kicked after
#    this lenght(in seconds)
#   tmstart:
#    The starting charactor of the
#    topicmask(more information with
#    /cs help channel topicmask).
#   tmend:
#    The ending charactor of the
#    topicmask(more information with
#    /cs help channel topicmask).
#   started:
#    This is the same as EIRCD
#    startup in dontedit.
#   accountlen:
#    The max length of an account.
#   csaccount:
#    The oper account and password of
#    ChanServ. You must add it to
#    EIRCD for ChanServ to start up.
#   hsaccount:
#    The oper account and password of
#    HelpServ. You must add it to
#    EIRCD for HelpServ to start up.
######################################
# 3) Accounts and Channels
######################################
#                          a. Accounts
# All the accounts for ChanServ are
#  kept in settings.ini under the
#  accounts section. The accounts that
#  are currently logged into are in 
#  the logged section. You can add an 
#  account 2 ways, use the ChanServ
#  command to register, or do it
#  manually:
#   Go into your mIRC and type
#   //echo -a $md5(password)
#   Then add User=md5Password to the
#   accounts section
#  The admin account is just an
#  example. The password is admin.
#
#                          b. Channels
# All the channels registered and the
#  users with access to those channels
#  are kept in the settings.ini. The
#  settup is like so:
#   [#chan]
#   useraccount=access
#   [#chan2]
#   useraccount2=access
#   useraccount3=access
#   .
#   .
#   .
#  You can add users to the channels
#   manually or using the ChanServ
#   commands.
#
#                        c. Dont Allow
# This section holds any channels that
#  can not be registered. The format
#  is(1 being on 0 being off):
#   [disallow]
#   #chan=1/0
#   #chan2=1/0
#   .
#   .
#   .
######################################
# 4) After All That
######################################
#             a. Starting the Services
# To start the services just type
#  /eircdserv or on the server type
#  /serv on. After you typed that it 
#  will echo startup information to 
#  the EIRCDServices Console. If there
#  is an error starting up the
#  services it will close down all of
#  the services and echo the problem 
#  to the EIRCDServices Console.
#
#          b. Turning the services off
# To turn off the services you must
#  type /eircdserv.off or type /serv
#  off(you can also do /serv restart
#  to restart the services).
#
#                c. Available Commands
#  I. ChanServ
# To find out the available commands,
#  type /cs help in the server.
#
#  II. HelpServ
# These are the commands that HelpServ
#  has:
#   /hnext:
#    Help the next person in line(only
#    helpers)
#   /hdone:
#    Finish helping someone(only
#    helpers)
#   /hdesc:
#    Specify a description about your
#    problem(not helpers)
#
# Missing any commands? I know i am!!
#  I will be adding more commands but
#  if you really want one please, talk
#  to me(Contacts topic 6).
######################################
# 5) Credits
######################################
# v3.1
#  PumaKuma:
#   Lots of testing and ideas.
# v3
#  stx-`Slipknot-:
#   Tested almost every command and
#   found a lot of bugs(:/).
#  scoutZor:
#   Tested out first commands for
#   ChanServ
#  codemastr, Coag, bewpy:
#   Help test
######################################
# 6) Contact
######################################
# If you have any suggestions, bugs,
#  ideas, rants, or anything else
#  related to EIRCD, feel free to
#  contact me any of these ways:
#   irc.gamesurge.net in #script
#    with nickname poiuy_qwert
#   irc.scriptersirc.net in
#    #scriptersirc with nickname
#    poiuy_qwert
#   p_q-poiuy_qwert@hotmail.com is
#    my email you can contact me at
#    but i dont really check it too
#    much
#   http://p-q.no-ip.org
#   Or just post a reply wherever
#    you downloaded this at :)
######################################
#######/  _____/    \#/ __ \ ___ \####
######/  /###| | |#\ | /##\_\|##\ \###
#####/  /####| | |#/ |/####| |###\ \##
####/       /| |    / |####| |####| |#
###/  /######| | |\ \ \####| |###/ /##
##/  /#######| | |#\ \ \##/�/|##/ /###
#/_______/###|_|_|##\_\____/_____/####
#Services#Services##Services#Services#
######################################