sxCardFighters v0.3 - Jeric Helsvin - The Found Swords (Chapter 2)
11082005 3:00PM by sprion(@lyniq.com)

Story:
	Jeric Helsvin falls deeper into his dream. His sword has suddenly returned,
	and so has his enemies'! The appearance of his lookalike enemy Krishnan has
	stunned him yet sparked a realization that things could be better than reality
        Who is this Krishnan Ganesan? Why does he resemble Jeric? The answer will
	astonish all..

	The question remains: Why are they fighting? Where are the others?


Game Info:
	Life - Determines how much HP the character begins with
	     - How much HP is regenerated per defended attack
	Strength - Determines how much force per attack/defend
	Luck - Determines how good your CARDS are

	Each defended attack regenerates your character's life
	Each attack can be defended by a specific move and can be 
	  worsened by another

In the next chapter:
	Online play - 1 vs 2?
	More found Weapons
	More heroes returns
	Learned magic spells?
	

Installation:
	1. Extract all the files to a folder (i.e. C:\sxcf)
	2. Load the file. '/load -rs c:\sxcf\sxCardFighters.mrc'
		Replace the folder above with the one you installed to
	3. Type '/sxcf' to begin
