Name Revenge
Author sethyx`
EMail sethyx@axelero.hu
Website http://sethyx.atw.hu
Description Revenge MTS theme created for NoNameScript, works in any MTS engine.
Version 1.0

You should copy the Revenge directory into /mirc/themes .

Then open the KTE, load revenge.mts & enjoy ! ;)