mIRC Conversions Readme
Created By zack^

Have you ever wanted to know what 145 protonmasses was in steradins? Or perhaps you have pondered over the number of spats in a lightyear. Whatever you have dream about, I have the answer for you!

Just load the convert.mrc into your remotes, by typing /load -rs convert.mrc (You may need to change the file location, depending on where you extracted the files too), and type /convert in mIRC. Its that simple!

You may be asking yourself, why? And the answer is simple, because its 5am!

Have fun cadets,
Zack.