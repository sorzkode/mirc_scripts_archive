==============================
=                            =
= InstallFont DLL v1.0       =
=                            =
= by Soul_Eater              =
==============================

This DLL temporarily installs (and uninstalls) a font for mIRC to readily use.
When mIRC is done using the font, use the uninstall function.


Functions:

InstFont

//echo -a $dll(installfont.dll,InstFont,fontfilename)

Installs the font

Example: //echo -a $dll(installfont.dll,InstFont,"C:\windows\fonts\arlbl.ttf")


RemFont

//echo -a $dll(installfont.dll,RemFont,fontfilename)

Uninstalls the font

Example: //echo -a $dll(installfont.dll,RemFont,"C:\windows\fonts\arlbl.ttf")


DllInfo

//echo -a $dll(installfont.dll,DllInfo,.)


Contact:

SoulEata on AIM
souleata@xrs.net