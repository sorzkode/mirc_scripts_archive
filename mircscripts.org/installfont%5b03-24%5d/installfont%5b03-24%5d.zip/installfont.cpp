/* Install Font Dll ********************************************************
 *
 * Version:			1.0.0.0.0
 * FileName:		installfont.dll
 * Date Created:	3/24/2004
 *
 * Author:			Soul_Eater
 * Comments:
 *		Installs fonts temporarily for mIRC
 *
 *******************************************************************/

#pragma check_stack(off)
#pragma comment(linker,"/OPT:NOWIN98")
#include <windows.h>
#include <winuser.h>

HWND mwnd;

int __stdcall InstFont(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
	
 AddFontResource((LPCTSTR)data);
 SendMessage(HWND_BROADCAST,WM_FONTCHANGE,0,0);
lstrcpy(data,"F_OK Font installed");
return 3;
}

int __stdcall RemFont(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
	
 RemoveFontResource((LPCTSTR)data);
 SendMessage(HWND_BROADCAST,WM_FONTCHANGE,0,0);
 lstrcpy(data,"F_OK Font Uninstalled");
return 3;
}


int MsgBox(char *data)
  {
 int xa = MessageBox (mwnd, data , "InstallFont DLL" , MB_OK | MB_ICONINFORMATION );
 return 0;
}


int WINAPI DllInfo(HWND,HWND,char *data,char*,BOOL,BOOL)
{
   MsgBox("InstallFont DLL v1.0 by Soul_Eater \n�2004\nContact Information:\nAIM- SoulEata");
   return 0;
}
