+--------------------------------
| SpaceOrange 1.1 by cyndis 
+--------------------------------
For help in loading the theme, look at your MTS theme engine's documentation.
If you don't have a MTS theme engine, i recommend you to use Kte (Kamek's theme engine),
you can find it here: http://www.mircscripts.org/comments.php?id=1194

//cyndis @ IRCnet,QuakeNet,IhmeNet,Undernet

Version history:

1.0 First release

1.1 Second release
added 12 schemes