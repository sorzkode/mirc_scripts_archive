.------------------------------------.
: vHost Changer v1.11 for UnrealIRCd |
'------------------------------------'

Released: 8, 2004
Type: Snippet
Requirements: mIRC 6.1x
Contents: vhost.mrc, readme.txt 
Author: Gizmo967
Home: http://www.mgs3.org
IRC: irc.mgs3.org #Help


I. Instructions:
	unzip countdown into your mirc\ directory then type:
	/load -rs vhost.mrc
        and to unload the script:
        /unload -rs vhost.mrc
	
II. Command
        !vHost <vhost>

III. Comments:
	Feel free to use this script to learn and to expand your ideas. please do not rip.

IV. Credits
        [M4rk0] (www.mostarac.net)

V. F.A.Q
        [*] How to add badword?
          Find line var %ban irc vhost.mrc and: Example: If you want to add word IRC to badword,
          you do next way: var %ban (bitch|shit|fuck|asshole|IRC)
          NOTE: It's important that you don't add "|" after last badword else it wont work.
        [*] How to change ignore time?
          To change ignore find line set -u600 in vhost.mrc and change 600 to whatever you want
          NOTE: it is in sec (600 = 10min)
        [*] How to set so user must have atleast 10 char vhost?
          To set short vhost find line: if ($len($2) < 5) in vhost.mrc and change 5 to 10 or
          whatever you want. NOTE: 5 is defult.
        [*] How to set it so users can use longer vhost?
          To set longer vhost find line: if ($len($2) > 60) in vhost.mrc and change 60 to 
          whatever you want it. NOTE: 60 is defult

VI. Changes:
        v1.11
          - Huge bug fixed! (This bug made v1.1 not work most of time!)
          - Documentation improved (Added FAQ on how to add/change things)
          - Added unset %vhost %vhostchan on unload
        v1.1
          - Now checks IRCd version on connect
          - You can't use snippet if you are not on UnrealIRCd
          - Menu will appear only when you /oper
          - Now you can set the channel you want to use !vhost in