## log.mrc
## advanced logging
## v1.0 - ash@scripters-austnet.org

What is it?
---------------------------------
log.mrc is a script which sees mIRC events, checks its table of logging rules, then logs the event if needed.  It provides many more features than standard mIRC logging, but also takes alot more processing.  It seems to work with no problems on my 350mhz pc, but if you're on a REALLY old computer and you're in channels that has alot of stuff happening then it might not be a good idea to have too many logging rules.

Advantages of using this script for logging are:

* ability to create more powerfull logging than mIRC can provide
* dynamic logging
* logs are written in the standard mIRC format, and thus are compatible with stats scripts etc.
* only events are logged, rather than just any output which echos. ie. "-> *NickOP* identify passpuss" wouldn't be logged as it isn't a channel event.

Yes, the script uses /log and halts the default mIRC command.  This is partly because I couldn't think of a better name for it, and also, if you're using this script you don't really need to use mIRC logging anyway.

/log has two parameters:
reload - start the logger if it isn't running or reload the log.db file. reloading the log.db file is only necessary if you manually edited it, rather than using /log add
add - add a logging rule.
list - list the active logging rules.
del - delete a logging rule. the rule can be a number (referenced from 'list'), or a rule that completely matches a current one.
flush - flush all rules.

When you first load the script, you should do /log reload to get it running.  In future it will load itself on start.  Now to start adding rules!  This means using the command:
/log add <rule>

rules have the following format:

log <events> in <targets> from <nicknames> to <output> [options]

** events **
The events are thesame as the remote name for that event, ie. "join,part,text,action,ctcp" etc.
Multiple events are to be seperated by commas.  The event 'all' matches every event. Events can be negated by prefixing them with a exclamation mark (eg. !kick).

** targets **
The target is the 'target' of the event.  This could be a channel, nickname (for query), a '#' or '?' to match all channel/queries.  Seperate targets by commas.

** nicknames **
The user(s) triggering the event, seperated by commas.  Can be a wildcard. Nicknames can be prefixed with an @ or + to indicate that they must be opped or voiced.

** output **
The output is where the log is sent to.  This can be a file, and window, a #channel/nick or a command.  Each are prefixed by their type, ie.

window @hi
irc nick/#chan
file &t.&w.log

you could put specify the window as an /echo switch due to the way it works, such as
'window -a'. Logs will then echo in the active window.

File's have meta-characters starting with &.  These are:

&c - Channel
&t - Target (usefull for rules involving both channels AND queries)
&n - Nickname
&w - Network

** options **
Options modify the way the event is logged. Currently the only options are strip and notimestamp which are pretty self explanatory

NOTE
------
This script doesn't log your own messages 

Examples of using /log
-----------------------

The following examples don't include the "/log add " you must write before them.

** EXAMPLE 1 **

log join,part in # from * to file modes.&c.log strip notimestamp

This will log all joins and parts in any channel (#) from any nickname to the file modes.<#channelname>.log with no timestamp. The 'strip' on the end means that control codes are stripped from every event.


** EXAMPLE 2 **

To do the standard mIRC logging, add the following rule:

log all in #,? from * to file &t.&w.log

However, this will make private notices also log to query logs, so you may want to use this:

log !notice,all in #,? from * to file &t.&w.log

If you were in a channel that you don't want to log, such as #warez, you could make it:

log !notice,all in !#warez,#,? from * to file &t.&w.log

The !notice MUST come before the 'all', and the !#warez MUST come before the other targets due to the way it's parsed.  In other words, make sure you put the negated parameters before the others.

** EXAMPLE 3 **

log mode in #scripters from @* to window @opwatch

This will log all channel modes that ops do into the window @logwatch.  Generally only ops can do modes anyway, but you get my point.

---- to do ----
I'm probably going to add features to log other events such as sockets opening, dcc's, etc.

********************

If there's anything you're unclear on, or you want to make a suggestion, email me at ash@scripters-austnet.org and I'll be  glad to hear from you.