Zip.dll v1.02 for mIRC by mc68000
---------------------------------

Description:

  A simple .dll to zip and unzip files and directories. Uses a zip component
  by Turbopower that is open source and available on SourceForge.net

Introduction:

  There are 3 functions: _zip, _unzip and _about

Usage:

  _zip function:

    echo $dll(path\to\zip.dll, _zip, -d "c:\example\file.exe" "c:\test.zip")
    ...should return "OK" if all is well and "Error" if a problem is encountered

  _unzip function:

    echo $dll(path\to\zip.dll, _unzip, "c:\example.zip" "c:\extractdir")
    ...should return "OK" if all is well and "Error" if a problem is encountered

  _about function:

    echo $dll(path\to\zip.dll, _about, _)
    ...should return some info about the dll

Explanation of _zip function:

  There are 3 arguments you must supply to the dll. The first one
  is either -d or -r. -d tells the dll to zip only the file(s) in
  the directory specified. -r tells it to recurse directories,
  zipping all files matching the filename or filter.
  The second argument is the source. You can specify a filter for
  the filename, and the dll will only zip those files matching.
  Example is *.ini will zip all .ini files in the directory.
  The third argument is the filename of the zip target file. If
  files already exist in the target .zip they will be replaced.

  IMPORTANT: Make sure arguments 2 and 3 are surrounded by " and ",
             even if they don't contain spaces. Make sure you supply
             a switch (-d or -r) as the first argument. IF YOU DO
             NOT DO THIS EXACTLY IT WILL PROBABLY CRASH mIRC!!!!!!

Explanation of _unzip function:

  There are 2 arguments you must supply to the dll. The first one
  is the actual zip file you want to extract (surrounded by quotes).
  The second argument is the destination directory for the unzipped
  files (surrounded by quotes). If files already exist in the target
  directory they will be overwritten. The target directory MUST exist.

  IMPORTANT: Make sure you surround each argument with quotes (")
             even if they don't contain spaces. IF YOU DO NOT DO
             THIS IT WILL PROBABLY CRASH mIRC!!!

Note:

  Let me know of any bugs, but make sure you surround your filenames
  with quotes as I know that problems occur if this isn't done. The
  reason for needing the quotes is for 2 reasons. (1) In case a file
  or dir name has spaces in, and (2) To ease the parsing of the arg-
  uments. I don't add 1,000,000 options for zipping and unzipping for
  the reason that I wanted this dll to be fast and simple to use.

  Enjoy,
  mc68000 (mc68000@nextgenirc.net)
