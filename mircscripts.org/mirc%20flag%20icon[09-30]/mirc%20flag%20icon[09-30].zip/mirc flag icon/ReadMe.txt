mIRC Flag Icon
---------------

Hey again, its me with a funny icons again :P

Okay this time, im modified mIRC icons based on the nation flag
where cLeuS from mircscripts.org had asking me if I can make
more icon with a flag. So this is it(but yeah its only contain
7 icon with a different m - where the flag contain)

I have randomly pick this 7 nation to make this, so how about if 
your nation flag not in this collection?

First, yes you can make it yourself(if you want and know how) or
ask me to do it :P(but theres only a slim chance :P) or you can
ask someone else that know how to make an icon or learn how to make
it yourself or wait for somebody publish their icons or etc. :)

Phew a lot of or....

What contain in the archive
-----------------------------

Its come in .bmp, .ico, .gif and .png with a dimension of 32x32 pixels.
(I kinda lazy to make it in the other size :P)


Terms of Use:
--------------
Heh, is it real? Its had a term for using it? Yes dude, you need to follow
this thing either on commercial or personal used:

1 - Use it freely(which means do whatever you want with it :P)
2 - Always enjoy to see and use it :P
3 - Delete it if you dont like(that will save your hard disk space :P)

Heh, actually that not a term :P

So do anything you like with it either use it on your script, on your website
or anything, anyplace(that icon can be put, logical man logical heh) and
anytime since its a free to use :p Its up to you!

Last thing ENJOY it!

P/S: Credit goes to Khaled because its mIRC make my life so cheerful :)
     Also to da^hype, h3lp and bruas that always help me a lot in mIRC scripting
     (Uh uh is this read me file for icon or script :P)
     For all chatters especially mircscripts.org, mirc.net, hawkee.com members
     thanx all for da comment... even if its a negative one but hey thats what 
     a life isnt it?
     Lastly to you because downloading this thing(even if you dont intend to use
     it)

zonIRC
Thu Sep 29 17:55:16 2005