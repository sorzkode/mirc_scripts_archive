.:: ��Litoplath�� ::. .:: ��Mp3 System�� ::. .:: ��By aura�� ::.
________________________________________________________________

Because I liked the Mp3 System that I put together in my script,
I thought I would make it into an addon for other people to use.
So here it is...
________________________________________________________________

Works on mIRC v5.91 - Haven't tried it on others!
Extract the mp3system.mrc into your mirc directory and simply 
type;

//load -rs mp3system.mrc

And voila!
________________________________________________________________

Send any comments/suggestions to aura aka Kate (girl scriptah!)

attraktion@excite.com

Keep a look out for future updates!