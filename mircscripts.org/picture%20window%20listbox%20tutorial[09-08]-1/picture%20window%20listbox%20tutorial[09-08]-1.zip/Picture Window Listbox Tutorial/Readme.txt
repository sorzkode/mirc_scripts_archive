----------------------------------------------
     Picture Window Listbox Tutorial
----------------------------------------------

To run the worked example, in the tutorial do the following:-

1.	Copy the example code into your mIRC remote.
2.	Copy the genre.txt file from the tutorial directory, to the script directory.
3.	Type /load.buffer in the active window editbox to create the genre buffer file.
4.	Complete the /test1 alias as indicated in section 4 by the listbox diagram (your going to have to read it =D )
5.	Type /test1 in the active window editbox

The sample listbox should open up, and be fully functional.

If you come across any errors or have suggested improvements, contact me, details are at the end of the tutorial file.