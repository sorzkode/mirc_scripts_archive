                      _/_/_/                        _/
     _/_/_/  _/_/    _/    _/    _/_/_/  _/_/_/    _/  _/
    _/    _/    _/  _/_/_/    _/    _/  _/    _/  _/_/
   _/    _/    _/  _/    _/  _/    _/  _/    _/  _/  _/
  _/    _/    _/  _/    _/    _/_/_/  _/    _/  _/    _/
			v1.1

			by zack^.

Contents:
	- Introduction
	- Installation
	- Usage
	  - Section 1 (Script)
	  - Section 2 (Dialog)
	- Un-install
	- Credits
	- Further information
	- History


Introduction:

	Welcome to mRank, first of all I would like to thank you for downloading this mIRC add-on, 
and hope it fulfills everything it sets out to do. mRank, is a mIRC channel statistical logging 
system, with many features. It logs most of IRC's commonly used channel events, such as messages, 
actions, joins, parts, quits, etc. It logs these in a single file, so it's not creating a lot of 
redundant files. This also makes sorting and removal of the add-on much more easier.

	It also has a placing, and top ranking system, where users can compete to be the top speaker
in the channel and check their progress. Or a channel operator might want to keep a record of the most
active users in the channel for channel organisation purposes. Whatever your reason for using it, if
you want to keep record of users in the channel, then this is for you.

	I originally set out in making this add-on to compete against the statistical logging system created
by equak, which in my opinion can be quite slow in large channels. Hopefully this one will be faster and
provide a lot more features than his version. This will also provide IRC users with a choice, so if
they like equak's version then that's fine, but I ask that you try them both before passing judgement.
I personally didn't like his slower (for me) version, how you feel could be different.

Installation:

	Installing this add-on is quite simple, you just load it like any other mIRC add-on, if it was in your 
mIRC directory than you would use:

		/load -rs1 mRank.mrc

	Otherwise if it was in another directory you'll have to use:

		/load -rs1 directory/to/mRank.mrc

	Note: You must be running mIRC 6.1 or above to use this add-on.
	
	When you load, click YES when it asks and a dialog will appear asking you to change settings, and add 
channels. If you select NO then you'll have some problems with the add-on, just unload (see Un-install section) 
and reload selecting YES next time. By default the settings are:

		- Database file: mRank.db (This file is always in the same directory in which the script 
		  mRank.mrc is located).
		- Message Type: Msg Channel
		- Switch: Enabled
		- Flood Pro: 5 secs
		- Host Type: 13

	Change any of these as you wish, what they are will be explained in the Usage section. And that's about it,
you're now ready to record channel stats in the channels/networks you've choosen.

Usage:

- Section 1 (Script):

	After installing there is nothing else you have to do, but only look out for cheaters (damn I hate them).
In future versions I may include a function to ignore users, a ban type of feature...

	If you've set everything up correctly then it should work without any issues (if you get strange errors,
you know you've done something wrong, yes YOU not the add-on, the add-on is PERFECT! YOU HEAR ME!). If you do happen
to receive any strange errors that you cannot fix, contact me at zack@mircscripts.org.

	Accessing the stats list and other features is quite simple, please note that YOU CANNOT TYPE THESE YOURSELF.
IF YOU WANT TO RECORD YOUR OWN TEXT, YOU'LL HAVE TO LOAD THIS ONTO A BOT OTHER THAN YOUR OWN MIRC OKAY?

	The commands include (please note, when you see[word] it means it's optional):

		- !stats [nickname] : This displays the user the statistics of a user, if 'nickname' is specified it
		  shows the stats of the nickname stated.
		- !topN [section] : Shows the top N ranked users from the channel in the words section, if 'section'
		  is specified than it shows the top N users in that section.
		  For example: !top32 words
		- !place [section] [nickname] : Displays the placing of the user from the channel in the words section,
		  if 'section' is specified, it shows the ranking of the user in that section, if 'nickname' is specified,
		  and 'section' is specified, it displays the ranking of the specified user in that section, otherwise
		  section words is used.

	This statistical system logs the following events:

		- Number of Words (NOTE: A word in this add-on is defined as having 3 or more characters).
		- Number of Characters
		- Number of Smilies (Yes I spell it like that, and is how it's used in this add-on, other variations won't work).
		- Number of Swears
		- Number of Lines
		- Number of Control Codes (Bold, Underline, Reverse, Colour, etc)
		- Number of Kicks given
		- Number of Modes set
		- Number of Topics set
		- Number of Actions (Actions also affect words, characters, smilies, swears, lines, and ctrl codes).
		- Number of Joins
		- Number of Parts
		- Number of Nicknames used
		- Number of Quits

	The system records users on mIRC mask type 13, for example:

		zack^!zack@dialup-217.173.220.203.acc01-cres-mil.comindico.com.au

	Will be recorded as:

		*!*zack@dialup-???.???.???.???.acc??-cres-mil.comindico.com.au
	
	This may cause some problems with repeating of nicknames within the stats, that means the user has changed host, 
ip or ident format since the last logging. If a user doesn't change this, then no matter what nickname he/she uses
the stats will follow them. A future function may be to allow the runner of the stats to include stats from different
entries in the database.

	Sections within the add-on are important to know because you require them when using !top10, !top20 and !place.
They include:

		- Words
		- Chars
		- Smilies
		- Swears
		- Lines
		- Ctrlcodes
		- Kicks
		- Modes
		- Topics
		- Actions
		- Joins
		- Parts
		- Nicks
		- Quits

	You'll use these, and only these when typing in one of the commands above, some examples would be:

		!place swears zack^
		!place lines
		!place zack^
		!top10 smilies
		!top20
		!top20 words

	In essence , it isn't that hard, you just gotta remember them all. Typing an invalid !place response will return
the list of sections, so that might make things easier.

- Section 2 (Dialog)

	The setting dialog might look confusing at first, but this section will explain what each function does. The
	dialog consists of 2 sections, the 1) Channel Setup, and 2) Options.

	1) Channel Setup
	Simply put, this is where you put in which channels and on which networks mRank will run in. So if you want
	it to run in #Scripting on DALnet, you'll enter:
	
	#Scripting

	Into the 'Channel' part, and:

	DALnet

	Into the 'Network' part. And then you'll click 'Add' to add it to the list. You can edit and delete just by
	selecting an option from the list and editing the data, or delete it.

	2) Options
	This section is further split up into smaller sub-sections,

		- Database File: This is what file all your channel statistics will be held, just type in a filename
		  and press 'Set'. This file will be saved to the root mIRC directory, so DO NOT enter any directories.
		- Message Type: This is how the script will reply to users who use a command, eg: !stats, !top10, etc.
		  You can either message the channel they typed the command in, or notice them the results.
		- Switch: This turns mRank on/off in all channels.
		- Flood Pro: This feature is a protection so you're not flooded off with results to users. For example,
		  If you set it to '5 secs' it means that only 1 command for mRank can be typed every 5 seconds.
		- Host Type: Configures what host type is stored for nicknames, you can find out what each number means
		  by typing /help $mask in your mIRC and reading the help on it.

	When you change the host type, a new dialog will open which will ask you if you want to change the database file.
	You must press 'Yes' for this if you want to continue using any stats that you've already been recording. BUT
	there is no promise that the stats will be saved correctly, because mIRC's $mask is VERY limited in what it can
	process, it isn't a mind reader. So please do not come to me saying this is a bug, I know that it exists and I can't
	do anything about.
	If you've accidently changed the host type, just select 'No' in this dialog and no changes will be made.


Un-install:

	Quite simple, just type the following command in your mIRC which has the add-on loaded:

		/unload -rs mRank.mrc

	Then select whether you want to remove the database file or not, and then it's complete.

Credits:

	mRank was developed by zack^, over one weekend, and through many apple juices.

	Special thanks go to the following people

		- plugged for the words regular expression.
		- Sam, Splodge, norad, W1cK3d and a few others for testing it out (Peeps in #scripting and #ircgeeks).
		- #Scripting and #IRCgeeks on DALnet, for allowing me to flood them for hours on end with useless
		statistical information.
		- equak for making me want to make a faster channel statistical system than his *cough* attempt.
		- My brain + hands, you've been through a lot.
		- That figlet thingy for my logo
		- And anyone else I've forgotten.

Further Information:

	You can contact me through either connecting to DALnet (irc.dal.net, mesra.dal.net, hotspeed.dal.net, etc)
	and joining #Scripting, PMSG through mircscripts.org (nickname zack^), or through email zack@mircscripts.org.

History:

v1.1 (290 lines)
------
* Fixed up messy coding.
* Edited readme correctly, and fixed some typographical errors.
* Added, !topN feature, with the ability to do a top listing of users from a seed of N.
* Added, ability to change the host type stored.
* Added, db.changehost alias, which changes the currently stored database file to the newly selected host type.
* New dialog, to incorporate new host type feature.
* Beta combine_stats alias, not fully functional, but it allows you to combine multi-host stats, where if the 
  same nickname has used many different hosts, this will combine them all with:
  /combine_stats <network> <channel> <nickname>
  Doesn't fully work, and can cause errors so it's by default commented out.

v1.0 (231 lines)
------
Initial public release on www.mircscripts.org