MyURL Dupe Checker 1.0
  - Funky

----------------------------------------------------------
Stuff
----------------------------------------------------------
Very simply this script monitors a channel for URLs or URIs
whatever you want to call them. It's spammable and can be a
little easyer to use but it works well.

You need to create a database and create the table structure
below in that database. (MySQL).

You also need to load mIRC MySQL Interface v1.3 By MonoTek.
It is available here:

http://www.mircscripts.org/comments.php?cid=1393



What this script does:

When a user types a URL in the channel it gets logged in 
the DB. When the same user (same nick) types the URL again
it notices the user how long ago they typed the URL.

If another user types the URL after its already been seen,
the script messages the channel with the nick of the
original user who typed the URL and how long ago it was.

That's it that's all. One good thing about this is with a
DB it's easy to add this to a website aswell.


----------------------------------------------------------
MySQL Table Information:
----------------------------------------------------------

CREATE TABLE `url` (
 `id` int(10) NOT NULL auto_increment,
 `date` timestamp NULL default CURRENT_TIMESTAMP,
 `nick` varchar(9) collate latin1_general_ci NOT NULL,
 `chan` varchar(30) collate latin1_general_ci NOT NULL,
 `url` varchar(200) collate latin1_general_ci NOT NULL,
 `type` varchar(4) collate latin1_general_ci NOT NULL,
PRIMARY KEY  (`id`)
)  ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;