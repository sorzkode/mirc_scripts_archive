/*
  Thanx to L. Peter Deutsch <ghost@aladdin.com> Aladdin Enterprises
  who has wrote md5.cpp and md5.h
*/

#pragma check_stack(off)
#pragma comment(linker,"/OPT:NOWIN98")

#include <windows.h>
#include "md5.h"

int __stdcall md5(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
{
	// declaration des variables
	char car[900];
	char hex_output[16*2];
	int len;
	int di;

	// cr�ation du code md5
	strcpy(car,data);
	len = strlen(car);
	md5_state_t state;
	md5_byte_t digest[16];
	md5_init(&state);
	md5_append(&state, (const md5_byte_t *)car, len);
	md5_finish(&state, digest);

	for (di = 0; di < 16; ++di){
	    wsprintf(hex_output + di * 2, "%02x", digest[di]);
    }
	wsprintf(data,"%s",hex_output);
	return 3;
}