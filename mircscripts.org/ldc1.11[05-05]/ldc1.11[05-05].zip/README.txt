-= Leprechaun dialog creator v1.11

This addon was made to make it easier for newbie scripters
to understand how dialogs are built up, and help them create simple
dialogs. It only helps with creating the graphical display.
Use the mIRC help file to learn about the /did command and the
$did identifier.

An example project is included to show how this dialog creator works
To view this, select Leprechaun Dialog Creator -> Open Project (menubar).
A dialog will then pop up with the projects. Select Example.
When the Dialog interface editor has finished loading,
right click and select 'Compile'. In the @Dialog�Source 
window you can right click and select Run to view the dialog.

Loading the file:
You really should know this, but... to load the file type /load -rs [subdirectory]\ldc.mrc

NOTE:	You should not have windows maximised when you use this addon.

The output of this addon (the dialogs that are made) can be used in whichever
ways you like, but I would be thankful if you could let the comment that it
was compiled by this creator remain in the file :)


-= Creating new Items

Item creation is fully drag/drop compliant, like most other dialog designing
tools, and is therefore not further documented.


-= Compiling methods

1. Created
	Items will be arranged according to the creation order

2. X -> Y
	Items will be arranged first by their X value, then their Y value

3. Y -> X
	Items will be arranged first by their Y value, then their Y value

4. Identifier.ID
	Items will be given the last number in their identifier as an ID,
	and sorted by these. This method will make it possible to rebuild
	dialogs imported from files, with the same ids.


-= Other important stuff

If there is something you don't understand, try searching 'ldc versions.txt'
for it, as it most likely will be described there.


-= Credits:
ProjectX scripting Crew (www.projectx.mx.dk)
The guys there gave me some excellent ideas and solutions for some proplems.
Thanks guys.



-= Bugs/comments/suggestions
Please mail me comments or suggestions.

Ymar(_the_Leprechaun)
(leprechaun@aurskog.net)


