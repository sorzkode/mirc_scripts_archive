TwistOFlex by ToKeN 2004

To install >>

1) Copy all files from the .zip file into a directory on your hardrive.

2) type /load -rs whatever_the_scriptdiris_\twistoflex.mrc 

3) Follow instructions on load

- Peace ToKeN
- j_ustin_@hotmail.com