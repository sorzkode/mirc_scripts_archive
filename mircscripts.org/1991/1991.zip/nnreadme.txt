NoNameScript version 4.03 readme
================================

If   you   have   trouble   using   the   script,   check  out  our  forums  at
http://www.nnscript.de.


Known bugs in this version
--------------------------
- The custom treeview switchbar may disappear when using a multi-monitor setup.
  I haven't found a fix for this yet.
- The channel central may display incorrect ban/invite/except information. This
  is  due  to  some bugs in mIRC 6.17 and will hopefully be fixed when the next
  version of mIRC is released.


That's all, have fun.
