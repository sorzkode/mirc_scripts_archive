===============================================================================
 Jaffa Icon Collection
-------------------------------------------------------------------------------
 Copyright �2002 Greg Fleming of Dark Project Studios.
===============================================================================

	ICON PACK NAME:         Jaffa
        DATE RELEASED:          27/09/2002
        ICON FORMAT:            Windows .ico (32x32 & 16x16)
	COLOUR DEPTH:		24bit colour
        # OF ICONS in pack:     78

	AUTHOR:                 Greg Fleming (aka Hell Dragon)
	e-MAIL:                 helldragon@darkproject.com
	WEB:                    http://www.darkproject.com	


[-- Tools Used: --]
-------------------------------------------------------------------------------

  [   ] Adobe PhotoShop
  [   ] JASC's Paint Shop Pro
  [ x ] Microangelo Icon Studio
  [ x ] Icon Collector Graphics Editor
  [   ] Adobe Illustrator



[-- Icon Description: --]
-------------------------------------------------------------------------------

Jaffa is a complete system replacement set, designed to change the look of all
the icons on your system; Your desktop, start menu, folders, drives, files etc...

The style is a bright tasty orange and grey, mixed with a healthy splash of colour
here and there... and has an almost toy like quality to it, whilst still keeping a
professional clean look.

Originally codenamed 'Solero', the final name of the set was changed to 'Jaffa'
after the orange-centred Jaffa cake biscuits. :)



[-- Installation Instructions: --]
-------------------------------------------------------------------------------

To install these icons on your system you can either apply each one manually
using an icon changing tool like:

** iPhile: http://www.virtualplastic.net/scrow/iphile.html

Or you can download and install:

** IconPackager: http://download.com.com/3000-2195-10146793.html?tag=tid

and double click on the .iptheme file included in this zip file which will apply
all of the icons automatically for you.



[-- Copyright & Legal Information: --]
-------------------------------------------------------------------------------

a) ALL of these ICONS were created solely by Greg Fleming (aka Hell Dragon) of
   darkproject.com.

b) The icons are Freeware for PERSONAL USE only.

c) The icons may NOT be re-distributed on download sites without my permission
   and when they are I must be given FULL credit for the work, as the original
   creator of the icons.

d) This readme file must also be KEPT intact and unaltered with any of the icons
   that are distributed and the icons may NOT be CHANGED, RENAMED or ALTERED
   in any way.

e) Feel free to use my icons for your own individual projects and needs - but 
   my permission MUST be acquired before any money may be made from the icons.
   
f) Therefore, YOU may NOT use my icons in any THEMES, SKINS, SOFTWARE,
   WEBSITES, Books, CD's or in any COMMERCIAL way... without my PERMISSION first.

g) If you want to use them in your software applications, or to use them as graphics
   for your personal web page, please drop me an e-mail with the details and the URL.

-------------------------------------------------------------------------------