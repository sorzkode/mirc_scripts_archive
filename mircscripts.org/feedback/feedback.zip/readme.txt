
                                    *** FeeDBacK 'readme' by MaL-FuNcTi (PTnet) ***

          	                    www.feedbackscript.cjb.net / feedback@yours.com

===Attention: ===================================================================

- Script was meant to run under mIRCv5.82 (some features cannot work properly if lower or higher version)
- Avoid install FeeDBacK in a folder w/ spaces. I'm trying too prevent that but sometimes script can stuck completely.


===Index: =======================================================================
						   
1. Instalation
2. Upgrading
		
	    
==============
1.

*If this is the complete script 'feedback.zip'*

  Unzip files to an empty folder (Eg. c:\feedback) and run mIRC32.exe


*If this is only script files 'feedback_f.zip'*

  Unzip files to an empty folder (Eg. c:\feedback)
  
  Copy mIRC32.exe file to script folder and run it


  Note: you could download mIRC32.exe in script website www.feedbackscript.cjb.net


==============
2.

  Just unzip upgrade.zip files to script folder
  
  Restart mIRC if open


===================================================================================

                              For a detailed list of changes from version to version, see whatsnew.txt.

				      Bugs report: feedback@yours.com or use site webboard
 


 							   Enjoy :-)
 


                                                          *** EOF ***

