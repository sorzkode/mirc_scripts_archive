/*!
 * \file vector.h
 * \brief Dummy vector definition file
 */

namespace std {
  
  /*!
   * \brief STL vector dummy definition
  */
template<class T> class vector { 

public: 
  T m_element; //!< Vector Element of type T
};

} // namespace

