/*!
 * \file defines.h
 * \brief Definition Support File
 *
 * This file contains constant, alias and variable type defintions.
 *
 * \author David Legault ( clickhere at scriptsdb dot org )
 * \version 1.0
 *
 * \b Revisions
 *
 * � ScriptsDB.org - 2006
 */

#pragma warning( disable : 4530 )

#ifndef _DEFINES_H_
#define _DEFINES_H_

#define _WIN32_WINNT 0x0501
#define _WIN32_IE 0x0501

#include <windows.h>
#include <vector>
#include <commctrl.h>
#include "classes/tstring/tstring.h"

#define XPOP_DLL_VERSION 1
#define XPOP_DLL_SUBVERSION 1
#define XPOP_DLL_BUILD 3
#define XPOP_DLL_STATE "Official Release"


#define mIRC_ID_OFFSET 6000 //!< mIRC Dialog ID Offset

#define XPOPUPMENUCLASS "XPopupMenu32" //!< XPopupMenu Window Class Name

/*! \brief mIRC Function Alias */
#define mIRC( x ) int __stdcall WINAPI x( HWND mWnd, HWND aWnd, char * data, char * parms, BOOL, BOOL )

/*! \brief Return String DLL Alias */
#define ret( x ) { lstrcpy( data, x ); lstrcat( data, "\0" ); return 3; }

/*!
 * \brief mIRC DLL Loading Structure
 */

typedef struct {

  DWORD  mVersion; //!< mIRC Version
  HWND   mHwnd;    //!< mIRC Hwnd 
  BOOL   mKeep;    //!< mIRC variable stating to keep DLL in memory

} LOADINFO;

/*!
 * \brief DCX DLL mIRC Information Structure
 */

typedef struct {

  HANDLE m_hFileMap; //!< Handle to the mIRC DLL File Map
  LPSTR m_pData;     //!< Pointer to a character buffer of size 900 to send mIRC custom commands
  HWND m_mIRCHWND;   //!< mIRC Window Handle

} mIRCDLL;

/*!
 * \brief Switch Parameters Container
 *
 * This structure is used to parse /xdid or /xdialog command -switches. It contains two arrays
 * populated by 26 values from a/A-z/Z and of value 1 indicating the switch was in the command or 0 if not.
 */

typedef struct {

  int switch_flags[26];     //!< Lowercase switches a-z
  int switch_cap_flags[26]; //!< Uppercase switches A-Z

} XSwitchFlags;

void mIRCError( const char * data );
void mIRCeval( const char * text, char * res );
void mIRCcom( const char * data );

LRESULT CALLBACK mIRCSubClassWinProc( HWND mHwnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
BOOL isMenuBarMenu( HMENU hMenu, HMENU hMatch );


#endif // _DEFINES_H_