/*!
 * \file xpopupmenuwindow.cpp
 * \brief blah
 *
 * blah
 *
 * \author David Legault ( clickhere at scriptsdb dot org )
 * \version 1.0
 *
 * \b Revisions
 *
 * � ScriptsDB.org - 2005
 */

#include "xpopupmenuwindow.h"

/*!
 * \brief Constructor
 *
 * blah
 */

XPopupMenuWindow::XPopupMenuWindow( ) {

}

/*!
 * \brief Destructor
 *
 * blah
 */

XPopupMenuWindow::~XPopupMenuWindow( ) {

}
