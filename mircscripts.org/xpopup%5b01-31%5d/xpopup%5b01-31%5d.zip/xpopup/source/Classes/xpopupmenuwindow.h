/*!
 * \file xpopupmenuwindow.h
 * \brief blah
 *
 * blah
 *
 * \author David Legault ( clickhere at scriptsdb dot org )
 * \version 1.0
 *
 * \b Revisions
 *
 * � ScriptsDB.org - 2005
 */

#ifndef _XPOPUPMENUWINDOW_H_
#define _XPOPUPMENUWINDOW_H_

/*!
 * \brief blah
 *
 * blah
 */

class XPopupMenuWindow {

public:

  XPopupMenuWindow( );
  virtual ~XPopupMenuWindow( );

protected:


};

#endif // _XPOPUPMENUWINDOW_H_