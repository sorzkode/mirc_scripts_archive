#include "stdafx.h"
#include <afxdllx.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

extern "C" int APIENTRY // hostname -> ip address
resolvename(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause) {
	IN_ADDR in;

	if ((in.s_addr = inet_addr(data)) == INADDR_NONE) {
		LPHOSTENT pHE = gethostbyname(data);
		if (!pHE)
			sprintf(data, "$false"); // specified host doesnt have ip addy
		else 
			in = *((LPIN_ADDR)*pHE->h_addr_list);
	} //otherwise return ip variable

	strcpy(data, inet_ntoa(in)); 

	return(3);
}

extern "C" int APIENTRY // ip address -> hostname
resolveaddr(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause) {
	u_long addr = inet_addr(data);
	LPHOSTENT pHE = 0;

	if (addr != INADDR_NONE) {
		pHE = gethostbyaddr((char*)&addr, sizeof(struct in_addr), AF_INET);
		if (pHE) strcpy(data, pHE->h_name);
	}

	if (!pHE)
		sprintf(data, "$false"); // specified ip addy doesnt have hostname

	return(3);
}
