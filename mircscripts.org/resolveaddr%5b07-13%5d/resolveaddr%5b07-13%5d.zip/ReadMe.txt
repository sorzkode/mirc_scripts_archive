ResolveAddr v0.1 By iRP
-----------------------
I was programming in mIRC and came across the functionality problems involved with the /DNS command... It is intented to 
give the output of other computer addresses only onto the screen and not in with the mIRC coding language. 

Bug:
When you query a hostname that contains more then one ip address, it will only return the first address in the list.
Example:
irc.efnet.info contains:
	195.111.64.195
	198.3.160.3
	198.163.214.60
	198.175.186.5
	198.252.144.2
	204.92.73.10
	205.210.145.2
	216.32.207.207
	216.193.223.223
	217.17.33.10
	64.156.25.83
	65.77.140.140
	66.225.225.225
	69.16.172.2
	80.240.238.17
	141.213.238.252
	192.116.231.44
	193.109.122.77
	193.163.220.3
	194.109.129.220

But this .DLL will only return the first address:
//echo -a $dll(resolveaddr.dll,resolvename,irc.efnet.net)
	Output: 195.111.64.195 
-------
Functions:
//echo -a $dll(resolveaddr.dll,resolvename,www.dnsstuff.com)
	Output: 66.36.247.82 
		(IP address of www.dnsstuff.com)

//echo -a $dll(resolveaddr.dll,resolveaddr,66.36.247.82)
	Output: www.DNSstuff.com
		(Hostname of 66.36.247.82)