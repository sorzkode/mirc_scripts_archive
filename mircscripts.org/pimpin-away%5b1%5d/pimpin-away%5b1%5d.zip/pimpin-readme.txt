#------------------------------------
# Pimpin' Away v 1.0 by Shikkie
# Date: Jan 22 2001
#------------------------------------

----Preface
This is a quick attempt at a configurable away system with a friendly user interface with no "Leet" or "Hacker" style ASCII crap, or any other lame features. I'll keep working on it and tweaking it from time to time.

----Installation

To load this script, extract the zip to a new folder on your hard drive. Go into mIRC and get into the remotes editor (alt+R) then go to File-Load-Script. Browse to where you extracted the Pimpin' Away zip file and load the file pimpin-away.mrc. Choose 'Yes' if asked to allow Pimpin' Away to initialize itself.

----Configuration

Pimpin' Away will automatically create a file where you extracted the zip to named pa.ini which is the configuration settings for Pimpin' Away. (If you are installing a new version into the same place, it will keep the old settings, any new options since the pa.ini file was made will be left unset/blank as a result. You can fix those up in the configuration dialog)

Open the controls dialog by right clicking in the menubar, a channel, or a query window and selecting Pimpin' Away Vxx.xx-View Controls. From there it's rather self explanatory, you use add, del, save to manage the theme and presets.

----Presets

Nothing too fancy here, you just set your nick, reason, pager on/off for each preset you create. 

----Themes

This is the bread and butter here folks. Creating a theme is rather simple once you know what you are doing with it (which is what this readme is for :D)

First are the basic control characters, Bold, Underline, and Color

Use Ctrl+B for Bold, Ctrl+U for Underline, and Ctrl+K for color.
Note: You MUST Close the control codes to prevent them from overlapping, much like HTML if you don't put a second BOLD control the bold continues to the end of the theme.

The only tricky thing is colors (if you are familiar with mIRC's color system feel free to skip this) When you hit Ctrl+K a window pops up and you select one of the colors there. It will insert the numeric where it is needed. You can set background colors as well, you just add a comma ',' after the first numeric and insert a second (making sure to backspace over the second control code box that appears) So []2,9 would result in dark blue text on a lime green background (ugly looking, don't try it at home kids!)

Note: You MUST use the closing color control code to prevent the colors from continuing to the end of the theme, just press Ctrl+K but do not insert a numeric.

***Really important note: Not everyone uses the same mIRC color scheme as you, hot pink may not look good for everyone, so keep that in mind when you design your themes. If you go overboard with colors and get banned from a channel, it's your fault. Just warning you in advance :) 
*Less is More***

Now, for what is really fun, inserting the various variable data into the Theme. Press the "Codes" button at the bottom of the dialog to view the codes data:

	<Nick> = Your AFK Nick - Just the nick you change to when afk.
	<Msg> = Your AFK Msg - Your Reason for being away.
	<Pager> = Pager ON/OFF - wether your pager is on or off.
	<Time> = Time Went Away - The time you went away (hh:nn:sstt) format.
	<Duration> = Time spent Afk - a $duration return calulating how long you have been gone.
	<Status> = Away or Back - wether the action you are taking is going afk, or coming back.
	<CurrTime> = Current Time - the current system time on your computer.

You do NOT need to use "$+" to group colors/control codes with the variables, they fill in without that assistance. Here is the default theme provided with Pimpin' Away.

---AWAY THEME

<status>: (<msg>) Since <time> for <duration> Pager(<pager>) /ctcp <nick> Page [MSG]

Creating this effect: (^U, ^B, ^K represents the control codes)

* shik2 away: ^U^B(^U^BAway From Keyboard^U^B)^U^B Since ^B07:53:29pm^N for ^U45mins 32secs^U Pager(ON) /ctcp Shik-Afk Page [MSG]

---BACK THEME

is <status>! Gone: <duration> since <time>

Creating this effect: (No control codes in default back theme)

* shik2 is back! Gone: 1min 25secs since 12:35:58am



----Going Away

Merely open the Controls dialog, select your theme and preset (or use the one you used last, selected by default) and press the "Go Away" button.

----Returning from Away

Once set away, a smaller desktop dialog will appear with two buttons on it. "Silent Unmark Server /away" and "Return." Obviously "Return" Makes you come back from afk. The other button when pressed tells IRC that you are back, thereby disabling the constant "NICK is away: Reason" being sent to your buddy every time he/she messages you. (This is an IRC protocol feature that informs persons messaging you that you are away, the IRC Server does this, not Pimpin' Away.) You are not publicly 'back' until you press the "Return" button, the "Silent Unmark.." feature merely protects your buddies from "Nick is Away.." messages.


---Auto away when Idle

In the lower left hand side of the Pimpin' Away configuration dialog is the option "Auto away when idle X minutes" If you select this option Pimpin' Away will check every minute to see if you have been idle (not said or done anything at all) for X minutes. If so it will set you away using the preset "Idle" and the last theme you used.

----Conclusion

I hope you like Pimpin' Away, if you have any comments, bug reports, or suggestions feel free to mail shikkie@rebelsquadrons.org or post on the Web Board at www.mircscripts.org

---Thanks

Thanks to dohcan for looking at previous versions and making suggestions.