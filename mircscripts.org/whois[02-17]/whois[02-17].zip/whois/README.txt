;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; ########################## ;;
;; Domain Whois Lookup � v1.2 ;;
;; ########################## ;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

::: HOW TO INSTALL ::::

  1. Unzip whois.zip to your hard drive (C:\mIRC), 
     you don't need to create a folder.

  2. Type the following line in the command line of mIRC:
     /load -rs whois\whois.mrc
     Click 'yes', when a dialog box opens to ask whether you want to execute the
     initialization.
  
  3. Type /whoisd 


TIPS: If Hostname or IP not show up...
      Change the Database and try again.

                                              have fun!
                                             - fachos -
                                         fachos@time.net.my