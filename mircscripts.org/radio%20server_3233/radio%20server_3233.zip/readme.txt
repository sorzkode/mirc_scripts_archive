; Radio Server 1.0 By SCouNDReL                                                     

Usage ;

For Loading ;

//load -rs $shortfn($mircdirradio server\server.mrc)

For Unloading ;

//unload -rs $shortfn($mircdirradio server\server.mrc)

You Can Work With /radioServer Command

You Can See Server's Logs With Edit Box.

You Can Take The Best Result With mIRC 6.1* Versions

Thanks ;

Whilefix.dll By Bamaboy

About ;

For Bugs, Comments..

Msn & Mail: Cacikgelis@hotmail.com


SCouNDReL ...