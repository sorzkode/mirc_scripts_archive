rPlayer 1.1 by r6x (aka RainbowSix)					Jan/03
===================================					========

This script is was mainly done in 2001 but never released to the public.
Now that i'm out of mirc scripting stuff, im tranquil to release this script
bcause if u say that my code sucks i won't care anymore :P lol

Last-hour Updates
=================
- Supports any file type through settings.ini


To Install:
===========

/load -rs rplayer.mrc

To uninstall:
=============

hmm.. don't remember ;P


Usage:
======

/rplayer or /rmp3 shows the damn dialog
btw, use right-click to hide the main dialog without stopping the music...


The Config File - Advanced Options
==================================

SupportedMedia=;*.mp3;*.ogg	; file types which can be added to the playlist, separated by semicolons


Info for mIRC scripters
=======================

U may add rPlayer to your own mIRC script without contacting me 1st, but i want the code
to retain intact, please.

Extra:

If u want to play a song through a script, for example, after receiving a song in a dcc-get, use "r_addsong filepath"
Also, U may want to automatic search for music files in the first run of ur script, to do so use "r_search4media c:\directory\name\blah\blah\"

===============

thats it, have fun

http://www.rplayer.kit.net / irc.redesul.net