------------------------------------------------------------------
------------------------------------------------------------------
	HennesScript 0.61b for mIRC 5.91
------------------------------------------------------------------
------------------------------------------------------------------
	Installation guide
------------------------------------------------------------------
------------------------------------------------------------------

The location from where you opened this file (readme.txt)
is the main folder of HennesScript. Copy mirc32.exe into this
folder. If you don't have mirc32.exe, download mIRC from
http://www.mirc.com

mirc32.exe is located in your mIRC folder, usually in c:\mIRC\.

When you have copied mirc32.exe to the HennesScript main folder,
double-click on mirc32.exe to run HennesScript. That's it!

Have fun.


------------------------------------------------------------------
Web: http://HennesScript.cjb.net
E-mail: HennesScript@planet.nl
------------------------------------------------------------------