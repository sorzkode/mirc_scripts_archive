-euphoria! v0.2.1b8 (released xx/xx/xxxx)

v0.2.1b8 needs mIRC 6.01 or greater to work correctly, if you don't know what version of mirc
you have go to www.mirc.com and download the last version.

/**** Installing ****/

�Unzip all the content of euphoria.zip. The path can be with or without spaces.

�If you download the version without mirc.exe, get a copy of mirc.exe and put it in the path which are 
 the euphoria! files.

�Click on mirc.exe and enjoy the script (if you delete mirc.exe.manifest), euphoria will create it 
 and the script will be restarted.

-NOTE: If you have euphoria! v0.1b7 with settings, note that /loadconf is not avalaible so please, you have to copy the content of
       the directory "conf" at euphoria! v0.1b7 path to "profiles/default" on euphoria! v0.2.1b8. (please note that fkeys.ini, the 
       function keys file is this, so i recommend you to copy file by file :), if you want that fkeys work.

/**** Questions & Contact ****/

�Please read the help if you don't know how do anything, type /help. And reate changelog to see the
 updates on the script.
�Contact me at IRC with the nick SirKeldon at:
  - IRC-Hispano: #scripting #mircscripts
  - Atom-Net: #chatzone
  - Undernet: #mircscripts.org

/**** Credits ****/

---euphoria! v0.2.1b8
	written by SirKeldon
	site: www.euphoriascript.net
	mail: sirkeldon@euphoriascript.net