Query-Reply v1.0
Created by Zyberdog @ Quakenet

It is important that all the files lies in your /mIRC/ folder. Otherwise it will not work!
To load, unzip the "query-reply.mrc" to your mIRC folder and type inside mIRC:

/load -rs query-reply.mrc

To unload, either choose it it the menu or type inside mIRC:

/unload -rs query-reply.mrc


Please report all bugs and suggestions to Zyberdog@Hotmail.com
For help just load the script.

Enjoy!

Btw.
Ripping is lame.....