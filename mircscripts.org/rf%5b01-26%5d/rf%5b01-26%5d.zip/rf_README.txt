					Resultant Force Calculator Readme

Contents:
---------------------------
1. A small note before use
2. How to load the script
3. How to use the script
4. License
---------------------------

-------------------------
1. A small note on use
-------------------------

This script is really only intended for people with knowledge of physics or mechanics. To use it, you need to know about
unit vectors and forces. That isn't to say that only physics students can use it, but if you haven't studied physics, you'll probably have some difficulty with it.

-------------------------
2. How to load the script
-------------------------

Move the rf.txt file to your mIRC directory. Open mIRC and type "/load -rs rf.txt" (without quotes).

------------------------
3. How to use the script
------------------------

Type "/rf" to open the resultant force window. You should have a window open with a blank graph to the left. To add a force, right click the window and select "Add Force". You must enter the force as a vector quantity. You can add as many forces as you want. After you add a force, the force will be drawn on the graph in white and the resultant force will be drawn in red.

To edit a force, use the up and down arrow keys to select the force you want, then right click and click "Edit selected force". You'll be prompted to enter the new i and j vector components for that force.

To delete a force, use the up and down arrow keys to select the force you want, then right click and click "Delete Selected Force".

To delete all forces, right click and select "Delete all forces".

------------------------
4. License
------------------------

You're free to distribute this as you please, but credit to the author (Haddock) would be appreciated.