
 	* Outpost Theme 2.3 *
 
 Author:
	Zyberdog <zyberdog@quakenet.org>

 Description:
	Aligned MTS theme using the all too famous Tahoma font. Inspiration gather from Negative Entropy (by Darksadin) and Winter (by greeny).
	Optimized for use with NNscript and/or QuakeNet/Undernet.

 Changelog:
   v2.3 (01/03/2004)
	* Optimized alignment system.
	* Fixed unloading error.
   v2.2 (19/12/2003)
	+ Added support for notices from -psyBNC (More noticeable).
	* Changed highlighting to only color the word, and not the whole line. (only with actions)
	* Fixed bug where topics would be a weird color.
	* Fixed bug in scheme 10 (xemacs (aligned)) where channel text weren't themed.
   v2.1 (08/12/2003)
	- First public release.