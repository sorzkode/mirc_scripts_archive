listfiles.dll v0.99 beta by Misanthrop

Functions
---------

1.) setoutput

Sets the output for each file. The tags are replaced with the file information and written to a file or send as a signal, depending on the output mode you set.
You may set it to 0 + 0 0 0 <fname> $+ $!chr(9) $+ <fsize> for example to work with an mdxed list
The default value is: <fname> <fsize>
the function always returns OK

tags are always enclosed in <tag>
The supported tags are:

<size>		This is the size of the file in bytes. NOTE: This tag was named <fsize> in a prior version

<fsize>		This is the formatted and rounded size of the file in b, kb, mb or gb. Example: 12.34mb

<type>		The number of the wildcard, that matched for this file, starting with 1.
		The value will be 0 if it didn't matched, but * flag was set


<fname>		The name of the file found (without pathname)

<dir>		The path to the file (with a \ at the end)

<reldir>	This is the path to the file relative to the dir you searched in. For example, 
                if searched in C:\audio and found C:\audio\Metallica\Metallica - One.mp3, 
                <reldir> contains "Metallica\". If you found C:\audio\title.ogg, <reldir> is 
                empty.


<sfname>
<sdir>		Similiar to <fname>, <dir> and <reldir> but uses a short filename instead of a long filename.
<sreldir>	

<afname>	a* for auto *.
<adir>		Similiar to the long filename functions, but uses short filenames automatically, if the long filename
<areldir>	contains a space followed by a second (mIRC will remove one space -> the filename is wrong).

<attr>		for each attribute that is set, the depending char will be added
		a = archive attribute is set
		c = compressed attribute is set
		e = encrypted attribute is set
		h = hidden attribute is set
		r = readonly attribute is set
		s = system  attribute is set
		t = temprorary attribute is set

<created>	the creation time of the file
<accessed>	the time the file was last accessed
<modified>	the time the file was last modified


the following tags are only available if the mode 'm' is set for listfiles function

MPEG info:
<lenf>		estimated length of the file formatted to hh:mm:ss (if hh is 0, it is only mm:ss or m:ss)
<len>		estimated length of the file in seconds
<bitrate>	bitrate in kbps on mp1/2/3 files (this value is incorrect for VBR files for dll version 1.0)
<sample>	samplerate in Hz
<chans>		typ of channels: Mono, Dual Channel, Stereo, Joint Stereo
<layer>		layer of file: I, II or III
<ver>		mpeg version: 1.0, 2.0 or 2.5
<vbr>		if file has a variable bitrate: 1 for vbr, 0 for cbr (constant bitrate)
<priv>		1 if the private bit is set, else 0
<crc>		1 if the file is CRC protected, else 0
<copy>		1 if the copyright bit is set, else 0
<orig>		1 if the original bit is set, else 0

id3v1 info:
<title>		title or empty string
<artist>	artist or empty string
<album>		album or empty string
<year>		year or empty string
<comment>	comment or empty string
<track>		track number, for idv1.0 this is 0 (track number is only set in version 1.1)
<genre>		genre or "Unknown"

id3v2 info:
to read information about id3v2, use <id3_frame>, replacing "frame" with the name of the frame you're searching for
for example, to get the title, which is "TIT2", use the tag <id3_tit2>
you'll find a list of all frames here: http://www.id3.org/id3v2.3.0.html#sec4

example:
$dll(listfiles.dll, setoutput, <fname> MPEG <version> <layer> <bitrate>kbps $!iif(<vbr>,[VBR]) <sample>Hz <chans> title:<title> $!iif($len(<v2_tit2>),tit2: <v2_tit2>) artist:<artist> album:<album> comment:<comment> year:<year> track:<track> genre:<genre>)

$!iif($len(<v2_tit2>),tit2: <v2_tit2>) isn't very nice, but using $!iif(<v2_tit2>,tit2: $ifmatch) isn't possible, cause a title like "Turn The Page" will be interpreted as using "Turn" as first parameter, "Page" as second, and "The" as operator (like $iif(%a >= %b))


2.) listfiles

NOTE1: You should call the "setoutput" function before using the listfiles function.
NOTE2: To scan for all files, you should set the * mode instead of insert * as a wildcard.

Parameters:	mode > filename > dir > [wildcards] > [ex. wildcards] > [depth]

mode		the output modes, supported modes are:
		a = appends to file, this also sets the 'f' flag, filename has to be valid, if the file doesn't exist, it will be created
		f = writes output to file, the output is formatted by what you set with setoutput before, filename has to be valid, if the file exists, it will be truncated before
		h = skips files and directorys that have the attribute hidden set
		m = if the file matches *.mp?, the file is scanned for mpeg, id3v1 and id3v2 information and the tags for mpeg, v1 and v2 are valid. setting the m flag will slow down the dll (but should be faster than using mircs $sound() identifier), therefore it is recomment to use the multithreaded $dllcall() instead of $dll()
		s = sends the signal "listfiles" for each file, the output is formatted by what you set with setoutput before

		* = adds all files (excluded files or hidden files when h is set still are skipped)
		it is possible to output to a file AND using the signals

filename	if a or f flag is set, this is the file where the dll writes to
dir		initial directory to scan
wildcards	a ; seperated list (up to 32 at the moment) of wildcards (* and ? should work)
ex. wildcards	a ; seperated list (up to 32 at the moment) of wildcards (* and ? should work), that are excluded if the * flag is set
depth		the directory depth to scan, 0 for no limit


wildmatches have only to be set if the * flag isn't set
ex. wildmatches may be set
depth defaults to 0

example:
$dll(listfiles.dll,listfiles, fhs* > $mircdirbla.txt > $mircdir > *.mrc;*.ini > *.exe;*.bat;*.dll)

return value:
the first token informs if the call succeeded or failed
if it fails, the first token is ERROR, followed by a description
if it successed, the first token is OK, the second is the filename you gave in double quotes, param 3 is the number of files, param 4 the number of bytes of all files, param 5 the size of all files, converted to b, kb, mb or gb

this value is returned by $dll() and always send to mirc as listfiles_result signal, which makes it work with the multithreading $dllcall(), cause $dllcall() returns the path to the dll (useless in my option); cause this signal is send when the dll has finished its work, the callback alias (2. param in $dllcall()) isn't needed and may be .echo -q for example

3.) DllInfo

returns some useless information about the dll



--------------------
Contact Information:
--------------------

only English and German plz

EMail: CarpeNoctem@Black-Gothic.com
pmsg to Misanthrop on www.mircscripts.org
[ www.mircscripts.org's forum ]



----------
Changelog:
----------
V1.00 BETA
+   added scan mode 'm', which activates reading of audio specific data for mpeg files (vbr isn't completed yet)
+   added 20 tags (only activated if 'm' mode set) to get information about mpeg files, id3v1 and id3v2 data
f   fixed a but, where the signal output was not null terminated if the output string wasn't ended by a tag

V0.99 BETA
+   sends a signal when the scan is finished to make the script get information about number of files and total size with multithreaded $dllcall()
c   the dll now uses wildcards to search (idea by hybcoder)
c   output mode param changed from bitmask to list of chars for easier use
c   the dll now will not be unloaded after 10mins, to free resources, use /dll -u
-   the functions for common dialogs has been removed, if you still need the function, maybe you'll find a dll on mircscripts.org
    or mail me and I'll think about making a seperate dll for that

V0.95, V0.98 (never released)
c   parts of the dll are rewritten (about the half)
c   memory management has changed, the dll doesn't allocate dynamic memory
c   64bit handling optimized (used for total filesize)
+   added the output mode param as bitmask
+   new tags <created>, <modified>, <modified> and <attr>


V0.92
f   fixed a bug, where the last char (the ">") of an unsupported tags like <unknown> was cutted off
f   fixed a small memory leak
c   some code changes
c   changed typo in Changelog of V0.9 ;) the tag <fsize> had be renamed to <size> and a new <fsize> was included
    (and NOT a new <fname>)
+   exclude param for listfiles (idea by First Last)

V0.9
c  changed the tag name of <fsize> to <size>
+  added a new <fsize>, the new tag stands for "formatted size" and returns the size converted to b, kb, mb or gb
+  added <afname>, <adir> and <areldir> tag, automatically switching between long and short filenames, to
   prevent, that mIRC can't access a file, cause it contains a space followed by a second like "ab   cd.txt"
+  an empty output string now means, that the files and their size should only be counted, but the results are not
   printed to the output file. the second parameter of setoutput returns if the dll will write to file.
+  added a DllInfo function


V0.8
?  first public release, don't use 1.0 cause it may happen that someone will find a bug and there 
   are problems on other OS's and don't want to be at version 5.32123324 if dll is final.

... (lots of changes, bug fixes, bleh...)

V0.1
?  got back to 0.1 Version cause of complete recoding (know using C instead of delphi)
