~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
AUTHOR: shadowofthenight aka Shadow
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Instructions:

To view this tutorial, go to the hash table folder and double click on

mainview.htm

you can link around the other pages from within that page.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Contact:

Pvt msg "shadowofthenight" on mirc.net or mircscripts.org or hawkee.com or scriptheaven.net

or

email me on justanother78@hotmail.com

*DON'T ADD ME TO MSN MESSAGNER, ADDY ABOVE IS JUST THERE TO EMAIL ME*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
FUTURE PLANS:

nothing really, may add more snippets of code to acheive differnet things

may very well add a FAQ section

this all depends on how many questions or feedback i get 


