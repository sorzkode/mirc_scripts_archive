/* SoulSeek Dll ********************************************************
 *
 * Version:			2.3.0.0.0
 * FileName:		slsk.dll
 * Date Created:	7/12/2004
 *
 * Author:			Soul_Eater
 * Comments:
 *		For interaction with SoulSeek 156+
 *
 *******************************************************************/
//thanks to Cory N.& byte

#pragma check_stack(off)
#pragma comment(linker,"/OPT:NOWIN98")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "Oleacc.lib")
#include <windows.h>
#include <winuser.h>
#include <stdio.h>
#include <commctrl.h>
#include <windef.h>
#include <mshtml.h>
#include <atlbase.h>
#include <oleacc.h>
#include <exdisp.h>
#import <shdocvw.dll>

HWND mwnd, window;
HBITMAP hbmp;
BITMAP bm;
WNDPROC oldproc;
char string[999];
char title[999];
BOOL CALLBACK MyEnumProc(HWND hwnd, LPARAM lp);
void MyFindWindow(char *szp);
LRESULT CALLBACK Newproc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp);

BOOL CALLBACK MyEnumProc(HWND hwnd, LPARAM lp)
{
	const char *szpart = (const char*)lp;
	char szt[256];
	memset(&szt,0,sizeof(szt));
	GetWindowText(hwnd,szt,256);
	if (strstr(szt, szpart))
	{
		window = hwnd;
		return FALSE;
	}
	return TRUE;
}
void MyFindWindow(char *szp)
{
	EnumWindows((WNDENUMPROC)MyEnumProc,(LPARAM)szp);
}
/*LRESULT CALLBACK Newproc(HWND hwnd, 
						 UINT msg, WPARAM wp, LPARAM lp)
{
	HBITMAP oldbmp;
	HDC hdc;

	switch(msg) {
	case WM_SIZE:
	    hdc = GetDC(hwnd);
		oldbmp = NULL;
        oldbmp = (HBITMAP) SelectObject(hcompdc,hbmp); 
		SelectObject(hcompdc,oldbmp);
		break;
	case WM_PAINT:
		{
        hdc = (HDC)wp;
		RECT rect;
		GetClientRect(hwnd,&rect);

		UINT width = rect.right - rect.left;
		UINT height = rect.bottom - rect.top;

		UINT nx, ny;
        
		for(nx = 0; nx < width; nx += bm.bmWidth)
			for (ny = 0; ny < height; ny += bm.bmHeight)
				BitBlt(hdc,nx,ny,bm.bmWidth,bm.bmHeight,hcompdc,0,0,SRCCOPY);

		}
		return 0L;
	return CallWindowProc(oldproc, hwnd, msg, wp, lp);
	}
	return CallWindowProc(oldproc, hwnd, msg, wp, lp);
}*/

char *StripSpace(char *text)
{
	char *Text = text;
	int slot = 0,num = strlen(text);
	if (text[0] == ' ')
	{
		for (int i = 1;i <= num;i++)
		{
			Text[slot] = text[i];
			slot++;
		}
	}
	return Text;
}
void Gettok(char *string,char *outstring,char sepchar,int whichTok,int maxlen) {
	int count = 0;
	int outputcount = 0;
	int tokencount = 0;
	while (string[count]) {
		if ((string[count] == sepchar) && (count != 0)) {
			if (tokencount == whichTok)
				break;
			tokencount++;
		}
		else if (tokencount == whichTok) { 
			if (outputcount == maxlen)
				break;
			outstring[outputcount] = string[count];
			outputcount++;
		}
		count++;
	}
	outstring[outputcount] = '\0';
	if (outstring[0] == 32)
		wsprintf(outstring,"%s",StripSpace(outstring));
	if (outstring[strlen(outstring)-1] == 32)
		outstring[strlen(outstring)-1] = '\0';
}

//retrieves total # of active dls in soulseek
int __stdcall SlskTotal(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{

	MyFindWindow("SoulSeek - [");  
	HWND next = FindWindowEx(window,NULL,"MDIClient",NULL);
	  HWND tf1 = FindWindowEx(next,NULL,NULL,"Transfers");
	  HWND tf2 = FindWindowEx(tf1,NULL,NULL,"Transfers");
      HWND list = FindWindowEx(tf2,NULL,NULL,"List1");  

   if (!IsWindow(window)) { 
	   lstrcpy(data,"SS_ERR SoulSeek is not open."); 
	   return 3; 
   }
  // int items = SendMessage(list,LVM_GETITEMCOUNT,(WPARAM)0,(LPARAM)0);
   int items = ListView_GetItemCount(list);
   wsprintf(data,"%d",items);
 return 3;

}

int __stdcall SlskItem(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
    char id[150], type[150]; 
	 
	Gettok(data,id,'>',0,150); 
	Gettok(data,type,'>',1,150);


 	int it = atoi(id);
	char item[512], subitem[512];
	char *_item, *_subitem;

	MyFindWindow("SoulSeek - [");  
	HWND next = FindWindowEx(window,NULL,"MDIClient",NULL);
	  HWND tf1 = FindWindowEx(next,NULL,NULL,"Transfers");
	  HWND tf2 = FindWindowEx(tf1,NULL,NULL,"Transfers");
      HWND list = FindWindowEx(tf2,NULL,NULL,"List1");  

   if (!IsWindow(window)) { 
	   lstrcpy(data,"SS_ERR SoulSeek is not open."); 
	   return 3; 
   }
 
   unsigned long pid;
   HANDLE process;
   GetWindowThreadProcessId(list, &pid);
   process = OpenProcess(PROCESS_VM_OPERATION|PROCESS_VM_READ|PROCESS_VM_WRITE|PROCESS_QUERY_INFORMATION,
	   FALSE, pid);

   LVITEM lvi, *_lvi;
   
   _lvi = (LVITEM*)VirtualAllocEx(process, NULL, sizeof(LVITEM), MEM_COMMIT, PAGE_READWRITE);

   _item = (char*)VirtualAllocEx(process, NULL, 512, MEM_COMMIT, PAGE_READWRITE);

   _subitem = (char*)VirtualAllocEx(process, NULL, 512, MEM_COMMIT, PAGE_READWRITE);

   
   
   lvi.pszText = _item;
   lvi.cchTextMax = 999;

   if (stricmp(type,"name") == 0) { lvi.iSubItem = 0; }
   if (stricmp(type,"status") == 0) { lvi.iSubItem = 1; }
   if (stricmp(type,"timeleft") == 0) { lvi.iSubItem = 2; }
   if (stricmp(type,"timelapse") == 0) { lvi.iSubItem = 3; }
   if (stricmp(type,"ks") == 0) { lvi.iSubItem = 4; } 
   if (stricmp(type,"user") == 0) { lvi.iSubItem = 5; }
   if (stricmp(type,"size") == 0) { lvi.iSubItem = 6; }

   WriteProcessMemory(process, _lvi, &lvi, sizeof(LVITEM), NULL);
   
   SendMessage(list, LVM_GETITEMTEXT, (WPARAM)it, (LPARAM)_lvi);
   ReadProcessMemory(process, _item, item, 512, NULL);
   VirtualFreeEx(process, _lvi, 0, MEM_RELEASE);
   VirtualFreeEx(process, _item, 0, MEM_RELEASE);
   VirtualFreeEx(process, _subitem, 0, MEM_RELEASE);

  lstrcpy(data,item);
   return 3;
}


 //slsk is opened or closed
int __stdcall Slsk(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
 
   MyFindWindow("SoulSeek - [");

   if (!IsWindow(window)) { 
	   lstrcpy(data,"SS_ERR SoulSeek is not open."); 
	   return 3; 
   }

  lstrcpy(data,"SoulSeek is open");
 return 3;

}

/*int __stdcall Tab(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
      HWND window = FindWindowEx(NULL,NULL,NULL,"SoulSeek - [");
	  HWND next = FindWindowEx(window,NULL,NULL,"Views");
	  HWND tf1 = FindWindowEx(next,NULL,NULL,"Views");
      HWND tab = FindWindowEx(tf1,NULL,"SysTabControl32",NULL);


	/*  HIMAGELIST himl = ImageList_LoadImage(NULL,data,10,1,CLR_DEFAULT,IMAGE_BITMAP,
		  LR_DEFAULTCOLOR|LR_DEFAULTSIZE|LR_LOADFROMFILE|LR_LOADTRANSPARENT);

	  SendMessage(tab,TCM_SETIMAGELIST,0,(LPARAM)(HIMAGELIST)himl);

	  ImageList_Destroy(himl); 
	  //TCS_TOOLTIPS TCS_BUTTONS

SetWindowLong(tab, 
                      GWL_STYLE, 
                      GetWindowLong(tab, GWL_STYLE) | TCS_BUTTONS | TCS_TOOLTIPS);

     SendMessage(tab,TCM_SETEXTENDEDSTYLE,TCS_FLATBUTTONS,TCS_FLATBUTTONS);
	  //TCS_FLATBUTTONS 
	  lstrcpy(data,"yes");
	 return 3;
	 

} */

int __stdcall SlskStatus(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
	MyFindWindow("SoulSeek - [");  

   if (!IsWindow(window)) { 
	   lstrcpy(data,"SS_ERR SoulSeek is not open."); 
	   return 3; 
   }

	  HWND next = FindWindowEx(window,NULL,"MDIClient",NULL);
	  HWND tf1 = FindWindowEx(next,NULL,NULL,"Transfers");
	  HWND tf2 = FindWindowEx(tf1,NULL,NULL,"Transfers"); 
	  HWND tf3 = FindWindowEx(tf2,NULL,"AfxWnd42s",NULL);
	  HWND txt = GetNextWindow(tf3,GW_HWNDPREV);

	 
	  char text[999];
      GetWindowText(txt,text,999); 
	  lstrcpy(data,text);
	  return 3;
}


int __stdcall SlskFlat(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
	MyFindWindow("SoulSeek - [");  

   if (!IsWindow(window)) { 
	   lstrcpy(data,"SS_ERR SoulSeek is not open."); 
	   return 3; 
   }

   if (stricmp(data,"download") == 0) { 
	   	HWND next = FindWindowEx(window,NULL,"MDIClient",NULL);
	  HWND tf1 = FindWindowEx(next,NULL,NULL,"Transfers");
	  HWND tf2 = FindWindowEx(tf1,NULL,NULL,"Transfers");
      HWND list = FindWindowEx(tf2,NULL,NULL,"List1");  
	   SendMessage(list,LVM_SETEXTENDEDLISTVIEWSTYLE,LVS_EX_FLATSB,LVS_EX_FLATSB); 
     lstrcpy(data,"SS_OK Scrollbars flattened");
   }
   if (stricmp(data,"user") == 0) { 
	   HWND next = FindWindowEx(window,NULL,NULL,"Room List");
	  HWND tf1 = FindWindowEx(next,NULL,NULL,"User List");
      HWND list = FindWindowEx(tf1,NULL,"SysListView32",NULL);  
	    SendMessage(list,LVM_SETEXTENDEDLISTVIEWSTYLE,LVS_EX_FLATSB,LVS_EX_FLATSB); 
     lstrcpy(data,"SS_OK Scrollbars flattened");
   }
	  if (stricmp(data,"rooms") == 0) { 
	   HWND next = FindWindowEx(window,NULL,NULL,"Room List");
	  HWND tf1 = FindWindowEx(next,NULL,NULL,"Room List");
      HWND list = FindWindowEx(tf1,NULL,"SysListView32",NULL);  
	    SendMessage(list,LVM_SETEXTENDEDLISTVIEWSTYLE,LVS_EX_FLATSB,LVS_EX_FLATSB); 
     lstrcpy(data,"SS_OK Scrollbars flattened");
   }
 return 3;

}
int __stdcall SlskBg(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
      
	MyFindWindow("SoulSeek - [");  
	HWND next = FindWindowEx(window,NULL,"MDIClient",NULL);
	  HWND tf1 = FindWindowEx(next,NULL,NULL,"Transfers");
	  HWND tf2 = FindWindowEx(tf1,NULL,NULL,"Transfers");
      HWND list = FindWindowEx(tf2,NULL,NULL,"List1");  

   if (!IsWindow(window)) { 
	   lstrcpy(data,"SS_ERR SoulSeek is not open."); 
	   return 3; 
   }
/*
     COLORREF colorbg = ListView_GetTextBkColor(list);
   if (0xffffffff != colorbg)
   {
	   ListView_SetTextBkColor(list, 0xffffffff);
	   InvalidateRect(list, NULL, TRUE);
	   UpdateWindow(list);
   }
  */

 //  ListView_SetExtendedListViewStyleEx(
   
   LVBKIMAGE plvbki = {0};

   plvbki.ulFlags = LVBKIF_SOURCE_URL;
  // plvbki.ulFlags = LVBKIF_SOURCE_NONE;
  // lstrcpy(plvbki.pszImage,TEXT(data));
lstrcpy(plvbki.pszImage,data);
  // plvbki.xOffsetPercent = 40;
   //plvbki.yOffsetPercent = 15;
 //  plvbki.xOffsetPercent = 60;
 //  plvbki.yOffsetPercent = 35;
   OleInitialize(NULL);
   SendMessage(list,LVM_SETTEXTBKCOLOR,0,(LPARAM)CLR_NONE);
   SendMessage(list,LVM_SETBKIMAGE,0,(LPARAM)(LPLVBKIMAGE)&plvbki);
 //    InvalidateRect(list, NULL, TRUE);
 // UpdateWindow(list);
 
   
   
  /* LVBKIMAGE bki;

   SendMessage(list,LVM_GETBKIMAGE,0,(LPARAM)&bki);
   if (bki.ulFlags == LVBKIF_SOURCE_NONE)
   {
	   //SendMessage(list,LVM_SETBKIMAGE,0,(LPARAM)TEXT(data));
	   lstrcpy(bki.pszImage,data);
	   SendMessage(list,LVM_SETBKIMAGE,0,(LPARAM)&bki);
	   UpdateWindow(list);
   }*/

   //SendMessage(list,LVM_SETBKCOLOR,0,(LPARAM)(COLORREF)atoi(data));
  // SendMessage(list,LVM_SETTEXTBKCOLOR,0,(LPARAM)CLR_NONE);
 
  lstrcpy(data,"SS_OK Image set");
 return 3;

}


//returns total users in userlist
int __stdcall SlskUsers(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
	   MyFindWindow("SoulSeek - [");
	  HWND next = FindWindowEx(window,NULL,NULL,"Room List");
	  HWND tf1 = FindWindowEx(next,NULL,NULL,"User List");
      HWND list = FindWindowEx(tf1,NULL,"SysListView32",NULL);  

   if (!IsWindow(window)) { 
	   lstrcpy(data,"SS_ERR SoulSeek is not open."); 
	   return 3; 
   }
  
   int items = ListView_GetItemCount(list);
   wsprintf(data,"%d",items);
 return 3;

}

int __stdcall UserItem(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{


 	char id[150], type[150]; 
	 
	Gettok(data,id,'>',0,150); 
	Gettok(data,type,'>',1,150);


 	int it = atoi(id);
	char item[512], subitem[512];
	char *_item, *_subitem;

	MyFindWindow("SoulSeek - [");  
	HWND next = FindWindowEx(window,NULL,NULL,"Room List");
	  HWND tf1 = FindWindowEx(next,NULL,NULL,"User List");
      HWND list = FindWindowEx(tf1,NULL,"SysListView32",NULL); ;  

   if (!IsWindow(window)) { 
	   lstrcpy(data,"SS_ERR SoulSeek is not open."); 
	   return 3; 
   }

   unsigned long pid;
   HANDLE process;
   GetWindowThreadProcessId(list, &pid);
   process = OpenProcess(PROCESS_VM_OPERATION|PROCESS_VM_READ|PROCESS_VM_WRITE|PROCESS_QUERY_INFORMATION,
	   FALSE, pid);

   LVITEM lvi, *_lvi;
   
   _lvi = (LVITEM*)VirtualAllocEx(process, NULL, sizeof(LVITEM), MEM_COMMIT, PAGE_READWRITE);

   _item = (char*)VirtualAllocEx(process, NULL, 512, MEM_COMMIT, PAGE_READWRITE);

   _subitem = (char*)VirtualAllocEx(process, NULL, 512, MEM_COMMIT, PAGE_READWRITE);

   
   
   lvi.pszText = _item;
   lvi.cchTextMax = 999;
   if (stricmp(type, "user") == 0) { lvi.iSubItem = 1; }
   if (stricmp(type, "files") == 0) { lvi.iSubItem = 2; }
   if (stricmp(type, "ks") == 0) { lvi.iSubItem = 3; }
    
   WriteProcessMemory(process, _lvi, &lvi, sizeof(LVITEM), NULL);
   
   SendMessage(list, LVM_GETITEMTEXT, (WPARAM)it, (LPARAM)_lvi);
   ReadProcessMemory(process, _item, item, 512, NULL);
   VirtualFreeEx(process, _lvi, 0, MEM_RELEASE);
   VirtualFreeEx(process, _item, 0, MEM_RELEASE);
   VirtualFreeEx(process, _subitem, 0, MEM_RELEASE);

  lstrcpy(data,item);
   return 3;
}

int __stdcall Windows(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
      
	MyFindWindow("SoulSeek - [");  
	HWND next = FindWindowEx(window,NULL,"MDIClient",NULL);

	  if (stricmp(data,"cascade")) {  CascadeWindows(next,NULL,NULL,NULL,NULL); }
	  if (stricmp(data,"tile")) { TileWindows(next,NULL,NULL,NULL,NULL); }

	  lstrcpy(data,"S_OK done");
	  return 3;
}

int __stdcall MdiBg(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
      
	MyFindWindow("SoulSeek - [");  
	HWND mdi = FindWindowEx(window,NULL,"MDIClient",NULL);

	  hbmp = (HBITMAP)LoadImage(NULL,data, IMAGE_BITMAP,0,0,LR_LOADFROMFILE);
      ZeroMemory(&bm, sizeof(BITMAP));
	  GetObject(hbmp, sizeof(BITMAP), (LPVOID)&bm);
      HDC hDC = GetWindowDC(mdi);  
       RECT rect;
	   GetClientRect(mdi, &rect);
       HDC hMemDC = CreateCompatibleDC(NULL);
	 // oldproc = (WNDPROC)GetWindowLong(mdi, GWL_WNDPROC);
	 // SetWindowLong(mdi, GWL_WNDPROC, (LONG)Newproc);

       HBITMAP hOldBitmap = NULL;

			UINT nWidth = rect.right - rect.left;
			UINT nHeight = rect.bottom - rect.top;

			hOldBitmap = (HBITMAP) SelectObject(hMemDC, hbmp);

			UINT nX;
			UINT nY;

			for (nX = 0; nX < nWidth; nX += bm.bmWidth)
				for (nY = 0; nY < nHeight; nY += bm.bmHeight)
					BitBlt(hDC, nX, nY, bm.bmWidth, bm.bmHeight, hMemDC, 0, 0, SRCCOPY);

			SelectObject(hMemDC, hOldBitmap);

	    if (!IsWindow(window)) { 
	   lstrcpy(data,"SS_ERR SoulSeek is not open."); 
	   return 3; 
   }
     
	  lstrcpy(data,"S_OK done");
	  return 3;
}
int __stdcall WebPrint(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
	   MyFindWindow("SoulSeek - [");
	  	HWND next = FindWindowEx(window,NULL,"MDIClient",NULL);
	  HWND tf1 = FindWindowEx(next,NULL,NULL,"Web");
	  HWND tf2 = FindWindowEx(tf1,NULL,NULL,"Web");
      HWND tf3 = FindWindowEx(tf2,NULL,"Shell Embedding",NULL); 
	  HWND shelldoc = FindWindowEx(tf3,NULL,"Shell DocObject View",NULL);
	  SendMessage(shelldoc,WM_COMMAND,260,(LPARAM)NULL);
   lstrcpy(data,"SS_OK Printing");
 return 3;
}

int __stdcall Web(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
	   MyFindWindow("SoulSeek - [");
	  	HWND next = FindWindowEx(window,NULL,"MDIClient",NULL);
	  HWND tf1 = FindWindowEx(next,NULL,NULL,"Web");
	  HWND tf2 = FindWindowEx(tf1,NULL,NULL,"Web");
      HWND tf3 = FindWindowEx(tf2,NULL,"Shell Embedding",NULL); 
	  HWND shelldoc = FindWindowEx(tf3,NULL,"Shell DocObject View",NULL);
	  HWND web = FindWindowEx(shelldoc,NULL,"Internet Explorer_Server",NULL);
  
	  if (!IsWindow(window)) { 
	   lstrcpy(data,"SS_ERR SoulSeek is not open."); 
	   return 3; 
   }
  
	  if (!IsWindow(web)) { 
		  lstrcpy(data,"nope");
			  return 3;
	  }

	  CoInitialize( NULL );
  HINSTANCE hInst = ::LoadLibrary( _T("OLEACC.DLL") );

 CComPtr<IHTMLDocument2> spDoc;

 CComBSTR bstrURL(data);

	LRESULT lRes;

		UINT nMsg = ::RegisterWindowMessage( _T("WM_HTML_GETOBJECT") );
				::SendMessageTimeout( web, nMsg, 0L, 0L, SMTO_ABORTIFHUNG, 1000, (DWORD*)&lRes );

				LPFNOBJECTFROMLRESULT pfObjectFromLresult = (LPFNOBJECTFROMLRESULT)::GetProcAddress( hInst, _T("ObjectFromLresult") );
				if ( pfObjectFromLresult != NULL )
				{
					HRESULT hr;
					hr = (*pfObjectFromLresult)( lRes, IID_IHTMLDocument2, 0, (void**)&spDoc );
					if ( SUCCEEDED(hr) )
					{
						CComPtr<IDispatch> spDisp;
						CComQIPtr<IHTMLWindow2> spWin;
						spDoc->get_Script( &spDisp );
						spWin = spDisp;
						spWin->get_document( &spDoc.p );			
		       		   spWin->navigate(bstrURL);			
					}
				}
::FreeLibrary( hInst );
	CoUninitialize();
   lstrcpy(data,"SS_OK URL sent");
 return 3;
}

int MsgBox(char *data)
  {
 int xa = MessageBox (mwnd, data ,"SoulSeek DLL" , MB_OK | MB_ICONINFORMATION );
 return 0;
}


int WINAPI DllInfo(HWND,HWND,char *data,char*,BOOL,BOOL)
{
   ShellExecute(NULL,"open","http://www.freewebz.com/souleata/",NULL,NULL,SW_SHOW);
   MsgBox("SoulSeek DLL v2.3 by Soul_Eater \n�2004-05\nContact Information:\nAIM- SoulEata");
   return 0;
}
