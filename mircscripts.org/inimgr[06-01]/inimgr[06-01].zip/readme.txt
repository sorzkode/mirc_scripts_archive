INI Manager
__________

By zacke (zack@sc.rr.com) on June 1, 2003

How to use:
1) Type /_inimgr on any editbox.
2) Select a file by clicking on the [...] button
3) Click on a Section
4) Click on a Key
5) Editing the key will automatically update the value.
6) Yes. Directories with spaces are supported.