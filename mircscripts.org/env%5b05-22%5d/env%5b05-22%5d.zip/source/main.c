/* mIRC Environment Variable Manipulation Routines
 * (c) 2001 codemastr
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include "mirc.h"

int __stdcall GetEnv(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause) 
{
	char *data2 = getenv(strtok(data, " "));
	if (!data2) {
		sprintf(data,"$null");
		return MIRC_RETURN_DATA;
	}
	strcpy(data,getenv(data));
	return MIRC_RETURN_DATA;
}

int __stdcall SetEnv(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause) 
{
	char *var = strtok(data, " ");
	char *val = strtok(NULL, "");
	char out[1024];
	char envstr[512];

	if (!var || !val) {
		sprintf(data, ".echo $colour(info) -ae * /setenv: insufficient parameters | .halt");
		return MIRC_RETURN_PROCESS;
	}
	/* Allow use of %varname% for including other variables */
	ExpandEnvironmentStrings(val, out, 1024);
	sprintf(envstr, "%s=%s",var,out);
	putenv(envstr);
	return MIRC_RETURN_CONTINUE;
}
