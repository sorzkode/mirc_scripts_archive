/* mIRC Standard Header File
 * (c) 2001 codemastr
 * 
 * This file just contains some standard definitions that mIRC uses 
 * to communicate with a DLL
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/* For LoadDLL */
typedef struct {
    DWORD mVersion;
    HWND  mHwnd;
    BOOL  mKeep;
} LOADINFO;

/* For UnloadDLL */
#define MIRC_EXIT_UNLOAD  0
#define MIRC_EXIT_TIMEOUT 1

/* For standard routines */
#define MIRC_RETURN_HALT	 0
#define MIRC_RETURN_CONTINUE 1
#define MIRC_RETURN_PROCESS	 2
#define MIRC_RETURN_DATA	 3

/* For SendMessage */
#define WM_MEVALUATE (WM_USER+201)
#define WM_MCOMMAND  (WM_USER+200)
