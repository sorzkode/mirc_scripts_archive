

				( [[ defect/0.3r1 ],
				     =  ( all that is sexy ..] )
				   ! .. erawtic ),.  .


				..theme   : defect
				..version : 0.3r1
				..author  : era-
				..email   : nick@mosdev.org
				..url     : http://era.echotheory.com/defect


	( -+- [ info         ..] )

	   neato. an update.

	   the default setup is a lilac-colored schematic with a pretty cool whois and laid-back
	   colors. changing to one of the color schematics will present you with somewhat of a
	   'different' look.  the 2 format schemes, Desert and Hydrous,  will change the whois.
	   (Desert will also change a few event formats around.)

	   a unique feature of this theme is the bold highlighting feature. this turns all bold
	   text into a highlighted version of the text. so instead of seeing bold, you will see
	   a brighter text. it's a method used in most console clients, and i'm akin to it. you
	   can turn it off using the /defect.toggle command:

		/defect.toggle hibold		will toggle bold highlighting on and off
		/defect.toggle align		will toggle nick alignment on and off


	( -+- [ instructions ..] )

	   i seriously doubt you need these, but i kept them here for those insignificant ones who
	   still wear diapers, (or started again), and/or can't get it up [anymore].

		1. unzip the files to a new subfolder (preferably 'defect\') in your theme folder.
		2. use your theme engine to load it.
		3. oogle. <3


	( -+- [ change log   ..] )

		i'm no longer using kamek's kte to test this, as it has too many bugs of its own.
		i finally [somewhat] finished up a solid engine, so i'll be testing it there.

	   0.3r1 - 04.22.2004
		1. added 4 new schemes: Mer, Pastel-gray, Pastel-haze, and Pastel-light.
		2. added a variable font scheme: Verdana. you can use this scheme to make schemes
		   based on variable-width fonts, or to use an ascii-charset font of your choice.
		3. tremendously sped up bold-highlighting. this will be useful for those with
		   slower pc's.
		4. cleaned up stats a bit.
		5. modified how /defect.toggle works a little for compatibility, (doesn't use an
		   on-start anymore.)

	   0.2r2 - 01.19.2003
		1. fixed a color problem i was having with the echo formats. it may not have been
		   apparent in your theme engine, but if it was, it's fixed now.
		2. changed up the indenting again. now, if you want to change the timestamp, it
		   will still indent correctly.
		3. the _defect_echo command was acting up. i bitch-slapped it into submission.
		4. changed the /defect.toggle to make it use hash tables. no need for unnecessary
		   file accessing.
		5. changed the prefix.
		6. changed up the join format.  it looks normal until a clone joins.  you'll see
		   what i mean.
		7. fixed a stupid problem with the indenting code.
		8. spread the whoises around. hydrous' and desert's whoises now get more play in
		   other schemes.
		9. changed up the join format again. just a bit.
	       10. added new schemes: Plaid - HAHAHAHAHAHA

	   0.2r1 - 01.12.2003
		1. added a /defect.toggle command to toggle nick aligning and bold highlighting
		   on and off. removed the no-align scheme because of this. keep in mind that the
		   names list will still be aligned to keep the format correct.
		2. added a bunch more raw formats -- stats are now included as well.
		3. added 2 new schemes: Dazed (color), and Hydrous (format).
		4. added 3 more color schemes: Pastel-blue, Pastel-green, and Pastel-violet.
		5. added new event formats to the Desert scheme.
		6. added another color scheme: Pastel-red
		7. updated the Desert scheme again; now has its own event formats.
		8. fixed a bug in the ctcp format; wasn't indenting correctly. stupid mistake.

	   0.1r4 - 01.05.2003
		1. upped the brightness on the dark gray a bit.
		2. fixed up some of the indenting problems. i still think mts needs a %::window.
		3. added new scheme: Desert - has it's own whois.
		4. next release will have more raw formats.

	   0.1r3 - 12.29.2002
		1. minor bugfixes and raw additions

	   0.1r2 - 11.05.2002
		1. put the timestamp stuff back in. this can cause kte's preview of this theme to
		   look rather, uh, disturbing.
		2. added new scheme; No-Align. this is for you wonderful irc'ers who chat on even
		   more wonderful networks such as dalnet, ircnet, and the like,  which allow for
		   nick lengths longer than 9 characters.
		3. added a nifty on-load display.  gives you a little info just incase you choose
		   not to read this file. :)
		4. changed up the /names list a little; colored the nicks/cmodes and gathered the
		   information first so it could be sorted properly.
		5. fixed a few minor bugs; including the funky channel creation time, a weird bug
		   in the bold highlighting, and some others that i don't remember.
		6. changed the colors of the nicks in the nicklist.  should be somewhat easier to
		   read now for those who's gamma is funky.
		7. the end of the whois was bugging me. i made a minor adjustment.
		8. added 2 new schemes; Crimson by your's truly, and Citron by remx.

	   0.1r1 - 11.04.2002
		1. took out %::timestamp. it was causing some weird things to happen.
		2. added new scheme: Sunset

	   0.1r0 - 11.03.2002
		first release.


	( -+- [ greets       ..] )

	   i hate everyone. i'm a huge-ego'd pessimistic agnosticist who looks down on all peons.
	   just kidding; i don't have a huge ego.

		#pollution	// le clique
		#abortion	// crank addicts


 erawtic/2k3
 eof!
