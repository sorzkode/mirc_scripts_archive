=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
fS v1.0 is an Encryption & Decryption Tool for mIRC
It is written in Visual Basic 6.0
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

Just load the MRC file into mIRC
and type: 
Encryption: /fs.encrypt <A plain Secret message>
Decryption: /fs.decrypt <A Encrypted Secret message>


This DLL builds a table for the chars. with x and y values.
Supported chars. are:

abcdefghijklmnopqrstuvwxyz
ABCDEFGHIJKLMNOPQRSTUVWXYZ
0123456789
-_.,;'"()
[Space][Enter]

If an unknown char. is encoded it comes out of the decoding as a space...


ENjoy, NederMacht