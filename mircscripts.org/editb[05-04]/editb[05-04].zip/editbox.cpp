/* Editbox Dll ********************************************************
 *
 * Version:			2.0.0.0.0
 * FileName:		editbox.dll
 * Date Created:	3/20/2004
 *
 * Author:			Soul_Eater
 * Comments:
 *		Modifies the editbox of the hwnd
 *
 *
 *******************************************************************/

#pragma check_stack(off)
#pragma comment(linker,"/OPT:NOWIN98")
#define _WIN32_WINNT 0x0500
#include <windows.h>
#include <richedit.h>
#define Edit_LineFromChar(hwndCtl,ich) ((int)(DWORD)SendMessage((hwndCtl),EM_LINEFROMCHAR,(WPARAM)(int)(ich),0))
#define Edit_LineIndex(hwndCtl,line) ((int)(DWORD)SendMessage((hwndCtl),EM_LINEINDEX,(WPARAM)(int)(line),0))
#define STAYLOADED
#define WM_MCOMMAND ((WM_USER) + 200) 	
#define USE_EVENTS
#ifndef WS_EX_LAYERED
#define WS_EX_LAYERED           0x00080000
#define LWA_COLORKEY            0x00000001
#define LWA_ALPHA               0x00000002
#endif
WNDPROC OldProc[999];
HWND mwnd,mIRCWND;
char end[300];
int count =0;
int bc = 0; 
int uc = 0;
int cd = 0;
int Search(HWND hwnd);
HINSTANCE OurSelf;
BOOL StayLoaded = FALSE;
LPSTR			      mData;
HANDLE              hFileMap;
WNDPROC SubclassWindow(HWND hwnd,WNDPROC WndProc);
void				DllMainLoadDll(void);
void				DllMainUnloadDll(void);
static int g_nRichEditVersion = 0;
typedef BOOL (WINAPI *lpfnSetLayeredWindowAttributes)(HWND hWnd, COLORREF crKey, BYTE bAlpha, DWORD dwFlags);
lpfnSetLayeredWindowAttributes m_pSetLayeredWindowAttributes;
LRESULT CALLBACK RichProc(HWND hwnd,UINT msg,WPARAM wp,LPARAM lp);
BOOL DoCommand(char *command)
{
	wsprintf(mData,"/%s",command);
	return SendMessage(mIRCWND,WM_MCOMMAND,1,0);
}


typedef struct tagPROCSTRUCT{; 
	int index; 	
	HWND procwin;
	WNDPROC procold;
	HWND procz;
} PROCSTRUCT,*LPPROCSTRUCT;
PROCSTRUCT AllProcs[500];


LRESULT CALLBACK RichProc(HWND hwnd,UINT msg,WPARAM wp,LPARAM lp)
{
   switch(msg)
   {
     {   
    case WM_KEYDOWN:
		  if(wp == VK_CONTROL) {
			  cd++;
		  }
	 break;
  case WM_KEYUP:
	   if(wp == 0x42 && cd !=0) {
		   if(!bc) {
		         CHARFORMAT2 cfm;
                    cfm.cbSize = sizeof(cfm);
					SendMessage( hwnd, EM_GETCHARFORMAT,
                    (WPARAM)SCF_SELECTION, (LPARAM)&cfm );
                     cfm.dwMask = CFM_PROTECTED | CFM_BOLD;
                     cfm.dwEffects = CFE_BOLD;

                    SendMessage( hwnd, EM_SETCHARFORMAT,
                   (WPARAM)SCF_SELECTION, (LPARAM)&cfm );
					bc++;
					cd--;
			  }

		   else if(bc != 0) {
		      	  CHARFORMAT2 cfm;
                    cfm.cbSize = sizeof(cfm);
                     cfm.dwMask = CFM_PROTECTED;
                    SendMessage( hwnd, EM_SETCHARFORMAT,
                   (WPARAM)SCF_SELECTION, (LPARAM)&cfm );
					bc--;
					cd--;
			  }
	   }
	  else if(wp == 0x55 && cd !=0) {
		  if(!uc) {
	               CHARFORMAT2 cfm;
                    cfm.cbSize = sizeof(cfm);
					SendMessage( hwnd, EM_GETCHARFORMAT,
                    (WPARAM)SCF_SELECTION, (LPARAM)&cfm );
                 //    cfm.dwMask = CFM_UNDERLINETYPE;
					cfm.dwMask = CFM_UNDERLINE;
					 cfm.dwEffects = CFE_UNDERLINE;
			//		 cfm.bUnderlineType = CFU_UNDERLINEWAVE | 0x50; 

                    SendMessage( hwnd, EM_SETCHARFORMAT,
                   (WPARAM)SCF_SELECTION, (LPARAM)&cfm );
					uc++;
					cd--;
			   }
		   else if(uc != 0) {
		      	  CHARFORMAT2 cfm;
                    cfm.cbSize = sizeof(cfm);
                     cfm.dwMask = CFM_PROTECTED;
                    SendMessage( hwnd, EM_SETCHARFORMAT,
                   (WPARAM)SCF_SELECTION, (LPARAM)&cfm );
					uc--;
					cd--;
			  }
	  }
         break;
	case WM_CHAR: {
	   int blah = Search(hwnd);
	   char buf[999];
	   GetWindowText(hwnd,buf,999);
	   wsprintf(end,"%s %d %s","//.signal -n editbox ",(int)AllProcs[blah].procz, buf);
	   DoCommand(end);
				 }
	   break;
	  case WM_DESTROY:
          SubclassWindow(hwnd,NULL);
		  PostMessage(hwnd,WM_DESTROY,0,0);
		  break;
			}
		int blah = Search(hwnd);
          return CallWindowProc(AllProcs[blah].procold,hwnd,msg,wp,lp);
	 }
   int blah = Search(hwnd);
     return CallWindowProc(AllProcs[blah].procold,hwnd,msg,wp,lp);
}

WNDPROC SubclassWindow(HWND hwnd,WNDPROC WndProc)
{
	return (WNDPROC)SetWindowLong(hwnd,GWL_WNDPROC,(LONG)WndProc);
}

BOOL InitRichEdit()
{
	static HINSTANCE hInstRichEdit;
	if (hInstRichEdit == NULL)
	{
		g_nRichEditVersion = 0;
		hInstRichEdit = LoadLibraryA("RICHED20.DLL");
		if (hInstRichEdit)
		{
			g_nRichEditVersion = _RICHEDIT_VER;
		}
		else
		{
			hInstRichEdit = LoadLibraryA("RICHED32.DLL");
			if (hInstRichEdit)
			{
				g_nRichEditVersion = 0x0100;
			}
		}
	}
	return (hInstRichEdit != NULL) ? TRUE : FALSE;
}

char *StripSpace(char *text)
{
	char *Text = text;
	int slot = 0,num = strlen(text);
	if (text[0] == ' ')
	{
		for (int i = 1;i <= num;i++)
		{
			Text[slot] = text[i];
			slot++;
		}
	}
	return Text;
}
void Gettok(char *string,char *outstring,char sepchar,int whichTok,int maxlen) {
	int count = 0;
	int outputcount = 0;
	int tokencount = 0;
	while (string[count]) {
		if ((string[count] == sepchar) && (count != 0)) {
			if (tokencount == whichTok)
				break;
			tokencount++;
		}
		else if (tokencount == whichTok) { 
			if (outputcount == maxlen)
				break;
			outstring[outputcount] = string[count];
			outputcount++;
		}
		count++;
	}
	outstring[outputcount] = '\0';
	if (outstring[0] == 32)
		wsprintf(outstring,"%s",StripSpace(outstring));
	if (outstring[strlen(outstring)-1] == 32)
		outstring[strlen(outstring)-1] = '\0';
}

int __stdcall eEdit(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
	
 HWND hwnd = (HWND)atoi(data);
 if (!IsWindow(hwnd)) { 
	lstrcpy(data,"E_ERR Window does not exist");
  return 3;
 }
 HWND db = FindWindowEx(hwnd,NULL,"RichEdit20A",NULL);
 if (!IsWindow(db)) { 
	lstrcpy(data,"E_ERR You are not on mIRC 6.14 or the multibyte editbox in options isnt checked");
  return 3;
 }

 InitRichEdit();

    AllProcs[count].procold = SubclassWindow(db,RichProc);
	AllProcs[count].procwin = db;
	AllProcs[count].procz = hwnd;
		 count++;

  SendMessage(db, EM_AUTOURLDETECT, TRUE, 0 );
  SendMessage(db, WM_SETTEXT, 0, (LPARAM)"" );
  SendMessage(db, EM_SETTEXTMODE, TM_RICHTEXT, 0 );
  SendMessage(db, EM_SETEVENTMASK, 0, ENM_LINK);

  lstrcpy(data,"E_OK Editbox set");
  return 3;
}

int __stdcall eBg(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
	char window[150], bg[150], font[150];

  Gettok(data,window,'>',0,150); 
  Gettok(data,bg,'>',1,150); 
  Gettok(data,font,'>',2,150);
 HWND hwnd = (HWND)atoi(window);
 COLORREF cr = atoi(bg);
 COLORREF cr2 = atoi(font);
 if (!IsWindow(hwnd)) { 
	lstrcpy(data,"E_ERR Window does not exist");
  return 3;
 }
 HWND db = FindWindowEx(hwnd,NULL,"RichEdit20A",NULL);
 if (!IsWindow(db)) { 
	lstrcpy(data,"E_ERR You are not on mIRC 6.14 or the multibyte editbox in options isnt checked");
  return 3;
 }
  SendMessage(db, EM_SETBKGNDCOLOR , 0, (COLORREF)cr );
   CHARFORMAT cf;  
   cf.cbSize = sizeof(cf);
   cf.dwMask = CFM_COLOR;
   cf.crTextColor = cr2;
SendMessage(db, EM_SETCHARFORMAT, SCF_ALL, (LPARAM)&cf );
  lstrcpy(data,"E_OK Background color set");
  return 3;
}


int __stdcall eFont(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
	char window[150], font[32], size[150];

  Gettok(data,window,'>',0,150); 
  Gettok(data,font,'>',1,32); 
  Gettok(data,size,'>',2,150);
  int fs = atoi(size);
 HWND hwnd = (HWND)atoi(window);
 if (!IsWindow(hwnd)) { 
	lstrcpy(data,"E_ERR Window does not exist");
  return 3;
 }
 
 HWND db = FindWindowEx(hwnd,NULL,"RichEdit20A",NULL);
 if (!IsWindow(db)) { 
	lstrcpy(data,"E_ERR You are not on mIRC 6.14 or the multibyte editbox in options isnt checked");
  return 3;
 }

  CHARFORMAT cf;  
   cf.cbSize = sizeof(cf);
   cf.dwMask = CFM_FACE | CFM_SIZE;
   cf.yHeight = fs * 20;
   strcpy(cf.szFaceName, font);
SendMessage(db, EM_SETCHARFORMAT, SCF_ALL, (LPARAM)&cf );
  lstrcpy(data,"E_OK Font & size set");
  return 3;
}


/*  CHAR szBuf[80]; 
    DWORD dw = GetLastError(); 
    wsprintf(szBuf, "%s failed: GetLastError returned %u\n", 
        "ok", dw); 
    MessageBox(NULL, szBuf, "Error", MB_OK); 
 lstrcpy(data,"E_OK Image set");
  return 3;
*/

int __stdcall eTrans(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
	char window[150], percent[150], color[150];

  Gettok(data,window,'>',0,150); 
  Gettok(data,percent,'>',1,150); 
  Gettok(data,color,'>',2,150);
 HWND hwnd = (HWND)atoi(window);
 int perc = atoi(percent);
 COLORREF cr = (int)atoi(color);
 if (!IsWindow(hwnd)) { 
	lstrcpy(data,"E_ERR Window does not exist");
  return 3;
 }
 HWND db = FindWindowEx(hwnd,NULL,"RichEdit20A",NULL);
 if (!IsWindow(db)) { 
	lstrcpy(data,"E_ERR You are not on mIRC 6.14 or the multibyte editbox in options isnt checked");
  return 3;
 }
 typedef DWORD (WINAPI *PSLWA)(HWND, DWORD, BYTE, DWORD);
   PSLWA pSetLayeredWindowAttributes;
 HMODULE hDLL = GetModuleHandle("user32.dll");
    pSetLayeredWindowAttributes = 
     (PSLWA) GetProcAddress(hDLL,"SetLayeredWindowAttributes");
    if (pSetLayeredWindowAttributes != NULL)
    {
        // Set WS_EX_LAYERED on this window 
        SetWindowLong(hwnd, 
                      GWL_EXSTYLE, 
                      GetWindowLong(hwnd, GWL_EXSTYLE) | WS_EX_LAYERED);
        // Make this window 70% alpha
        SetLayeredWindowAttributes(hwnd, 0, (255 * 70) / 100, LWA_ALPHA);
		lstrcpy(data,"E_OK Transparency set");
		return 3;
	}  
 //SetWindowLong(hwnd, GWL_EXSTYLE,GetWindowLong(hwnd, GWL_EXSTYLE) | WS_EX_LAYERED);
  //SetLayeredWindowAttributes(hwnd,cr,perc,LWA_COLORKEY);
  lstrcpy(data,"E_OK");
  return 3;
}


int Search(HWND hwnd) {
	 for (int i = 0;i < count;i++)
 if (AllProcs[i].procwin == hwnd) return i;
 return 0;
}
typedef struct
{
	DWORD  mVersion;
	HWND   mHwnd;
	BOOL   mKeep;
} LOADINFO;


void WINAPI LoadDll(LOADINFO *li)
{
	mIRCWND = li->mHwnd;
	hFileMap = CreateFileMapping(INVALID_HANDLE_VALUE,0,PAGE_READWRITE,0,
		0x4000,"mIRC");
	mData = (LPSTR)MapViewOfFile(hFileMap,FILE_MAP_ALL_ACCESS,0,0,0);
	if (!StayLoaded)
		li->mKeep = FALSE;

}

int WINAPI UnloadDll(int timeout)
{
	if (!timeout)
	{
		UnmapViewOfFile(mData);
		CloseHandle(hFileMap);
		return 1;
	}
	return 0;
}

BOOL WINAPI DllMain(HINSTANCE hinst,DWORD reason,LPVOID)
{
	switch(reason)
	{
		case DLL_PROCESS_ATTACH:
#ifdef STAYLOADED
			StayLoaded = TRUE;
#endif
			OurSelf = hinst;
#ifdef CALL_ON_LOAD
			DllMainLoadDll();
#endif
#ifdef NOTIFY_EVENTS
			UseEvents = TRUE;
#endif
			break;

#ifdef CALL_ON_UNLOAD
			DllMainUnloadDll();
#endif
			break;
	}
	return TRUE;
}


int MsgBox(char *data)
  {
 int xa = MessageBox (mwnd, data , "Editbox DLL" , MB_OK | MB_ICONINFORMATION );
 return 0;
}

int WINAPI DllInfo(HWND,HWND,char *data,char*,BOOL,BOOL)
{
   MsgBox("Editbox DLL v2.0 by Soul_Eater \n�2004\nContact Information:\nAIM- SoulEata");
   return 0;
}