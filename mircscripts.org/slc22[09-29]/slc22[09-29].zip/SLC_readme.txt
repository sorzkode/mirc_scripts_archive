Server Links Checker v2.2

; Description

Server Links Checker will check for other servers on the network you're on. This can be helpfull if you're encountering problems with lag, or connection issues with the server you're on. This tool also 'pings' any server that's on the list, to check how long it takes to connect to it. Some servers may be out of your location's reach, this will be noted too.

; Note

'Ping' feature isn't a real PING you might know. Since most (if not all) IRC servers block this type of pings, the only reasonable way was to check, how long does it take to connect to each. So, this script will simply open mirc sockets, and calculate the succesfull connect time.





; Installation

Unzip slc2.mrc file to your mIRC directory. Run mIRC.exe and type /load -rs slc2.mrc


; Uninstalling

Type /unload -rs slc2.mrc




; Thanks

Alltech (Suggested new dialog layout :P)


|nsane (Dalnet/#scripters)