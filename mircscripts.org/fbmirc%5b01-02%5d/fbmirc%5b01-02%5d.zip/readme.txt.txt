fbmirc.dll - by h1web. 
purpose: reading the foobar2000 title
credits: rob
irc:	 irc.rizon.net #ecc

usage:
place the dll in your mirc directory and add this script to any
file that gets loaded when mirc gets started:

alias np {
  me np: $dll(fbmirc.dll, getinfo, 0)
}