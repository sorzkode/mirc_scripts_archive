/*
fbmirc.dll - by h1web. 
purpose: reading the foobar2000 title
credits: rob
irc:	 irc.rizon.net #ecc
*/

#include <windows.h>
#include <tlhelp32.h>
#include <string>

HWND hFoobar = 0;
char szWindowTitle[3024];
DWORD dwProcIdWnd = 0, dwProcIdProc = 0;

BOOL __stdcall wndEnumProc(HWND hWnd, LPARAM lParam)
{
	lParam += 1;
	GetWindowText(hWnd, szWindowTitle, 3024);
	if(strstr(szWindowTitle, "[foobar2000 v0."))
	{
		hFoobar = hWnd;
		GetWindowThreadProcessId(hWnd, &dwProcIdWnd);
		return false;
	}
	return true;
}

HWND GetFoobarWindow()
{
	LPARAM lParam = 0;
	EnumWindows((WNDENUMPROC)&wndEnumProc, lParam);
    HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);
	PROCESSENTRY32 pe;
	pe.dwSize = sizeof(PROCESSENTRY32);
	Process32First(hSnap, &pe);
	do
	{
		if(!strcmp(pe.szExeFile, "foobar2000.exe"))
		{
			dwProcIdProc = pe.th32ProcessID;
			break;
		}
		pe.dwSize = sizeof(PROCESSENTRY32);
	} while(Process32Next(hSnap, &pe));
	if(dwProcIdProc = dwProcIdWnd)
		return hFoobar;
	return 0;
}


int __stdcall getinfo(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)
{
	HWND hFb = GetFoobarWindow();
	if(!hFb) { strcpy(data, "foobar2000 not running."); return 3; }
	char* pszWindowTitle = strstr(szWindowTitle, "[foobar2000 v0.");
	*pszWindowTitle = 0;
	strcpy(data, szWindowTitle);
	return 3;
}

int __stdcall about(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)
{
	strcpy(data, "echo :: fbmirc.dll :: by h1web ::");
	return 2;
}
