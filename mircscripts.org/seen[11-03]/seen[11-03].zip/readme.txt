Seen system v1
by Artwerks

� � �

-Unzip it in the mirc main folder (The folder which contains the mirc.exe).
-Then, open mIRC, if it's not already done.
-Type: /load -rs seen.mrc
-Say YES if there is a mIRC warning about loading the script.
-If the addon was loaded successfully, you'll see a "Seen system" popups on the channel and menubar.

� � �

The addon is quite easy to use. Some helps by dialogs can be found on the main seen system dialog.
It is already configure with initial parameters, you can personalize it if you want.
But if you're not sure about configuring it, it will work with the initial parameters.

� � �

You can email me if you have any comments, suggestions or questions. Enjoy!

� � �

ppnadeau@hotmail.com