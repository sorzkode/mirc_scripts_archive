* Author, Contact information & Load information
-----------------------------------------------------------------------------------------------------------------------------
By: Mpdreamz 
Email: Mpdreamz@gmail.com
How to load:
-Unzip the contents of this folder anywhere (in case you haven't already)
-Press ALT+R in mIRC.
-Goto File then click Load.
-Browse to the folder where you unzipped mIRC and select "snake2.txt'.
-Press OK.
-Type /snake and hit enter in mIRC

*  Usage
-----------------------------------------------------------------------------------------------------------------------------
/snake 
will start a new game of snake
use the arrow keys to move around and eat the red and grey gumballs but dont bite the borders or yourself 
borders are there for a reason and well its kinda silly to bite yourself.


In the main screen you can press 1 to 5 to select the speed where 5 is the slowest.
To start playing you can press P in the main screen to start playing.
In the play screen you can press B at all times to go back to the main screen.
Once your dead you can press C to start a new game without going to the main screen.

If you have an highscore they are added regardless of wheter you decide to continue to a new game straight away.
Highscores can be viewed on the mainpage at all times. When your playing you'll notice that you'll be notified of your Highscore place in real time.

Red squares give you 10 minus the level points. If you play level 1 you get 9 points for each , 2 gets you 8 points and so on and so on.
Grey squares give you 20 points but only excist for 2 seconds, so the slower you play the harder they are to get.

* Note
-----------------------------------------------------------------------------------------------------------------------------
I will NEVER EVER add the option to make the field bigger, it's suppose to be a challenge.


Enjoy snake!

*/