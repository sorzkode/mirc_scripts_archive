TeamSpeak Interaction v1.6
Author: aca20031 AKA 1stAdmiral
-Contact me for help at irc.st0rmgaming.com in #The-Hangout or 1stAdmiral@gmail.com
Note: Superadmin access required as of version 1.1 due to the fact that
      commands exist that require "database" access.

Setup:
1. Copy the contents of this folder to any directory, it's best if this is on
the server computer, but not necessary.
2. If you copied this file to your mIRC directory, simply type
 /load -rs teamspeak_interaction.mrc
 otherwise, type:
 /load -rs path\to\script\teamspeak_interaction.mrc
3. A file should open, if it does not, manually open "tsconfig.ini" and fill in
the information using the example provided. You'll also need to fill in the box
that comes up after the load in your mIRC client with your username in IRC.
4. Edit Settings.ini to enable logging. Do this by finding the [Log] section
	and changing every item under it from 0 to 1. You must restart the
	TeamSpeak server if it is on after doing this, for the changest to
	take effect.
5. Join or rejoin the channel your specified in the ini after saving it.
Note: You MUST enable logging in settings.ini (In your TS Server Folder)

Commands:
All commands can be seen by typing "!ts" (without the quotation marks) in the 
channel provided in the ini. For further help on them, in the channel, type
!ts commandname ?
IE: !TS Users ?

!TS Users
!TS Kick
!TS MSG
!TS PrivMSG
!TS Operators
!TS Ban
!TS Banlist
!TS Unban
!TS Info
