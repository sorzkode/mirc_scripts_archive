zAmp Audio Player
Written by [AFX]
Readme file

1. INTRODUCTION

zAmp is a mIRC audio player. It pretty much supports whatever mIRC's /splay command can handle (generally, MP2/MP3/WMA/WAV). zAmp also features some extra options like advertising, and the ability to create schemes for the player/addon. This addon requires at least mIRC 6.15 in order to use.


2. HOW TO USE/INSTALL

- Open the zip file containing zAmp
- Extract to your mIRC directory
- Run mIRC
- Type /load -rs zAmp.mrc
- Once loaded, type /zamp to open the player, or use the menubar popups


3. PLAYLISTS

When loading zAmp for the first time, it is a must that you create a playlist. If no playlist is chosen, zAmp won't continue and you won't be able to play any of your audio. Creating a playlist isn't hard, just open the Playlist Creator or type /zplcreate. The left column is the directory you chose to open to add the audio, and the second column is your playlist. To open a directory, click on the "Open" button, then point your mouse to "Directory". Select a directory where audio resides and voila, column 1 is filled by that audio. To add the song from column 1 into the playlist column (2), either double click on the filename or right click and get a choice: add the file, or add the whole directory. This is pretty self-explanitory. 

Once you are done creating a playlist, you MUST click on the "Save" button, otherwise you have to add your audio again. When saving, you are asked to enter the new playlists' name. Do not follow the name by an extension (.txt,.dat,etc), as the playlist will be saved as a .txt file in the zAmp\Playlists directory.


4. CONFIGURATION

This is where you can set up zAmp. You can set zAmp to show on the desktop, don't show dialog aliases in the titlebar, change zAmps' titlebar to the current playing song, or match every dialog with the chosen zAmp scheme. Another cool part about zAmp is that you can select a custom button set. You can create your own button sets too (with the knowledge of icons/icon libraries; I use Microangelo). If you plan on doing this, follow this order for the buttons:

PREVIOUS - PLAY - PAUSE - STOP - NEXT

Once done creating the library file, throw it in the zAmp directory and reload the configuration. The icon set should appear in the list. 

The second tab is all related to advertising. Advertising lets others know what song you are listening to (like they care!?!?). This has some options too, you can advertise to the active network, all networks, or specify which channels you want to advertise too. You also have the option of using a single, pre-defined message for your advertising, or you can use random messages that you can create by clicking on the "Messages" button. To specify which channels you want to advertise to, click the "Ad targets" button. A small note about the message tags <bold> and <underline>: these are just meant for the pre-made message. In the random messages, you can use the actual control codes for bold and underline. The reason for this is because INI files don't let you save control codes in an item.

Finally, the third tab is for schemes. A scheme is a color scheme you can use with zAmp, and all of it's dialogs. When adding a scheme, you must specify a name and a description for your scheme, otherwise it won't continue. When you specify these, a dialog pops up asking you for 3 colors: the zAmp header color (where all the audio information goes), listbox/editbox background, and listbox/editbox/zAmp header text color. The scheme creator also comes with a small RGB locator, in which you can operate by moving the sliders (you get a preview of the color as well). Once completed adding a new scheme, it is now availble in your schemes list. To use a scheme, double click on a scheme of your choice in the schemes list, and it will apply to everything (only if the match every dialog with scheme option is on; if checked off, only the zAmp interface is affected).


5. ZAMP INTERFACE

The zAmp interface is easy to understand. You got the header portion which tells you all the current playing audio information (filename, quality, bitrate, elapsed time/length of song). Underneath this is the trackbar in which you can seek to a certain part of a song if you wish. Next is the buttons of the zAmp player. The first five are obvious. The remaining 3 on the right are Playlist, Configuration, and Modes. When you click on the Playlist button, the player resizes, and you can view your playlist there. To select a song in the playlist to play, double click on it. If you have a playlist open, you can save time adding/removing a file from your playlist by using the 2 buttons below (Add/Del). The button in the bottom right makes a popup appear, with an option to choose your playlist, open the Playlist Creator, or search your playlist with any keywords. This is a nifty tool for those of you who are lazy and can't find the song your looking for in your playlist. Enter your keywords in the editbox, and either a) press the Enter button or b) click on the bottom right button and click the Search section to search. The results will show in the playlist box and you can select a song to play by double clicking on it. To return back to the normal playlist, click the bottom right button and click "Return to playlist".


6. CREDITS

The only people I'm crediting are DragonZap for MDX, whoever made the icons for the amp buttons, and the QNX iconset author. No one helped me making this addon, so there isn't really much credit towards that. Just the people who provided the resources. Also, Khaled for providing mIRC with a scripting language.


7. CONTACT

If you need me that bad, you can find me on PTnet on #SCT. The nickname is [AFX]. Do not ask me for my e-mail because I'm sick of all the retards adding me to MSN for no reason. I gave you a place to find me. If I'm not around, feel free to leave a message to one of the users in the channel or something.

Also, visit http://www.coderscore.org/afx for news and updates concerning zAmp and my other projects. I update frequently or whenever there is an update, even the News/Updates section gets updated. Just pay a visit.


8. FUTURE EXPANSIONS

In the next version, for sure I am going to implement and ID3 tag editor made by tidy_trax. It works well and I'm sure it would be a nice thing for you (the user) to have handy instead of opening Winamp, of course nothing against Winamp (if you prefer that over this, do what you must; Winamp is an audio player designed for Windows, not mIRC). 

I want to make this clear as well: I AM NOT FMODING IT. I'm happy with this product. It doesn't need FMOD unless I plan to expand on what the audio player plays. And even if I did FMOD it, I ain't doing no fancy ass spectrum analyzers or oscilloscopes. I already have one in my script, I don't need to be arsed to make another.

I may re-do the Configuration, but probably not. If you have any other suggestions, let me know! I'm open to them.


EOF