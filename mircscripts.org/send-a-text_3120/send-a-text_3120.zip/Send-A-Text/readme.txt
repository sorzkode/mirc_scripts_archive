==========================
Send-A-Text 
by
[Hercules]
==========================

----install----

- first, extact the folder to your mirc directory (ex: c:\mirc\)
- then open up mIRC, and type //load -rs $+(",$findfile($mircidr,s-a-t.txt,1),")


----usage----

- once loaded, look in the pop-ups for "Send-A-Text" 
 - or type in /smst in any window
- once you get the dialog opened, you must do the following:
 - enter in the number to the phone youy want to send to (ex: 4184567894)
 - then choose the carrier of the phone you are sending to (i tried to get the most possible)
   - if the phone carrier isn't avaiable, then it will not work
 - after you selected the phone carrier, the enter your smtp server (ex: stmp.server.com)
 - after that then enter in the message you are trying to send (can not exceed over 100 chars)
 - once you are finished, click "Send!"
- the "Save Info" is when you are chaning stmp (most never, but you never know)

----contact info----

- hit me on irc.webchat.org, in either #mIRC or #help.mIRC with the nick [Hercules]
- if im not there, just send me a memo
- if you are a lazy bum, and like emails, email me at 0hercules0@gmail.com

----extra----

- well thats all you need to know how to work the script
- for any comments/suggesttions contact me as mentioned in the contact section
- enjoy!
