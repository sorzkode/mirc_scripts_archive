l0n3R's Custom mIRC nicklist

Brief Description:
This addon uses nickLUST.dll to customize the nicklist, Color.dll to let use choose the color for the various options.

It allows you to customize ur nicklist with icons, background color, status(Op, Voice, Normal, Yourself, Friends)
text color. Rollover shows brief information(Nick, Hostmask, Status) of nick. Ability to let you add, remove nick from
Friends' list. Add multiple friends directly from the nicklist. 

Installation:
- Unzip zip file into your mIRC directory.
- //.load -rs $findfile($mircdir,nicklust.mrc,1)
- Answer "Yes" if a popup box comes up.
- After loaded right click, Choose "Custom Nicklist" to customize the nicklist settings

Problems/Bugs:
Report any bugs/problems to l0n3R, l0n3R@eudoramail.com

++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
+++++++++++++++++++++++++Version History++++++++++++++++++++++++++
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

[5th May 2003]
- Interface of the setup dialog was re-design. Due to the feedback of my tester.
- Fixed the bug of WHO (#1 join has more user than #2, the who of #1 will be shown)
- Added Halfops supports
- Ability to customize info text/background

[27 April 2003]
Due to the following errors, submission was rejected by mircscripts.org

- When clicking on the 'remove' button under the Friends editbox and not selecting a nick from the editbox you get 
* /did: insufficient parameters (line 228, nicklust.mrc)

- Addon won't function properly if the addon is in a directory that has spaces in it.
- Added the ability to add MULTIPLE NICKS from the nicklist.
- Above bugs fixed and resubmitted back.

[25 April 2003]
- Borned of Custom Nicklist and Submitted to mirscripts.org

++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
+++++++++++++++++++++++++Special THanks+++++++++++++++++++++++++++
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

je||yZzz from Galaxynet (Main tester of this addon)
Staffs in mircscripts.org (Error testing and feedbacks and of cause for hosting the addon =D)