=============================================================================
=**************      DISPLAYS ADDON VERSION 2.0 by VASIL      **************=
=============================================================================

I) First of all excuse me for my English :>

II) Install
  1) Requires mIRC 6.0 or newer (that's a lie but you have to trust me ;b) 
  2) To install:
    - Unzip the content of displays2.zip to the desired folder
    - Since the script uses .ini files for different styles i suggest you make
     a subdir for it, like dysplays or something. The scipt will work just fine
     in $mircdir too, but you may find loading/saving styles quite annoing in
     that dir :)
###############################################################################
     ATTENTION:If you place this script in dir with .ini files and choose to
     unload it, DO NOT PRESS YES when it asks you whether you want to clear 
     saved style files, cause every .ini file will be purged!
###############################################################################
    - Load the script, either using /load -rs path_to_the_script or thru the 
     mIRC editor(alt+r, file, load, script, double click the file)
    - Read the echos (for the laziest - the command is /displays)

III) What's new
  1) Many new buttons. All those tiny square buttons. They popup codes select
   dialog that enables you to alter almost every part ov every event display.
  2) The addon now uses hashtables(one hashtable in fact;)
  3) I've rewrited many things. Everything works better now(i think...)
  4) Added support for loading/saving different styles.
       PLEASE LOAD/SAVE STYLE FILES ONLY IN $SCRIPTDIR !!!
  5) Some bugfixes...

IV) Some tips
  1) You can use control codes in almost every editbox,so use them ;)
  2) Don't use too much codes:>
  3) Try to load crazy.ini style file to figure out what this addon can do :)
  4) There are 3 editboxes that you should take in mind either if your too lame
    or too leet (3 is all i can remeber right now). These are the suffixes for 
    messages, notices and snotices. These are the only editboxes which content 
    isnt combined with the ctr+o char, so if you live control codes there wihout
    halting them they will apply on messages/notices/snotices.This gives you 
    the power to edit messages/notices/snotices displaing. The other choice was 
    resising the dialog but...i like it this way ;b
  5) There are also 4 things you can't alter fully: action text, kick $nick and 
    $knick, usermodes and part messages. The reason i didn't add option to change
    their appearence is stated three lines above :)
  6) Use this script in combination with the mIRC colour dialog and ALT+V
  7) There's some annoing things like on join text and kick text that also 
    can not be altered (there's no place for them on the dialog)

V)Some stuff
  1) This isn't a theme!!!
  2) This isn't a theme script althought it looks like one.
  3) What i mostly like in this script is that in few seconds i can change all 
    the displays.This is the purpose it was created.I've added style files in
    this version so you can save different styles.
  4) Raws are not included.Only events. (I'm lazzzzzzzzy)... There are too many 
    raws that come together so letting the user edit them in the style this addon
    lets you edit events is mission impossible.
  5) $nick colour can be altered only by changing the event colour in mIRC colour
    central
  6) Don't use $chr(153), $chr(176), $chr(175), $chr(247) in editboxes. I'm using them
    to write/read codes.

  I know that some things in this script truly suck in coding. But most of the
  ways i tried to script them leaded to bugs :). So I know that there are 
  faster/smaller ways, but this is the most bugless version I've made. Not that
  there aren't bugs. I'm sure there are;). If you find one feel free to email me.
  If anyone wants to use this addon in his/her script feel free to do it(I will
  be truly amazed though...:).
       
                                        For contacts: vasil_michev@lycos.com










