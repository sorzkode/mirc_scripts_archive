#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>

#define VERSION "1.0"

#define STRUCTN (sstruct *)NULL

#define TSHORT 0
#define TINT 1
#define TLONG 2
#define TFLOAT 3
#define TDOUBLE 4
#define TCHAR 5
#define TSTRING 6
#define TSTRUCT 7

#define NORM 0
#define	DEFN 1

#define OK "S_OK"
#define ERR "E_FAILED"
#define DEFINING "E_DEFINING_STRUCTURE"
#define NOMEMORY "E_NO_MEMORY"
#define PARAM "E_MORE_PARAMETERS_NEEDED"
#define WPARAM "E_WRONG_PARAMETERS"
#define LONG "E_NAME_IS_TOO_LONG"
#define NAME "E_NAME_ALLREADY_IN_USE"
#define NDEFINING "E_NOT_DEFINING_STRUCTURE"
#define TYPE "E_WRONG_TYPE"
#define NONAME "E_NO_MATCH_FOUND"
#define EPRINT "E_COULD_NOT_PRINT"
#define WPATH "E_WRONG_PATH"
#define NYA "E_NOT_YET_AVAILABLE"

#define DEFSTRINGLEN 256
#define NAMELEN 20
#define PRINTF "printstruct.txt"

struct _sshort
{
	char name[NAMELEN];
	short value;
	struct _sshort *nshort;
};
typedef struct _sshort sshort;
struct _sint
{
	char name[NAMELEN];
	int value;
	struct _sint *nint;
};
typedef struct _sint sint;
struct _slong
{
	char name[NAMELEN];
	long value;
	struct _slong *nlong;
};
typedef struct _slong slong;
struct _sfloat
{
	char name[NAMELEN];
	float value;
	struct _sfloat *nfloat;
};
typedef struct _sfloat sfloat;
struct _sdouble
{
	char name[NAMELEN];
	double value;
	struct _sdouble *ndouble;
};
typedef struct _sdouble sdouble;
struct _schar
{
	char name[NAMELEN];
	char value;
	struct _schar *nchar;
};
typedef struct _schar schar;
struct _sstring
{
	char name[NAMELEN];
	int length;
	char *value;
	struct _sstring *nstring;
};
typedef struct _sstring sstring;
struct _sstruct
{
	char name[NAMELEN];
	sshort *nshort;
	sint *nint;
	slong *nlong;
	sfloat *nfloat;
	sdouble *ndouble;
	schar *nchar;
	sstring *nstring;
	struct _sstruct *ustruct;	//under struct, a struct part of a struct
	struct _sstruct *nstruct;	//next struct, next struct that has been declared
};
typedef struct _sstruct sstruct;

typedef struct
{
	sstruct *defstruct;	//define struct, used when defining a new struct
	sstruct *avstruct;	//available struct, structs that can be used for declaration
	sstruct *dclstruct;	//declared struct, structs that have been declared
} Smain;

typedef struct
{
    DWORD  mVersion;
    HWND   mHwnd;
    BOOL   mKeep;
} LOADINFO;

int sendmsg(char *value);
void sclear(void);
void sclearstruct(sstruct *clrstruct);
void sclearshort(sshort *clrshort);
void sclearint(sint *clrint);
void sclearlong(slong *clrlong);
void sclearfloat(sfloat *clrfloat);
void scleardouble(sdouble *clrdouble);
void sclearchar(schar *clrchar);
void sclearstring(sstring *clrstring);
char *getparam(char *data);
sstruct *searchstruct(sstruct *ssstruct, char *name);
sshort *searchshort(sshort *ssstruct, char *name);
sint *searchint(sint *sistruct, char *name);
slong *searchlong(slong *slstruct, char *name);
sfloat *searchfloat(sfloat *sfstruct, char *name);
sdouble *searchdouble(sdouble *sdstruct, char *name);
schar *searchchar(schar *scstruct, char *name);
sstring *searchstring(sstring *ssstruct, char *name);
int addshort(char *name);
int addint(char *name);
int addlong(char *name);
int addfloat(char *name);
int adddouble(char *name);
int addchar(char *name);
int addstring(char *name, char *length);
int addstruct(sstruct *type, char *name);
int isnum(char *in);
sstruct *copystruct(sstruct *type);
sshort *copyshort(sshort *type);
sint *copyint(sint *type);
slong *copylong(slong *type);
sfloat *copyfloat(sfloat *type);
sdouble *copydouble(sdouble *type);
schar *copychar(schar *type);
sstring *copystring(sstring *type);
BOOL delstruct(char *name);
void printspace(FILE *fout, int space);
void printstruct(sstruct *pstruct, FILE *fout, int space);
void printshort(sshort *pshort, FILE *fout);
void printint(sint *pint, FILE *fout);
void printlong(slong *plong, FILE *fout);
void printfloat(sfloat *pfloat, FILE *fout);
void printdouble(sdouble *pdouble, FILE *fout);
void printchar(schar *pchar, FILE *fout);
void printstring(sstring *pstring, FILE *fout);
sstruct *getstruct(char *name);
int setvalue(char *dest, char *value);
int copyvalue(char *dest, char *source);
int getvalue(char *source);
int incbyvalue(char *dest, char *value);
int incbystruct(char *dest, char *source);
int decbyvalue(char *dest, char *value);
int decbystruct(char *dest, char *source);

