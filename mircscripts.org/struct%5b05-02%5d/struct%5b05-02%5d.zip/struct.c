#include "struct.h"

int smode;
Smain smain;
char *Data;

void __stdcall LoadDll(LOADINFO *LoadInfo)
{
	sclear();
	return;
}
int __stdcall UnloadDll(int timeout)
{
	if (!timeout)
	{
		sclear();
		return 1;
	}
	else return 0;
}

int __stdcall info(HWND mWnd,HWND aWnd,char *data,char *parms,BOOL show,BOOL nopause)
{
	strcpy(data,"Buddyke >> Struct DLL << contact on ms.org");
	return 3;
}
int __stdcall version(HWND mWnd,HWND aWnd,char *data,char *parms,BOOL show,BOOL nopause)
{
	strcpy(data,VERSION);
	return 3;
}
int __stdcall clear(HWND mWnd,HWND aWnd,char *data,char *parms,BOOL show,BOOL nopause)
{
	Data = data;
	sclear();
	return sendmsg(OK);
}
int __stdcall define(HWND mWnd,HWND aWnd,char *data,char *parms,BOOL show,BOOL nopause)
{
	char *p1;
	sstruct *pstruct;
	Data = data;
	p1 = getparam(data);
	if (smode)
		return sendmsg(DEFINING);
	if (!p1)
		return sendmsg(PARAM);
	if (p1[0] == '\"')
		return sendmsg(WPARAM);
	if (strlen(p1) > NAMELEN)
		return sendmsg(LONG);
	if (searchstruct(smain.avstruct,p1) || searchstruct(smain.dclstruct,p1))
		return sendmsg(NAME);
	if (!(pstruct = malloc(sizeof(sstruct))))
		return sendmsg(NOMEMORY);
	smode = DEFN;
	memset(pstruct,0,sizeof(sstruct));
	strcpy(pstruct->name,p1);
	smain.defstruct = pstruct;
	return sendmsg(OK);
}
int __stdcall cancel(HWND mWnd,HWND aWnd,char *data,char *parms,BOOL show,BOOL nopause)
{
	Data = data;
	if (!smode)
		return sendmsg(NDEFINING);
	sclearstruct(smain.defstruct);
	smode = NORM;
	smain.defstruct = STRUCTN;
	return sendmsg(OK);
}
int __stdcall add(HWND mWnd,HWND aWnd,char *data,char *parms,BOOL show,BOOL nopause)
{
	char *p1, *p2, *p3;
	sstruct *astruct;
	Data = data;
	p1 = getparam(data);
	p2 = getparam(NULL);
	p3 = getparam(NULL);
	if (!smode)
		return sendmsg(NDEFINING);
	if (!p2)
		return sendmsg(PARAM);
	if (p1[0] == '\"' || p2[0] == '\"')
		return sendmsg(WPARAM);
	if (strlen(p1) > NAMELEN || strlen(p2) > NAMELEN)
		return sendmsg(LONG);
	if (searchshort(smain.defstruct->nshort,p2) || searchint(smain.defstruct->nint,p2))
		return sendmsg(NAME);
	if (searchlong(smain.defstruct->nlong,p2) || searchfloat(smain.defstruct->nfloat,p2))
		return sendmsg(NAME);
	if (searchdouble(smain.defstruct->ndouble,p2) || searchchar(smain.defstruct->nchar,p2))
		return sendmsg(NAME);
	if (searchstring(smain.defstruct->nstring,p2) || searchstruct(smain.defstruct->ustruct,p2))
		return sendmsg(NAME);
	if (!strcmp("short",p1))
		return addshort(p2);
	else if (!strcmp("int",p1))
		return addint(p2);
	else if (!strcmp("long",p1))
		return addlong(p2);
	else if (!strcmp("float",p1))
		return addfloat(p2);
	else if (!strcmp("double",p1))
		return adddouble(p2);
	else if (!strcmp("char",p1))
		return addchar(p2);
	else if (!strcmp("string",p1))
		return addstring(p2,p3);
	else if ((astruct = searchstruct(smain.avstruct,p1)))
		return addstruct(astruct,p2);
	else
		return sendmsg(TYPE);
}
int __stdcall save(HWND mWnd,HWND aWnd,char *data,char *parms,BOOL show,BOOL nopause)
{
	sstruct *svstruct;
	Data = data;
	if (!smode)
		return sendmsg(NDEFINING);
	smain.defstruct->nstruct = smain.avstruct;
	smain.avstruct = smain.defstruct;
	smain.defstruct = STRUCTN;
	smode = NORM;
	return sendmsg(OK);
}
int __stdcall del(HWND mWnd,HWND aWnd,char *data,char *parms,BOOL show,BOOL nopause)
{
	char *p1;
	Data = data;
	p1 = getparam(data);
	if (smode)
		return sendmsg(DEFINING);
	if (!p1)
		return sendmsg(PARAM);
	if (p1[0] == '\"')
		return sendmsg(WPARAM);
	if (strlen(p1) > NAMELEN)
		return sendmsg(LONG);
	if (delstruct(p1))
		return sendmsg(OK);
	else
		return sendmsg(NONAME);
}
int __stdcall new(HWND mWnd,HWND aWnd,char *data,char *parms,BOOL show,BOOL nopause)
{
	char *p1, *p2;
	sstruct *newstruct, *typestruct;
	Data = data;
	p1 = getparam(data);
	p2 = getparam(NULL);
	if (smode)
		return sendmsg(DEFINING);
	if (!p2)
		return sendmsg(PARAM);
	if (p1[0] == '\"' || p2[0] == '\"')
		return sendmsg(WPARAM);
	if (strlen(p1) > NAMELEN || strlen(p2) > NAMELEN)
		return sendmsg(LONG);
	if (!(typestruct = searchstruct(smain.avstruct,p1)))
		return sendmsg(NONAME);
	if (searchstruct(smain.avstruct,p2) || searchstruct(smain.dclstruct,p2))
		return sendmsg(NAME);
	if (!(newstruct = copystruct(typestruct)))
		return sendmsg(NOMEMORY);
	strcpy(newstruct->name,p2);
	newstruct->nstruct = smain.dclstruct;
	smain.dclstruct = newstruct;
	return sendmsg(OK);
}
int __stdcall print(HWND mWnd,HWND aWnd,char *data,char *parms,BOOL show,BOOL nopause)
{
	FILE *fout;
	Data = data;
	if (!(fout = fopen(PRINTF,"w")))
		return sendmsg(EPRINT);
	fprintf(fout,"Defining Structure\n------------------\n\n");
	printstruct(smain.defstruct,fout,0);
	fprintf(fout,"Available Structures\n--------------------\n\n");
	printstruct(smain.avstruct,fout,0);
	fprintf(fout,"Declared Structures\n-------------------\n\n");
	printstruct(smain.dclstruct,fout,0);
	fclose(fout);
	return sendmsg(PRINTF);
}
int __stdcall set(HWND mWnd,HWND aWnd,char *data,char *parms,BOOL show,BOOL nopause)
{
	char *p1, *p2;
	Data = data;
	p1 = getparam(data);
	p2 = getparam(NULL);
	if (smode)
		return sendmsg(DEFINING);
	if (!p2)
		return sendmsg(PARAM);
	if (p1[0] == '\"')
		return sendmsg(WPARAM);
	if (strlen(p1) > NAMELEN)
		return sendmsg(LONG);
	if (p2[0] == '\"')
		return setvalue(p1,p2);
	else
		return copyvalue(p1,p2);
}
int __stdcall get(HWND mWnd,HWND aWnd,char *data,char *parms,BOOL show,BOOL nopause)
{
	char *p1;
	Data = data;
	p1 = getparam(data);
	if (smode)
		return sendmsg(DEFINING);
	if (!p1)
		return sendmsg(PARAM);
	if (p1[0] == '\"')
		return sendmsg(WPARAM);
	if (strlen(p1) > NAMELEN)
		return sendmsg(LONG);
	return getvalue(p1);
}
int __stdcall inc(HWND mWnd,HWND aWnd,char *data,char *parms,BOOL show,BOOL nopause)
{
	char *p1, *p2;
	Data = data;
	p1 = getparam(data);
	p2 = getparam(NULL);
	if (smode)
		return sendmsg(DEFINING);
	if (!p2)
		return sendmsg(PARAM);
	if (p1[0] == '\"')
		return sendmsg(WPARAM);
	if (strlen(p1) > NAMELEN)
		return sendmsg(LONG);
	if (p2[0] == '\"')
		return incbyvalue(p1,p2);
	else
		return incbystruct(p1,p2);
}
int __stdcall dec(HWND mWnd,HWND aWnd,char *data,char *parms,BOOL show,BOOL nopause)
{
	char *p1, *p2;
	Data = data;
	p1 = getparam(data);
	p2 = getparam(NULL);
	if (smode)
		return sendmsg(DEFINING);
	if (!p2)
		return sendmsg(PARAM);
	if (p1[0] == '\"')
		return sendmsg(WPARAM);
	if (strlen(p1) > NAMELEN)
		return sendmsg(LONG);
	if (p2[0] == '\"')
		return decbyvalue(p1,p2);
	else
		return decbystruct(p1,p2);
}

int sendmsg(char *value)
{
	strcpy(Data,value);
	return 3;
}
void sclear(void)
{
	sclearstruct(smain.defstruct);
	sclearstruct(smain.avstruct);
	sclearstruct(smain.dclstruct);
	smode = NORM;
	memset(&smain,0,sizeof(Smain));
}
void sclearstruct(sstruct *clrstruct)
{
	if (clrstruct)
	{
		sclearshort(clrstruct->nshort);
		sclearint(clrstruct->nint);
		sclearlong(clrstruct->nlong);
		sclearfloat(clrstruct->nfloat);
		scleardouble(clrstruct->ndouble);
		sclearchar(clrstruct->nchar);
		sclearstring(clrstruct->nstring);
		sclearstruct(clrstruct->ustruct);
		sclearstruct(clrstruct->nstruct);
		free(clrstruct);
	}
}
void sclearshort(sshort *clrshort)
{
	if (clrshort)
	{
		sclearshort(clrshort->nshort);
		free(clrshort);
	}
}
void sclearint(sint *clrint)
{
	if (clrint)
	{
		sclearint(clrint->nint);
		free(clrint);
	}
}
void sclearlong(slong *clrlong)
{
	if (clrlong)
	{
		sclearlong(clrlong->nlong);
		free(clrlong);
	}
}
void sclearfloat(sfloat *clrfloat)
{
	if (clrfloat)
	{
		sclearfloat(clrfloat->nfloat);
		free(clrfloat);
	}
}
void scleardouble(sdouble *clrdouble)
{
	if (clrdouble)
	{
		scleardouble(clrdouble->ndouble);
		free(clrdouble);
	}
}
void sclearchar(schar *clrchar)
{
	if (clrchar)
	{
		sclearchar(clrchar->nchar);
		free(clrchar);
	}
}
void sclearstring(sstring *clrstring)
{
	if (clrstring)
	{
		sclearstring(clrstring->nstring);
		if (clrstring->value)
			free(clrstring->value);
		free(clrstring);
	}
}
char *getparam(char *data)
{
	int i = 0;
	char check = ' ';
	static char *data2, *data3;
	if (data)
		data2 = data;
	else
		data2 = data3;
	while (data2[0] == ' ')
		data2++;
	if (data2[0] == '\"')
	{
		check = '\"';
		data2++;
		i++;
	}
	for (data3 = data2; data3[0] != check && data3[0] != 0; data3++);
	if (data3[0] == check)
	{
		data3[0] = 0;
		data3++;
	}
	if (i)
		data2--;
	if (!strlen(data2))
		return NULL;
	return data2;
}
sstruct *searchstruct(sstruct *ssstruct, char *name)
{
	if (ssstruct)
	{
		if (!strcmp(name,ssstruct->name))
			return ssstruct;
		else
			return searchstruct(ssstruct->nstruct,name);
	}
	else
		return NULL;
}
sshort *searchshort(sshort *ssstruct, char *name)
{
	if (ssstruct)
	{
		if (!strcmp(name,ssstruct->name))
			return ssstruct;
		else
			return searchshort(ssstruct->nshort,name);
	}
	else
		return NULL;
}
sint *searchint(sint *sistruct, char *name)
{
	if (sistruct)
	{
		if (!strcmp(name,sistruct->name))
			return sistruct;
		else
			return searchint(sistruct->nint,name);
	}
	else
		return NULL;
}
slong *searchlong(slong *slstruct, char *name)
{
	if (slstruct)
	{
		if (!strcmp(name,slstruct->name))
			return slstruct;
		else
			return searchlong(slstruct->nlong,name);
	}
	else
		return NULL;
}
sfloat *searchfloat(sfloat *sfstruct, char *name)
{
	if (sfstruct)
	{
		if (!strcmp(name,sfstruct->name))
			return sfstruct;
		else
			return searchfloat(sfstruct->nfloat,name);
	}
	else
		return NULL;
}
sdouble *searchdouble(sdouble *sdstruct, char *name)
{
	if (sdstruct)
	{
		if (!strcmp(name,sdstruct->name))
			return sdstruct;
		else
			return searchdouble(sdstruct->ndouble,name);
	}
	else
		return NULL;
}
schar *searchchar(schar *scstruct, char *name)
{
	if (scstruct)
	{
		if (!strcmp(name,scstruct->name))
			return scstruct;
		else
			return searchchar(scstruct->nchar,name);
	}
	else
		return NULL;
}
sstring *searchstring(sstring *ssstruct, char *name)
{
	if (ssstruct)
	{
		if (!strcmp(name,ssstruct->name))
			return ssstruct;
		else
			return searchstring(ssstruct->nstring,name);
	}
	else
		return NULL;
}
int addshort(char *name)
{
	sshort *asstruct;
	if (!(asstruct = malloc(sizeof(sshort))))
		return sendmsg(NOMEMORY);
	memset(asstruct,0,sizeof(sshort));
	strcpy(asstruct->name,name);
	asstruct->nshort = smain.defstruct->nshort;
	smain.defstruct->nshort = asstruct;
	return sendmsg(OK);
}
int addint(char *name)
{
	sint *aistruct;
	if (!(aistruct = malloc(sizeof(sint))))
		return sendmsg(NOMEMORY);
	memset(aistruct,0,sizeof(sint));
	strcpy(aistruct->name,name);
	aistruct->nint = smain.defstruct->nint;
	smain.defstruct->nint = aistruct;
	return sendmsg(OK);
}
int addlong(char *name)
{
	slong *alstruct;
	if (!(alstruct = malloc(sizeof(slong))))
		return sendmsg(NOMEMORY);
	memset(alstruct,0,sizeof(slong));
	strcpy(alstruct->name,name);
	alstruct->nlong = smain.defstruct->nlong;
	smain.defstruct->nlong = alstruct;
	return sendmsg(OK);
}
int addfloat(char *name)
{
	sfloat *afstruct;
	if (!(afstruct = malloc(sizeof(sfloat))))
		return sendmsg(NOMEMORY);
	memset(afstruct,0,sizeof(sfloat));
	strcpy(afstruct->name,name);
	afstruct->nfloat = smain.defstruct->nfloat;
	smain.defstruct->nfloat = afstruct;
	return sendmsg(OK);
}
int adddouble(char *name)
{
	sdouble *adstruct;
	if (!(adstruct = malloc(sizeof(sdouble))))
		return sendmsg(NOMEMORY);
	memset(adstruct,0,sizeof(sdouble));
	strcpy(adstruct->name,name);
	adstruct->ndouble = smain.defstruct->ndouble;
	smain.defstruct->ndouble = adstruct;
	return sendmsg(OK);
}
int addchar(char *name)
{
	schar *acstruct;
	if (!(acstruct = malloc(sizeof(schar))))
		return sendmsg(NOMEMORY);
	memset(acstruct,0,sizeof(schar));
	strcpy(acstruct->name,name);
	acstruct->nchar = smain.defstruct->nchar;
	smain.defstruct->nchar = acstruct;
	return sendmsg(OK);
}
int addstring(char *name, char *length)
{
	int len;
	char *string;
	sstring *asstruct;
	if (!length || !strlen(length) || !isnum(length))
		len = DEFSTRINGLEN;
	else
		len = atoi(length);
	if (!(asstruct = malloc(sizeof(sstring))))
		return sendmsg(NOMEMORY);
	memset(asstruct,0,sizeof(sstring));
	if (!(string = malloc(len*sizeof(char))))
	{
		free(asstruct);
		return sendmsg(NOMEMORY);
	}
	memset(string,0,len*sizeof(char));
	asstruct->length = len;
	strcpy(asstruct->name,name);
	asstruct->nstring = smain.defstruct->nstring;
	smain.defstruct->nstring = asstruct;
	return sendmsg(OK);
}
int addstruct(sstruct *type, char *name)
{
	sstruct *asstruct;
	if (!(asstruct = copystruct(type)))
		return sendmsg(NOMEMORY);
	strcpy(asstruct->name,name);
	asstruct->ustruct = smain.defstruct->ustruct;
	smain.defstruct->ustruct = asstruct;
	return sendmsg(OK);
}
int isnum(char *in)
{
	for (; in[0] != 0; in++)
	{
		if (!isdigit(in[0]))
			return 0;
	}
	return 1;
}
sstruct *copystruct(sstruct *type)
{
	if (!type)
		return NULL;
	sshort *nshort = type->nshort;
	sint *nint = type->nint;
	slong *nlong = type->nlong;
	sfloat *nfloat = type->nfloat;
	sdouble *ndouble = type->ndouble;
	schar *nchar = type->nchar;
	sstring *nstring = type->nstring;
	sstruct *tstruct, *ustruct = type->ustruct, *nstruct = type->nstruct;
	if (!(tstruct = malloc(sizeof(sstruct))))
		return NULL;
	memcpy(tstruct,type,sizeof(sstruct));
	if (nshort)
	{
		if (!(tstruct->nshort = copyshort(nshort)))
		{
			free(tstruct);
			return NULL;
		}
	}
	if (nint)
	{
		if (!(tstruct->nint = copyint(nint)))
		{
			free(tstruct);
			return NULL;
		}
	}
	if (nlong)
	{
		if (!(tstruct->nlong = copylong(nlong)))
		{
			free(tstruct);
			return NULL;
		}
	}
	if (nfloat)
	{
		if (!(tstruct->nfloat = copyfloat(nfloat)))
		{
			free(tstruct);
			return NULL;
		}
	}
	if (ndouble)
	{
		if (!(tstruct->ndouble = copydouble(ndouble)))
		{
			free(tstruct);
			return NULL;
		}
	}
	if (nchar)
	{
		if (!(tstruct->nchar = copychar(nchar)))
		{
			free(tstruct);
			return NULL;
		}
	}
	if (nstring)
	{
		if (!(tstruct->nstring = copystring(nstring)))
		{
			free(tstruct);
			return NULL;
		}
	}
	if (ustruct)
	{
		if (!(tstruct->ustruct = copystruct(ustruct)))
		{
			free(tstruct);
			return NULL;
		}
	}
	if (nstruct)
	{
		if (!(tstruct->nstruct = copystruct(nstruct)))
		{
			free(tstruct);
			return NULL;
		}
	}
	return tstruct;
}
sshort *copyshort(sshort *type)
{
	sshort *tshort, *nshort = type->nshort;
	if (!(tshort = malloc(sizeof(sshort))))
		return NULL;
	memcpy(tshort,type,sizeof(sshort));
	if (nshort)
	{
		if (!(tshort->nshort = copyshort(nshort)))
		{
			free(tshort);
			return NULL;
		}
	}
	return tshort;
}
sint *copyint(sint *type)
{
	sint *tint, *nint = type->nint;
	if (!(tint = malloc(sizeof(sint))))
		return NULL;
	memcpy(tint,type,sizeof(sint));
	if (nint)
	{
		if (!(tint->nint = copyint(nint)))
		{
			free(tint);
			return NULL;
		}
	}
	return tint;
}
slong *copylong(slong *type)
{
	slong *tlong, *nlong = type->nlong;
	if (!(tlong = malloc(sizeof(slong))))
		return NULL;
	memcpy(tlong,type,sizeof(slong));
	if (nlong)
	{
		if (!(tlong->nlong = copylong(nlong)))
		{
			free(tlong);
			return NULL;
		}
	}
	return tlong;
}
sfloat *copyfloat(sfloat *type)
{
	sfloat *tfloat, *nfloat = type->nfloat;
	if (!(tfloat = malloc(sizeof(sfloat))))
		return NULL;
	memcpy(tfloat,type,sizeof(sfloat));
	if (nfloat)
	{
		if (!(tfloat->nfloat = copyfloat(nfloat)))
		{
			free(tfloat);
			return NULL;
		}
	}
	return tfloat;
}
sdouble *copydouble(sdouble *type)
{
	sdouble *tdouble, *ndouble = type->ndouble;
	if (!(tdouble = malloc(sizeof(sdouble))))
		return NULL;
	memcpy(tdouble,type,sizeof(sdouble));
	if (ndouble)
	{
		if (!(tdouble->ndouble = copydouble(ndouble)))
		{
			free(tdouble);
			return NULL;
		}
	}
	return tdouble;
}
schar *copychar(schar *type)
{
	schar *tchar, *nchar = type->nchar;
	if (!(tchar = malloc(sizeof(schar))))
		return NULL;
	memcpy(tchar,type,sizeof(schar));
	if (nchar)
	{
		if (!(tchar->nchar = copychar(nchar)))
		{
			free(tchar);
			return NULL;
		}
	}
	return tchar;
}
sstring *copystring(sstring *type)
{
	char *string;
	sstring *tstring, *nstring = type->nstring;
	if (!(tstring = malloc(sizeof(sstring))))
		return NULL;
	memcpy(tstring,type,sizeof(sstring));
	if (!(string = malloc(type->length*sizeof(char))))
	{
		free(tstring);
		return NULL;
	}
	memset(string,0,type->length*sizeof(char));
	tstring->value = string;
	if (nstring)
	{
		if (!(tstring->nstring = copystring(nstring)))
		{
			free(tstring);
			free(string);
			return NULL;
		}
	}
	return tstring;
}
BOOL delstruct(char *name)
{
	int i;
	sstruct *dstruct, *dstructprev;
	for (i = 0; i < 2; i++)
	{
		dstructprev = STRUCTN;
		if (!i)
			dstruct = smain.avstruct;
		else
			dstruct = smain.dclstruct;
		while (dstruct)
		{
			if (!strcmp(dstruct->name,name))
				break;
			else
			{
				dstructprev = dstruct;
				dstruct = dstruct->nstruct;
			}
		}
		if (dstruct)
		{
			if (dstructprev)
				dstructprev->nstruct = dstruct->nstruct;
			else
			{
				if (!i)
					smain.avstruct = dstruct->nstruct;
				else
					smain.dclstruct = dstruct->nstruct;
			}
			dstruct->nstruct = STRUCTN;
			sclearstruct(dstruct);
			return TRUE;
		}
	}
	return FALSE;
}
void printspace(FILE *fout,int space)
{
	int i;
	for (i = 0; i < space; i++)
		fprintf(fout," ");
}
void printstruct(sstruct *pstruct, FILE *fout, int space)
{
	if (pstruct)
	{
		fprintf(fout,"struct:   %s\n",pstruct->name);
		printspace(fout,space);
		fprintf(fout,"|short:   ");
		printshort(pstruct->nshort,fout);
		printspace(fout,space);
		fprintf(fout,"|int:     ");
		printint(pstruct->nint,fout);
		printspace(fout,space);
		fprintf(fout,"|long:    ");
		printlong(pstruct->nlong,fout);
		printspace(fout,space);
		fprintf(fout,"|float:   ");
		printfloat(pstruct->nfloat,fout);
		printspace(fout,space);
		fprintf(fout,"|double:  ");
		printdouble(pstruct->ndouble,fout);
		printspace(fout,space);
		fprintf(fout,"|char:    ");
		printchar(pstruct->nchar,fout);
		printspace(fout,space);
		fprintf(fout,"|string:  ");
		printstring(pstruct->nstring,fout);
		printspace(fout,space);
		fprintf(fout,"+---------");
		printstruct(pstruct->ustruct,fout,space+10);
		fprintf(fout,"\n\n");
		printstruct(pstruct->nstruct,fout,space);
	}
}
void printshort(sshort *pshort, FILE *fout)
{
	while (pshort)
	{
		fprintf(fout,"%-20s ",pshort->name);
		if ((pshort = pshort->nshort))
			fprintf(fout,"- ");
	}
	fprintf(fout,"\n");
}
void printint(sint *pint, FILE *fout)
{
	while (pint)
	{
		fprintf(fout,"%-20s ",pint->name);
		if ((pint = pint->nint))
			fprintf(fout,"- ");
	}
	fprintf(fout,"\n");
}
void printlong(slong *plong, FILE *fout)
{
	while (plong)
	{
		fprintf(fout,"%-20s ",plong->name);
		if ((plong = plong->nlong))
			fprintf(fout,"- ");
	}
	fprintf(fout,"\n");
}
void printfloat(sfloat *pfloat, FILE *fout)
{
	while (pfloat)
	{
		fprintf(fout,"%-20s ",pfloat->name);
		if ((pfloat = pfloat->nfloat))
			fprintf(fout,"- ");
	}
	fprintf(fout,"\n");
}
void printdouble(sdouble *pdouble, FILE *fout)
{
	while (pdouble)
	{
		fprintf(fout,"%-20s ",pdouble->name);
		if ((pdouble = pdouble->ndouble))
			fprintf(fout,"- ");
	}
	fprintf(fout,"\n");
}
void printchar(schar *pchar, FILE *fout)
{
	while (pchar)
	{
		fprintf(fout,"%-20s ",pchar->name);
		if ((pchar = pchar->nchar))
			fprintf(fout,"- ");
	}
	fprintf(fout,"\n");
}
void printstring(sstring *pstring, FILE *fout)
{
	while (pstring)
	{
		fprintf(fout,"%-20s ",pstring->name);
		if ((pstring = pstring->nstring))
			fprintf(fout,"- ");
	}
	fprintf(fout,"\n");
}
sstruct *getstruct(char *name)
{
	char *p1, *p2, *p3;
	sstruct *gsstruct;
	p1 = strtok(name,".");
	p2 = strtok(NULL,".");
	p3 = strtok(NULL,".");
	if (!p2)
		return NULL;
	if (!(gsstruct = searchstruct(smain.dclstruct,p1)))
		return NULL;
	while (p3)
	{
		if (!(gsstruct = searchstruct(gsstruct->ustruct,p2)))
			return NULL;
		p2 = p3;
		p3 = strtok(NULL,".");
	}
	strcpy(name,p2);
	return gsstruct;
}
int setvalue(char *dest, char *value)
{
	int len;
	sstruct *svstruct;
	sshort *svshort;
	sint *svint;
	slong *svlong;
	sfloat *svfloat;
	sdouble *svdouble;
	schar *svchar;
	sstring *svstring;
	value++;
	len = strlen(value);
	if (value[len] == '\"')
		value[len--] = 0;
	if (!(svstruct = getstruct(dest)))
		return sendmsg(WPATH);
	if ((svshort = searchshort(svstruct->nshort,dest)))
	{
		svshort->value = (short)atoi(value);
		return sendmsg(OK);
	}
	if ((svint = searchint(svstruct->nint,dest)))
	{
		svint->value = atoi(value);
		return sendmsg(OK);
	}
	if ((svlong = searchlong(svstruct->nlong,dest)))
	{
		svlong->value = atol(value);
		return sendmsg(OK);
	}
	if ((svfloat = searchfloat(svstruct->nfloat,dest)))
	{
		svfloat->value = (float)atof(value);
		return sendmsg(OK);
	}
	if ((svdouble = searchdouble(svstruct->ndouble,dest)))
	{
		svdouble->value = atof(value);
		return sendmsg(OK);
	}
	if ((svchar = searchchar(svstruct->nchar,dest)))
	{
		svchar->value = value[0];
		return sendmsg(OK);
	}
	if ((svstring = searchstring(svstruct->nstring,dest)))
	{
		strncpy(svstring->value,value,svstring->length);
		return sendmsg(OK);
	}
	return sendmsg(WPATH);
}
int copyvalue(char *dest, char *source)
{
	sstruct *cvstruct1, *cvstruct2;
	sshort *cvshort1, *cvshort2;
	sint *cvint1, *cvint2;
	slong *cvlong1, *cvlong2;
	sfloat *cvfloat1, *cvfloat2;
	sdouble *cvdouble1, *cvdouble2;
	schar *cvchar1, *cvchar2;
	sstring *cvstring1, *cvstring2;
	if (strlen(source) > NAMELEN)
		return sendmsg(LONG);
	if (!(cvstruct1 = getstruct(dest)) || !(cvstruct2 = getstruct(source)))
		return sendmsg(WPATH);
	if ((cvshort1 = searchshort(cvstruct1->nshort,dest)) && (cvshort2 = searchshort(cvstruct2->nshort,source)))
	{
		cvshort1->value = cvshort2->value;
		return sendmsg(OK);
	}
	if ((cvint1 = searchint(cvstruct1->nint,dest)) && (cvint2 = searchint(cvstruct2->nint,source)))
	{
		cvint1->value = cvint2->value;
		return sendmsg(OK);
	}
	if ((cvlong1 = searchlong(cvstruct1->nlong,dest)) && (cvlong2 = searchlong(cvstruct2->nlong,source)))
	{
		cvlong1->value = cvlong2->value;
		return sendmsg(OK);
	}
	if ((cvfloat1 = searchfloat(cvstruct1->nfloat,dest)) && (cvfloat2 = searchfloat(cvstruct2->nfloat,source)))
	{
		cvfloat1->value = cvfloat2->value;
		return sendmsg(OK);
	}
	if ((cvdouble1 = searchdouble(cvstruct1->ndouble,dest)) && (cvdouble2 = searchdouble(cvstruct2->ndouble,source)))
	{
		cvdouble1->value = cvdouble2->value;
		return sendmsg(OK);
	}
	if ((cvchar1 = searchchar(cvstruct1->nchar,dest)) && (cvchar2 = searchchar(cvstruct2->nchar,source)))
	{
		cvchar1->value = cvchar2->value;
		return sendmsg(OK);
	}
	if ((cvstring1 = searchstring(cvstruct1->nstring,dest)) && (cvstring2 = searchstring(cvstruct2->nstring,source)))
	{
		strncpy(cvstring1->value,cvstring2->value,cvstring1->length);
		return sendmsg(OK);
	}
	return sendmsg(WPATH);
}
int getvalue(char *source)
{
	sstruct *gvstruct;
	sshort *gvshort;
	sint *gvint;
	slong *gvlong;
	sfloat *gvfloat;
	sdouble *gvdouble;
	schar *gvchar;
	sstring *gvstring;
	if (!(gvstruct = getstruct(source)))
		return sendmsg(WPATH);
	if ((gvshort = searchshort(gvstruct->nshort,source)))
	{
		sprintf(Data,"%hd",gvshort->value);
		return 3;
	}
	if ((gvint = searchint(gvstruct->nint,source)))
	{
		sprintf(Data,"%d",gvint->value);
		return 3;
	}
	if ((gvlong = searchlong(gvstruct->nlong,source)))
	{
		sprintf(Data,"%ld",gvlong->value);
		return 3;
	}
	if ((gvfloat = searchfloat(gvstruct->nfloat,source)))
	{
		sprintf(Data,"%f",gvfloat->value);
		return 3;
	}
	if ((gvdouble = searchdouble(gvstruct->ndouble,source)))
	{
		sprintf(Data,"%lf",gvdouble->value);
		return 3;
	}
	if ((gvchar = searchchar(gvstruct->nchar,source)))
	{
		sprintf(Data,"%c",gvchar->value);
		return 3;
	}
	if ((gvstring = searchstring(gvstruct->nstring,source)))
	{
		sprintf(Data,"%s",gvstring->value);
		return 3;
	}
	return sendmsg(WPATH);
}
int incbyvalue(char *dest, char *value)
{
	int len;
	sstruct *svstruct;
	sshort *svshort;
	sint *svint;
	slong *svlong;
	sfloat *svfloat;
	sdouble *svdouble;
	value++;
	len = strlen(value);
	if (value[len] == '\"')
		value[len--] = 0;
	if (!(svstruct = getstruct(dest)))
		return sendmsg(WPATH);
	if ((svshort = searchshort(svstruct->nshort,dest)))
	{
		svshort->value += (short)atoi(value);
		return sendmsg(OK);
	}
	if ((svint = searchint(svstruct->nint,dest)))
	{
		svint->value += atoi(value);
		return sendmsg(OK);
	}
	if ((svlong = searchlong(svstruct->nlong,dest)))
	{
		svlong->value += atol(value);
		return sendmsg(OK);
	}
	if ((svfloat = searchfloat(svstruct->nfloat,dest)))
	{
		svfloat->value += (float)atof(value);
		return sendmsg(OK);
	}
	if ((svdouble = searchdouble(svstruct->ndouble,dest)))
	{
		svdouble->value += atof(value);
		return sendmsg(OK);
	}
	return sendmsg(WPATH);
}
int incbystruct(char *dest, char *source)
{
	sstruct *cvstruct1, *cvstruct2;
	sshort *cvshort1, *cvshort2;
	sint *cvint1, *cvint2;
	slong *cvlong1, *cvlong2;
	sfloat *cvfloat1, *cvfloat2;
	sdouble *cvdouble1, *cvdouble2;
	if (strlen(source) > NAMELEN)
		return sendmsg(LONG);
	if (!(cvstruct1 = getstruct(dest)) || !(cvstruct2 = getstruct(source)))
		return sendmsg(WPATH);
	if ((cvshort1 = searchshort(cvstruct1->nshort,dest)) && (cvshort2 = searchshort(cvstruct2->nshort,source)))
	{
		cvshort1->value += cvshort2->value;
		return sendmsg(OK);
	}
	if ((cvint1 = searchint(cvstruct1->nint,dest)) && (cvint2 = searchint(cvstruct2->nint,source)))
	{
		cvint1->value += cvint2->value;
		return sendmsg(OK);
	}
	if ((cvlong1 = searchlong(cvstruct1->nlong,dest)) && (cvlong2 = searchlong(cvstruct2->nlong,source)))
	{
		cvlong1->value += cvlong2->value;
		return sendmsg(OK);
	}
	if ((cvfloat1 = searchfloat(cvstruct1->nfloat,dest)) && (cvfloat2 = searchfloat(cvstruct2->nfloat,source)))
	{
		cvfloat1->value += cvfloat2->value;
		return sendmsg(OK);
	}
	if ((cvdouble1 = searchdouble(cvstruct1->ndouble,dest)) && (cvdouble2 = searchdouble(cvstruct2->ndouble,source)))
	{
		cvdouble1->value += cvdouble2->value;
		return sendmsg(OK);
	}
	return sendmsg(WPATH);
}
int decbyvalue(char *dest, char *value)
{
	int len;
	sstruct *svstruct;
	sshort *svshort;
	sint *svint;
	slong *svlong;
	sfloat *svfloat;
	sdouble *svdouble;
	value++;
	len = strlen(value);
	if (value[len] == '\"')
		value[len--] = 0;
	if (!(svstruct = getstruct(dest)))
		return sendmsg(WPATH);
	if ((svshort = searchshort(svstruct->nshort,dest)))
	{
		svshort->value -= (short)atoi(value);
		return sendmsg(OK);
	}
	if ((svint = searchint(svstruct->nint,dest)))
	{
		svint->value -= atoi(value);
		return sendmsg(OK);
	}
	if ((svlong = searchlong(svstruct->nlong,dest)))
	{
		svlong->value -= atol(value);
		return sendmsg(OK);
	}
	if ((svfloat = searchfloat(svstruct->nfloat,dest)))
	{
		svfloat->value -= (float)atof(value);
		return sendmsg(OK);
	}
	if ((svdouble = searchdouble(svstruct->ndouble,dest)))
	{
		svdouble->value -= atof(value);
		return sendmsg(OK);
	}
	return sendmsg(WPATH);
}
int decbystruct(char *dest, char *source)
{
	sstruct *cvstruct1, *cvstruct2;
	sshort *cvshort1, *cvshort2;
	sint *cvint1, *cvint2;
	slong *cvlong1, *cvlong2;
	sfloat *cvfloat1, *cvfloat2;
	sdouble *cvdouble1, *cvdouble2;
	if (strlen(source) > NAMELEN)
		return sendmsg(LONG);
	if (!(cvstruct1 = getstruct(dest)) || !(cvstruct2 = getstruct(source)))
		return sendmsg(WPATH);
	if ((cvshort1 = searchshort(cvstruct1->nshort,dest)) && (cvshort2 = searchshort(cvstruct2->nshort,source)))
	{
		cvshort1->value -= cvshort2->value;
		return sendmsg(OK);
	}
	if ((cvint1 = searchint(cvstruct1->nint,dest)) && (cvint2 = searchint(cvstruct2->nint,source)))
	{
		cvint1->value -= cvint2->value;
		return sendmsg(OK);
	}
	if ((cvlong1 = searchlong(cvstruct1->nlong,dest)) && (cvlong2 = searchlong(cvstruct2->nlong,source)))
	{
		cvlong1->value -= cvlong2->value;
		return sendmsg(OK);
	}
	if ((cvfloat1 = searchfloat(cvstruct1->nfloat,dest)) && (cvfloat2 = searchfloat(cvstruct2->nfloat,source)))
	{
		cvfloat1->value -= cvfloat2->value;
		return sendmsg(OK);
	}
	if ((cvdouble1 = searchdouble(cvstruct1->ndouble,dest)) && (cvdouble2 = searchdouble(cvstruct2->ndouble,source)))
	{
		cvdouble1->value -= cvdouble2->value;
		return sendmsg(OK);
	}
	return sendmsg(WPATH);
}
