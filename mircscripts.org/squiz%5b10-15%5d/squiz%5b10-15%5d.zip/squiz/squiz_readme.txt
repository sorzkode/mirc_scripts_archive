                ******************************
                * S-Quiz v1.5                *
                * By SSJ4_Son_Goku           *
                * Finished on August 26th    *
                ******************************

***** INSTALL *****

To install this addon, unzip the folder and put it in your $mircdir (to find out what your mircdir is type //echo -a $mircdir in any window). Then type //load -rs $$sfile($mircdir.*mrc) in any window. Navigate to the squiz.mrc file. Done. Right click in a channel or access the menubar to open the dialog.

***** QUESTION FILE *****

I have included a sample question file with ~50 questions. The file is squiz_sample_questions.txt Feel free to use it as your question database, but remember, if many people download this script they all have the same question file which makes it very easy to cheat. If you want to make your own question database the format is:

Question=Answer

i.e.

Who wrote this script?=SSJ4_Son_Goku


***** CONTACT & CREDITS *****

If you find any bugs with this script or have any suggestions for it or just want to get in contact with me, you can either find me on #ssj4 @ irc.quakenet.org or email me at songoku1@gmail.com

You can always find the latest version of this either at:
http://www.ssj4.s4.cybton.com/scripts/index.html (along with all my other released scripts)
http://www.mircscripts.org

Special Thanks to:
Cerialkiller (for testing this script and giving tons of suggestions)
wiebe and Doomie (for help on features for the script)
You (for using this)
#quiz @ Quakenet (inspiration)