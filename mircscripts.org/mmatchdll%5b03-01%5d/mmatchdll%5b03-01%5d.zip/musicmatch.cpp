/* MusicMatch Dll ********************************************************
 *
 * Version:			2.2.0.0.0
 * FileName:		musicmatch.dll
 * Date Created:	1/12/2004
 *
 * Author:			Soul_Eater
 * Comments:
 *		For MusicMatch Jukebox 8.20.0081(above or below unsure)
 *      returns the current playing song, and performs many functions
 *
 *******************************************************************/

#pragma check_stack(off)
#pragma comment(linker,"/OPT:NOWIN98")
#include <windows.h>
#include <winuser.h>
#define MMJB_PREV 32854
#define MMJB_PLAY 32856
#define MMJB_PAUSE 32857
#define MMJB_STOP 32858
#define MMJB_NEXT 32859
#define MMJB_VOLUME_UP 32864
#define MMJB_VOLUME_DOWN 32865
#define MMJB_MUTE 32866
#define MMJB_SEEK_FORWARD 32861
#define MMJB_SEEK_BACKWARD 32860
#define MMJB_SKIP_BACK_TRACKS 32862
#define MMJB_SKIP_FORWARD_TRACKS 32863


HWND mwnd;
char string[999];
char title[999];

int __stdcall MmCurrent(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
	
 HWND window = FindWindow("MMJB:MAINWND",NULL);
char this_title[2048],*p;
GetWindowText(window,this_title,sizeof(this_title));
p = this_title+strlen(this_title)-8;
while (p >= this_title)
{

if (!strnicmp(p,"- MUSICMATCH Jukebox",8)) break;
p--;

}
if (p >= this_title) p--;
while (p >= this_title && *p == ' ') p--;
*++p=0;
 lstrcpy(data,this_title);
   return 3;
}

int __stdcall MmPause(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
	
   HWND window = FindWindow("MMJB:MAINWND",NULL);
   if (!IsWindow(window)) { 
	   lstrcpy(data,"MM_ERR MusicMatch Jukebox is not open."); 
	   return 3; 
   }
SendMessage(window,WM_COMMAND,MMJB_PAUSE,0);
lstrcpy(data,"MusicMatch song paused.");
   return 3;
}

int __stdcall MmStop(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
	
   HWND window = FindWindow("MMJB:MAINWND",NULL);
   if (!IsWindow(window)) { 
	   lstrcpy(data,"MM_ERR MusicMatch Jukebox is not open."); 
	   return 3; 
   }
   SendMessage(window,WM_COMMAND,MMJB_STOP,0);
   lstrcpy(data,"MusicMatch song stopped.");
   return 3;
}

int __stdcall MmPlay(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
	
   HWND window = FindWindow("MMJB:MAINWND",NULL);
   if (!IsWindow(window)) { 
	   lstrcpy(data,"MM_ERR MusicMatch Jukebox is not open."); 
	   return 3; 
   }
   SendMessage(window,WM_COMMAND,MMJB_PLAY,0);
   lstrcpy(data,"MusicMatch song played.");
   return 3;
}

int __stdcall MmPrev(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
	
   HWND window = FindWindow("MMJB:MAINWND",NULL);
   if (!IsWindow(window)) { 
	   lstrcpy(data,"MM_ERR MusicMatch Jukebox is not open."); 
	   return 3; 
   }
   SendMessage(window,WM_COMMAND,MMJB_PREV,0);
   lstrcpy(data,"MusicMatch playing previous song.");
   return 3;
}
int __stdcall MmNext(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
	
   HWND window = FindWindow("MMJB:MAINWND",NULL);
   if (!IsWindow(window)) { 
	   lstrcpy(data,"MM_ERR MusicMatch Jukebox is not open."); 
	   return 3; 
   }
   SendMessage(window,WM_COMMAND,MMJB_NEXT,0);
   lstrcpy(data,"MusicMatch playing next song.");
   return 3;
}
int __stdcall MmVolup(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
	
   HWND window = FindWindow("MMJB:MAINWND",NULL);
   if (!IsWindow(window)) { 
	   lstrcpy(data,"MM_ERR MusicMatch Jukebox is not open."); 
	   return 3; 
   }
   SendMessage(window,WM_COMMAND,MMJB_VOLUME_UP,0);
   lstrcpy(data,"MusicMatch volume up.");
   return 3;
}
int __stdcall MmVoldown(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
	
   HWND window = FindWindow("MMJB:MAINWND",NULL);
   if (!IsWindow(window)) { 
	   lstrcpy(data,"MM_ERR MusicMatch Jukebox is not open."); 
	   return 3; 
   }
   SendMessage(window,WM_COMMAND,MMJB_VOLUME_DOWN,0);
   lstrcpy(data,"MusicMatch volume downs.");
   return 3;
}
int __stdcall MmMute(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
	
   HWND window = FindWindow("MMJB:MAINWND",NULL);
   if (!IsWindow(window)) { 
	   lstrcpy(data,"MM_ERR MusicMatch Jukebox is not open."); 
	   return 3; 
   }
   SendMessage(window,WM_COMMAND,MMJB_MUTE,0);
   lstrcpy(data,"MusicMatch muted.");
   return 3;
}
int __stdcall MmSkFw(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
	
   HWND window = FindWindow("MMJB:MAINWND",NULL);
   if (!IsWindow(window)) { 
	   lstrcpy(data,"MM_ERR MusicMatch Jukebox is not open."); 
	   return 3; 
   }
   SendMessage(window,WM_COMMAND,MMJB_SEEK_FORWARD,0);
   lstrcpy(data,"MusicMatch seek forward.");
   return 3;
}
int __stdcall MmSkBw(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
	
   HWND window = FindWindow("MMJB:MAINWND",NULL);
   if (!IsWindow(window)) { 
	   lstrcpy(data,"MM_ERR MusicMatch Jukebox is not open."); 
	   return 3; 
   }
   SendMessage(window,WM_COMMAND,MMJB_SEEK_BACKWARD,0);
   lstrcpy(data,"MusicMatch seek backward.");
   return 3;
}
int __stdcall MmSkipFw(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
	
   HWND window = FindWindow("MMJB:MAINWND",NULL);
   if (!IsWindow(window)) { 
	   lstrcpy(data,"MM_ERR MusicMatch Jukebox is not open."); 
	   return 3; 
   }
   SendMessage(window,WM_COMMAND,MMJB_SKIP_FORWARD_TRACKS,0);
   lstrcpy(data,"MusicMatch skip forward.");
   return 3;
}
int __stdcall MmSkipBw(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{
	
   HWND window = FindWindow("MMJB:MAINWND",NULL);
   if (!IsWindow(window)) { 
	   lstrcpy(data,"MM_ERR MusicMatch Jukebox is not open."); 
	   return 3; 
   }
   SendMessage(window,WM_COMMAND,MMJB_SKIP_BACK_TRACKS,0);
   lstrcpy(data,"MusicMatch skip backward.");
   return 3;
}

int MsgBox(char *data)
  {
 int xa = MessageBox (mwnd, data , "MusicMatch DLL" , MB_OK | MB_ICONINFORMATION );
 return 0;
}


int WINAPI DllInfo(HWND,HWND,char *data,char*,BOOL,BOOL)
{
   MsgBox("MusicMatch DLL v2.2 by Soul_Eater \n�2004\nContact Information:\nAIM- SoulEata");
   return 0;
}
