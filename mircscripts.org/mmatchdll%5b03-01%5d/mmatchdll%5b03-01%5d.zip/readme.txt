=========================
=                       =
= MusicMatch DLL v2.1   =
=  by Soul_Eater        =
=                       =
=========================


This DLL performs many functions for MusicMatch Jukebox v8.20.0081(the version I have when coding this dll, if it works for any other version, let me know)

How to use:

MmCurrent

//echo -a $dll(musicmatch.dll,MmCurrent,.)

Returns the current song playing in MusicMatch

Example return: "Home & Dry (Blank & Jones)" by Pet Shop Boys


MmPlay

//echo -a $dll(musicmatch.dll,MmPlay,.)
/dll musicmatch.dll MmPlay

Plays a song in MusicMatch

MmPause

//echo -a $dll(musicmatch.dll,MmPause,.)
/dll musicmatch.dll MmPause

Pauses the currently playing song in MusicMatch

MmStop

//echo -a $dll(musicmatch.dll,MmStop,.)
/dll musicmatch.dll MmStop

Stops the currently playing song in MusicMatch

MmPrev

//echo -a $dll(musicmatch.dll,MmPrev,.)
/dll musicmatch.dll MmPrev

Plays the previous song in MusicMatch

MmNext

//echo -a $dll(musicmatch.dll,MmNext,.)
/dll musicmatch.dll MmNext

Plays the next song in MusicMatch

MmVolup

//echo -a $dll(musicmatch.dll,MmVolup,.)
/dll musicmatch.dll MmVolup

Increases the volume in MusicMatch

MmVoldown

//echo -a $dll(musicmatch.dll,MmVoldown,.)
/dll musicmatch.dll MmVoldown

Decreases the volume in MusicMatch

MmMute

//echo -a $dll(musicmatch.dll,MmMute,.)
/dll musicmatch.dll MmMute

Mutes the volume in MusicMatch

MmSkFw

//echo -a $dll(musicmatch.dll,MmSkFw,.)
/dll musicmatch.dll MmSkFw

Seeks forward within the currently playing track in MusicMatch

MmSkBw

//echo -a $dll(musicmatch.dll,MmSkBw,.)
/dll musicmatch.dll MmSkBw

Seeks backward within the currently playing track in MusicMatch

MmSkipFw

//echo -a $dll(musicmatch.dll,MmSkipFw,.)
/dll musicmatch.dll MmSkipFw

Skips forward a few tracks in MusicMatch

MmSkipBw

//echo -a $dll(musicmatch.dll,MmSkipBw,.)
/dll musicmatch.dll MmSkipBw

Skips backward a few tracks in MusicMatch


DllInfo

//dll musicmatch.dll DllInfo

returns info about this dll


Questions? Comments?

SoulEata on AIM
Let me know what you think.

-Soul_Eater