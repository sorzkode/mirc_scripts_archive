/***************************************************/
/*       recycle.dll by da^hype (Shahir Reza Ali)  */
/* da-hype@hirc.org						           */
/* www.hirc.org									   */
/* Malaysian Made.                                 */
/***************************************************/

#pragma check_stack(off)
#pragma comment(linker,"/OPT:NOWIN98")
#pragma comment(lib,"Winmm.lib")
#include <windows.h>

// general constants
#define mFunc(x) int __stdcall x(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)


/*
 * Emptys the recycle bin
 * //dll recycle.dll EmptyBin Confirm OR //dll recycle.dll EmptyBin NoConfirm
 * $dll(recycle.dll,EmptyBin,Confirm) OR $dll(recycle.dll,EmptyBin,NoConfirm)
 */
mFunc(EmptyBin)
{
	if (!lstrcmpi(data,"NoConfirm"))
	{
		if (SHEmptyRecycleBin(NULL,NULL,SHERB_NOCONFIRMATION|SHERB_NOPROGRESSUI|SHERB_NOSOUND) == S_OK)
			strcpy(data,"S_OK");
		else
			strcpy(data,"ERROR");
		return 3;
	}
	if (!lstrcmpi(data,"Confirm"))
	{
		if (SHEmptyRecycleBin(NULL,NULL,NULL) == S_OK)
			strcpy(data,"S_OK");
		else
			strcpy(data,"ERROR");
		return 3;
	}
	strcpy(data,"ERROR");
	return 3;
}

/*
 * Returns number of items in the recycle bin
 * //dll recycle.dll BinItems c:
 * $dll(recycle.dll,BinItems,c:)
 */
mFunc(BinItems)
{
	SHQUERYRBINFO info;
	ZeroMemory((void*)&info,sizeof(SHQUERYRBINFO ));
	info.cbSize = sizeof(SHQUERYRBINFO );
	SHQueryRecycleBin(data,&info);
	wsprintf(data,"%d",info.i64NumItems);
	return 3;
}

/*
 * Returns size of items in the recycle bin (in bytes)
 * //dll recycle.dll BinSize c:
 * $dll(recycle.dll,BinSize,c:)
 */
mFunc(BinSize)
{
	SHQUERYRBINFO info;
	ZeroMemory((void*)&info,sizeof(SHQUERYRBINFO ));
	info.cbSize = sizeof(SHQUERYRBINFO );
	SHQueryRecycleBin(data,&info);
	wsprintf(data,"%d",info.i64Size);
	return 3;
}

/*
 * Dll Info dialog
 * $dll(recycle.dll,DllInfo,.)
 *
 */
int WINAPI DllInfo(HWND,HWND,char *data,char*,BOOL,BOOL)
{
	MessageBox(NULL, "Made by da^hype (Shahir Reza Ali). www.hirc.org", "Recycle Bin 1.0. Malaysian Made", MB_OK);
	return 0;
}

