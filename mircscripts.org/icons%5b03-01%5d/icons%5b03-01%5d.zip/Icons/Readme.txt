_________________________________________________________________________________________________________________________

- Title: 		Jynx Icons - Readme
- Created: 	2nd December 2003
- Author: 		Jynx

- Contact Me:	MSN:	jynx_scripter@msn.com
		ICQ:	196310847
		Server:	irc.digitalfuse.net:6667 #digitalfuse
_________________________________________________________________________________________________________________________

- Acknowledgements/Credits

- Creators of Microangelo Studio


- You are welcome to use these icons in your personal script, but if you do release... please leave this readme file intact, in your script directory!
_________________________________________________________________________________________________________________________

- If you require this icon pack in any other color, i can try and make them for you, contact me using the above details...
_________________________________________________________________________________________________________________________

- EOF 		***Best Viewed With Tahoma 8pt