fractal2 beta release.

First of all, before saying it lacks lots of things and else, you should know
that it is NOT finished. I'll be adding modules (you can download them from the
/module dialog) as soon as I get time. 

Sorry for bothering you all this time with the beta, and for not releasing it
when it was expected, but real life is more important than IRC, and I haven't
had a lot of time lately (and the little I got wasn't used to script).

If u like it, test it and report all the bugs and suggestions that comes to
your mind. If you don't like it, it's ok. Just give me constructive criticism, not useless
flames, thanks.

Send your mails to admin@tig0ti.org

- tig0ti.


