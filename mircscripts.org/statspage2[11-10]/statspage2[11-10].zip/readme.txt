*********************************************************************************************
Stats page script for mIRC - no ripping
[Config window and songplaying script by |CE, HTML Socket output by TheAvatar and Stats by Phoenix_the_II]
http://www.gouldby.demon.co.uk/scripts/
*********************************************************************************************

mircsripts.org version - Infofile2.0.exe not included - if you want to use that Winamp3 plugin
either download the plugin from somewhere else or get the version of this zip file with the
plugin from my scripts site: http://www.gouldby.demon.co.uk/scripts/


To load:
/load -rs socketscript.mrc

To access the config window right click some where in mIRC and goto Stats Page Config
Your settings are stored in statspagecfg.ini

If you don't use a dialup you will probably want to disable connection stats - this displays 
stats for a dialup networking connection - use network card stats

You can edit the script a bit to include stats of other stuff if you know how to, but don't delete
the last few lines of the html or I'll get pissed off

*********
Commands: 

/statspage - msgs to the channel a link to your stats page

***************
Files included:

socketscript.mrc - main script file
moo.dll - a version of moo.dll that displays gfx stats - if you choose to use your 
          own moo.dll you may have to disable gfx stats [a moo.dll IS neccesary]
InfoFile2.0.exe - winamp 3 plugin used to display the song playing stat on the stats page [optional]

*****
Tips:

If you use a firewall make sure it doesn't block the port specified on the config screen.
[default is 6000]

If you don't want to use the supplied moo.dll [it is the moo.dll used in abe2000's stats script], 
you will have to disable gfx info.

The song playing stat uses the winamp3 plugin infofile v2.0 - in preferences set the output text file 
as your mirc dir - playing.txt, once you have set this up set the variable as =%song and enable
my script on the advanced tab. Also if you want to be able to display the current song playing
in a channel then use my winamp3 script.

You can edit the preferences file directly - doing this will allow you to set different colours
not listed in the config window

If you need help or spot another bug msg |CE on quakenet

***********
Known bugs:

Colours can mess up sometimes

If you use identifiers or variables in a title or the aditional code box it will save it fine 
but when you load the config screen up again it will evaluate it and you will have to replace it 
with the identifier/variable again.

If when you type /statspage it only displays your IP address and no port goto config and set one

