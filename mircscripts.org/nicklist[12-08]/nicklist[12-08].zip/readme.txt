Current version: 0.5
Last version: 0.41

Changes:
0.5
- Working on a HTML Help.
- Added DColor function.
- Added Scroll function.
- Added TopIndex function.
- Fixed some small bugs.

0.41
- Fixed a bug which made cline return things like "proccess execution successful" when
  the given index was larger than the total amount of items in the nicklist.

0.4
- Fixed a bug which made nearly all functions return stupid (random) errors.
- Added Cline function.

0.3
- Added everything.

Usage:
	echo -s $dll(nicklist.dll,Function,Parameters)

	
	example:

	alias nldll {
		var %r = $dll(nicklist.dll,ListBox,$1-)
		if ($left(%r,4) != Done) {
			echo $color(info) -s %r
			return
		}
		if ($prop == ItemIndex) { return $gettok(%r,-1,32) }
		return %r
	}

Functions:

	1. ListBox
		Parameters: <HWND> aline <Text>
			or: <HWND> iline <Index> <Text>
			or: <HWND> dline <Index>
			or: <HWND> rsline <Index1> <Index2>
			or: <HWND> cline <Index> <Color>
			or: <HWND> dcolor <Color>
			or: <HWND> scroll <ScrollOptions> [Index]
			or: <HWND> TopIndex [Index]

			  : aline = add line  // nothing to say here.
			    iline = insert line  // ...
			    dline = delete line  // be careful! 
						    u won't find deleted lines in your recycle bin!
			    rsline = range select line  // :|
			    cline = color line  // u like colors?
			    dcolor = default color  // oh, i can finally write something useful:
						       dcolor will only set the default color for
						       the specified window.
			    scroll = scroll  // wow!	

			  : <HWND> is the handle of the window which contains the ListBox
			           Use $window(name).hwnd to receive the window handle.
			  : <Text> is a text. (That sounds crazy, doesn't it?)
			  : <Index> is the item index, which starts with 0!
			  : <Index1> and <Index2> are the start and end indices in a range selection.
			  : <Color> is a number (0-15) and stands for one of your mIRC colors (Ctrl+K)
			  : <ScrollOptions> can be +L, -L, +P, -P, =I.
			  	            - and + stand for up and down. 
					    L stands for line, P for page.
					    =I will scroll to [Index].
			  : The [Index] parameter in the TopIndex function is optional. If you set it
			    the index will be changed. If not, it won't change anything. Both will
			    return the (new) top index.

		Result: "Done." or "Done. New item index: <Index>"
		Failure: "Error: <Error>"
		Example: $dll(nicklist.dll,ListBox,$window($active).hwnd iline 0 Sometexthere)
		Hint: Added and inserted lines will always be white. You will need to change their
		      color with the cline function.