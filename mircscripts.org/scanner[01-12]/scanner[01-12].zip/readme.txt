;:. clone/ircop/away scanner v2.0
;:. SwEEt^M0uSSa on DALnet (#NDJ) (m0ussa@helpdesk.zaz.net)

- Loading
To load the file, simply type : /load -rs scanner.txt

- Usage
Check your channel's popups after loading it, and choose different types of scanning for the active channel
Just one thing, please make sure you CLOSE the dialog on each scan.

- Credits
GoldenGoblin : helped with some aliases
Probably: helped with some aliases as well ;)
DragonZap: helped with the icons thingy 

- Feedback
Please do not hesitate to send me all your suggestions and comments on this script at (m0ussa@helpdesk.zaz.net)
I'm always on DALnet in #NDJ 

More versions to come that's for sure, and I'll try to improve my scripting with the next versions ;)
Thank you all for downloading this script ;) Have fun!

- updates (v2.0)
added global ircop scan
added yes.ico/no.ico instead of yes/no text
rewrited some aliases

M0uSSa