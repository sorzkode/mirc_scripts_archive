////////////////////////////////////////////////////////////////////////////////////////////
// nLINKn 1.0 - a DLL for creating, resolving and editing shell links (shortcuts)
////////////////////////////////////////////////////////////////////////////////////////////

//the WIN32_LEAN_AND_MEAN macro excludes rarely used stuff from <windows.h>, such as
//Korean language support, making compilation faster

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

//these are pointers to the IShellLink and IPersistFile interfaces
//implemented by the CLSID_ShellLink system object
//we include <shlobj.h> because IShellLink and IPersistFile are declared there

#include <shlobj.h>
IShellLink *psl;
IPersistFile *ppf;

//this macro helps us return values to mIRC
//instead of writing
//		lstrcpy(data,"S_OK");
//		return 3;		
//we will be able to use
//		ret("S_OK");

#define ret(x) { lstrcpy(data,x); return 3; }

//the entry point of the DLL

extern "C" int WINAPI _DllMainCRTStartup(HANDLE,DWORD,void*) { return 1; }

//since in the Options we have disabled the C run-time library,
//we must write the "atol" function ourselves (it converts character strings into numbers)

int atol(char *p)
{
	int result = 0, sign = 1;
	if (*p == '-') { sign = -1; p++; }
	while (*p >= '0' && *p <= '9') { result *= 10; result += (*p++ - '0'); }
	return result * sign;
}

extern "C"
{
	//this function is called by mIRC after it loads the DLL
	//we perform all the initialization here, which includes:
	//		1. CoInitialize - initializes the Component Object Library
	//		2. CoCreateInstace - creates the CLSID_ShellLink system object as an in-process server,
	//			and gets a pointer to its IShellLink interface
	//		3. QueryInterface - gets a pointer to the IPersistFile interface
	
	void WINAPI LoadDll(void*)
	{
		CoInitialize(0);
		CoCreateInstance(CLSID_ShellLink,0,CLSCTX_INPROC_SERVER,IID_IShellLink,(void**)&psl);
		psl->QueryInterface(IID_IPersistFile,(void**)&ppf); 
	}
	
	//this function is called by mIRC when it wants to unload the DLL
	//if "timeout" is not 0, we can return 0 to stay loaded,
	//otherwise we release the interface pointers and shutdown COM
	
	int WINAPI UnloadDll(int timeout)
	{
		if (!timeout) { ppf->Release(); psl->Release(); CoUninitialize(); }
		return 0;
	}
	
	//this function returns information about the DLL and its author
	//it is ABSOLUTELY necessary ;-)
	
	int WINAPI version(HWND,HWND,char *data,char*,BOOL,BOOL)
	{
		ret("nLINKn 1.0 by Necroman, http://necroman.wot.net, necroman@europe.com, #mIRC @ Undernet");
	}
	
	//this function converts the filename into Unicode and calls IPersistFile::Save
	
	int WINAPI save(HWND,HWND,char *data,char*,BOOL,BOOL)
	{
		WCHAR filename[MAX_PATH]; MultiByteToWideChar(CP_ACP,0,data,-1,filename,MAX_PATH); 
		ret(FAILED(ppf->Save(filename,TRUE)) ? "E_FAILED" : "S_OK");
	}
	
	//this function converts the filename into Unicode and calls IPersistFile::Load
	
	int WINAPI load(HWND,HWND,char *data,char*,BOOL,BOOL)
	{
		WCHAR filename[MAX_PATH]; MultiByteToWideChar(CP_ACP,0,data,-1,filename,MAX_PATH); 
		ret(FAILED(ppf->Load(filename,STGM_READ)) ? "E_FAILED" : "S_OK"); 
	}
	
	//this function passes to IPersistFile::Resolve the maximum number of milliseconds
	//allowed to resolve the link
	
	int WINAPI resolve(HWND,HWND,char *data,char*,BOOL,BOOL)
	{
		ret(FAILED(psl->Resolve(0,((atol(data) * 1000) << 16) | SLR_NO_UI)) ? "E_FAILED" : "S_OK"); 
	}
	
	//this function obtains the path to one of the system special folders
	
	//the SHGetSpecialFolderLocation function returns PIDL -
	//the pointer to a list of identifiers in the system namespace
	
	//the SHGetPathFromIDList converts the PIDL into a string
	//the PIDL is freed with IShellMalloc::Free
	
	int WINAPI specdir(HWND,HWND,char *data,char*,BOOL,BOOL)
	{
		int folder = atol(data);
		lstrcpy(data,"E_FAILED");	//assume failure
		
		if (folder == -1) { GetWindowsDirectory(data,MAX_PATH); return 3; }
		if (folder == -2) { GetSystemDirectory(data,MAX_PATH); return 3; }
		
		LPITEMIDLIST pidl;
		LPMALLOC pShellMalloc;
		
		if(SUCCEEDED(SHGetMalloc(&pShellMalloc)))
		{
			if(SUCCEEDED(SHGetSpecialFolderLocation(0,folder,&pidl)))
			{
				SHGetPathFromIDList(pidl,data);
				pShellMalloc->Free(pidl);
			}
			pShellMalloc->Release();
		}
		return 3;
	}
	
	//this function reads a field in the shortcut in memory
	//it interprets the first word as the name of the field to read
	//then it calls one of the IShellLink methods
	
	int WINAPI get(HWND,HWND,char *data,char*,BOOL,BOOL)
	{
		HRESULT hres;
		WIN32_FIND_DATA pfd;
		WORD key;
		int show;
		char path[MAX_PATH];
		
		switch(*data)
		{
		case 'l':	//label
			hres = psl->GetDescription(data,MAX_PATH); break;
		case 'p':	//path
			hres = psl->GetPath(data,MAX_PATH,&pfd,SLGP_UNCPRIORITY); break;
		case 'a':	//arguments
			hres = psl->GetArguments(data,MAX_PATH); break;
		case 'd':	//directory
			hres = psl->GetWorkingDirectory(data,MAX_PATH); break;
		case 's':	//show
			wsprintf(data,FAILED(psl->GetShowCmd(&show)) ? "E_FAILED" : "%d", show); return 3;
		case 'i':	//icon
			wsprintf(data,FAILED(psl->GetIconLocation(path,MAX_PATH,&show)) ? "E_FAILED" : "%d %s",show,path);
			return 3;
		case 'k':	//key
			wsprintf(data,FAILED(psl->GetHotkey(&key)) ? "E_FAILED" : "%d",key); return 3;
		default:
			ret("E_UNKNOWN_FIELD");
		}
		if (FAILED(hres)) lstrcpy(data,"E_FAILED");
		return 3;
	}
	
	//this function overwrites information in a field of a shortcut in memory
	//it interprets the first word as the name of the field to change,
	//passing the rest of the string to one of the IShellLink methods
	
	int WINAPI set(HWND,HWND,char *data,char*,BOOL,BOOL)
	{
		HRESULT hres;
		int icon;
		char *p = data;
		while (*p && *p != ' ') p++; while (*p == ' ') p++; //skip field
		
		switch(*data)
		{
		case 'l': hres = psl->SetDescription(p);		break;
		case 'k': hres = psl->SetHotkey(atol(p));		break;
		case 'p': hres = psl->SetPath(p);				break;
		case 's': hres = psl->SetShowCmd(atol(p));		break;
		case 'a': hres = psl->SetArguments(p);			break;
		case 'd': hres = psl->SetWorkingDirectory(p);	break;
		case 'i': 
			icon = atol(p);
			while (*p >= '0' && *p <= '9') p++; while (*p == ' ') p++; //skip number
			hres = psl->SetIconLocation(p,icon); break;
		default:
			ret("E_UNKNOWN_FIELD");
		}
		ret(FAILED(hres) ? "E_FAILED" : "S_OK");
	}
}