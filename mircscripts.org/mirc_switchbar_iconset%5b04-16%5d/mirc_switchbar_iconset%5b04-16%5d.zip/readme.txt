mirc switchbar icon set
by yAmi
email: yAmi@scrapinc.com
web: www.scrapinc.com

tools used: Microangelo Icon Studio

Copyright:
All of these icons were created by j. sp. (aka yAmi) of www.scrapinc.com
The icons are freeware for PERSONAL USE only.
If you want to use them in your software applications, please drop me an e-mail with the details and the URL.