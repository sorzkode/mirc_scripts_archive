Beware of Dog: Secure Query 1.18 by krazy :: Coded using mIRC 6.17
CONTACT
---
network: irc.rizon.net
channel: #help

Report any errors or bugs there please ( I will be under alias krazy or turk).
----

Installation:
-----------------------------
	To load the script, place the file "squery.mrc" in your mIRC directory
	(Default C:\Program Files\mIRC\) Once "squery.mrc" is in your mIRC directory, 
	load up mIRC(if currently not running) and type /load -rs squery.mrc If it asks you
	to execute On Load commands, click yes.


Update:
-----------------------------
	Use this command to keep your old settings: /reload -rs squery.mrc


Usage:
-----------------------------
	You can right click a persons name, go under "Secure Query", and allow
	their query(if they are messaging you), decline their query(if they are 
	messaging you), add/remove them to/from your 'white list'.

	When someone messages you, their messages will appear in a window called @messages in the following
	syntax:
	[00:00:00] [NickName]: <message>

	check the window regularly for new messages.


Commands:
-----------------------------
	/squery: Opens the dialog.
	/kAllow: allows the requested query from a certain user. Syntax: /kallow nickname
	/kDecline: declines the requested query from a certain user. Syntax: Syntax: /kDecline nickname
	/kAlwaysAllow: permanently allows this user to msg you without need for accepting(adds to white list). Syntax: /kAlwaysAllow nickname
	/kRemoveAllow: removes a user from the white list. Syntax: /kRemoveAllow nickname
	/blockall: blocks all queries
	/unblockall: unblocks all queries
	/bodactivate: activates the script
	/boddeactivate: deactivates the script
	(all these commands can be executed from the dialog so you shouldn't need to use
	these, I just listed them here so the user may know what they are)

Credits
-----------------------------
krazy - coder
Hera - someone that pushed me to make this. :P
zack^ - suggestions
Nickolay - bug testing