SystemIdle.dll 1.0 by FoLKeN^

Update!! 1/19/05

Added SystemIdle9x.dll, which works on any windows version (+9x)
The reason why I didnt update the existing dll is because 9x version needs to keep loaded in memory to work. And is +500 bytes. The documentation below is the same for both dlls.

Description: A dll that returns your system idle time, (NOT MIRC $idle!!!!) - useful if you want to script, for example, an auto-away using system idle and not mirc idle. 

Differencing from mirc idle, system idle resets when you press a key, or move/press your mouse on any window. Its used, for example, to count the time until show screensaver...

Enjoy it ;)

Usage:

		$dll(SystemIdle.dll,GetIdleTime,.)


Returns:
		The system idle time in milliseconds


Example code:

alias sidle {
 return $dll(SystemIdle.dll,GetIdleTime,.)
}

alias test_idle {
 .timeridle 0 1 echo -a The system idle is... $!sidle - Don't move your mouse or press a key or you will reset it!!
}
