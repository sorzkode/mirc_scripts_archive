
//SystemIdle 1.0 Dll for Windows 98 and lower - by FoLKeN^

//Enjoy

#include <windows.h>
#include <crtdbg.h>

#pragma data_seg(".SystemIdle")
HHOOK 	keyb_hook = NULL;
HHOOK 	mouse_hook = NULL;
DWORD	lastTick = 0;
LONG	mouseX = -1;
LONG	mouseY = -1;
#pragma data_seg()
#pragma comment(linker, "/section:.SystemIdle,rws")

typedef struct	
{
	DWORD  mVersion;
	HWND   mHwnd;
	BOOL   mKeep;
} LOADINFO;

HINSTANCE hInstance = NULL;

__declspec(dllexport) DWORD SystemIdleGetLastTickCount()
{
	return lastTick;
}
LRESULT CALLBACK kbHookProc(int code, WPARAM wParam, LPARAM lParam)
{
	if (code==HC_ACTION) {
		lastTick = GetTickCount();
	}
	return ::CallNextHookEx(keyb_hook, code, wParam, lParam);
}

LRESULT CALLBACK mouseHookProc(int code, WPARAM wParam, LPARAM lParam)
{
	if (code==HC_ACTION) {
		MOUSEHOOKSTRUCT* pStruct = (MOUSEHOOKSTRUCT*)lParam;
		if (pStruct->pt.x != mouseX || pStruct->pt.y != mouseY)
		{
			mouseX = pStruct->pt.x;
			mouseY = pStruct->pt.y;
			lastTick = GetTickCount();
		}
	}
	return ::CallNextHookEx(mouse_hook, code, wParam, lParam);
}

__declspec(dllexport) BOOL SystemIdleInit()
{
	if (keyb_hook == NULL) {
		keyb_hook = SetWindowsHookEx(WH_KEYBOARD, kbHookProc, hInstance, 0);
	}
	if (mouse_hook == NULL) {
		mouse_hook = SetWindowsHookEx(WH_MOUSE, mouseHookProc, hInstance, 0);
	}

	_ASSERT(keyb_hook);
	_ASSERT(mouse_hook);

	lastTick = GetTickCount(); // init count

	if (!keyb_hook || !mouse_hook)
		return FALSE;
	else
		return TRUE;
}
__declspec(dllexport) void SystemIdleTerm()
{
	BOOL bResult;
	if (keyb_hook)
	{
		bResult = UnhookWindowsHookEx(keyb_hook);
		_ASSERT(bResult);
		keyb_hook = NULL;
	}
	if (mouse_hook)
	{
		bResult = UnhookWindowsHookEx(mouse_hook);
		_ASSERT(bResult);
		mouse_hook = NULL;
	}
}

int WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	switch(dwReason) {
		case DLL_PROCESS_ATTACH:
			DisableThreadLibraryCalls(hInstance);
			hInstance = hInstance;
			break;
		case DLL_PROCESS_DETACH:
			SystemIdleTerm();
			break;
	}
	return TRUE;
}
extern "C" BOOL __stdcall _DllMainCRTStartup( HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved) {
    return DllMain( hinstDLL, fdwReason, lpvReserved );
}
extern "C"
{
	int WINAPI GetIdleTime(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)
	{
		wsprintf(data,"%d",GetTickCount() - SystemIdleGetLastTickCount());
		return 3;
	}
	void WINAPI LoadDll(LOADINFO *li)
	{
		SystemIdleInit();
	}
	
	int WINAPI UnloadDll(int timeout)
	{
		SystemIdleTerm();
		return 0;
	}
}
