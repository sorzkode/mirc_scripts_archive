

#define _WIN32_WINNT 0x0500
#include <windows.h>

extern "C" int WINAPI _DllMainCRTStartup(HANDLE,DWORD,void*) { return 1; }

DWORD GetLastInputTime(void)
{
	LASTINPUTINFO li;
	li.cbSize = sizeof(LASTINPUTINFO);
	GetLastInputInfo(&li);
	DWORD liTime = li.dwTime;
	return liTime;
}

extern "C"
{
	int WINAPI GetIdleTime(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)
	{
		DWORD totalTime = GetTickCount();
		DWORD lastInputTime = GetLastInputTime();
		DWORD idleTime = totalTime - lastInputTime;
		wsprintf(data,"%d",idleTime);
		return 3;
	}
	int WINAPI Version(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)
	{
		lstrcpy(data,"SystemIdle.dll 1.0 by FoLKeN^ - Contact: warufolken@hotmail.com");
		return 3;
	}
}