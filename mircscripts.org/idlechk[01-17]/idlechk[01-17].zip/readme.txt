idlechk.mrc v0.1a by Azra (togallan@hotmail.com)

====================
install notes:
====================

unzip, /load -rs drive:\path\idlechk.mrc or
//load -rs $sfile($mircdir) and browse and select the file.

*** ONLY WORKS WITH MIRC V6.03... ***

====================
usage:
====================
right click channel, Idle Check, than pick your user class
than the idle time.

NOTE: this addons works better the longer you are on the channel.


====================
changes:
====================
v0.1a : autocolor all idle nicks.
v0.1  : [x] dbl click user kicks user from channel.
v0.0  : original.
