Online Translator v1.4 for mIRC 6.03
------------------------------------
Installation:
 * Unzip the file (Babylon.zip) to your mIRC dir.
   The files should be extracted to a new folder (example: C:\mIRC\Babylon)
 * Run mIRC and type in the command line '/load -rs Babylon\bab.mrc'
 * If the 'Script Warning' dialog opens, click the OK button.

Using the addon:
 * You can open the dialog by typing '/bab' in the commmand line or through the menubar.
 * You can also type '/bab [word]' to translate a word instantly.
 * You can change the translation language in the dialog or through the menubar.
 * In the menubar you will find hotlink trigger options. This enables you to translate
   easily words in your mIRC windows, by holding the shift/ctrl key and double-clicking
   the word with the mouse.

Version History:
 * 1.0 - First public release.
 * 1.1 - Several bugs fixed: dialog and socket errors.
 * 1.2 - Added icons in the language choosing combo and in the statusbar.
       - Replaced the translation editbox with a combo, which saves the 10 recent words.
       - Some minor bugs fixed.
 * 1.3 - Replaced aliases to local.
       - Not really my work: babylon.com updated their data base.
       - If no results are founded, it searches for more results.
       - It is now possible to cancel a translation.
       - Little display bugs fixed.
 * 1.4 - Changed main dialog a bit.
       - Added a little about dialog.
       - No need for DMU.dll anymore.
       - Updated icons.

Known bugs:
 * MDX's ComboBoxEx allows you to enter a limited number of characters according to its
   length. Until DragonZap fixes this problem, you can enlarge the dialog so the combo will
   be able to handle a larger number of characters.
 * Every once in a while connection fails ('Connection closed.' in the statusbar) for some reason.
   I don't know what is the source of the problem, but I'm working on it.

Author:
 Nicknames: ^BeAsT^, Melkor
 Channels:  #COME on Macron (infinity.macron.co.il)
 Contact:   Talk to me in the channel, or send private message.

Thanks:
 * http://www.babylon.com/ - The translations data base
 * Khaled Mardam-Bey (khaled@mirc.com) - Created mIRC
 * DragonZap (dragonzap1@aol.com) - Created MDX.dll
 * Soul_Eater (souleata@beer.com) - Created DMU.dll
 * Necroman - Created nHTMLn_2.92.dll