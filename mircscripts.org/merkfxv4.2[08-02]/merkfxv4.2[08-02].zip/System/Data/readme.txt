merkFX v4.2
Written by [AFX]
www.merkFXscript.tk
Readme file

[INSTALLATION]

-requires mirc 6.15+
-extract all the files in the zip to a directory (preferably C:\merkFX)
-copy mIRC.exe to the directory where you extracted the files
-run mIRC.exe, and then set up the script



[CONTACTING]

-you can find me on PTnet as [AFX] in #SCT.
-drop me a line at somebodysomeone__@hotmail.com
-visit the web board from the website
-add me to MSN if it is about the script, and not for script help



[CREDITS/ACKNOWLEDGMENTS]

DLL authors for:

-MDX, Popups
-kTools
-mircustom, mUnzip
-KMB
-mOTFv3
-RebaR
-nHTMLn

-Khaled for mIRC
-Morphy for snippets, help when needed
-mIRCscripts.org, best scripting site ever
-[Fe|ix] for mIRC icon
-Kamek for KTE, it rules
-Nodren for help fixing KTE for 6.15
-^BeAsT^ for /download snippet
-beta testers/supporters
-peppie for the quicker sub_mod alias
-xhaker. need i say more? he's so fucken smart, he helped me correct some things in my script, including some /scon/scid crap. thanks man
-you, for using the script :)



[VERSION HISTORY]

4.2:

-fixed the switchbar arrow button not showing the right popup (my bad, i had 2 aliased called the same thing)
-made an option on the notify list where you can make it appear on connect
-fixed the scon/scid crap on toolbar/switchbar thanks to xhaker
-improved channel statstistics/log viewer/seen system/email sender/more modules (find them in the module update thing)
-added Urban Dictionary module 
-editted the toolbar box thing
-improved sub_mod alias thanks to peppie
-changed the first-time startup image


4.1:

-changed my author picture
-improved auto away
-added an option to select your own MP3 buttons. To use your own, you must create an .icl in the same order as the MP3 icons included. 
 Save it, then copy it in the System\Icons\MP3 directory. Load the Setup dialog and in the MP3 Settings, it should appear in the combo box
-added new module, Nick Mentions. Useful if someone calls you on a different network (imo, I use it and I find it useful)
-improved module downloading, if there is a newer version of the module, merkFX will download it and replace the old module
-fixed the toolbar bugs and switchbar bugs when you first extract the script
-added fserve support on switchbar (for when you serve someone. if you are being served, it will show up as a DCC chat, so don't be confused,
 that is how mIRC runs it)
-updated help file a little bit
-updated the mp3 players' (both) stop functions, now it doesn't display 2/2 or 2 when both are opened and you press stop on one of them
-made the MP3FX positions to top and bottom of the switchbar (find this on the menu on the MP3FX)
-updated the switchbar, now you can click on an active window button and it will minimize and go to the next window


4:

-redid away system
-completed auto away
-added nick completor
-added icon package downloader
-deleted icon packages, you can download them using the downloader
-fixed some bugs around everywhere as well as improved things
-new icon package: BeOS
-fixed MP3 player/MP3FX
-other stuff, can't quite rememeber :P

3.4:

-completed MP3FX, very simple to use
-redid readme file
-redid help file
-fixed various bugs
-editted tips file, removed some things and added new ones
-removed some themes, trying to stick to Tahoma-based themes, or other cool looking fonts like bright
-removed manifest checking

3.3:

-fixed KTE bug for 6.15 
-fixed MP3 player bugs 
-MP3 player now uses /filter -k to load the playlist 
-Continue function added for MP3 Player 
-speed (setup is alot faster than before) 
-$input error on E-mail Sender 
-sidebar issues (network listing) 
-toolbar icon errors 
-lagbar issues 


3.2:

-updated script so it works with mIRC versions 6.03 and up :D 
-changed the look of the MP3 Player 
-added a connections list to the Notify List (docked) 
-fixed some code that I noticed that returned errors 
-kept kTools.dll. Why? Because whoever is using 6.03, the Statusbar is still available. Also  needed it to count icons. 
-added more themes I think 
-now using $scriptdir instead of $mircdir 
-edited the First-time use dialog 
 

3.1:

-fixed the Switchbar Editor, one of the functions in v3 wasn't working right due to a typo (?), so I released this version to clear it up 


3:

-added new icon package: QNX2 
-completed Module Downloader. When new modules are created, you can now download them and use them inside the script 
-updated update process for the last time, it just wasn't working correctly before (poor execution and checking/downloading) 
-redid "About" dialog 
-ridded of the popups for channel/query/status/nicklist with popups.dll and went back to the old school popups style 
-improved speed when switching through windows, now it doesn't refresh the window or toolbar anymore like it used to 
-just screwed around with the Setup menu 
-added switchbar editor, now the look of the bar is customizable  
-redid the loading bar 

  
2.2:

-fixed update patterns again 
-working on a module downloader 
-added Lyrics Searcher (beta), E-mail Sender, and Memo Sender modules 
-made the last cell in the Statusbar customizable, even its' style (flat, popped out, regular) 
-added new icon package: BlockOS 
-added more MTS themes 
-re-designed KTE dialog 
-added more to the toolbar 
-added a DCC Transfers to the Download Manager module 
-added a Notify List that can be docked to the right of the screen in a Treeview style, as well as redid the old notify list 
-added Titlebar Editor 
-added a User Tips dialog 
-cleaned up some popups and changed their design 
-made it so when you kill the menubar, the modules button on the toolbar shows an arrow so you can access your modules 
-added a web bar and a lag bar to the toolbar. You can enable this via Toolbar Functions menu on the left of the toolbar. Lag is calculated on active server every 10 seconds 
-redid the introduction when you first load the script ever. It shows a few things about merkFX, tells you about the script, etc 
-fixed sound events 
-added a small fix for the nasty DCC exploit (just blocks DCC sends temporarily) 

  
2.1:

-New MP3 player module. You can add directories finally. Working on selecting multiple files via DLL. 


2.0:

-reworked the whole help file, now done in HTML. 
-reworked readme file, now done in HTML. 
-added XP schemes for toolbar and switchbar. 
-fixed auto joins' password error, was adding the channel 2 times, one without a pass and one with a pass. 
-made the away log + page viewer with their own viewers, now each opens up as a @window where you can view your messages, including clearing them as well. 
-icon packages: Orange (I don't know if I'll keep this set, it's big in size) and QNX. 
-updated the auto-update code, so you don't have to re-download the new version (so you don't have to reset your settings over again; only the files that are updated are downloaded). 
-added a new function: Shitlist. Read the Help File on how it works. 
-added feature to show the drop-down menus in the toolbar or not 
-added version reply changer. Read the Help File on how it works. 
-update the Seen System module: now you have the option to Log Seen Events, this meaning that when the module picks up join/part/nick change/quit events, it won't save them to the  Seen.ini file.


1.4:

-updated auto update feature for script updates: dosen't redownload a whole new version, just the updates now
-fixed Auto join setup: when being asked for a pass for a channel, it would add the channel twice after adding it instead of just once
-working on auto away crap (ZzZz...)


1.3: 

-added sounds setup
-added away pager sound
-added new auto update feature
-working on auto away crap
-small bug fixes all around the script

1.2.2:

-editted script engine: now all of the tools are in .mfx format. Script is now modular, total of 10 modules now
-editted switchbar: got rid of combo box, added arrow w/ popup
-created NET color for switchbar
-Alot of other small things...


1.2:
 
-added more tools
-added a function on the toolbar: has a small arrow that preforms small functions (Lag, www, search)
-added statusbar
-added switchbar functions
  

1.1:
 
-added Custom CTCP's, function key bindings, quit messages editor, quotes 
database, display stuff, toolbar editor, MP3 stuff, help file, connection manager
download manager, domain whois, language translator, log viewer, notes, 
servers list, Kameks' Theme Engine (KTE), new switchbar, more icons,
custom popups and query blocker
-got rid of custom nicklist, flat scrollbars, alot of other things that were in merkFX v1.0


1.0:

-first initial release, very small, scripted in 3 hrs


EOF