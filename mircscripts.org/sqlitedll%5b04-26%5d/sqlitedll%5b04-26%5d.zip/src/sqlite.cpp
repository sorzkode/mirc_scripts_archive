/*
** 2004 April 26
**
** The author disclaims copyright to this source code.  In place of
** a legal notice, here is a blessing:
**
**    May you do good and not evil.
**    May you find forgiveness for yourself and forgive others.
**    May you share freely, never taking more than you give.
**
*************************************************************************
** This is the header file for the dll wrapper of SQLite used in mIRC.
*/
#undef UNICODE
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#define __VALIST_BP
#include "sqlite.h"
#include "hash.h"

#define MAXSTRINGLEN	900
#define FUNCPARMS		HWND mWnd,HWND aWnd,char* data,char* parms,BOOL show,BOOL nopause
#define VERSION			"0.5.3"
#define VERSION_L		"mIRC SQLite " VERSION " (SQLite " SQLITE_VERSION ") by Klops"
#define DllExport		extern "C" __declspec(dllexport)
#define MircFunc		extern "C" __declspec(dllexport) int __stdcall
#define WM_EVALUATE	((WM_USER) + 201)

#define RET_HALT  0
#define RET_NULL  1
#define RET_EVAL  2
#define RET_VALUE 3

#define ret(parms)        { lstrcpy(data,parms); return 3; }

typedef struct
{
	DWORD mVersion;
	HWND mHwnd;
	BOOL mKeep;
} LOADINFO;

typedef struct LABEL
{
	sqlite			*db;
	/* Allocated By SQLite Library
	 * Free with sqlite_free_table()
	 */
	int				rows_affected;
	int				row_count;
	int				field_count;
	char			**data;
} LABEL;

Hash			labels[1];
char            tempMem[4096];

DWORD           mVersion;				//mIRC's Version
HWND			mWnd;					//mIRC main window

///////////////////////////////
// Error Number to To Definition Name
//////////
const char *sqlite_error_name[] =
{
	"OK",
	"ERROR",
	"INTERNAL",
	"PERM",
	"ABORT",
	"BUSY",
	"LOCKED",
	"NOMEM",
	"READONLY",
	"INTERRUPT",
	"IOERR",
	"CORRUPT",
	"NOTFOUND",
	"FULL",
	"CANTOPEN",
	"PROTOCOL",
	"EMPTY",
	"SCHEMA",
	"TOOBIG",
	"CONSTRAINT",
	"MISMATCH",
	"MISUSE",
	"NOLFS",
	"AUTH",
	"FORMAT",
	"RANGE",
	"ROW",
	"DONE",
};

///////////////////////////////
// Ascii to Integer Conversion
//////////
int _atol(register char* p)
{
	register int n = 0;
	int r=1;
	if (*p == '-')
	{
		p++;
		r=-1;
	}
	else if (*p == '+')
		p++;
	while ('0' <= *p && *p <= '9')
	{
		n *= 10;
		n += (*p++ - '0');
	}
	return n*r;
}

///////////////////////////////
// Get the next word delmited by <c>
//////////

char* _getword(register char*&p,register int c = ' ')
{
	if (!p)
		return NULL;
	while (*p == c)
		p++;
	char *r=p;
	while (*p && (*p != c))
		p++;
	if (*p) {
		*p++ = 0;
		while (*p == c)
			p++;
	}
	return r;
}

///////////////////////////////
// Find a Field Id By Name
//////////
int fieldid_by_name(LABEL *lbl,char *field)
{
	int i,isnull;
	if (!field)
		return -1;
	isnull=lstrcmpi(field,"NULL");
	for (i=0; i < lbl->field_count; i++)
	{
		if (lbl->data[i] == 0)
		{
			if (!isnull)
				return i;
		}
		else if (field[0] == lbl->data[i][0] && !lstrcmpi(field,lbl->data[i]))
			return i;
	}
	return -1;
}

///////////////////////////////
// Load the Dll
//////////
DllExport void __stdcall LoadDll(LOADINFO* l)
{
	l->mKeep = TRUE; // we _must_ stay loaded

	// Create the main Hash that stores our Database Information
	sqliteHashInit(labels,SQLITE_HASH_STRING,1);

	mWnd = l->mHwnd;
	mVersion = l->mVersion;
}

///////////////////////////////
// Unload the Dll
//////////
DllExport int __stdcall UnloadDll(int m)
{
	if (!m)
	{
		HashElem *temp;
		LABEL    *lbl;
		// Clear all the memory in the hash and close open databases...
		for (temp=sqliteHashFirst(labels); temp; temp=sqliteHashNext(temp))
		{
			lbl = (LABEL*)sqliteHashData(temp);
			if (lbl->db)
				sqlite_close(lbl->db);
			// Remember lbl->data is just an offset of field_data
			// So we dont need to free it...
			if (lbl->data)
				sqlite_free_table(lbl->data);
			delete lbl;
		}
		// Clear that hash~
		sqliteHashClear(labels);
	}
	return 0; // don't unload me you bastard!
}
MircFunc DllInfo(FUNCPARMS) ret(VERSION_L)

///////////////////////////////
// Open a Database
//////////
MircFunc Open(FUNCPARMS)
{
	char *tmp = data, *err, *label = _getword(tmp), *fname = _getword(tmp);
	int   len = lstrlen(label);
	void *temp;
	LABEL *lbl = NULL;

	if (!*label || !*fname)
	{
		lstrcpy(data,"E_INVALID_ARGUMENTS");
		return 3;
	}
	lbl = (LABEL*)sqliteHashFind(labels,label,len);
	if (lbl)
	{
		lstrcpy(tempMem,label);
		wsprintf(data,"E_LABEL_IN_USE %s",tempMem);
		return 3;
	}
	lbl = new LABEL();
	lbl->db = sqlite_open(fname,0,&err);
	if (!lbl->db)
	{
		delete lbl;
		wsprintf(data,"E_SQLITE_ERROR %s",err);
		sqlite_freemem(err);
		return 3;
	}
	lbl->data = NULL;
	temp = sqliteHashInsert(labels,label,len,lbl);

	lstrcpy(data,"S_OK");
	return RET_VALUE;
}

///////////////////////////////
// Return Rows that Were Affected
//////////
MircFunc RowsAffected(FUNCPARMS)
{
	char *tmp=data, *label=_getword(tmp);
	LABEL *lbl;

	if (!*label)
	{
		lstrcpy(data,"E_INVALID_ARGUMENTS");
		return RET_VALUE;
	}

	lbl = (LABEL*)sqliteHashFind(labels,label,lstrlen(label));
	if (lbl == NULL)
	{
		lstrcpy(tempMem,label);
		wsprintf(data,"E_INVALID_LABEL %s",tempMem);
	}
	else
		wsprintf(data,"S_OK %d",lbl->rows_affected);
	return RET_VALUE;
}

///////////////////////////////
// Return Row count that Were Returned
//////////
MircFunc Rows(FUNCPARMS)
{
	char *tmp=data, *_label = _getword(tmp);
	LABEL *label;
	if (!*_label)
	{
		lstrcpy(data,"E_INVALID_ARGUMENTS");
		return RET_VALUE;
	}
	label = (LABEL*)sqliteHashFind(labels,_label,lstrlen(_label));
	if (label == NULL)
	{
		lstrcpy(tempMem,_label);
		wsprintf(data,"E_INVALID_LABEL %s",tempMem);
		return RET_VALUE;
	}
	wsprintf(data,"S_OK %d",label->row_count);
	return RET_VALUE;
}

///////////////////////////////
// Return the Fields
//////////
MircFunc Fields(FUNCPARMS)
{
	char *tmp=data, *_label = _getword(tmp), *_sep=_getword(tmp), *sep, **dr;
	int i;
	LABEL *label;
	sep=tempMem;
	if (!*_sep)
		sep = "\t";
	else
	{
		if (*_sep == '"')
			_sep++;
		if (*_sep == '\'')
			_sep++;

		if ('0' <= *_sep && *_sep <= '9')
		{
			sep[0] = _atol(_sep);
			sep[1] = 0;
		}
		else
			sep = _sep;
		/* You Cannot use character 0 as the separator */
		if (*sep == 0)
			*sep = '\t';
	}

	if (!*_label)
	{
		lstrcpy(data,"E_INVALID_ARGUMENTS");
		return RET_VALUE;
	}
	label = (LABEL*)sqliteHashFind(labels,_label,lstrlen(_label));
	if (label == NULL)
	{
		lstrcpy(tempMem,_label);
		wsprintf(data,"E_INVALID_LABEL %s",tempMem);
		return RET_VALUE;
	}
	dr = label->data;
	if (label->row_count > 0)
	{
		wsprintf(data,"S_OK %s",(dr[0]?dr[0]:"NULL"));
		for (i=1; i < label->field_count; i++)
			wsprintf(data,"%s%s%s",data,sep,(dr[i]?dr[i]:"NULL"));
	}
	else
		lstrcpy(data,"S_OK");
	
	return RET_VALUE;
}

///////////////////////////////
// Fetch a Row of Results
//////////
MircFunc FetchRow(FUNCPARMS)
{
	char *tmp=data, *_label = _getword(tmp), *_row=_getword(tmp), *_sep=_getword(tmp), *sep;
	sep=tempMem;
	if (!*_sep)
		sep = "\t";
	else
	{
		if (*_sep == '"')
			_sep++;
		if (*_sep == '\'')
			_sep++;

		if ('0' <= *_sep && *_sep <= '9')
		{
			sep[0] = _atol(_sep);
			sep[1] = 0;
		}
		else
			sep = _sep;
		/* You Cannot use character 0 as the separator */
		if (*sep == 0)
			*sep = '\t';
	}

	int i,row;
	char **dr;
	LABEL *label;

	if (!*_label || !*_row)
	{
		lstrcpy(data,"E_INVALID_ARGUMENTS");
		return RET_VALUE;
	}

	label = (LABEL*)sqliteHashFind(labels,_label,lstrlen(_label));
	if (label == NULL)
	{
		lstrcpy(tempMem,_label);
		wsprintf(data,"E_INVALID_LABEL %s",tempMem);
		return RET_VALUE;
	}

	row = _atol(_row);
	if (row == 0)
	{
		wsprintf(data,"S_OK %d",label->row_count);
		return RET_VALUE;
	}
	if (row < 0 || row > label->row_count)
	{
		lstrcpy(tempMem,_row);
		wsprintf(data,"E_INVALID_ROW %s",tempMem);
		return RET_VALUE;
	}
	dr = label->data + ((row * label->field_count));

	if (label->field_count > 0)
	{
		wsprintf(data,"S_OK %s",(dr[0]?dr[0]:"NULL"));
		for (i=1; i < label->field_count; i++)
			wsprintf(data,"%s%s%s",data,sep,(dr[i]?dr[i]:"NULL"));
	}
	else
		lstrcpy(data,"S_OK");

	return RET_VALUE;
}


///////////////////////////////
// Fetch does what FetchRow and Fields does, plus more...
//////////
MircFunc Fetch(FUNCPARMS)
{
	char *tmp=data, *_label = _getword(tmp), *_row=_getword(tmp), *_field=_getword(tmp), *_sep=_getword(tmp), *sep;
	sep=tempMem;
	if (!*_sep)
		sep = "\t";
	else
	{
		if (*_sep == '"')
			_sep++;
		if (*_sep == '\'')
			_sep++;

		if ('0' <= *_sep && *_sep <= '9')
		{
			sep[0] = _atol(_sep);
			sep[1] = 0;
		}
		else
			sep = _sep;
		/* You Cannot use character 0 as the separator */
		if (*sep == 0)
			*sep = '\t';
	}
	int row,field,i;
	char **dr;
	LABEL *label;

	if (!*_field)
		_field = "-1";
	if (!*_label || !*_row)
	{
		lstrcpy(data,"E_INVALID_ARGUMENTS");
		return RET_VALUE;
	}

	label = (LABEL*)sqliteHashFind(labels,_label,lstrlen(_label));
	if (label == NULL)
	{
		lstrcpy(tempMem,_label);
		wsprintf(data,"E_INVALID_LABEL %s",tempMem);
		return RET_VALUE;
	}

	row = _atol(_row);
	if (('0' <= _field[0] && _field[0] <= '9')
	  ||('-' == _field[0] && _field[1] == '1'))
		field = _atol(_field);
	else
	{
		field=fieldid_by_name(label,_field);
		if (field < 0)
		{
__inv_field:
			lstrcpy(tempMem,_field);
			wsprintf(data,"E_INVALID_FIELD %s",tempMem);
			return RET_VALUE;
		}
	}
	if (field < -1 || field > label->field_count)
		goto __inv_field;
	if (row < -1 || row > label->row_count)
	{
		lstrcpy(tempMem,_row);
		wsprintf(data,"E_INVALID_ROW %s",tempMem);
		return RET_VALUE;
	}
	if (row == 0)
	{
		wsprintf(data,"S_OK %d",label->row_count);
		return RET_VALUE;
	}
	if (field == 0)
	{
		wsprintf(data,"S_OK %d",label->field_count);
		return RET_VALUE;
	}
	if (row > 0)
		--row;
	dr = label->data + ((row+1) * label->field_count) + field;
	if (field == -1)
	{
		++dr;
		wsprintf(data,"S_OK %s",(dr[0]?dr[0]:"NULL"));
		for (i=1; i < label->field_count; i++)
			wsprintf(data,"%s%s%s",data,sep,(dr[i]?dr[i]:"NULL"));
	}
	else
		wsprintf(data,"S_OK %s",(*dr?*dr:"NULL"));
	return RET_VALUE;
}

///////////////////////////////
// Return Database Engines Version
//////////
MircFunc Version(FUNCPARMS) ret("SQLite " SQLITE_VERSION " - www.sqlite.org")

///////////////////////////////
// Execute a Query
//////////
MircFunc Query(FUNCPARMS)
{
	char *tmp = data, *err, *label = _getword(tmp), *query = tmp;
	int   errno;
	LABEL *lbl;

	if (!*label || !*tmp)
	{
		lstrcpy(data,"E_INVALID_ARGUMENTS");
		return RET_VALUE;
	}

	lbl = (LABEL*)sqliteHashFind(labels,label,lstrlen(label));
	if (lbl == NULL)
	{
		lstrcpy(tempMem,label);
		wsprintf(data,"E_INVALID_LABEL %s",tempMem);
		return RET_VALUE;
	}
	if (lbl->data)
		sqlite_free_table(lbl->data);

	do
	{
		errno = sqlite_get_table(lbl->db,query,&lbl->data,&lbl->row_count,&lbl->field_count,&err);

		if (errno == SQLITE_OK )
			goto done;
		if (errno != SQLITE_BUSY)
		{
			if (errno > SQLITE_NOTADB)
				wsprintf(data,"E_SQLITE_UNKNOWN %s",err);
			else
				wsprintf(data,"E_SQLITE_%s %s",sqlite_error_name[errno],err);
			lbl->rows_affected = 0;
			lbl->field_count = 0;
			lbl->row_count = 0;
			lbl->data = NULL;

			sqlite_freemem(err);
			return RET_VALUE;
		}
		/* Sleep for a 10th of a second...
		** pretty much we are yielding to let something
		** else work with the db... :)
		*/
		Sleep(10);
	} while ( errno == SQLITE_BUSY );
done:
	lbl->rows_affected = sqlite_changes(lbl->db);

	wsprintf(data,"S_OK %d %d",lbl->row_count,lbl->field_count);
	return RET_VALUE;
}

///////////////////////////////
// Free a Query
//////////
MircFunc FreeQuery(FUNCPARMS)
{
	char *tmp = data, *label = _getword(tmp);
	LABEL *lbl;

	if (!*label)
	{
		lstrcpy(data,"E_INVALID_ARGUMENTS");
		return RET_VALUE;
	}

	lbl = (LABEL*)sqliteHashFind(labels,label,lstrlen(label));
	if (lbl == NULL)
	{
		lstrcpy(tempMem,label);
		wsprintf(data,"E_INVALID_LABEL %s",tempMem);
		return RET_VALUE;
	}
	if (lbl->data)
		sqlite_free_table(lbl->data);
	lbl->rows_affected = 0;
	lbl->field_count = 0;
	lbl->row_count = 0;
	lbl->data = NULL;

	lstrcpy(data,"S_OK");
	return RET_VALUE;
}


///////////////////////////////
// Lists All Current Databases...
//////////
MircFunc Labels(FUNCPARMS)
{
	char  *tmp = data, *label = _getword(tmp);
	int _lbl,lbl_max = labels->count;
	HashElem *lbl;
	if (!label)
	{
__count:
		wsprintf(data,"S_OK %d",lbl_max);
		return RET_VALUE;
	}
	_lbl = _atol(label);
	if (_lbl < 0 || _lbl > lbl_max)
	{
__error:
		lstrcpy(tempMem,label);
		wsprintf(data,"E_INVALID_LABEL %s",tempMem);
		return RET_VALUE;
	}
	if (_lbl == 0)
		goto __count;
	for(lbl=sqliteHashFirst(labels); lbl && --_lbl; lbl=sqliteHashNext(lbl));
	if (!lbl)
		goto __error;

	lstrcpyn(tempMem,(char*)sqliteHashKey(lbl),sqliteHashKeysize(lbl)+1);
	wsprintf(data,"S_OK %s",tempMem);
	return RET_VALUE;
}


///////////////////////////////
// Close Database
/////////////////////
// Closes a SQLite Database..
// Releases all stored memory forit...
//////////
MircFunc Close(FUNCPARMS)
{
	char  *tmp = data, *label = _getword(tmp);
	LABEL *lbl;


	if (!*label)
	{
		lstrcpy(data,"E_INVALID_ARGUMENTS");
		return 3;
	}

	// Passing Null for the pointer in sqliteHashInsert
	// actually Removes the item from the hash :)

	lbl = (LABEL*)sqliteHashFind(labels,label,lstrlen(label));
	if (!lbl)
	{
		lstrcpy(tempMem,label);
		wsprintf(data,"E_INVALID_LABEL %s",tempMem);
		return 3;
	}
	lbl = (LABEL*)sqliteHashInsert(labels,label,lstrlen(label),NULL);
	if (lbl->data && lbl->field_count > 0)
		sqlite_free_table(lbl->data);

	sqlite_close(lbl->db);
	delete lbl;
	
	lstrcpy(data,"S_OK");
	return 3;
}

