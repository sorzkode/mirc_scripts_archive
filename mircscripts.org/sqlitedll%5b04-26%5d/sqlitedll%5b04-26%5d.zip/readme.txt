
//////////////////////////
// Information
////////

   SQLite.dll is a Dll Wrapper for the SQLite embeddable SQL engine.
   i wrote this wrapper so that people would be able to access the extremely
   useful SQLite databases from mIRC. sqlite is good because of the fact its
   so portable, and also since its not a client library that connects to a sql
   server (the dll is the server) you don't need to worry about the user having
   mysql, postgresql, oracle (etc..).
   
   Sqlite is also useful because multiple instances of mirc can be connected to
   a singular database without a major fear of database corruption(within reason).
   if something happens and mirc crashes in the middle of a statement, then no
   worries, sqlite uses journaling and 90% of the time can Roll back the database
   to fix it up. Using transactions are a must for multiple updates. it is recommended
   that you check out www.sqlite.org a little more about the library to get the
   most out of it.

   The implementation that is provided with SQLiteDLL is slightly different
   (I've mod'ded a few things here and there, nothing major though) from the one
   that is at www.sqlite.org.

   The DLL that came with this package has been packed by UPX (upx.sourceforge.net)
   to effectively half the size of the dll. which is a bonus for anyone distributing
   it.

   UPX output:
        File size         Ratio      Format      Name
   --------------------   ------   -----------   -----------
    213504 ->    113664   53.23%    win32/pe     SQLite.dll

//////////////////////////
// Tools
////////

   I have also packaged the sqlite command line tool for working with sqlite
   databases. Here are a few other tools which i found good for working with
   sqlite (or other databases).

   - DBTools Manager                                        www.dbtools.com.br

     Totally FREE Win32 application to manage MySQL, PostgreSQL, XBase Tables
     and SQLite databases. Supports managing all objects in the database, create
     queries in visual mode, import/export data from MSAccess, ODBC, text files,
     Paradox, DBF Tables and generate PHP scripts. The list of features is just
     too big.

   - SQLiteCC                     http://bobmanc.home.comcast.net/sqlitecc.html

     SQLite Control Center is a visual tool for working on SQLite database files
     similar to MySQL CC. I personally use this one more than DBTools Manager,
     mainly because its simple and does the job :]

   Email me if you would like to add another tool here (my email is at the bottom)

//////////////////////////
// SQLite Library Information
////////

     SQLite is a C library that implements an embeddable SQL database engine.
     Programs that link with the SQLite library can have SQL database access
     without running a separate RDBMS process.

     SQLite is not a client library used to connect to a big database server.
     SQLite is the server. The SQLite library reads and writes directly to and
     from the database files on disk.

     Features

       * Implements most of SQL92. (Features not supported: http://www.sqlite.org/omitted.html)
       * A complete database (with multiple tables and indices) is stored in a
         single disk file.
       * ACID (Atomic, Consistent, Isolated, Durable) transactions.
       * Database files can be freely shared between machines with different
         byte orders.
       * Supports databases up to 2 terabytes (2^41 bytes) in size.
       * Small memory footprint: less than 25K lines of C code.
       * Two times faster than PostgreSQL and MySQL for many common operations.
       * Very simple C/C++ interface requires the use of only three functions
         and one opaque structure.
       * Simple, well-commented source code.
       * Automated test suite provides over 90% code coverage.
       * Self-contained: no external dependencies.
       * Built and tested under Linux and Windows.
       * Sources are in the public domain. Use for any purpose.

   -- Taken from www.sqlite.org

//////////////////////////
// API Documentation
////////

 Results are returned as follows:
   S_OK          <RESULTS>      = Successful
   E_<SHORT_MSG> <FULL_MESSAGE> = Failure

     Most Error Messages are Self Explanatory.

SQLite.dll,Open,<LABEL> [DATABASE]

  DATABASE is the database file you would like sqlite to open/create.
  using :memory: as the database, will create an in-memory (temporary)
  database.


SQLite.dll,Query,<LABEL> <QUERY>

  LABEL is the label you used when calling the Connect command. Use a
  standard SQLite query for QUERY.


SQLite.dll,FreeQuery,<LABEL>

  Free's the memory after you've finished with a query.


SQLite.dll,Rows,<LABEL>

  Will return the number of rows returned by Query.


SQLite.dll,RowsAffected,<LABEL>

  Will return the number of rows affected by a DELETE, UPDATE, or INSERT statement.
  If the query was a SELECT statement, RowsAffected will return the same result
  as Rows.

  NOTE:	SQLite implements the command "DELETE FROM table" without a WHERE clause
	by dropping and recreating the table.  (This is much faster than going
	through and deleting individual elements form the table.)  Because of
	this optimization, the RowsAffected count for "DELETE FROM table" will be
	zero regardless of the number of elements that were originally in the
	table. To get an accurate count of the number of rows deleted, use
	"DELETE FROM table WHERE 1" instead.


SQLite.dll,FetchRow,<LABEL> <ROW> [SEPARATOR]

  Will return the row number specified by ROW, with data being separated by the
  character specified by SEPARATOR.  If SEPARATOR is not specified, a tab
  character will be assumed.


SQLite.dll,Fetch,<LABEL> <ROW> [FIELD] [SEPARATOR]

  will return the number of rows, number of fields, entire rows, a specific
  row's column, the fields, a specific field. im still working on this one,
  so there is no guarentee it's usage may change, see test.mrc for some
  example of how it works...


SQLite.dll,Fields,<LABEL> [SEPARATOR]

  Will return the list of field names returned by a Query with names being separated by the
  character specified by SEPARATOR.  If SEPARATOR is not specified, a tab character will be
  assumed.


SQLite.dll,Labels,[n]

  If n is specified, and a positive number, the label matching that number will be returned.
  If n is 0, or not specified, the total number of labels will be returned.  If n is greater
  than the number of labels, an error will be returned.


SQLite.dll,Close,<LABEL>

  Closes the database file.


//////////////////////////
// Contributions
////////
   Most of this was written by me with exception for
   _atol() & _getword() which were taken from another mIRC dll,
   i forget what one though. Most of the ideas on the api were taken
   from the MySQL.dll for mirc.

   http://www.sqlite.org/ - sqlite embeddable database engine


//////////////////////////
// License
////////
   Generally I'd release it under the GNU GPL or LGPL, but as
   sqlite is public domain. i thought i might follow suit since
   what I've done is nothing major and thus, i have adopted
   this license:

   The author disclaims copyright to this source code.  In place of
   a legal notice, here is a blessing:

      May you do good and not evil.
      May you find forgiveness for yourself and forgive others.
      May you share freely, never taking more than you give.

   Enjoy! :D


//////////////////////////
// Contact
////////

  E-mail: kloptopsATamitar.com.au
