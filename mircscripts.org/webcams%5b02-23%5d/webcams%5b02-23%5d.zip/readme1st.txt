Title: Webcam viewer
Created by The_Hewbie 20/2/2001
Email: poptel@yahoo.com (feel free send me comments/suggestions/problems or vist url address below)
Url: www.mircforums.com
mIRC: 5.81+ later

:UNZIP

Place all files into Current mirc folder

webcam.mrc
webcams.dat
read1st.txt


:install / Uninstall script

/load -rs webcam.mrc

/unload -rs webcam.mrc


:How-To-Use

typing /wbc <enter> will load up option box with three buttons

goto: will connect you to irc server which cam has chat channel plus load webcam

showcam/StopCam: will just load up cam or by click it again will stop loading of webcam & timer  

View Profile: loads up infomation about Selected Webcam, see below for more info

:<ViewProfiles Options>

( Webcam profiles ) 

Name
URL & tick box at end of it (Note: only tick the box if you getting unable show cam pic)
Channel Name
IRC Server
* Notes
Webcams Refesh Rate


( Profiles controls ) 
Add / Apply
Delete


* ( Prev<>Next ) 

* -> not implemented yet


:Misc




