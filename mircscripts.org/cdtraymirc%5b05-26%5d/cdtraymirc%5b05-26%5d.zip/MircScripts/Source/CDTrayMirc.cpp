#include <windows.h>

#define mIRCReturn(x) { lstrcpy(data,x); return 3; }
#define mIRCProc(x) int WINAPI x(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)

extern "C" {
	mIRCProc(OpenCDTray) {
		MCIERROR mciResult;
		LPTSTR mciString = "";

		lstrcpy(mciString,"Set CDAudio!");
		lstrcat(mciString,data);
		lstrcat(mciString," Door Open");

		mciResult = mciSendString(mciString,0,0,0);

		if (mciResult == 0) {
			mIRCReturn("S_OK");
		} else if (mciResult == MCIERR_INVALID_FILE) {
			mIRCReturn("E_INVALID_CD_DRIVE");
		}
		
		return 3;
	}
	
	mIRCProc(CloseCDTray) {
		MCIERROR mciResult;
		LPSTR mciString = "";

		lstrcpy(mciString,"Set CDAudio!");
		lstrcat(mciString,data);
		lstrcat(mciString," Door Closed");

		mciResult = mciSendString(mciString,0,0,0);

		if (mciResult == 0) {
			mIRCReturn("S_OK");
		} else if (mciResult == MCIERR_INVALID_FILE) {
			mIRCReturn("E_INVALID_CD_DRIVE");
		} else {
			MessageBox(mWnd,ltoa(mciResult,"blah",10),"shit",0);
		}
		
		return 3;
	}
}