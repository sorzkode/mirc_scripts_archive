################################
# xServ created by zeeg (zeeg@evilcoder.net)	#
# See contact information for more details	#
# Like the script? Support my network at	#
# irc.evilcoder.net				#
################################
# 		Install.			#
################################
# 1)	Unzip xdb\ into your mircdir		#
# 2)	Unzip xserv.mrc wherever		#
# 3)	Load xserv.mrc into remotes		#
# 4)	Grab some pie!			#
################################
# 		The Key.			#
################################
# @	Updated or Improved		#
# !	Fixed (For now at least		#
# +	Added				#
# -	Removed				#
################################

VERSION 3.2

! Removed flood protection, was causing file server sessions to close
! Misc bug fixes
*NOTE: This COULD be the final version


VERSION 3.1.4b

! Fixed a bug that wasn't allowing the FServ chat to function, was returning an '/if' error
! Fixed multi-drive bug making it so you couldn't switch to drives that were enabled
! /xrload now will reload it if the script is in a spaced dir
! Fixed another bug in multi-drive with spaced dirs

VERSION 3.1.4

! Fixed a massive heap of bugs from when i changed from on/off values to state values, almost everything that didnt work and was supposed to work, works now (i hope, contact me if it doesnt)

VERSION 3.1.3

! Fixed the bug that wouldn't let you change some of the ad intervals

VERSION 3.1.2

! Fixed a couple bugs, 1 with the update system, it WORKS this time

VERSION 3.1.0b

+ XDCC is done
@ XDCC single line ad is now available
! Fixed a bug with the XDCC Long ad flooding you off :)
@ Made it check if you put the xdb\ in your main mirc folder or not

VERSION 3.1.0a

@ Dialog changes, a lot
- Temporarily removed the Help, and XDCC these will be done... 1) when people complain 2) when i get around to it
@ The code, its a bit cleaner, ill be able to make it a lot smaller killing some dialogs when i complete these new ones as well as changed some stuff

### Please check your server settings to make sure they are still valid ###

VERSION 3.0.2b

! !list now functions correctly
! XS: You can once again download styles with /xs

VERSION 3.0.1

! xServ now includes styles (this way i dont have to fix bugs!)
@ Updated contact links, added a Forum link, and changed Chat with Us to IRC

VERSION 3.0.0

! Fixed queues
- Channel Guard, it will be back
! A lot of misc stuff
+ Styles now included in the ZIP file
@ Fixed my readme so its here again

################################
# 		The FAQ.			#
################################

Q: I get an error message saying BLAH, what do I do?
A: Restart IRC, If it happens again, contact me (see below)

Q: My file servers aren't displaying the ads, what is wrong?
A: a few things here;
    1) Did you click Enable Ad so it has a checkmark?
    2) Did you push in the Server (XXX) button so it says Server (On)?
    3) Did you setup a network, i.e. *.exxnet.net and add a channel? i.e. #corix, and are you on this channel?
    -
    Yes, Yes, and Yes..
    Contact me (see below)

################################
# 		Contact Me.		#
################################
# E-mail:		zeeg@evilcoder.net	#
# MSN:		zeeg_irc@hotmail.com	#
# AIM:		CrmrDvd			#
# ICQ:		155412574		#
# IRC:		irc.exxnet.net (zeeg/#corix)	#
# Forums:	www.evilcoder.net		#
################################