Readme for IDEmIRC
Updated 14/05/03

Changes v1.1:
	-Aparently some people couldn't grasp step by step instructions, so documentation has been redone.
	-Help files are now in a seperate directory. See \Help\index.htm
	-DDECommander supports the command line arguments which I couldn't squeeze in before
	-Improved Documentation
	-mIRCDD minor issue fixed (filepath issues)
	-Added color codes, bold, underline, reverse control chars to cliptext

Installation
See \Help\installation.htm for full instructions.