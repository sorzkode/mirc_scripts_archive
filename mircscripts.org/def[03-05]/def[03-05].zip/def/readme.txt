def v1.1046866283.12518626
==========================

what more do you need? A simple tool to lewk up words

/def <word to look up>

example:

/def webmaster

based on a php script some friend of me coded (love ya pizza :p)

Spola - users.pandora.be/spola
pizza_milkshake - parseerror.com

(i do NOT plan to convert it to dialogs,
 i do NOT plan to fix the window name)

