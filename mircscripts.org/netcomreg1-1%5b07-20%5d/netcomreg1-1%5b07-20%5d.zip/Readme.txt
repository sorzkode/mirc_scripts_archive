Micorosft .NET Framework Registration tool for .NET Class Librarys (for use in mIRC via $com)
Sample for mIRC included

Author: Acidized

Description:
quick program to simplify COM registration for C#/J#/VB.NET dlls for use in mIRC

source is included! 

Instructions for the mIRC script:

1: unzip the netcomreg dir to you mirc folder

2: run /load -rs netcomreg\netcomreg.mrc

3: If you still have no idea what to do check the src in Sample dir (dll is included for those of you that dont have vs.net to compile it)
copy the dll to the mirc folder or wherver then run:
/netcomreg -r $mircdirpath-to-dll

Example:
//netcomreg -r path-to-Sample.dll (Exactly like that it is case sensitive and does require DriveLetter:\)

4: Open mIRC and type:
/comopen Sample Acidized.Sample

5:
//echo -a $com(Sample,Hello,1) <--- Should return a 1 if it worked

6:
//echo -a $com(Sample).result) <--- will return Hello World! if step 5 worked

7: Thats it!


Examples in the DLL:


Add:

//echo -a $com(Sample,Add,1,i4,5,i4,10)
//echo -a $com(Sample).result

will return 15

Echo:

//echo -a $com(Sample,Echo,1,bstr,Testing 1 2 3)
//echo -a $com(Sample).result

Will Return Testing 1 2 3


If you have any quitions feel free to email me at:
Acidized@earthlink.net