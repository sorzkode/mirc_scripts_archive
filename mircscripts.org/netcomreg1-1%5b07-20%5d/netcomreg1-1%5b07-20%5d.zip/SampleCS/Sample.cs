using System;

namespace Acidized
{
	/// <summary>
	/// Summary description for Acidized.Sample.
	/// Hello: returns Hello World! back to mIRC
	/// Echo: returns Whatever you like back to mIRC
	/// Add: Adds v1 and v2 and returns the result to mIRC
	/// </summary>
	public class Sample
	{
		public Sample() { 
			//init code here
		}
		
		public string Hello() 
		{
			// Return to mIRC
			return "Hello World!";
		}
		
		public string Echo(string str) 
		{
			// Return to mIRC
			return str;
		}
		
		public int Add(int v1,int v2) 
		{
			// Return to mIRC
			return v1 + v2;
		}
			#region Unload
		~Sample() { }
		#endregion
	}
}
