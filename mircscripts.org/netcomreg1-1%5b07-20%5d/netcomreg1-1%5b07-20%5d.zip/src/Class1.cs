using System;
using System.Reflection;
using System.Runtime;
using System.Runtime.InteropServices;

namespace netcomreg
{
	class RegAsm
	{
		public RegistrationServices reg = new RegistrationServices();
		static void DoParse(string[] str,string parm) 
		{
			if (parm == "r") 
			{
				Console.WriteLine("Successfully Registered: " + str[0]);
			}
			if (parm == "u") 
			{
				Console.WriteLine("Successfully Unregistered: " + str[0]);
			}
			Console.WriteLine(str[1]);
			Console.WriteLine(str[2]);
			Console.WriteLine(str[3]);
		}
		[STAThread]
		static void Main(string[] args)
		{
			if (args.Length < 1) { Console.WriteLine("Invalid Format:"); Console.WriteLine("Usage netcomreg [-ruh] path-to-library"); Console.ReadLine(); }
			else 
			{
				RegistrationServices reg = new RegistrationServices();
				if (args[0].ToString() == "-r") 
				{
					try 
					{
						Assembly regass = Assembly.LoadFile(args[1]);
						reg.RegisterAssembly(regass,AssemblyRegistrationFlags.SetCodeBase);
						DoParse(regass.FullName.Split(Convert.ToChar(",")),"r");
					}
					catch (Exception e) 
					{
						if (e.GetType().ToString() == "System.IndexOutOfRangeException") 
						{
							Console.Write("Please Specify a filename eg: netcomreg [-ruh] filename");
							Console.Read();
						}
						if (e.GetType().ToString() == "System.ArgumentException") 
						{
							Console.Write("File not found / Not a Valid .NET Class Library.");
							Console.Read();
						}
					}
				}
				else if (args[0].ToString() == "-u") 
				{
					try 
					{
						Assembly ass = Assembly.LoadFile(args[1]);
						reg.UnregisterAssembly(Assembly.LoadFile(args[1]));
						DoParse(ass.FullName.Split(Convert.ToChar(",")),"u");
					}
					catch (Exception e) 
					{
						if (e.GetType().ToString() == "System.IndexOutOfRangeException") 
						{
							Console.Write("Please Specify a filename eg: netcomreg [-ruh] filename");
							Console.Read();
						}
						if (e.GetType().ToString() == "System.ArgumentException") 
						{
							Console.Write("File not found / Not a Valid .NET Class Library.");
							Console.Read();
						}
					}
				}
				else 
				{ 
					Console.WriteLine("Usage: netcomreg [-ruh] path-to-library");
					Console.WriteLine("Start Help");
					Console.WriteLine("Options:");
					Console.WriteLine("	-h		Shows this Help.");
					Console.WriteLine("	-r		Registers a the specified dll in the Global Assembly Cache.");
					Console.WriteLine("	-u		Unregisters the specified dll from the Global Assembly Cache.");
					Console.WriteLine("End Help");
					Console.ReadLine();
				}
			}
		}
	}
}
