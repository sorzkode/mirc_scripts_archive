KoProt - Personal Flood Protection

How do I load this thingy?

	Put files in your mIRC directory, then, open mIRC
	and type /load -rs KoProt/KoProt.mrc, a window 
	will popup asking if you want to load the script,
	click yes...., and don't have it in a direcotry 
	with a space in it, (I didn't use $shortfn)

I found a bug, /me points and laughs!

	No, Don't laugh, tell me in the comments section..

I hate this, it's crap!

	Like they all say, don't use it, and you'll live

How do I set this thing up...?

	Theres a setup dialog, which can be accessed from 
	the menubar, it's a neat/tight dialog which is easy
	to use :)

I still don't like it!!!

	Oh shut up!....
