ENNSlookup
Version 1.0 beta4
Author: ENNE
Realase: 4. January 2006
For info: http://ennslookup.altervista.org
Based on: mIRC 6.16

---- Addon's typical installation
1) Unzip the file ennslookup.zip in the mIRC's folder (for example C:\mIRC\ennslookup\).
2) Start mIRC.
3) Write this command:
   /.load -rs ennslookup\ennslookup.mrc
4) Click "Yes" on the mIRC's question.
5) Select the language.
6) The installation is complete. 
---------------------------

---- Features
- You can chose the name server to use.
- You can chose the query type (A, MX, NS, ...).
- Help buttons
- Live Update
- Feedback with author
---------------------------

---- Addon's uninstall
To uninstall ENNSlookup write this command: /ennslookup.uninstall
or on the main menu of mIRC: "ENNSlookup" -> "Uninstall"
---------------------------