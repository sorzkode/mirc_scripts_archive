This tutorial has copyright @ www.regular-expressions.info - If
you have any problem with it, or if you find an error please
don't contact me. But the site.

I only convert this tutorial, I didn't write it...

Xenoxsis