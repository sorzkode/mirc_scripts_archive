Zip v1.0 by nix2k
DLL by mc68000

This is my newest addition to mircscripts.org. It uses mc68000s wonderful ZIP dll to zip files and/or directories.

---------------------------
Installation
---------------------------
To install, unzip into your mIRC directory (or anywhere, if thats your thing). 
It should be in its own directory, although its not necessary. We'll use c:\mIRC\zip\ for an example.

When unzipped, type /load -rs c:\mIRC\zip\zip.ini

Thats it for installation. When its installed, it will add a new menu option called "Zip" to the MAIN menu bar.

---------------------------
Usage
---------------------------

First, to start the dialog, select "Zip" from the menubar, or type /zipdiag

The dialog will look rather bland (and it is, I don't believe in releasing an addon thats 5 megs big because of MDX).
It will have a list on the left size, with some options on the right, and a button on the top.

The list will list all files in the currently selected dialog. When you start the dialog, it defaults to your current mIRC directory.
You can select other directories by pressing the "Select Directory" button at the top. Just select the directory you want, and it will
list the files.

In the list, you can select multiple files, so you can zip specific files.

If you wish to just zip the selected files, make sure the "Selected Files" radio button is checked, and click on "Zip Files".
This will then ask you to specify a file. Just navigate to where you want to save the zip file, and type in a name. (You can leave off
the .zip extention, the addon will check for it before it starts to zip files). It should then zip the files, and a zip file will be
created where you specified.

If you wish to zip all of the files listed, you can either select all the files on the list, and follow the directions above. Or, instead
of selecting files, just select the "Directory" radio button. Press the "Zip Files" button. It will ask where you want to save the zip file, 
follow the directions above for this. It will then zip all files in the directory (but not in subdirectories, thats what the next option
is for).

If you wish to zip all of the files listed in the directory, plus all of its subdirectories, press the "Select Directory" button. Choose
a directory, and it will load the files into the list. Ignore the list, and select the "Directory (Recursive)" option. Click the "Zip Files"
button, and it will ask you to select a file. Follow the directions above for this. It will then zip all of the files in the current
directory, as well as all files in subdirectories (Yes, it DOES preserve directory structure). 

---------------------------
Comments/Questions/Bugs
---------------------------

Any bugs, comments, or questions should be sent to nix2k. (Unless its a DLL problem, then I can't help you, but I can try)

I can be reached at either nick@mircscripts.org or nick@emergeonline.org
You can also send me a private message on mircscripts.org, my username is nix2k

Thanks :)