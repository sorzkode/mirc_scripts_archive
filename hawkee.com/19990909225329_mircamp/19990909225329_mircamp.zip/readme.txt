 __________________________
|/\/\/\/\/\/\/\/\/\/\/\/\/\|
|\/mircamp*v1.0*By*Shongo\/|
|/\/\/\/\/\/\/\/\/\/\/\/\/\|
 ��������������������������
******************************
Overview
1) What is mircamp
2) How to load and setup mircamp
3) How to use mircamp
4) The scripter
******************************
What is mircamp
******************************
mircamp is an addon for mIRC v5.31. mircamp's goal is simulate an 
actual mp3 player. mircamp is used by clicking on the buttons using
your mouse. mircamp also has a small visual plugin that can be turned 
on and off using your mouse.
******************************
How to load and setup mircamp
******************************
to load mircamp you would use this command
/load -rs <location of mircamp.mrc "example c:\mirc\mircamp.mrc">
this will load mircamp into mirc. After you load mircamp a box will 
appear asking if it should run the setup for the script, choose ok.
The first question is to locate the bitmap used as the interface.
The name of the file is mircamp.bmp. Next it will ask for your mp3
directory, this is were all of your mp3s are stored at. the final 
question is to locate your mp3 player "example winamp.exe". After you
have finished this setup proccess you are ready to run mircamp.
******************************
How to use mircamp
******************************
Using mircamp is simple. Everything is point and click. 

1) To load a mp3 single click on the middle button (eject button)
2) select an mp3
3) single click on the first button (play button)

this will start your mp3 player and play the desired song.
or you can play a random mp3

1) single click on the last button (R button)
2) single click on the first button (play button)

mircamp also comes with a type of visual plugin (simulate winamp)
to turn on the plugin

1) double click in the window at the bottom right (Biggest window)

to turn the plugin off

1) double click in the window at the bottom right (Biggest window)

to close mircamp 

1) single click on the X at the top right of mircamp
******************************
The scripter
******************************
Hello my name is Mike Filson. I am a 19 year old male, from
Harrodsburg, KY. I am currently enrolled at college at 
Eastern Kentucky University (EKU). If you have any comments about
mircamp please send mail to shongo@rocketmail.com
