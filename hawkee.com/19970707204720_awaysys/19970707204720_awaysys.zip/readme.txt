******AwaySys Version 1.00 README******

-Getting Started
First off You need to load the file "awaysys.mrc" Into Your
mIRC Remote Script Section. to do this 
1)Open mIRC
2)type //load -rs $findfile(c:\,awaysys.mrc,1)
  [You can also replace "$findfile(c:\,awaysys.mrc,1)" with the
   path but if you dont know what i mean then just leave it]
3)The file will Load and off you go!
4)You can control it from the Popups in Any Channel or load it 
manually.

E.A. Borgstrom -AKA- malevolence [&previously] null-
