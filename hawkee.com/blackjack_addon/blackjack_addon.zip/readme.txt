Yes peeps, its time for
another great addon from
your truly hellish. this
addon will mimic genuine
casino blackjack with 1
small acception. if your
able to hit off 5 cards
without busting, you win
this is a old house rule
the only reason i imple-
mented it into the code
is so the window wouldnt
have to support 11 or so
cards and that would have
been a pain.  -hellish 