============================================
   Log Master v2.4-SE Addon For mIRC 5.3+
          by Paul <kbhw@religious.com>           
============================================

Introduction
------------

     Thanks for downloading Log Master v2.4-SE!!  This addon was originally created for C-Script, and I have decided to make a "Special Edition" of this addon for mIRC users who do not use C-Script.

     Log Master is an addon that lets you view your mIRC logs right in full color in mIRC.  You no longer have to open up each log in notepad and try to read lines of text with all those distracting color codes everywhere.

     Besides just opening up the logs, you may also search each log for specific text, copy a log to another directory, rename logs, and much more!

Installation
------------

     Log Master is easy to set up!  Just load logmastr.mrc by typing /load -rs logmastr.mrc (Make sure logmastr.mrc is in your mIRC directory)  It's that simple!  Use the popup provided in the Channel, Status, and Menubar popups to start Log Master or just type /logmaster

Comments, Questions or Bug Reports
----------------------------------

     Please send all comments, questions, and/or bug reports to kbhw@religious.com