SwearKick 2.0 for mIRC 5.02 by Poolshark

Full-featured offensive language detection.

INSTALATION
1. Place sk20.mrc in your mIRC directory.
2. Run mIRC and type /load -rs sk20.mrc.
3. Follow the simple setup instructions.
