skz readme%!

um, this is the third release of sekz, a few bugs where fixed
changed the theme shit, instead of $format(formatname,parm1,parm2,ect) 
you now have $format.formatname(parm1,parm2,parm3). I also made a new 
theme, its called jizz, what it basicly is, is a copy of def.thm with 
different colors, megaton eweet eh? um, thanks go out to treason who let
me use his neat text halt alias and whoever else that has contributed 
in the making of this script. you may use my code in your own shit
i dont give a poo. presently there is no help screen, to obtain help on
a specific comand type the root of the comand, i.e /j or /p. 

im currently working on a fourth and final release, which will take advantage
of mirc`s new sockets and shit, hopefully to be released by may 20 '98. 

I can be contacted at: beacker@total.net
;greets

kremlan: i fear you
compy: because your elite 
^-nicole-^: hanky spanky :P
unconnected: where are you#$!@!&# 
kalus: hi#$! 
martie: *spoink* 
relode: that time of month again?
_unique: one leet fool
barbi: hi! 
semp: semp#$!@@#^!@#$! *smooch*
pawt: hello
treason: elite canadian like myself :P  
drache: i keep on forgeting#$@!$@ new years resoulution is to add on 1:start:{ server irc.magiccarpet.com } :)
anybody else i forgot, sorry :)

;#eof