Hello,
Thank you for Choosing <--Gre/-\t-Ju]{e-->.
To install @Great-Juke, just Copy the Juke.txt File to your mIRC 
5.02 Directory and type: /load -rs directory\Juke.mrc
You will be asked several times If you want to proceed, Press yes, 
or type it when asked. 
Have Fun...Goldfing

