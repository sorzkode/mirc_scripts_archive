Auto Scans every X (configurable) seconds
(or single scans) participants in a 
channel, and auto warns/kicks (kicks after
X seconds [configurable]) for 
co-channelling in teen/incest/child porn
channels.  Self loading (*.mrc) form.
Configerable from popup in channel window.
*Only works in one channel at a time.
*Only works with mirc 5.1+
*You can turn off the flashy graphics and
auto op notices by turning verbose mode to off.

Type /load -rs autoscan.mrc when the file is placed 
in your mIRC directory.