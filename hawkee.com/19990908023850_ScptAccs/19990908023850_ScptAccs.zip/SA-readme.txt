
------------------------------------------------------------------

             Scripting Accessories for mIRC, UNIT 1 (1.0).

					By Plaza.
------------------------------------------------------------------

=============
Requirements.
=============

  The script itself can be used on versions below 5.31, but it 
is full-featured in that version. To get the latest version of 
mIRC, visit http://www.mirc.co.uk/.
  For any suggestions, comments, bug reports or flames you can 
reach me at Plaza@A-VIP.com.

==================================
Loading and installing the script.
==================================

1. Unzip the files to your mIRC directory.
2. Within mIRC, type on any window "/Load -rs c:\mIRC\ScptAccs.mrc"
   when c:\mIRC is replaced with your mIRC directory.
3. Click "Yes", when a dialog box appears, asking whether you want
   to perform the script's auto operations.

==========================
Commands, Identifiers etc.
==========================

	NOTE: '<','>' enclosed words are neccesary parameters.
	      '[',']' enclosed words are optional parameters.



	DESIGN TOOLS
	------------

	$Space([Number])

		Returns a space character ($chr(32),$chr(160)). 
		If the Number parameter is defined, it returns 
		'Number' of times space character.

		eg: $Space
		    $Space(4)

	$CSpace(<Colour>,[Number])
	
		Returns a space character with the defined colour 
		as its background. The Number parameter react the
 		same as in $Space.

		eg: $CSpace(6)
		    $CSpace(5,3)


	/WinMes <@Window Name>

		Return the measurements for the defined custom window
		(Meaning: x,y,w,h).

		eg: /WinMes @Sockets

	Picture Window Helpful tools
		
		Copy and paste those in your picture window menu. They
		are used in Cut and Paste because of the complexity of
		other methods.
		The x,y coordinates of a clicked point will be echoed 
		when clicked. Dragginf and Dropping will echo the x,y
		of the dropping point as well as the width and height
 		if the formed rectangle.

	VARIOUS SCRIPTING TOOLS
	-----------------------

	/Check [Text]

		Will print out the name of the script and the text 
		message. Is usually used to check where have your
		script reached so far when it is not working properly.

		eg: /Check Okay, passed the first loop.

	/For <Minimum Limit> <Maximum Limit> <Command>

		Will perform the specified command for Max-Min times.
		The loop variable, %Scp.For, can be used in your script
		as an assistant.

		eg: /For 1 4 echo -a This will be printed four times.
		    /For 3 $nick($chan,0) echo -a $nick($chan,%Scp.For)
 		    ; -- This will print the nicks from the third to the
		    ;    Last in the active channel.

	Status Auto '/'ing.

		Saves you the bugging bother to type '/' as the command 
		beginning in the status window. You never type anything
		BUT commands in the status window, so...

	ARRAYS
	------

	Arrays are a set of 'cells', each one can contain a value. Every 
	set in an array can be accessed by the name of the array and the
	cell number. This can be very helpful when doing something like
	channel-wide address list, and don't want to mess with many '$+'s 
	for every user. This way you can create an array and access to 
	the addresses simply by reading the array and mentioning the number.

	/Array <Array Name> <Minimum Value> <Maximum value>

		Create a new array, spreading from the specified minimum
		value to the maximum. The array will be named as specified.

		eg: /Array Plaza 1 7
		    /Array ChanAddress 1 $opnick($chan,0)
		    ; -- This will create an array with the number of cells
		    ;    as in the active channel's op number.

	/ArrayInsert <Array Name> <Cell Number> <Value>

		Insert the specified value to the array defined, in the 
		cell number defined.

		eg: /ArrayInsert Plaza 1 PLAZA@A-VIP.com
		    /ArrayInsert ChanAddress 3 $address($opnick($chan,0),1)
	
	$ArrayRead(<Array Name>,<Cell Number>)

		Reads the value of the specified cell in the specified array.

		eg: $ArrayRead(Plaza,1) will return PLAZA@A-VIP.com
		    $ArrayRead(ChanAddress,5) will return the address
		    of the fifth op in the active channel.

	/ArrayDelete

		Deletes the specified Array.
	
		eg: /ArrayDelete Plaza

	RECORDS
	-------

	Records are actually arrays with named fields. You can define an unlimited 
   	number of fields to a record. Records are useful for storing different 
	details for the same subject.

	/Record [-v] <Record Name> <Field 1> [<Field 2>...<Field N>]
	
		Create a record named as specified, including all the fields 
		mentioned. You can use the -v switch in order to base the record
		on variables (Normal records and arrays are based on ini files.).

		eg: /Record Plaza e-mail favchan1 favchan2 gender
		    /Record -v NetHours Sun Mon Tue Wed Thu Fri Sat

	/RecordInsert [-v] <Record Name> <Field> <Value>

		Insert the value in the field, in the specified record. Use 
		the -v switch to state it is a variable based record. Note
		that the v parameter is very important; If not mentioned,
		the script will produce an error message.

		eg: /RecordInsert Plaza gender Male
		    /RecordInsert -v NetHours Sun 01.00

	$RecordRead(<Record Name>,<Field>[,v])
	
		Reads the value of the field in the record. Use the extra v 	
		parameter to state it is a variable based record. Pay 
		attention to the v paramter, as above.

		eg: $RecordRead(Plaza,e-mail) will return Plaza@A-VIP.com.
		    $RecordRead(NetHours,Mon,v) will return 02.30.
		    
	/RecordDelete [-v] <Record Name> [Field]

		Deletes the specified field out the record. If the field	
		is not mentioned, the whole record is deleted. Use the
		-v switch to state it is a variable based record.

		eg: /RecordDelete Plaza favchan2
		    /RecordDelete -v NetHours

	VARIABLE WATCH
	--------------

	Sometimes you are dealing with a script that has frequently changing
	variables. In this case, it is not always comfortable to open the
	mIRC editor every moment. For this, there is the variable watch.
	If you want a variable to be watched, use the following commands.
	You can use your variables as a regular one at all times. W-variable
	refers to a normal variable name, without the %.
	Note: When showing the value in the watch window, only the first word
	of all is shown; All the words are set anyway.

	/Watch
	
		Opens the Variable Watch window. It is done automatically
		when using any of the Watch commands.

	/WSet [-uN] <W-Variable> <Value>

		Set a Watch Variable, as the value defined. You can use
		the -uN switch to automatically unset the variable after
		N seconds.

		eg: /WSet ScptVersion 1.0
		    /WSet -u3 UNIT 1
		    /WSet Var 11

	/WUnset <W-Variable>

		Unset a Watch Variable.

		eg: /WUnset ScptVersion

	/WInc <W-Variable> [Value] and 
	/WDec <W-Variable> [Value]

		The same as /Inc and /Dec, just on Watch Variables.

		eg: /WInc Plaza 
		    /WDec Var 5

	$WRead(<W-Variable>)
	
		Returns the value of the variable specified. 

		eg: $WRead(Var) will return 6.

	SOCKET CONTROL
	--------------

	Sockets, being a very critical tool, lack visibility. It is very
	Difficult to remember all the sockets names, know who is on and
	so on. This is why the Socket Control is made. Once opened, it 
	will show every movement in the sockets' existance.

	/SockControl
	
		Will open the Socket Control window.

	/SockInfo <Socket Name>

		Will show basic information about the specified socket.

		eg: /SockInfo SCP.LISTEN

=================================================

  Regev Schweiger, Plaza@A-VIP.com

=================================================

		  

		

