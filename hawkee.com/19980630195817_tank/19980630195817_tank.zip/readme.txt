Tank 2.1 �

Install:
	load "loadme.mrc"

Controls:
	* F2 fires
	* Left clicking the mouse moves the tank
	*The tank turns to face the mouse cursor

Misc:
	* ($) money bags are worth 100 - 1000 points
	* (R) rebound cause shots to rebound off the borders for 
            a random number or seconds
        * grass causes the tank to get stuck for 5 seconds
        * oil causes the tank to get stuck for 10 seconds

Objective:
	It is my objective to create a series of mIRC scripts that
others can use to make dealing with pictures windows easier. The full
set of scripts will be called PicLib 2.1 � and already includes a 
listbox, sprites, animation, grid, and buttons.
	Future additions to PicLib will be an enhanced list box, 
an optimized grid and sprites, and pull down and popup menus.
	Future additions to Tank, already in the works, will be 
multiplayer via sockets, enhanced AI, configurable game features,
and a scrolling map (a grid that's bigger than the window, which 
the current grid already has basic support for, it's called a view.)
	I also am open and ethusiastic about getting ideas for
features from you and other script writers as to what they need to
make their job easier.
		
GraySquire
DALnet
mford@huskynet.com