CloneStopper 2.5 for mIRC 5.02 by Poolshark

The most comprehensive clone detection/removal script you'll find anywhere.

INSTALATION
1. Place cs25.mrc in your mIRC directory.
2. Run mIRC and type /load -rs cs25.mrc.
3. READ the online readme and follow the simple setup instructions.
