=-------------------------------=-------------------------=
| <�>BackDrafT<�> Mp3 Selector  |  by: Mer|in on undernet |
=-------------------------------=-------------------------=

To Install:

1. unzip this file into your mirc directory
2. within mirc type /load -rs mp3.ini
3. click yes to run the "Initialization Commands"
4. when it says Type Your Mp3 Directory... type it like this: 
	c:\mp3\ or d:\mp3\ Make sure to have the second \ on the name
5. select your winplay or winamp directory (those are the only 2 i have
	tried w/ this...) and then the select the player and click ok

--- Now It Is Configured ---


To Use:

1. right click in a channel window and go down to the Mp3 Selector,
	then goto list files.. a window should pop up with your mp3s
2. from here there are 2 things you can do
	a. play a single song by double clicking on it
	b. play a random song by right clicking in the @mp3 window 
		(refer to the instructions within this menu)
3. if you did mess up with your configuring at the begining of this 
	help file just right click in the channel, goto Mp3 Selector,
	and the click on Configure/Reconfigure and redo the process

--- Have Fun With It --- 


Notes:

1. there are a few bugs i couldn't seem to get around..
	a. you cannot have spaces in your mp3 filenames
	b. all of your mp3s have to be in 1 directory (the directory
		that you selected in the configuring process)
	c. if there are anymore please email me and tell me so i can 
		fix them
2. you can email me at malan@advancenet.net

--- Thank You For Downloading This Mp3 Selector ---