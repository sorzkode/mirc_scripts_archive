*G*�*�*�* *�*�*�*v*�*R*�*�* V�r���� 1.1

Hi :)  this readme.txt will hopefully help in using this script.  

HOW TO INSTALL THIS SCRIPT PROPERLY.

1.  Create a dir, anywhere you like, and extract all the files from
the .zip file into it.  
2.  Copy mIRC.exe + any other files that you need (like help file, 
different lists of servers, whatever).
3.  Run it ... haha if this works, then the script is installed properly.

(I removed the help thing in the old readme file, I've decided no technical
support will be offered, hey I don't have the time :P ... but drop me
a line sometime if you want, I don't mind)

If you need me e-mail me at alinna@usa.net  

GoLdStARs :)

http://www.geocities.com/SunsetStrip/6818
http://www.geocities.com/SoHo/Studios/6818
http://www.geocities.com/SouthBeach/Palms/5276
http://www.geocities.com/SunsetStrip/Lounge/7988

"life's a bitch and so am I.  the world owes me so fuck you" - The Grouch,
Green Day.  Nice quote eh?
