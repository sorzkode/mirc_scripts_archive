hellish@efnet

running clock.mrc...
 unzip clock.mrc into a dir
 type "/load -rs drive:\path\clock.mrc" in mirc
 type /clock to start the clock in mirc
