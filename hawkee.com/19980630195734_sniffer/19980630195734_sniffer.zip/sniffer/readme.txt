SCRIPT: Sniffer v1.0
AUTHOR: Eric Rolfe
  NICK: TestPiolt
E-MAIL: eric@oz.sunflower.org
###################################################
Section 1 --The Setup--
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
1. Unzip sniffer.zip

2. go into mIRC and load the file called sniffer.mrc
	into your remote section

3. After you load the sniffer.mrc you should get a
	dialog box that asks if you want to run the
	initialization. Click Yes

4. Congratulations you vae just completed the
	instalation of Sniffer v1.0

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%	
Section 2 --Using the Script--
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

1. The script is easy to use. Just type /sniff <search phrase|nick >.
   Here are some examples: the script
	/sniff *!*@*.com		<-not recomended could lockup mIRC
	/sniff *!*@*.sunflower.org
	/sniff *!eric@*sunflower.org
	/sniff TestPiolt!*@*.sunflower.org
	/sniff TestPiolt		<-This will search for a nick it is like Testpiolt!*@*

2. A window will apear when the search is complete

3. To Sort the information right mouse click and go to throught the Sort By menu
	you should select things in the order they should be sorted by (the script does this
	because if there is identical nick names or what not you can tell the difference)

4. Copy pop up
	the copy section of the popup is self explanatory

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
If you have any questions\comments please e-mail me

#This is my first script and would appreciate any comments you might have
#I will improve the interface hopefully on the next verison

That is all that you need to know to use this script
  Note: This script is not promised to work
	in conjunction with any other scripts.
	There is no reasonit shouldn't though.