Maker of [neXus]:
	_KaiSeR_, with a little help from _StriKeR_

Why I Made it:
	Tired of seeing all my friends with their own scripts..... So 
I decided to make my own.

If you want help: 
	Please don't bother me for dumb shit... if it is real impor-
tant then you can email me at bomy@codetel.net.do

A little bit about myself:
	I am 16 years old and very enthusiastic to learn all there is 
about computers. I live in the Tropical Paradise known as Dominican 
Republic. Briefly thats all I can say right now. Oh and one more thing 
if you are on the Irc come by to #dashit.
