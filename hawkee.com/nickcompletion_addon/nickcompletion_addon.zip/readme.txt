Nick Completion for mIRC 5.0+ by Nifty
--------------------------------------
To get started, simply place ncomp.mrc in your mIRC directory. Then, while 
in mIRC, just type "/load -rs ncomp.mrc" to get started.