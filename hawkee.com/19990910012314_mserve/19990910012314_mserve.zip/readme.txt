multi-fserve[v1.011] readme file.

This mIRC 5.31+ fserve script supports multiple fserves, each with a
wide range of options for configurability.
Remote administration allows for distributed fserve control and a
simple interface enables complex administration possible even for
fserve beginners.

To load this script, type //load -rs $findfile(c:\,fserve.mrc,1)

For more info see http://nuncio.hypermart.net
(there really is a lot more info :)

== thanks to ==
Hawkee        : suggestions and a damn fine server
Selom Ofori   : monster bug-fixes.
treason       : suggestions for multi-fserve[v1.02]
MacPhisto     : this could have been  b o r i n g . . .
#mirc_scripts : DALnet's most egotistical channel.
|Gravity|     : thanks for cracking those shells.  names.dict rules!
sm0ke         : are you ever NOT juping?
item          : for asking more questions than there are atoms.
ssds          : you'll always own my .it skills.
DeltaBot      : sexy, perpetual +v
magick.net    : I have devoured you.
