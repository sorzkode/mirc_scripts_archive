-==[ Away - System 1.0 ]==-

This is a simple away system I made myself. Just type /away <Reason> and it will set away for
you. It's not the normal away system that came with mirc when you type /away <Reason> and it
just puts it into your /whois. This will replace your old away system and give you a new one.
Just if a certain person named Deleted on IRC sees this addon and thinks it's his, well it's
not. I made this Addon myself. So Deleted can not complain about this addon.

Features:

Anti Idle - This will make you join a channel like #AntiIdle872 and message the channel and says
            Ping Timeout.
Pager     - This will keep your messages when someone pages you. They will put this into a window
            called @pager. I got this idea from Deleted but I made it myself.
Logging   - This will hold your messages and place them into @pager. So when you return you will
            who messaged you and what they want.
Timer     - This will keep track on how long you have been away. When you are away, aout every 3
            minutes will will note you away and tell the time you have been gone. When you return
            it will tell you on how long you have been away.

Email: foosh@wwdg.com
Web Pager:http://foosh.netopia.com

Thank You for using this addon
