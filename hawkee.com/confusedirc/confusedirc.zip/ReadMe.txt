Confused IRC Search was created EvilJason!
Graphics made by gL0baL...

I can  be found on Newnet: irc.assassination.org 
Nick: Eviljason
E-mail address: CoNfUsEd@CyberClan.com
please visit the Cyberclan homepage at 
Http://www.CyberClan.com 

This script was created to search popular IRC
networks for a particular user or a number of users.
I have worked on this for about a month and I think
i have gone over every error I could encounter.
There are a few errors that you may encounter and you 
can look up the problems below.  If you cant find a sollution
e-mail me at: CoNfUsEd@CyberClan.com

!!FIRST!!
load the ini file:confusedsearch.ini in remotes.
Type: /search to begin

keep all these files in the same directory!


This script searches the following networks:
Efnet 
Dalnet
Undernet
Newnet
more servers to be added later.

Possible errors:

Q: Why am i getting a bunch of errors like DRAWTEXT Unknown command?
A: You are not using mIRC 5.31 or higher!

Q: Why is it that I cant find anybody and the search takes forever?
A: Maybe you're not connected to the internet? or using a firewall? or 
have a slow modem, or no person matches the search string you supplied to
the script. 

Q: I can't find my friend dammit, what is wrong?
A: Are you typing the persons name right and/or
using wildcards like "*" or "?"

Q: Yes I am using wildcards and I still cant find them,
what is wrong with this damn thing?
A: Is your friend +I (invisible)?
or on one of the IRC networks that i have listed above?
maybe he/she is on a split server or not connected 
at all.

Q: My computer slows down and mirc freezes,
whats it doing that for?
A: maybe you did a search for an address that matched 
thousands of users, just wait until its done.

Q:Why isnt the little blue bar moving?
A: Because it is either collecting information or
its waiting for information.

How this works:
Well i created the picture window making it look 
like the Win95 search program.  It took a basic 
knowledge of picture windows, socket commands, mirc,
and basic geometry to create this.

Here is the procedure:
I connect to a bunch of IRC networks using hidden
sockets.  I do a /who "Person/Address".
I collect all the information.
when i recieve the "end of /who" raw numeric I
disconnect from the network.
Then you click the results button and see your 
search results.