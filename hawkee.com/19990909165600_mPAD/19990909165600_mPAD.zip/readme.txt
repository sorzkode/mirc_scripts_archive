mPAD v1.1 �1997 Quetzilla
A customziable toolpad with support for 20 selections

DISCLAIMER: This script is not to be modified in anyway without my
expressed permission.  The accompanying sample.pad and sample.bmp
may be modified and distributed freely.

mPAD is a customizable toolpad for mIRC with support for 20 choices
that was originally made for use with another project of mine (a visual
devlopment kit for mIRC scripts with point'n'click GUIs (Graphical
User Interfaces)) but as I was making it I realized its pretty nifty in
itself so here it is.

NOTE: If you didnt unzip mPAD to your mirc folder, move it and the
sample files there before loading mPAD.  You should also have your
remotes set to on.

________________
|  Using mPAD  |
����������������

To load mPAD either load it from the remotes menu or type:

 /load -rs mPAD.mrc

Once loaded the default .pad file is sample.pad, and its accompanying
.bmp file, sample.bmp.  To load a different .pad file hold Shift and
press F2 or type:

 /sf2

and select a .pad file.  The .bmp file should be in the same directory
as the .pad file and have the same filename except with .bmp instead of
.pad

To start mPAD simply type:

 /toolpad

mPAD has two modes, ClickActive being enabled or disabled.

It defaults to being disabled, in which case clicking a button in mPAD
assigns variable %tp.tool to the appropriate value designated in the
.pad file.  You can then use the sample alias /pad which will run the
commands listed under the selected section in the .pad file.

If enabled it will automatically play the commands listed under the
designated section as soon as you click an mPAD button.

To toggle ClickActive on or off type:

 /tpclick

___________________________________
|  Creating your own mPAD setups  |
�����������������������������������

Section 1:  the .pad file
����������

A pad file can consist of up to two parts, one required, one not.  The
required part is the assignment values for the mPAD buttons.

figure 1:
[toolmap]
1.1=11
1.2=12
1.3=13
1.4=14
1.5=15
1.6=16
1.7=17
1.8=18
1.9=19
1.10=10
2.1=21
2.2=22
2.3=23
.
.
.

Each assignment has 2 parts, the coordinate and the value:

       1.1    =      11
       ^^^           ^^
    coordinate      value

The coordinate has two subparts, separated by a . (period), the first
being the x coordinate and the second being the y coordinate.  The
value determines what %tp.tool is set to when an mPAD button is clicked

The not required part are the sub areas:

[11]
echo -a 11

[12]
echo -a 12

[13]
echo -a 13
.
.
.

the part in []'s refers to the value from the assignment portion
explained earlier.  The command(s) underneath are what are executed
when either sample alias /pad is used or ClickActive is on and an mPAD
button is pressed

When making your .pad file it is suggested you simply alter the sample
.pad file

Section 2:  the .bmp file
����������

The .bmp file is what shows the icon and/or text for each button,
the olivish background color is used for transparency and should not be
altered, the gray boxes formed are where you should draw your icons
and/or place your text.  Once again, it is suggested you alter the
sample.bmp when creating your own mPAD setup.


Thats basically everything, have fun!

Quetzilla jmquin@worldnet.att.net