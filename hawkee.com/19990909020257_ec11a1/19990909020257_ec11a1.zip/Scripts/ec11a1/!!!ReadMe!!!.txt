+----------------[everclear 1.1a1]---------------------+
 Welcome to everclear version 1.1 alpha 1.  If you do 
 not have it already, you will need to download the 
 font that is used in this script (gwdte_437.fon) and
 put in in your fonts directory.  You may get it at :
 http://kmv.simplenet.com/gwdte_437.fon  Online help
 will appear when you type /hlp.  Please use the popups
 to your best advantage.  Thank you, and any questions/
 comments may be sent to vega@mirc-scripts.com, or you
 may fill out the online feedback form at :
 http://kmv.simplenet.com/index1.html  Thank you. 
                                       - Matt
+------------------------------------------------------+