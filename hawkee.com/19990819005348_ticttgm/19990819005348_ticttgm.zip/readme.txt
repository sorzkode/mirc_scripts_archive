______________________Multi Tic Tac Toe_____________________

Author:		VeNo[M]
E-Mail:		venom@sodnet.com
WWW:                        http://siege.cjb.net soon to be www.sodnet.com
________________________________________________________

_________
Installation
_________
	1. Unzip ticttgm.zip to your mirc dir
	2. Run the mirc in that dir
	3. type in the command line //load -rs $mircdirticttgm.mrc
_________
What is this?
_________

	This is a Tic Tac Toe game i created it took me about a day
to get all of the coding correct and i had to find beta testers.  This Game
allows you to connect to another user of this addon and play Tic Tac Toe
with them.
_____
Usage
_____
	1. type in the command line /tictactoe 
          Host Mode..
	1. If you want to start a came hit the button Host Mode..
	2. Than tell a friend to open up tic tac toe and hit Client mode..
	 and connect to your ip address
	3.Once they are connected you start off.
         Client Mode..
	1. If you want to play with someone who is hosting a game
	hit the button Client mode..
	2. When it asks for the ip to connect to use the persons ip 
	who is hosting the game.
	3. Once connected wait till it is your turn.
__________
Requirements
__________
	1. mIRC5.4 or higher
	2. Another friend to play with.