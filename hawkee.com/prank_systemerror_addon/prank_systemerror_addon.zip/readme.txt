just a silly little 'novelty script' *c0f*addon*c0f*
that just makes you feel bad.  i made it the first day
5.3 came out, and lost, and just found it. wasnt exaclty
something i planned to put anywhere, but hey. just a
little something to give to your friends for a few
laughs.

					-zygote