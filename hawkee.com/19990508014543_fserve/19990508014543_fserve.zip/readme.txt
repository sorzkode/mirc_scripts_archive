File Server v1.1 by Hawkee
This script will give you the ability to keep
a ratio on your file server.  People must upload
a certain number of bytes before they may take 
files from you.  This also includes a few
extra features such as a top downloads record
and a custom file server mode.

Installation for mIRC 5.11 users:
  Unzip the .mrc files into your mIRC directory and from inside mIRC, type
  /load -rs fserv.mrc and it will be loaded.

Questions and Comments: Hawkee@hawkee.com
Updates: http://www.hawkee.com/hawkee.html

