========================================================
�$Makaveli$� Email System by str8ridah
========================================================
"God said he would send his one begotten son, to lead 
 the wild into the ways of the man ... follow me."
========================================================
HOMEPAGE: http://mak.home.ml.org
========================================================

LOADING FILE:

All you have to do is extract the files to your main irc 
directory and then in irc type /load -rs makmail.mrc

Click yes to running the initialization commands.

