hellish@efnet

type "/load -rs d:\path\blend.mrc" and use the parameters below
this was made as a novelty script for hawkee.com
you specify the parameters to make cool looking color blended windows with shadowed text
use as splash screens in your script

/blend <-b|-g|-p|-r|-s|-t|-w|-y> [<font> <size> <color of foreground> <color of background> <distance from top of window (pixels)> <text>]
  -b = blue blending
  -g = green blending
  -p = purple blending
  -r = red blending
  -s = specifies that you are making shadowed text, not blended colors
  -t = teal blending
  -w = white (grey) blending
  -y = yellow blending

 if you specify -t as your parameter 1 flag...
  <font> = the font of the shadowed text (sorry, only one worded fonts)
  <size> = the font size
  <color of foreground> = the color or the text foreground
  <color of background> = the color of the text's shadow
  <distance from top of window> = the distance from the top of the window at which the text will be placed
  <text> = the text you want to be displayed on the window

  the text will automatically be centered (widthly)

Example:
  /blend -t
  /blend -s arial 50 12 1 75 HIGH

 This will make a teal blend, and shadowed words (blue foreground, black background) in font arial size 50 that says "HIGH" 75 pixels away from the top of the window
 If you just understood that, have fun

 PS: after the window is formed, it is closed by clicking on it
