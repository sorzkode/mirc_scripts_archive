[TVivo] v4.13 by Pepsi Lizard

About:
This script is designed to allow a user to use aliases in mIRC to play VIVO files. VIVOs are video files that use a high ratio of compression.  For more information on VIVOs themselves go to http://www.vivo.com [NOTE: The VIVO files will have to have to be associated with a VIVO player.]

Commands: [USAGE: /VIVO (COMMAND)]
SETDIR: Sets the default VIVO directory
CTCP: Toggles channel CTCPs when playing a VIVO[on/off]
PLAY: Lets the user pick a VIVO file to play
INFO: Shows information about a VIVO in a new window
VER: Echos the version of TVivo
SHOWVER: Shows the version of TVivo in the current channel
AUTOGET: Toggles get requests when a VIVO is played[on/off]
SEND: Toggles the sending of VIVOs when a get request is received[on/off]
HELP: Shows the window

Loading:
In mIRC type /LOAD -RS <PATH>\TVIVO.MRC  A dialog box will then popup asking you to find your default VIVO directory.

Bugs:
NONE right now. DCC works fine even with spaces. Email me if you find a bug tho.

Credits:
   Author: Pepsi Lizard [th1rt33n@antisocial.com] [http://members.xoom.com/th1rt33n]
   Original concept and standardization of DCC thingy: sHADoW-c [shadow_caster@hotmail.com] 
   Shouts: genocide [genocide_rs@hotmail.com] for teaching me a lot about scripting.