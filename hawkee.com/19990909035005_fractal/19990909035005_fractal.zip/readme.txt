                       ..mIRC on Fractals..
Each of these take a really long time to generate.  About 20
minutes on my box.  I know someone who gets em in 5.  What the
hell?  This is mIRC after all.  I droped a lot of stuff that would
have made them easy to modify.  They're so damned slow I can't
picture anyone waiting around for the results anyhow.  If you want
something to play around with, email me and I'll give you a pascal
version of each.  If you wanna know more about fractals; go to the
ferking library. =]  I just barely understand them myself.

Type /load -rs fractal.mrc once you have unzipped the file to your
mIRC directory.  

/mandelbrot runs the Mandelbrot fractal
/julia runs the Julia fractal

Script by Breadball (bread@mirc-scripts.com)