
 #####################################################
 ##                                                 ##
 ## '���������������������������������������������' ##
 ## LLL                          LLL   LLLLL        ##
 ## LLL    LLLLL   LLLLL LLLLL  LLLLL LLL LLL LLLLL ##
 ## LLL   LLL LLL LLL       LLL  LLL  LLL LLL LLL   ##
 ## LLL   LLL LLL LLL    LLLLLL  LLL  LLL LLL LLL   ##
 ## LLLLL  LLLLL   LLLLL LLLLLL  LLL   LLLLL  LLL   ##
 ## ._________________________________________. 1.0 ##
 ##                                                 ##
 #####################################################
 ##                                                 ##
 ## Locat0r 1.0 by ArLo           December 23, 1997 ##
 ## arlo.fatalerror@usa.net                         ##
 ##  _____________________________________________  ##
 ##  The FIRST in a new generation of mIRC scripts  ##
 ##  ���������������������������������������������  ##
 ## A Minesweeper clone for mIRC 5.3 ONLY.          ##
 ## Check out my mIRC script, AsKrYpT, at           ##
 ## http://www.geocities.com/ResearchTriangle/8606/ ##
 ##                                                 ##
 #####################################################

 Requirements:

 mIRC 5.3
 Due to the advanced features that Locat0r uses, it
 WILL NOT work on any mIRC lower than version 5.3.

 #####################################################

 Installation:

 Unzip into your main mIRC directory.  You should have
 a folder called "locat0r\" in your main mIRC
 directory which will contain a bunch of files that
 are needed by Locat0r to run properly.  Now, in mIRC,
 type this:

 /load -rs locat0r\locat0r.mrc

 Then type /locat0r to run the game.  Enjoy.

 #####################################################

 Notes:

 The "uncovering-blank-space routine" isn't like the
 real Minesweeper's.  It's more challenging this way.

 The grid size is unchangeable.  (I have to leave
 something for the next version... right?)

 ############################################# ArLo ##
