Agent Orange DCC Partyline v2.2
-------------------------------

This ish is easy to use. Just type "/load -rs orange.mrc" once you got
all the files from the zip into your mIRC directory and everything pretty
much takes care of itself. I think ya'll will dig the console. I recoded
a little bit of the console stuff. Like getting rid of that damn "/dccconsole"
popping up everytime in the console. That was annoying. Enjoy.

- Decker
