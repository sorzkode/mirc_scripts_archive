  >----- ---- --- -- - Nav-Script v.2 by Goldfing - -- --- ---- -----<

To load the script type:
/load -rs c:\directory\nav.mrc

You will be asked if you want to continue (Twice), just press Yes if you do.

          *** History Stuff: ***

Nav Script is the follow up of the former @Great-Nav script, which was scripted for mIRC 5.11.
I gave that script a rest and pursued other business (Spy-Script), until I saw mIRC 5.5's dialog support.
Within 2 days I had the core of this script done, and the rest was to follow. It took me some time to get to finish it, but at last...You can see the result.

What's New?
Nothing...Except a whole new more 'professional' design.
Actually, I re-did the whole script, and haven't used much from the old one. It should run much smoother now.
Plus, I added a Connection Timer, which tells you how long you've been connected to that Host.

Khaled (the maker of mIRC) has changed the way F-serves work a bit, and that made it rather harder for me,
I wanted to add a DownLoad-Queue, but Khaled's changes didn't allow it.

E-mail me at yosko@netvision.net.il
or meet me at irc.mystical.net

Enjoy,
Goldfing
