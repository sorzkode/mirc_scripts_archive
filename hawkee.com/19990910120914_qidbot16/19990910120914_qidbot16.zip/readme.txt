  __  _____   ___    ___    __   _____
 /  \   |    |   \  |   \  /  \    |
|    |  |    |    | |___/ |    |   |
|  \ |  |    |    | |   \ |    |   |
 \__X __|__  |___/  |___/  \__/    |
  ______________________________________________________________________________
 /										\
| QIDBot is designed to run with mIRC 5.4.  It is mostly standalone, though it   |
| can work as a remote script.  Please read this file fully before starting.	 |
|--------------------------------------------------------------------------------|
|										 |
| Before you get started, be warned: QIDBot works best in a second copy of mIRC, |
| in an entirely separate directory on your hard drive.  You can still use it    |
| with your script if you want, but if you have problems, reinstall everything.  |
|--------------------------------------------------------------------------------|
|										 |
| Let's begin.  First off, put bot.ini and monitor.ini in your mIRC directory    |
| (make sure mirc32.exe or mirc16.exe is in this directory).  Run this copy of   |
| mIRC.  Now, we need to do some setup.  Make sure you're connected to a server, |
| then type /load -a bot.ini (to load the aliases) and then /setup (answer the   |
| questions).  Make sure the correct files are selected when you hit OK.  You    |
| can also choose whether or not to load the QIDBot popups.  This is		 |
| reccomended, it makes some functions easier, but your Status popups will be    |
| gone (unless you know where your current popups file is and how to reload it). |
| Of course, if you're using a separate copy of mIRC like I told you to, this    |
| shouldn't matter much.   After /setup has completed, everything should be      |
| loaded and the bot should be on.  The popup (if you chose to use it) should    |
| appear and function properly.  It's only in the status window.  You should     |
| also see a little message saying:						 |
|										 |
| Loaded script/users(/popup) '<filename>' 					 |
|										 |
| The bot is now loaded.  Type /set %QID.admin <yournickname> to make yourself   |
| the bot's admin (you can also access this through the popup).  Once you have   |
| done this, the bot is ready to be used.  Always use separate windows for	 |
| yourself and the bot so you don't encounter any problems.  If the bot won't    |
| respond to your commands, get on irc.3dnet.net or Undernet and ask me.  My     |
| username is most likely QID, although I might be [QID] or QIDBot.  There are a |
| few things you will have to do manually, such as deleting users, since I do    |
| not know how to automate this without making it insecure.  If you do, please   |
| tell me so I can make this bot better.  If you need to know the commands, type |
| !commands (from your separate window).					 |
|--------------------------------------------------------------------------------|
|										 |
| Monitoring a channel								 |
|										 |
| This is one of the most complicated things the bot will do, so I made a        |
| separate section for it.  In order to monitor a channel, these must be true:   |
|										 |
| 1).  The bot is in the channel						 |
| 2).  Your current username is defined as the admin				 |
| 3).  You are not in the monitored channel					 |
| 4).  Monitoring is on for the channel						 |
|										 |
| To turn monitoring on for a channel, type !set monitor on #channel  This sets  |
| %QID.monchans to #channel  If you like, set this yourself with /set (make sure |
| the names are right).  If you turn monitoring on for another channel, say,     |
| #temp, then %QID.monchans will be #channel #temp (including the spaces).  At   |
| present the bot will tell you everything that happens, except messages it      |
| receives, since you might have to communicate with it through messages.	 |
| Thanks for using QIDBot!							 |
|--------------------------------------------------------------------------------|
|  David Osolkowski				             larryo@buffnet.net	 |
|										 |
|  	     Visit my webpage at http://free.prohosting.com/~davido		 |
 \______________________________________________________________________________/










