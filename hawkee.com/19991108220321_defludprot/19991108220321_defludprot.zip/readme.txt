De�ire Flood Protection v1.5 **
Author: ZFact0r              **
Date Finished: 10/28/97      **
Date Started: 10/09/97       **
Filename: flood.mrc          **
Size: 11KB                   **
*******************************

Thanks for your interest in De�ire Flood Protection. This add-on was made 
with the script De�ire in mind, but it can be used with other scripts.
This script contains protection from CTCP and msg "floods", and character 
floods. In the future I hope to add nick flood, text/action flood protection,
and  channel protection. To load up this script just type:
/load -rs <directory of the file>\flood.mrc (ie. /load -rs c:\mirc\flood.mrc)
*****************************************************************************
Updates: 10/11/97
1. Created CTCP flood protection for maximum/normal/minimum levels
2. Created MSG flood protection for maximum/normal/minimum levels
3. Created Online help
4. Created Character flood protection for maximum/normal/minimum

10/29/97
1. Fixed the default settings bug
2. Changed it from nick to address = better protection
3. Added  the if op to the kick for character flood.
