- -- --- ---- ----- ------ ------- --------Spy-Script-------- ------- ------ ----- ---- --- -- -
Installation:
type:
/load -rs Spy.mrc
You will be asked if you wish to continue, Press Yes.
A window will Pop-Up with the terms of use, Accept it to go on.

The main usage of this script:
This script enables you to "take a peek" at your friend's Computer, and see what's going on in his
private chats. This script has great distruction potential, even if I took out all the file 
handling options (/remove,/remdir,mkdir,copy,move,etc.). I hope you won't misuse your power, and
use the script for it's main use: "harmless fun", just sit back, and watch all your friend's
secret chats. This script also has some helpful qualities. As an example, lets say my friend needs
something in mIRC, like to load a script, I can just log into his computer and do it for him, and
save some time on the phone, or on-line.

Known Problems:
1. When clicking on a @Spy- window, it doesn't become active. You need to set it active by
  clicking on it's name in the Spy-Task Bar.
2. The Close Window Pop-up doesn't work because of a bug in mIRC.

For further information, Contact me:
yosko@netvision.net.il
Goldfing on DALNET/irc.Mystical.net