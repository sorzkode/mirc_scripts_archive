little screen saver when idle over 10 minutes....
erm. stupid menu dont work...actually its just in an
infinite loop, and the mouse over commands dont work
because of it....so just CONTORL + BREAK, that means at
the same time press control and break for you computer
illiterate people...and it will break it out for you
dont try to close the window until it actually halts, 
you will probably end up closing your mirc instead
o well, if anyone can figure a solution lemme know.
                                            -zygote@ef

PS. Dont unload this manually, unless you want all the
variables to stay in there. type /screen.u to unload..