addon.faq+dp1
by deadparrot
_______________________________________________________
I decided to write this faq because all of the other
faqs on this subject are outdated. [x|x] and webba's
addon.faq gets the main point across, but that is for mirc472.

I encourage scripters to start using this medium for scripting, so those who use your script are capable of making addons for your script.

When you load installer.mrc into remote, type /install
and it will bring up the installer.  Choose an .mrc addon to load and the installer loads the addon into your mirc remote and adds credit for the addon in your /ad alias, You should make version.txt something like this:

/me uses %ver v1.0 with

(where %ver is your script name)
than your script ad should be this alias, which is included in the installer.mrc.

/ad {
  play -c version.txt
}

any addons you load to your script will show up in the /ad alias.  So, let's say your script name is Lame Script, and you load the addon: LameTalk by LameGuy.  After you /install the addons, you will be prompted for what to call the addon, or the %variable for the addon's name.  Let's say you fill that blank with 'LameTalk by LameGuy'.  Than your /ad alias comes out as.

* Bob uses Bob's Script with LameTalk by LameGuy
             (%ver)          (what you filled in)

and you can continue to add addons to your script with this /install command.  

It's wise for scripters to adapt some sort of medium for the variable the addon name's can be called by.

/minstall is the command to load a script using a %variable for the script's name.

deadparrot on DALnet