Official documentation for VoodooFetch version 1.2 beta by WEIRD_H

This script was started way back in March and has not been touched since.
I decided to submit it as is becuase it fits the guidelines of the monthly
challenge and it does actually work. This script is not well tested and
may have many problems but I simply did not have the time to update it
in time for the monthly challenge.

There have been no updates to include any mIRC 5.4 features but the script
should still run on 5.31 and up.

Unzip all the included files to any directory and load vdfetch.mrc to your remote
section in mIRC.

To use the script simply type /vdfetch <URL> 

This will pop up a small window. If you did not specify the URL you can now enter
one in the edit box and it will attempt to download the file.

Right click for popups that allow you to change a few options.

***Known Problems***

Certain large files, especially MP3's over 5MB may not download correctly. Im not
sure exactly why but I will try to fix this for next version.

If you are downloading from an FTP address, replace the ftp:// with http://  Thats
the only way it will work right now, sorry.

Features are sparse right now as is documentation. Hopefully I will be able to update
this script soon. Use the about menu to check for updates and notices.


-Author information-

WEIRD_H

weird_h@geocities.com

Find me on Undernet, channel #Kelowna 