Hello, Welcome to Spaulding Script v0.1. 
	This is my first attempt at writing a script and
its REALLY easy to install. Just make a new folder c:/spaulding
And copy all the files to it. Paste a copy of mIRC32 also to 
C:/spaulding . Thats it! Just run mirc and your done!