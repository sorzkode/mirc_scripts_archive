                                    +-+-+-+
                                    |M|P|3|
                                    +-+-+-+
                                                                           
                                +-+-+-+-+-+-+-+
                                |S|t|a|t|i|o|n|
                                +-+-+-+-+-+-+-+
                                                                          
                                    +-+-+-+
                                    |B|Y|:|
                                    +-+-+-+
                                                                            
                              +-+-+-+-+-+-+-+-+-+
                              |C|h|a|m|e|l|e|o|n|
                              +-+-+-+-+-+-+-+-+-+
	 	  http://fighters.simplenet.com/mp3station/
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
To load MP3 Station: 
1. Place mp3station.mrc into your main mIRC directory
2. type /load -rs mp3station41.mrc
3. Enjoy!
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Updates Since Last Version:
1) You can now play mp3s with file spaces....FINALLY!
2) Took out some of the flashiness
3) Made the MP3 Window optional 
NOTE: I am working on the time of the mp3 to get it to be more accurate.
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
After it is loaded and MP3 Station asks for setup information MAKE SURE 
that your main MP3 directory is in this format c:\whatever\
The last \ is important.
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
A quick way to play a MP3 is to type /playmp3 - after you type it a 
window should popup asking you what MP3 you want to play - or use the 
popup.
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
For a complete list of MP3's in the directory you specified when you
setup the addon just type /mp3files - Its also available through the 
POPUP
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
To generate a HTML list of every MP3 in the MP3 Directory you designated
in setup type /htmlmp3gen - or use the popup.
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
To reset the Jukebox press /mp3reset - or use the popup.
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
If at any time you need to resetup MP3-STATION either press /mp3setup or use 
the SETUP in the Channel Popups
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Send suggestions and comments to:
mkmyth@hotmail.com 
I can also be found all the time in #Mkdomain on any undernet irc server my nick will be Chameleon.
