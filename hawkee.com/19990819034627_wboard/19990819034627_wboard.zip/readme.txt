PLEASE read the enclosed wboard.txt before doing
ANYTHING.