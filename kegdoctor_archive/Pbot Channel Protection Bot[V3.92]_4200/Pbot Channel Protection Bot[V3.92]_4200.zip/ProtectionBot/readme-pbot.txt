Pbot (pronounced pee-bot) was borne out of desperation. Our servers were attacked on a daily basis, and we had no protection to help us. We tried using other bots out there on the internet, but they were all of limited help. I was an IRC operator on the (annonymous) server at the time, and took it upon myself to write a bot that would offer full protection to our server. Pbot evolved all the time, I used all the attacks as an opportunity to study their patterns and write algorithms to protect agaisnt each one of them, thse attacks then also evolved and pbot had to adapt to each of these attacks. It was not long before hundereds of our IRC users grew to rely on pbot for their personal security and protection on their day to day chat.
�
Pbot's popularity grew and it was not long before I was asked for the code, as people wanted to secure their servers too. mIRC being such a popular IRC client also was an advantahge as Pbot was written as an addon to mIRC. Word spread around the IRC community and it was not long before the number of requests grew, and I was asked to release Pbot to the public.
�
I now present to you Pbot, and hope it will serve you and your IRC community well. Pbot has had combined downloads of over 50000. On just one site (www.mirc.net) close to 30000 downloads. Pbot was never made for the public, and it is both surprising and touching at how much interest there has been in this project.
�
###################################################################
��
Alot of people ask, why have you not made pbot more flexible? Why can't i set it to warn kick and then ban? etc
�
To answer these questions one must understand the essence of pbot and what its aims.
�
Pbot dislikes kicking or banning anyone., its main aim is to keep the channel happy and active. Its goal is to remain silent and even hidden in the channel. Pbot does not like making its presence known.
�
Pbot will only kick-ban true spammers, for example if a users floods, the user will only get kicked, if the user floods, the user will get kicked again. It is only on the fourth or fifth time that Pbot will place a ban on the users host, as that user has proven beyond doubt that its a true spammer.
�
Furthermore is a user places the following text in a channel:
�
"SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM"
�
Pbot will instantly ban its host, as this is most definitly not a mistaken flood. It is a real attempt to spam a channel, in this case Pbot is not going to quander, should i give this user another chance? Pbot is urgently thinking about channel security, and in this case Pbot will instantly and urgently remove the user from the channel.
�
The same goes for many more spam patterns. The above was only and example.
�
In a nutshell, if pbot is in doubt, it will give the user another chance or two, if it is certain why waste time and put other users security at risk.
�
�
�
Further reading:
###############################################################
This section is for those who can give IRC operator privileges to Pbot, in order to realise server wide protection aswell as local channel protection.
�
�
BOTNETS:
�
These are the more serious threats to IRC users today.
�
WHAT IS A BOTNET?
�
Botnets are generally automated bots that can sometime number in the thousands, they will tend to mass join a server or channel, and spam the server and chanel making it unusable. additionally these mass connection can crash the server thus disconnecting everybody.
�
WHAT CAN PBOT DO?
�
Pbot can do a hell of alot in these circumstances. This is done by surrounding the server with three walls of security.
�
1. Scanning incoming IP addresses
2. Scanning joining users
3. Monitoring users once they are on a channel.
�
SCANNING INCOMING IP ADDRESSES:
�
Each incoming IP is scanned and compared against global proxy and blacklists. If a match is found the IP is instantly glined from the server. It is unlikley a botnet or spammer can get past this first layer of security. Usually botnets will match some proxy list somewhere.
�
SCANNING JOINING USERS:
�
In the unlikely event that a spammers get past the first layer of security. Pbot will aoutmatically scan the user AGAIN once they join a channel, in an attempt to build up a profile for that user. Pbot will google the users IP address, to see where that user has been on the internet, what records exist for that user? have they been on any forums? left any spam comments? if records exist, what websites have they been on? pbot will then slowly cral additional proxy and blacklists to try and build up a rundown of sorts on that user. It should be noted that pbot won't always act on information found, just to set a sensitivity level if that user does do something not in form with day to day IRC dialogue.
�
MONITORING USERS ONCE THEY ARE ON A CHANNEL:
�
Once the first two security checks have passed, still Pbot does not rest. Pbot will constantly monitor that user for any unusual behaviour, and act appropriately if this users places other channel members at risk.
�
####################################################################
�
WHY USE PBOT?:
�
This indeed is a good question, I mean on our server we have not had an attack in 6 months, and maybe on your server you have not had one in years? Why the need for so much security?
�
The answer is two pronged:
�
Firstly it is because security exists that attacks have dwindled in numbers! If houses had no locks there would be MORE buglaries, security needs to exist for the sake of security.
�
Pbot was initially written out of desperate need for our server which was under daily attack, when pbot was written and placed on our server, it started dealing with these attacks. Botnets were wiped out, spammers killed off, and drones were instantly destroyed.
�
We then started noticing after a while that the number of these attacks started plummetting. Attacks turned to a weekly episode, then fortnightly then to just every now and again. It was because that the attacks were dealt with that the people behind them realised that the damage they could inflict was negligible and gave up.
�
Secondly: like a quiet art gallery who have had an expensive painting in their possesion for years, suddenly have a burglary, out of nowhere, the same can be applied to IRC, an attack WILL happen, maybe not today, or even months... but it WILL happen and when it does you want to be ready.
�
We hope you never see Pbot in action, under a carefully planned server attack, but if you do prepare to be impressed, and be confident that your users security is unwavering in its commitments to protect and serve your IRC community.
�
;eof
