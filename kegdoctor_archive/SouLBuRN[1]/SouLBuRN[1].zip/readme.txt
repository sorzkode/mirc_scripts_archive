SouLBuRN Script 2000 Advanced Edition...
---------------------------------------------
After you open this folder with winzip, do not extract
anything. Just click on Setup.exe then press OK in the 
dialog which appears just after clicking on Setup.exe, then
wait for few seconds and install.exe will run.
-----------------------------------------------------------------
Important: If you want SouLBuRN Script Advanced Edition
to work perfectly, you must install this script C:\SouLBuRN\
------------------------------------------------------------------
--W00DeLF-- 1999