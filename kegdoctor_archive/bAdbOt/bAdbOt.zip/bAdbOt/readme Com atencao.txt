PASSWORD====<BADBOT>



====
=============CHANNEL ROBOT Version 1.0 By BaDBoY_17---------> 
====
FEATURES:
Channel controls: VOICE, DEVOICE, OP, DEOP, KICK, BAN, BANLIST, UNBANLIST
Protects masters from: KICK/BAN/DEOP 
Full personal CTCP protection
====

SETUP:
1. copy into and run mIRC in the bot dir ( default setup dir was c:\cbot )
2. When the bot starts for the first time you should be prompted to set a password. 
3. Enter a password to set the master password.
4. Get the bot online with you and /MSG<BOTNICK> �password�
5. you should then be set as the bots master
6. the pass is �badbot�

To add other masters have them /MSG the bot with the badbot
To change the password type /pass in a bot window.
====
====MASTER COMMANDS-------> 
(ALL COMMANDS ARE DONE IN A CHANNEL WITH THE BOT)
====

ADDMASTER <NICK>
REMMASTER <NICK>
OP ME (ops you)
OP <NICK> (ops another nick)
VOICE <NICK> (voices a nick)
DEVOICE <NICK> (devoices a nick)
DEOP ME (deops you)
DEOP <NICK> (deops another nick)
KICK <NICK> (kicks a nick>
BAN <NICK> (bans a nick)
BANLIST <NICK> (adds a nick/address to the bots banlist)
UNBANLIST <NICK> (removes nick/address from the bots banlist)
PING ME (bot pings you and notices you the reply)