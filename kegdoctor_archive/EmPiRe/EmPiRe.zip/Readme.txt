if u guys have any problem see me in #MoViE-EmPiRe on Dalnet!
i made this for Dalnet.... it can be used on other servers with Chanserv 
Well ahve Fun!
My E-Mail : nitin0@home.com

Unzip the file [[ i guess u have done that till now :p ]] and put the 
files in ur scripts main dir.
.
.
.
Well now that u have done that
Open ur Script............ 
&
just type /load -rs EmPiRe Protection.mrc

the Script should load .. and WOHoOOOO! ur DONE :)

Thnx!
