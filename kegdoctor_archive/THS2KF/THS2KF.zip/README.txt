Torment Hellscript 2000 Final

Extact Zip To Temp Directory
Double Click Setup.exe


:::::::::::: INSTALL AND SETUP TIPS :::::::::::::::::::

DO NOT INSTALL SCRIPT TO YOUR PROGRAM FILES
MAKE SURE INSTALL DIRECTORY IS A 1 WORD DIRECTORY
For Example: c:\TorHellScript
             d:\TorHellScript
             c:\Torment

DO NOT INSTALL TO
For Example: c:\Program Files\Torment
             d:\Torment Script
             c:\Torment Script

ALSO WHEN SETTING UP YOUR FILE SERVER
DO NOT MAKE YOUR ROOT DIRECTORY OR ANY OF YOUR
MULTIDRIVE DIRECTORIES 2 WORD DIRECTORIES.. IT CAUSES ERRORS
It's Ok To Have 2 Word Sub Directories
For Example: This Is Ok To Do

Root Directory: c:\fserv
                c:\warez
                c:\warez\music\
Sub Directories Located In The Root Directories Can Be Named Anything
                