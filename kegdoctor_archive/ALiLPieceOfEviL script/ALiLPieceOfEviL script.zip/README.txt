Install

Extract ALPOE_Install.exe
Double Click To Install

Find Icon On Desktop
And Start!