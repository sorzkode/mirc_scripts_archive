==========================================================================
TopazChat Version 4.01b
==========================================================================

Version 4 works with a redesigned internal interface, which should make
it more stable.  See version changes below.

Redesigned things a bit for version 3, see version changes below.

Note:  /join on and /join off commands have been changed to 
/joinres on and /joinres off to avoid having the chat "join" the
channel "on"


2.070 now includes user join responses for anyone entering the channel, not
just those on the list.  To set up phrases for any user, set the phrases
for the "ANY USER" section of the standard user join list. It also includes
timer operations, see below for use of this feature.

******* Note: ************************************************************
	As of version 2.060 all whisper commands must begin with "/", such
	as /say, /join, /squelch... this prevents accidental problems when
	another owner is talking to you and begins a sentence with a word
	like "say"

TopazChat is a battle.net chat interface that offers many features not 
normally available in Starcraft or Diablo, making chatting much simpler 
and flexible.  It also has many automatic response features and whisper 
commands, allowing it to be used as a bot, a channel op, or just to annoy 
spammers in general.

To run TopazChat, make a directory and copy the TopazChat.exe file there.  
No other files are necessary to run the program, except those that are 
auto-created by the program when it is first executed.  


--------------------------------------------------------------------------
Logging on to Battle.net
--------------------------------------------------------------------------
To connect, just click [Connect] and then [log on].  You may wish to 
change your name and password to something other than "guest".  This name 
MUST be a name you have already established on Battle.net, either with 
Starcraft or Diablo.

Common problems logging on:

If you are connected and you press [log on] and nothing seems to be 
happening, there are several possible problems:

- if it says "log on failed", but TopazChat is connected, then the server 
you selected may be down.  Disconnect, change servers, and try to connect 
and log on again.

- if it says "logged on" but nothing is happening, not even a channel 
name in the upper right, then you probably entered an incorrect 
name/password combination.  The name MUST be one you have set up with 
Diablo or Starcraft first, otherwise you can only log on as Guest.  This 
can also happen if the server is not responding, try changing servers and 
connecting again.

Sometimes TopazChat will not join the channel you have entered for "home 
channel" in the configuration.  This is particularly true if the server 
you selected is slow in responding that day.  You may need to manually 
change channels with the [channel] button.  I am working on a way to fix 
this problem.

Try to avoid using the [log accounts] and [display accounts] option if 
you have the "/whois on join" turned on in the configuration.  With [log 
accounts] on, every /whois command will store the name and number of the 
person.  With "/whois on join" active, every single person who enters the 
channel will be stored and the list of users will grow quite large.  With 
[display accounts] on, TopazChat searches through its list of saved 
numbers to find the person who you did the /whois on.  If this list is 
huge, it could slow the program down.


********  WARNING: please use the text file feature wisely... if this or
other programs abuse the battle.net chat gateway by excessive advertising 
and/or flooding, Blizzard may decide to remove the chat gateway.

--------------------------------------------------------------------------
Timer Operations
--------------------------------------------------------------------------
You can define certain phrases to be said every so often, ranging from 
every 1 second to every 9999 seconds (avoid using anything less than 3
seconds, otherwise you run into the danger of being flooded off).  As with
all response options, there is no limit to the number of phrases and time
intervals you can define, and the <user>, <random> and <drandom> codes 
work for these phrases.

--------------------------------------------------------------------------
Version information
--------------------------------------------------------------------------
4.01b
	fixed responses an whisper responses not working if the ignore
		code is blank
4.01a	
	fixed problem of connection not responding after cancelled
	reduced size of toolbar
	added specific user banning
	added color support for individual users and easier color setup
	added user-definable flood delay
	added response ignore code
	redesigned help screen
	added ability to reorder custom user list
4.00b
	fixed access violations with responses if only 1 of the 3 
		responses is filled in
4.00a	
	redesigned battle.net components
	added history buttons for scrolling back to read/copy text
	added ability to send URL's to other TopazChat 4 users
	added launch menu for running Starcraft, Diablo, or battle.net and
		blizzard websites
	fixed problem of chat saying it was connected before it was
		actually connected
	hopefully removed random access violation that terminates chat and
		rare cases of chat eating up resources
	improved anti-flooding		 
3.010
	changed layout of main screen
	put configure and setup into one screen
	added whisper responses 
	added text file whisper capability, and text file ability for
		responses and whispers
	made anti-flood settings more stable
	
2.080
	made connection more stable
	added enter/leave notification
	added auto-rejoin when kicked
	moved display and log account options to Settings screen
	added emote and away buttons
	added chat and whisper window text file save on right click menu
	added /exec, /stop, and /reset whisper commands (see configure 
		Screen help)
	
2.070
	fixed message length/cut off problem
	fixed resetting of file position when a new text file is loaded
	timer operations
	included alt-N for name copy
	user join response for all users
2.060
	whisper window on double click option added
	minor fixes to whisper windows
	new help screens
2.052
	various small bug fixes
2.051
	custom defined channel list
2.050
	individual whisper windows for multiple users
2.040
	fixes to auto-log functions
	join whisper command re-added
2.030
	auto-logging of account numbers
2.020
	converted to Delphi 4 from Delphi 3
	improved resize capabilities
2.010
	first version 2 release
	extensive reworking of internal chat commands
	whisper lock button
	new macros, allowing 26
	multiple choices for double click function
	user list for channel button
	improved fonts, additional colors
	improved interface screen, resizable user lists/chat screens
	improved
1.231
	gavel error when squelching fixed
1.230
	Gavel icon added
	<random> name insert for macros	
1.220
	various bug fixes
	<user> name insert for macro keys
1.210
	macro keys added
	right click menu for chat/whisper screens, with /users, /time,
	/rejoin
1.200
	custom user list with right click menu/whisper functions added
1.191
	copy command on right click menu for copying user name to entry 
	line
1.19
	split window chat/whisper screens now resizable
	right click menu added for users, with common commands like
	squelch/ban/kick/whois
1.18
	custom chat/whisper screen fonts
1.17
	mutli-color chat/whisper screens and improved custom color 
	support
1.16
	renamed TopazChat
	separate whisper window
1.15
	double-click squelch option added
	channel list added
1.14
	user join response added
	chat icons added
1.13
	resizable chat screen added
1.12
	whisper button added
	multiple color support added
1.11
	/whois on join option added
1.10 
	first release of TopazBot
	resposes to phrases, auto-ban, whisper commands

--------------------------------------------------------------------------
Questions/Comments
--------------------------------------------------------------------------
If you have comments or something REALLY weird happening and it isn't 
mentioned in this file, email your question to topazchat@hotmail.com.
Keep in mind that I wrote this for fun, and I am not selling this program
or really supporting it, but if I have time to answer questions I will.

Feel free to distribute this program freely, but please try to include
this readme.txt file with it.  If you want to put it on your website, all
I ask is that you email me the url of the site so I can check it out.

Have fun!
-Lady~Topaz-