
  __  __                       _     _____   _____   _____
 |  |/  /  _ __  _   _  _ __  | |_  |_   _| |  _  \ | ____| 
 |  '  (  | `__|| | | || `_ \ | __|   | |   | |_)  || |     
 |  |\  \ | |   | |_| || |_) || |_   _| |_  |  _  / | |___ 
 |__| \__||_|   |____ ||  __/  \__| |_____| |_| \_\ |_____| 
                  __| || |
 ________________|____||_|________________________________________
|                                                                 |
|  Version 1.1 for mIRC v5.61 32bit                               |
|  � 1999 TEAM [ACIDCODE]                                         |
|  http://acidcode.8m.com                                         |
|=================================================================|
|*****CONTENTS                                                    |
|          -SETUP                                                 |
|          -CREDITS                                               |
|          -CONCLUSION                                            |
|=================================================================|
|*****SETUP                                                       |
|          Usually,we don't include the mirc.exe (executable)     |
|          along with our scripts.But we got some complaints      |
|          from a few lazy bastards(dah) that it would be much    |
|          better if we included the mirc.exe in the file.        |
|          So READ what's given below,                            |
|          If you downloaded this script from :                   |
|          > www.xcalibre.com                                     |
|          > http://acidcode.8m.com                               |
|          > www.mircx.com                                        |
|          > www.mircscripts.com                                  |
|          this script includes the mirc.exe version 5.61.        |
|          So you don't have to copy or paste or do               |
|          any shit like that.Just double-click on the mirc       |
|          icon and you're all ready to chat and have some        |
|          good, clean(?) fun.                                    |
|          BUT, if you downloaded this script from :              |
|          > www.mirc.net                                         |
|          > www.pairc.com                                        |
|          > www.irc-scripts.com                                  |
|          then the script does not include the executable        |
|          (mirc32.exe) which means that you must have it         |
|          already, or download it from http://www.mirc.co.uk     |
|          Just unzip the script file into a separate folder      |
|          (eg. c:\krypt) with the "use folder names" option      |
|          enabled. Then, you must copy the mirc's executable     |
|          (mirc32.exe) into the folder where you unzipped the    |
|          script file (if you chose c:\krypt, thats the one      |
|          where you must put the file).Then, just run the        |
|          mirc32.exe....and it's done.This script requires       |
|          mirc32.exe version 5.61 and above.Do not try to run    |
|          it with an older version.                              |
|          The reason why you won't find mirc.exe along with the  |
|          script in these particular sites is that scripts with  |
|          mirc.exe are generally frowned upon in these sites,    |
|          and it is quality that matters, not quantity :P        |
|=================================================================|
|*****CREDITS                                                     |
|          Ashok,for his guidance and support                     |
|          qsera,for suggestions and tips                         |
|          Breaker,he's da koolest                                |
|          Rage`,for his help (http://uircscript.cjb.net)         |
|          grim(produkt),opal rocks..way to go                    |
|          coxton,for helpful little tips                         |
|          Free,for the titbits :P                                |
|          #helpdesk,thanx for all their help                     |
|          #india ops,for their help and support                  |
|          #bangalorechat,aaHa,Shiv_,laugh,T0xin,                 |
|          Guruji,Sanjay,^icE_berG^,Yash,ashman^,                 |
|          maverick,Rainmaker^,aaron_,and whoever we forgot....   |
|=================================================================|
|*****CONCLUSION                                                  |
|          Thank you for trying Krypt-IRC.We hope you have        |
|          a nice time on IRC using our script.                   |
|          Any bugs,comments or suggestions?                      |
|          Mail Us : info@acidcode.8m.com                         |
|          Our URL : http://acidcode.8m.com                       |
|=================================================================|
|                   � 1999 TEAM [ACIDCODE]                        |
|_________________________________________________________________|

