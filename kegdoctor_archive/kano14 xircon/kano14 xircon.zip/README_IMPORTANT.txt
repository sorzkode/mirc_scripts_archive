# kanov14: instructions - read carefully
# kano.net for more info...

1  The ZIP file should be unzipped to your XIRCON directory. It installs itself
   into its own directory.
2  RUN (double-click) the .REG file in your xircon\kano directory. It makes
   life that much easier. You must CLOSE XIRCON before running this.
3  FON files in the xircon\kano\fonts directory should be moved into
   c:\windows\fonts.
4  You have to LOAD a COLOR INI from the XIRCON PREFERENCES menu, COLORS tab.
   See the folder 'xircon\kano\Color Schemes' for more options.
5  Use a FONT in the ZIP -- gte437.fon or ibmpc. Do NOT use something
   idiotic like Times or Arial or Fixedsys or Courier.
6  Type /theme to load a theme. It will auto-load from then on until you decide
   to use another one.
7  To load an addon (*.ka) stick it in your_xirc_dir\addons (type /reload to
   activate it.)
8  Use /help! I spent a lot of time on it! Make me happy! Try /help aliases
   and /help <alias name> for specific help. If you plan on using kanotcl
   then please look through help to get the most out of the script.
   The script does a hell of a lot. It's just not all obvious.
9  As a reward for reading the readme... To stop autojoining #kano type
   /ajoin.
10 There are MORE ADDONS in 'xircon\kano\MORE ADDONS.' these do things like
   bot control and er, other stuff.
11 Get the latest betas, addons, and other cool stuff by typing /kfile.