READ ME- VITAL :)

Ok.. first, this isn't a war script and all that shit.
I HATE war it SUCKs completely. 

This script has, DeOP, Flood (thanx to Xerath for his addon... I just made it for notice flood too :P ), Bad Nick, Bad UserIdent (*!*ThiS@*), Cuss (able to set channels) Protections.

You also have...
!seen (part/ join/ quit), 
Auto ID to a Nick or ALL your nicks if they all the same, for eg.. 
A) If I had one nick OPped in a few channels, I would Turn it on and put, " NickName Pass " and it will...
/ns identify NickName Pass
B) If I didn't want to Identify to the OP nick, but identify to the nick I was using.... I would Turn Off and put " Pass ", and it will... 
/ns identify Pass

Easy to understand?? :))

A Lag Monitor.. AND a "auto send ping thingy" when you ping someone, you send, the reply to them, and echo to yourself :)) 

ALL Above with the ability to turn off or on :))

You got ChanServ, NickServ AND MemoServ popups..
A basic,  VERY BASIC away system type thing, none of the paging/ logging etc.. just puts you away with either your nick changing or not :))

You got plenty of choices to kick/ ban a peep :)

/wme <=--- /whois's you
/pme <=--- pings you :))

Yay!!! I fixed the nickcompleter!!!! Just a little #: was needed!! :) Woohoo!! Now with the ability to change the styles, and turn off and on with a click :)(Got it off Dan... SeAzUR... But I fixed it!!!!)

You got games now peeps!! :)))
And sayings like MOST scripts too :)

There 'may' be a few bugs... I am pretty sure that there is :(, but don't know for sure, so if you could e-mail me at outkast@key.net.au and tell me of any, it would be greatly apprectiated.
Or pop into MY channel, on any WebNet etc server (unless there be netsplits about), and join MY room, #NiGhT&StOrMy.

Thanx for selecting my script, there ofcourse are better out there, but this script was made by me, for me, with a few things taken from others.. But, Hey.. most things are simliar anyways.. so where is the diff?? :)

Sooo.. what are you waiting for.... get the scr|pt happenin!!! :)