Welcome To Torment Millennium 2
If You Don't Like This Script.. Find Another One
Don't Complain To Me if Something You're Looking For In A Script
Is Not Here. I've found That 90% Of The Time People Complain About Something Not
Being There.. It Usually Is! Take A Minute Out Of Your Day And READ The Help File.
Also.. If You Think The Script Doesn't Have Enough.. I Don't Think You'll Ever Be
Happy.. Cause Millennium Has More Options Then Any Other Script On IRC Today.

For Questions NOT Solved In The Help File
E-mail Me At sknart@hotmail.com

Install:
Extract Zip
Double Click Tm2Setup.exe
That's All

War Addon:
Can be downloaded from inside the script
or by visiting http://www.tormentscript.com

Themes:
Can be accessed by clicking MODES
Then clicking Themes
Press "Click Here For Downloadable Themes"