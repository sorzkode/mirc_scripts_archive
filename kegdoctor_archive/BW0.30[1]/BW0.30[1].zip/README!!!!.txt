#===============================#
# BLACK WIDOW 0.30 by Pellefant #
#===============================#

0.30 is the final version for mIRC 0.70. The next version of BLACK 
WIDOW will be for the next version of mIRC.

New in 0.30:
*A new MP#-player. This time it works perfect.
*New logo
*New autokicks

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

#===============================#
# BLACK WIDOW 0.20 by Pellefant #
#===============================#

The 0.10 version had so many bugs I decided to make a new version for
mIRC 5.7.
I personally think that 0.20 kicks ass!

New/changed stuff:
*New MP3-player
*More ascii
*More kewlstuff
*Changed autokicks
*Changed some wave-files
*New backgrounds
*A second nicklist popup called "Cool Menu"
+ a lot of bugs fixed.

If you find any bugs, plz report them to me by e-mail:
xyz_platinum@starmail.com
If too many bugs is found, there will be a new version of 0.20, called
0.21, before I release the 0.30 in the middle/end of May. 

You can always e-mail me if you wan't to ask about something or just
write what you think of the script. I'll answer every mail i get.

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

#===============================#
# BLACK WIDOW 0.10 by Pellefant #
#===============================#

This is the first version ever of Black Widow. When I made it I wanted
to make a fun script whitout silly nukes or stuff like that.
I haven't copyrighted any of the code in this script because I think
anyone should have the possibility to use any codes they wan't. The 
only thing I won't allow is if you try to change the name or anything 
else in the script just to make people believe it's your own script.
Some of the popups(slaps, Yo Momma etc.) are taken from the addon 
"KEWLSTUFF POPUPS v1.3" by wAvMaN. I would like to thank wAvMaN as
I think this is the best popus I ever had in a script.
Have Fun!

Pellefant
email: xyz_platinum@starmail.com