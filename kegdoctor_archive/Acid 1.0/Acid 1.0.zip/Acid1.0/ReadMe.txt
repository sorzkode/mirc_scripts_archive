Welcome To Acid Version 1.0
------------------------------------

This script has taken me almost a year to make, I don't
appreciate rippers or people who like to borrow parts
of my scripts, therefore if I ever hear, see, or catch
you ripping any part of my script I will personelly
rip your head off.

Now I've got that out of my system I will tell you
about the good parts of Acid 1.0.

Acid 1.0 contains many useful features which you can
see in 'Help', but in this script
i have also included a bot. Yes, I did make the bot
for my previous script 'BLiZzArD Script GoLD'
thats why its called 'BLiZzArD BoT', but it is also
used in this script too, like I meen why rename it?
when i made it for 'BLiZzArD GoLD'.

In the script there is also Dialogs, some of you script
users may not know what a 'Dialog' is, so I'll tell
you.
A Dialog is a line of coding that creats a box, much like
when a program pops up, from this box i have enabled you 
to be able to configure the script, open/close utils,
etc. Press F2 to see the main control centre in the
script.

The script also contains an MP3 Player which can play your
MP3's , the MP3 Player has a 'FileShare' if turned 'ON' 
every time you play an MP3 it will enable other people on
your server to 'Download' that current MP3. 
(eg. !tekaz KoRn - Got The Life.mp3)
If something like that is typed your DCC will automatically
send that MP3 to the user.

Thats all that cleaned up so now I will tell you some infomation
about my other scripts & my site.

I have already made 3 other scripts, which are:
** Blizzard Frosty 1.0 - My first script.. it sucks.
** Blizzard 2.2 - What my first script should have been.
** Blizzard Gold 3.1 - Fantastic all round script, very neat
and tidy.

My website is www.geocities.com/nick_x86 at my site you can download
some of my scripts and find out more about my scripts also.
At my site you can download a 'War Addon' which contains
a number of nukers & protection programs all in dialog
it's a must have if your into the netwar bullshit. You can
get the NB-IRC-MP3 addon for mIRC 5.61 at my site also.

E-mail: nick_x86@hotmail.com
Website: www.geocities.com/nick_x86

ThankYou for your time and enjoy the script!