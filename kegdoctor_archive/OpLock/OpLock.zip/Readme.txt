This is my next addon in the series of Lock.  If someone op someone on your channel while your there
this addon will deop them.  Only you can op while this is turned on.  You have to have ops
for this to work.  It helps if your on the access list but its not necessary.  Have fun!
e-mail me at haydes007@hotmail.com if u have questions or suggestions.
Or you can find me in #scripter on NewNet :)

To load type /load -rs oplock.mrc

