CatNinja << Doomsday Warrior 0.92 Edition >>
==================================
You will need pirch32.exe and pirchvdo.exe
I have files available at my site 
http://www.pacifier.com/~shasta
========
Please double click on warrior.exe file
Unzip to c:\ when prompted.

Note:
DO NOT extract or type in any other directory 
LEAVE it at c:\ 
The exe file will extract to warrior folder for you.
========
Have fun with the script!   
CatNinja


P.S. Once you've added pirch32 and pirchvdo.exe, double click on
c:\warrior\warrior.bat to start up script. If you get access errors,
close pirch, and try clicking on warrior.bat file again. 
