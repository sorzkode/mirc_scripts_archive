No-Limit By Ba||a

First thing i need to tell you about are the split bots.  They will automatically load when the split happens so you dont have to do anything with them except
for set the channels. Set the channels like this --> #room1,#room2

Use the popups for just about anything.  If u just click all the popups everything is mostly self explanitory.  So use the right click. it helps
For the mp3 player just click setup and then go into the file with all your mp3's are in.  Once you get into the file with the mp3's just click cancel.
DONT click on 1 of the mp3's.  Then another screen will come up, and on that one just find the file with the mp3's, and double click on it then just hit ok.

Thanks to all the people who helped me out with my scripting.  I really appreciate it because when i first started i didn't know anything really
and I asked a lot of questions.  The people that helped me the most and I would like to let people know is : ADROCK, aron, and [DaRtH-VaDeR].  
Thank You to '-Skoal also for teaching/helping me make an unmasker.  I love it =].
Aron made the leet double join bots and I just changed them around a little.
If you need any help just come in my room, #ballin , and ask me

Thanks and enjoy
