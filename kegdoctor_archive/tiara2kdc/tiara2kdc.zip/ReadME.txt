Require win98 SE to run this script in Full Multimedia.   >-[Genuine]-<
[TiArA] ScRiPt v10.3D (Build 4.5 MaRcH - 2K ReLease)         -MaRcH 2K-
-----------------------------------------------------------------------
SCRIPT BEST ViEW WITH 600 x 800 True Colour Revolution

[ALL ArounD EDiTioN With SPR JukeBox v8.4]

*This script is the FiNAL Edition Of Tiara Script*



Please Extract the script to 'C:\ '  directory only


Do not extract it to any folder....




Thanks :) ^WeeZ^
[TiArA] Enterprise Inc @ Metabilso Sabe Creation
http://tiara2k.cjb.net  |   http://tiara.tsx.org


Revision 3C [Genuine ReLease]

Make sure you download the [Genuine Product]

This script is totally virus free 