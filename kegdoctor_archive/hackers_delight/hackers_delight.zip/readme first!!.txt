ok peeps this script is really '-Skoal's but i added a few things of my own to it and took off
 a few too and changed the takeover(slightly)
to get the gIMP nuker to work all u have to do is
1)open up popups
2)select view..channel
3)look for the nuker
4)set the corect path
and your in
Sock commands are
.join joins bot 1
.prot joins both
.part parts bot 1
.allp parts both
.+prot optimises protection
.ping
.say <msg>
.adv advertise sock
.hop cycle bot 1
..hop cycle both
and all my thanks go out to 
1)'-Skoal
2)jade18..my lady!!
3)anyone i forgot
fkeys
f1 connect to irc.msn.com 6667
f2 socks connect
f3 rkey
f4 ial update
f5 timer access off(reduces lag but kills access timer)
