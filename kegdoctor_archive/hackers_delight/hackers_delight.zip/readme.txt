Hacker's Delight v1.2 Final By TheP|nkPanthe|2

This has been a fun little project, but I am no longer releasing it, this is the final version, and I have removed all of the things that I know annoy you, and got rid of that line 401 error introduced in 1.2, and this is to leave you with a perfectly working version, for those of you that DO know how to use it and would be interested in later releases of it which I will be making only for myself, please go ahead and email me and I will be happy to hook you up with a newer version, and please, if you do not know what this is, do not use it, if you don't know how to use it, delete it, it's of no use to lamers, it is not some point and click nuking device, it is for practical network security auditing, not for lamers to cyberly beat up other lamers, use with caution, I cannot be held responsible if you do something dumb like portscan, or do a mass banner colletion on www.fbi.gov, what you do with it is all you, I am just showing that you can do more than just make dumb ass ban protection scripts in mIRC, and hopefuly this will give some people the encouragement to attempt and script something that is of good use.

First off, i would like to thank elektrobank for his help on some of the socket shit, and the mirc telnet, even though we had to do a _LOT_ of debugging on it.
And i'd also like to thank Tyrant for his help when i first started this, and for being the elite mirc scripter he is...

Secondly, to load it type /load -rs hackersdelight.mrc in your mirc script's dir, if you don't know it, just load mirc and type "//echo $mircdir" and that'll tell you what dir your script is reading from.

There have been many improvments of Hacker's Delight in this version, it will no longer conflict with mIRC's DNS, and you will no longer get those annoying 'socket not open' errors.

Tools>Resolve>Resolve Host: A typical DNS.
Tools>Resolve>Resolve Host/Guess Domain: You put in www.site and it will DNS www.site.com, .org, .net, .gov, .mil, and .edu, i don't know if this is of any use to any of you, but it is to me...
Tools>Telnet: A telnet client for mirc, personaly, i like it...
Tools>ASCII <-> Hex: Converts ASCII to raw hex, or raw hex to ASCII
Tools>Overflow Generator: Some exploits are buffer overflows, some need a certain amount of characters sent to the service to exploit it, and this handy feature will echo any number of any character you want, so you don't have to count like 250 characters to overflow something.
Tools>Finger: Just a finger client that is better than mIRC's default finger client.
Probes>HTTP Info: You put in a address, and it connects to a site that will tell you the server version and OS the box is on.
Probes>Port Scan: A port scanner for commonly vulnerable services, uses dialogs and is very fast.
Probes>HTML Dump: Will output the index.html document on a remote host.
Probes>Banners>HTTP Headers: Will tell you almost everything there is to know about the remote HTTP server.
Probes>Banners>POP3: Will tell you the POP3 server version information, if any.
Probes>Banners>SMTP: Will tell you the SMTP server version information, if any.
Probes>Banners>FTP: Will tell you the FTP server version information, if any.
Probes>Banners>FP Server Extensions: Detects Microsoft FrontPage Server Extensions on a remote website.
Probes>Banners>All: Will get the banners for HTTPd, POP3, SMTP, and FTP at once.
Personal Links>*: A few links to sites that are hosting my banner, check them out, they're pretty nice.
Notes: Loads a notepad document for you to place your notes.

That's all there is for now, if you have any suggestions, please report them to me and i will try and utilize them.

DISCLAIMER: This script is for educational uses only, it is intended to do some low level security auditing on your _OWN_ network, i can not be held responsible for what you do with it...

This script is FREEWARE, and can be distributed freely as long as this readme remains with it and in full.

Hacker's Delight is �1997-2000 TheP|nkPanthe|2
The Black Baud Empire and Hacker's Delight is a �TM of TheP|nkPanthe|2

And I will leave you with a couple words: 
I fight the air I'm forced to breathe
I drain the blood I'm forced to bleed
I see what you force me to see
Now it's my turn to live for me
I hide behind the screen that you don't see
This is where I can be me
You can't grasp what you can't see
I am here eternally
You can't stop me, cos I'm inside you
You can't kill me, cos I'm part of you
You can't harness me, cos I suppress in your hate
You can't tame me, cos you can't hide your fear
I'm in your nightmares
I'm in your fears
I'm in your head
I inhabit your tears
I am the shadow beneath your hate
I am the darkness you cannot see
You can't stop me, I am fate
After all, you're bleeding me.

TheP|nkPanthe|2