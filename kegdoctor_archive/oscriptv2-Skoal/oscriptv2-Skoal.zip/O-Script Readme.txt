Readme for O-Script v2.0

If you read this in Notepad or wordpad, it's best to use word wrap!

This script has been a pain in the ass....it first started off being a completely new script which only two people have now...myself and Di]v[pLeS...but i decided to just upgrade my original O-Script.  This has taken more time to script than it should have, but that's only cuz i'm a slow learner :)  I hope you find this script a little better looking than my previous version.  My attitude towards my script still stands...if you see something you like in it and want to use it in your own, do it...you don't have to ask or give credit...just don't be a prick about it or anything.  In future versions, expect to see updated protections (these always need to be changed due to the fact that there is always someone out there better than you)...also more exploits if any more are found.   

I would like to thank Di]v[pLeS for helping me out with a few things and writing some of the stuff that was just beyond me.  Also, opt1ckz for letting me use his badass mp3 player in this script. And ba||a, who doesn't know it yet, but my masses are pretty much carbon copies of his, cuz i can't write a mass to save my ass :\
To all those countless people that answered my dumbass questions....thank you!  :)

This script is compatible with mIRC v5.61 and higher
Please do the following actions listed below to make sure the script runs properly.

A few things you need to do:

1) For less download time, I DID NOT include a copy of mIRC32.exe in the package....you need to copy that file into the O-Script folder.


If you have any problems, email me at silent_eyez@msn.com

Skoal