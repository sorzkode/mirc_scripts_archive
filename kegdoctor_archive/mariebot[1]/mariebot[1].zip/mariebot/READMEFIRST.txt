Marie Bot v1.0 (BETA)
====================
http://marie.gibthis.com

This is a FIRST Bot I have released and made in a couple days.  This bot may have a few bugs but not too big of a problem.
If You need help with my bot join IRC.GAMESMECCA.NET #MARIE

What you do with this bot is YOUR Responsibility!

Features:
========
- Commands for use on the master nick name.
- Repeat 2 times kick (upgradable in next version)
- Auto Greet
- Away system
- Swear Kick (upgradable for larger vocab)
- Offensive Nick Kick (Upgradable for larger vocab)
- Ignore all messages
- Auto Voicer
- Fserv fully functionable (upgradable, Have to go to options -> DCC -> FServ to change Max sends and Max gets per user)
- Fserv (Also File -> Options -> DCC -> Options for changing remote # of Sends)
- Seen Script

Installing:
==========

1.  Make a directory and unzip files in it
2.  Run mirc32.exe
3.  Let it connect to my irc channel
4.  disconnect if you wish and use on any server you would like

Using:
===== 

add a user by click right your right mouse button on the nick you want (Yours for if you add someone else they can disconnect your bot etc.)

Commands:
========

.topic (Changes topic to the one you .settopic'd)
.settopic (Add a topic for the bot to use)
.locktopic (locks the topic so when someone changes it, it will go back to the one you made.
.kick NICKNAME (Kicks a person from the channel.)
.ban NICKNAME (Kicks and Bans a nick from the channel.)
.op NICK (Ops a nick in a channel)
.deop NICK (Deops a nick in a channel)
.up (Ops yourself)
.down (Deops yourself)
.say TEXT (Makes Bot Talk)
.invite NICK (Invites a nick to a channel)
.reconnect (Reconnects the bot)
.ping (pings your self(can be done by all users))
.connect SERVER.ADDRESS.NET (Connects bot to a certain server)
.quit (Disconnects Bot)

