
So, you now have the KLoWnX script v1.7 :o
How do ya like it????
Well at least, we hope you did.
The KLoWnZ now have a new irc server, which is thejester.net:6667.
We added it in your server list with this script, please pop in at some point of time. Oh and we have a new site up, it is called http://www.irc2000.net.
This is based upon thejester.net server which we are building up personelle to make this a extremely good server. We have all the settings done, all we need is you guys.

Thank you--- The new KLoWnZ are here in '99... 
---------------------------------------------------------------------------
KLoWnDJearl 
� Copyright 1999 
7-20-99
if yer ript this script, we rip yew.
KLoWnDJearl's icq number -26983034 or e-mail earlsta@yahoo.com

*<{:0)*<{:0)*<{:0)*<{:0)*<{:0)*<{:0)*<{:0)
*<{:0)                   KLoWnZ                 *<{:0)          
*<{:0)                                                   *<{:0)
*<{:0)*<{:0)*<{:0)*<{:0)*<{:0)*<{:0)*<{:0)