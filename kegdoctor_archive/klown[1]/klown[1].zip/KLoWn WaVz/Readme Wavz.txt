---------------------------------------------------------------------------
                          KLoWnWaV's Made By KLoWnBRaT

Like em do ya??
hehehe, yeah well
oh,, and if you are interested in becomming a KLoWn msg us on icq or tell us when u see us :) KLoWnZ
---------------------------------------------------------------------------
KLoWnDJearl 
� Copyright 1999 
7-20-99
if yer ript this script, we rip yew.
KLoWnDJearl's icq number -26983034 or e-mail earlsta@yahoo.com

*<{:0)*<{:0)*<{:0)*<{:0)*<{:0)*<{:0)*<{:0)
*<{:0)                   KLoWnZ                 *<{:0)          
*<{:0)                                                   *<{:0)
*<{:0)*<{:0)*<{:0)*<{:0)*<{:0)*<{:0)*<{:0)