                                     __  __  _
            ___  ____ __  _ ___  ___ / /_ \ \/ /
           / _ \� __/ _ `/ / -_)/ __/  _/  )  (
          / .__/_/  \___/ /\___/\__/\__/  /_/\_\
         /_/ -------- /__/ ---------------------
                            
                  
================================================================


-----[ Install ]------------------------------------------------

1. Unzip the pxstats2.zip into your mIRC directory.
2. Type /load -rs pxstats2.mrc at the mIRC command line.
3. Click 'Yes', when a dialog box popup asks if you want 
   to run the initialization. If you do NOT click yes, the
   script will not be loaded. We guarantee that NO original 
   ProjectX scripts will load any code that may be harmful to your
   mIRC or computer.
   
 Note: This script requires the latest version of mIRC 5.71+.
       Download it at: http://www.mirc.co.uk/

-----[ Description ]--------------------------------------------

ProjectX Channel Statistics is a channel scanner that outputs
basic information about a channel (Total ops, voices, etc.).
Plenty of options for saving the statistics. Optional to save to
a text file or HTML file.

-----[ Manual ]-------------------------------------------------

First install the addon using the installation instructions at
the beginning of this file. Proceed below for information:

1.) First and foremost, you must connect to an IRC server.

2.) Next you must join a channel (any channel).

3.) Right click in your channel and find the popup that reads:
		ProjectX Channel Statistics

4.) Proceed to the sub-menu for that, and click on:
		#<The Channel You're On Appears Here> Statistics

5.) If all is well, you will see the statistics dialog pop up
    and then it will load all of the channel stats.


[[ New Scans ]]

To perform a new scan:

1.) You must have already scanned a channel (read above
    instructions). You have to still be in the stats dialog.

2.) Click the 'File' menu atop the Statistics dialog.

3.) Click the 'New Scan' menu item.

4.) In the 'Select Channel' dialog, you can select a new channel
    to scan.

5.) Double-click the channel you want to scan, or click 'Scan Now'
    to begin a scan.


[[ Saving Statistics ]]

To save all channel statistics:

1.) You should still have scanned a channel already (read the
    first section in this manual). Must still be in the stats
    dialog.

2.) Click the 'Output' menu, then click the 'Saving Statistics...'
    item.

3.) You have 3 options at this point:
					a.) Save As A Text File
					b.) Save As An HTML File
					c.) Don't Save At All

4.) Select one of the options that fits your needs! :-)


[[ Refresh Stats ]]

1.) You should still have scanned a channel already (read the
    first section in this manual). Must still be in the stats
    dialog.

2.) Click the 'Refresh' button at the bottom of the dialog  next
    to the 'Ok' button.


[[ Outputting Stats To Users or The Channel ]]

To output the stats

1.) You should still have scanned a channel already (read the
    first section in this manual). You must also be inside of the
    'Saving Statistics' dialog (read above on: 'Saving Statistics'
    for information on getting to this dialog).

2.) Once in this dialog, you have 2 input types:
						a.) Channel Combo
						b.) Nickname Textbox

3.) In the channel combo, you are given the list of channels that
    you were currently residing on at the time the dialog was opened.
    The Nickname Textbox is where you can enter the nickname of the
    user that you want to send the stats to.

	-] Send To Channel:
		To send the stats to a channel, select the channel
		that you want to send it to in the 'Combo Box' then
		click the 'Send' button. The addon will do all of the
		rest :-)

	-] Send To User:
		You have 2 options for sending the stats to a user:
						a.) Send The File
						b.) Send The Msg
		-]] Send User The File:
			To send the user the file, you just click
			the 'Send File' radio button under the
			'Send Stats To Another User' label above it.
			Type in the nickname of the user you want to
			send it to, and then click the 'Send' button.
			You're all set! The addon will do the rest!

		-]] Send User The Msg:
			To send the user the msg, click the 'Display
			Msg'd' radio button under the 'Send Stats To
			Another User' label above it. Type in the
			nickname of the user you want to send it to,
			and then click the 'Send' button. The addon
			will /.msg the user all of the statistical
			reports on that channel! :-)


[[ Remove All Saved Stat Files ]]

1.) You should still have scanned a channel already (read the
    first section in this manual). You must also be inside of the
    'Saving Statistics' dialog (read the section on: 'Saving 
    Statistics' for information on getting to this dialog).

3.) Click the 'Remove All Files' button.

4.) Voila! You're done. All stats files in the <scriptdir>\stats
    folder are now removed.


[[ Show Stat File ]]

1.) You should still have scanned a channel already (read the
    first section in this manual). You must also be inside of the
    'Saving Statistics' dialog (read the section on: 'Saving 
    Statistics' for information on getting to this dialog).

2.) Click the 'Show Stat File' button.

3.) This will display the stat file for this channel. If the
    channel's stat file does not exist, you cannot view it. (Note:
    You can make a stats file for the channel if one does not exist
    and even if one *does* exist and you want to change the type of
    file it is.)


[[ Make Stat File ]]

1.) You should still have scanned a channel already (read the
    first section in this manual). You must also be inside of the
    'Saving Statistics' dialog (read the section on: 'Saving 
    Statistics' for information on getting to this dialog).

2.) Click the 'Make Stat File' button.

3.) The addon will takeover and then create a stat file for the
    channel that you just scanned. You can also view it by using the
    'Make Stat File' reference in this manual. (Hint: It's the above
    topic ;-) )


[[ Unloading The Addon ]]

1.) First off, right-click in a channel, then go to: ProjectX Channel
    Statistics.

2.) Go to 'Unload' and click it. The script will now unload itself &
    and all variables (if any) that it is using.


[[ About Dialog ]]

Note: You can obtain the 'About' dialog in 2 ways:

1.) You should still have scanned a channel already (read the
    first section in this manual). Must still be in the stats
    dialog.

	a.) Click the 'Help' menu.
	b.) Click the 'About...' item.

Or...

2.) Right click a channel that you are on, then go to: ProjectX Channel
    Statistics.

	a.) Click the 'About...' item.


[[ View Readme File (You're Reading it ;-) ) ]]

1.) You should still have scanned a channel already (read the
    first section in this manual). Must still be in the stats
    dialog.

2.) Click the 'Help' menu.

3.) Click the 'Readme File...' item.


[[ Conform Dialogs To Desktop Style ]]

1.) You should still have scanned a channel already (read the
    first section in this manual). Must still be in the stats
    dialog.

2.) At the top of the Dialog, click the 'Dialog Windows' menu.

3.) In the 'Dialog Windows' menu, click the 'Conform To Desktop'
    item.

	Note: If the 'Conform To Desktop' item is already
	      checked, it means that all dialogs are already
	      being conformed to the desktop. Else, they aren't.




-----[ Notes ] -------------------------------------------------

I was pretty sure that this addon has no errors. I tried to add
as much error checking as possible.

The only possible error you will get is if you try to send the
stats to someone who is not on IRC. I don't really consider this
a problem. Everyone would think 'Just did it cause coding the
RAW is just more work'. This is far from the truth, I just don't
want my addon interfering with /whois addons or anything else
like that.

-----[ ProjectX ]-----------------------------------------------

'ProjectX' is a Scripters Crew that focuses on creating scripts,
mainly mIRC and TCL scripts. We do not concentrate on creating
full scripts, but instead on creating practical scripts for the
lazy IRC-user, protection scripts for the threatened one,
warscripts for the aggressive or vengeance-seeking among us.

We are an organised group of scripters determined to help each
other create, develop, and refine scripts. We bundle our 
knowledge, so that our inexperienced scripters may benefit from
our experienced crew-members, and our experienced crew-members
benefit from the enthusiasm and fresh insights from our newer
members. We concentrate on creating good, reliable, compatible
and useful scripts for mIRC users.

You can contact ProjectX in the following ways:
- Visit our homepage..: http://www.projectx.mx.dk/
- Visit us on IRC......: #projectx (GalaxyNet)
- Drop us an e-mail...: info@projectx.mx.dk


-----[ Disclaimer ]---------------------------------------------

We will under no circumstances be held responsible for any 
damage resulting from the use of this addon, whether emotional, 
physical, loss of data, health, wealth, religious beliefs, or
whatever other type of damage. By using this script and reading
this document you agree not to hold ProjectX or the author of 
this addon responsible for (including but not limited to) above
mentioned damages. If you do not agree with the above 
disclaimer, you should remove this script from your computer
immediately.

Thank you for using this ProjectX addon, we've worked hard to 
make this as useful, practical and safe as we could!
