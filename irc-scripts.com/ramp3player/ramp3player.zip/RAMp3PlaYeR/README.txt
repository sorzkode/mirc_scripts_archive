RAMp3 PlaYeR 1.0 By RaMzAl_X

***********************
* READ THIS CAREFULLY *
***********************


This Dialog Mp3 Player Addon is Very Simple To Use.
Its My First Addon Release, So I Would Like To Receive Your Commentaries and/or Suggestions
If You Find Any Bug, Please Tell It To Me.



INSTALLATION:

1) You MUST Unzip RAMp3PlaYeR.zip In Your Main mIRC Directory !!!
   I Repeat: In Your Main mIRC Directory !!!

2) Start mIRC And Type This In Any Window: //load $mircdir $+ ramp3player\ramp3player.ini

3) Enjoy !!! :))

===========================================================================================

I Don't Know What I Could Write Here Because This Addon Is So Simple !!!

If You Have Problems:

1) Evaluate The Problem To Find What Is REALLY a Problem; YOU or this ADDON...
2) Read The INSTALLATION Section Another Time.
2) Try to UNLOAD it And LOAD it Again.
3) Call Me On mIRC (Undernet And Dalnet), ICQ or Send Me a E-Mail.

===========================================================================================
mIRC Nick: RaMzAl_X
ICQ Number: 105311845
E-Mail: Ramzal_X@caramail.com
===========================================================================================