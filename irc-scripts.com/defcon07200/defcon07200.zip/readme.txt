readme.txt :
- About
  - about
  - credits
  - greets
- Installation
  - install
  - upgrade
- Description
- Manual
  - installation
  - support
  - f-keys
  - commands


-----[ About ]-------------------------------------------------------------------

[about]
=================================================================================

dEfCoN oNe for mIRC 5.82
by fiRE_ANGEl (fiRE.ANGEl@gmx.net)
http://defcon-one.purespace.de

Version      : 0.72.00
Release Date : 26.03.01 (dd/mm/yy)

[credits]
=================================================================================

- mIRC: khaled
- Nicklist Colourer: Projectx
- Services Popups: Stone_Eagle & Pseudo
- ideas: the dEfCoN oNe community

[greets]
=================================================================================

- all my IRC Friends (too many to mention here, but if you think you are here,
  then you are)
- to you

-----[ Installation ]------------------------------------------------------------

[install]
=================================================================================

1. Extract everything into a new folder.
   For example: c:\defcon
2. Rename the file 'mirc.bak' to 'mirc.ini'
3. Copy the mirc32.exe to the folder where you extracted those files.
   dEfCoN oNe is tested with mIRC version 5.82.

Note: This script requires mIRC 5.82 and above.  To get the latest version of
      mIRC, visit http://www.mirc.co.uk/

[upgrade]
=================================================================================

WARNING !!! This Version can ONLY upgrade dEfCoN oNe version 0.71 and above

1. Exit mIRC
2. Extract everything to your defcon one directory
That's it

-----[ Description ]-------------------------------------------------------------

[]
-----[ Manual ]------------------------------------------------------------------

[Installation]
dEfCoN oNe 0.72.00 help - Installation
=================================================================================

1. Extract everything into a new folder.
   For example: c:\defcon
2. Rename the file 'mirc.bak' to 'mirc.ini'
3. Copy the mirc32.exe to the folder where you extracted those files.
   dEfCoN oNe is tested with mIRC version 5.82.

Note: This script requires mIRC 5.82 and above.  To get the latest version of
      mIRC, visit http://www.mirc.co.uk/

[support]
dEfCoN oNe 0.72.00 help - Support
=================================================================================

dEfCoN oNe can be downloaded from http://defcon-one.purespace.de and information
about it and other scripts done by me will also be found there.

You can also contact me by e-mailing fiRE.ANGEl@gmx.net with any queries you may
have, or bugs you want to report.

Feel free to contact me anytime at all. Feedback should be in less than 48 hours,
unless I am experiencing difficulties beyond my control.

[f-keys]
dEfCoN oNe 0.72.00 help - Function Keys
=================================================================================

F2         - join channel(s)
F4         - opens dEfCoN oNe setup
F6         - Opens Away Log
F8         - Set Away with reason
F9         - Opens dEfCoN oNe WebPage (German)
Ctrl + F9  - Opens dEfCoN oNe Webboard (German)
Shift + F9 - Download latest version of defcon one

[commands]
dEfCoN oNe 0.72.00 help - Commands
=================================================================================

### /about

Opens the about dialog.

### /act [channel] <text>

Performs an action on the channel.

### /autojoin

Joins the autojoin channels for the current network

### /awayscan [#channel]
 
Scans away users in a channel

### /awaysetup

Opens the away Setup Dialog

### /bye [reason]

Shortcut for /quit

### /cs <command>
 
Sends a command to Chanserv

### /i <nick> [channel]

Shortcut for /invite

### /irc [server] [port] [nick]
 
Opens an IRC session.
 
/irc us.undernet.org 6667 mynick
This will connect you to us.undernet.org using the port 6667 and the nick mynick
 
/irc
This will open a dialog asking you the server, your nick, etc.

### /j <[#]chan1> [[#]chan2...]

Shortcut for /join
Differently than in the original # is not necessary.
Additionally several channels can be entered at the same time.

### /m <channel> <modes>

Shortcut for /mode

### /ms <command>
 
Sends a command to Memoserv

### /n <newnick>

Shortcut for /nick

### /ns <command>
 
Sends a command to Nickserv

### /p
 
Shortcut for /part

### /q
 
Shortcut for /query

### /seen [nick]
 
Tells you the last time he has been seen.

### /v
 
Shortcut for /voice

### /voice [#channel] [nick] [nick]...
 
Voices users in a channel.
 
� /voice Ecronika
  Voices Ecronika in the active channel
� /voice #lamest Ecronika fiRE_ANGEl
  Voices Ecronika and fiRE_ANGEl in #lamest

Commands to open Dialogs :
--------------------------

/nsetup   Network Setup
/ncsetup  Nick Completion Setup
/replace  Replacer Setup
/setup    General Setup
/seen     Opens Seen-Lookup

I think you know what this commands do ...