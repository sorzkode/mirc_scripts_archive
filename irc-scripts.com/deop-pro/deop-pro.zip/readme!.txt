��{deop-pro}� v1.0 By Bighawk

******************************
*** INSTALL ******************
******************************

(Step 1)

UnZip To Your mIRC <Dir> 
Example (c:\mirc)

(Step 2) 
Open mIRC if mIRC isnt open 
Type /load -rs deop-pro.mrc

Enjoy
bighawk


