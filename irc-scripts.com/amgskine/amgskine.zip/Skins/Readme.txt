             ArMAgeDdoN Skins V1.1 &
           ArMAgeDdoN Skins Maker V1.1
                  by DarkPoison
          ______________________________
Hi! This is my first addon, but I have a script!

This is a powerfull and simple Skin Menager or 
Themes, if you like!

Requeriments: mIRC 5.5 or higher

To load, just extract the files to the mirc
directory (eg. c:\mirc\ ) and type:

/load -rs skins\skinamg.mrc

or just cut and paste! (Ctrl+c e Ctrl+v)

-If this don't work, check if was created
-a directory with the name: skins, in the
-mirc directory.
-If this until doesn't work, contact me,
-see how in the last lines.


Will be created an �tem on the status, channels
and menubar popus. You can open the manager press
Shift+F1.

Ps. part of this code was made by ratdog, so tanx!!!


If you have trouble, or just want contact me:

e-mail: poison13@starmedia.com      UIN: 13083359
          ______________________________

  Look for atualizations and others addons/scripts
 
       http://members.xoom.com/tiferro/
              http://fly.to/tiferro/
              http://tiferro.cjb.net/