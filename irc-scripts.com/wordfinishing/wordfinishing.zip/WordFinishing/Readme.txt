Thanks for trying out my addon you can get all my addons at 24.160.231.122


This is the word finishing addon   v1.00
------------------------------------------
Install 

all u do is unzip this to your mirc dir
and then start up mirc and type /load -rs wordfinishing.ini
------------------------------------------
To use 

All you have to do is type like brb and it will come out as be right back

To see all the words that are in it look at the word list