
 add on script
 this script is file download on auto run..
 loading
 unzip to c:\mirc\
 /load -rs auto.mrc

if dialog make want ?
 mailto  akusi@hanmail.net..
 have fun..