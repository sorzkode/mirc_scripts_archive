Pretty simple,
in a dcc chat type /explore 
once you do this once goto settings and you can turn on auto-open

my first script for release, so please dont be too technical with judging, pretty simple coding, works great for me.

a few bugs... report any to abaratican@hotmail.com

/load -rs abaexp10.mrc