-----------------------------
 Clone Manager v1.02 Readme 
    - Delta2k
----------------------------

Welcome!
This file includes installation, usage and support instructions for Clone Manager.
Any questions you have can be answered in here, and if they arent you may find 
contact information at the bottom. 
* Note: mIRC's IAL must be on for this addon to work (/ial on)

Contents
  A) Installation
  B) Usage
  C) Uninstalling
  D) FAQ
  E) Contact
________________________________


A) Installation: 
 To load this file, simply unzip it into any directory you wish, and open your mirc exe file. 
 At the command prompt of mIRC, type /load -rs C:\path\to\clonemanager.mrc or if the file 
 is in your main directory (the one with the mirc exe file), you may use /load -rs clonemanager.mrc
 A popup dialog box will popup (surprise!) where it will ask if you want to load this file. 
 Press 'Yes' to continue loading and 'No' to not load it. When loaded, instructions will be given
 in the active window on how to use Clone Manager.
Quick Reference: type /load -rs C:\path\to\clonemanager.mrc

B) Usage:
 When you have loaded Clone Manager, there are several ways to access the different features.
 The main area would be in the channel popups, where you can configure the addon, as well as
 do various scan types and options. To open the scan dialog, right click in the channel and under
 'Clone Scan', you will see an option for Quick Scan. Clicking this options will bring you to the
 clone scanning dialog. You should see an interface with three menu items, 4 buttons, a list and a
 drop down box. The 'Done' button will exit the dialog, click this to finish. When you want to scan
 for clones in a channel, click on the drop down box to choose a channel to scan for. If you don't, 
 another error dialog box will inform you to choose one. (The drop down box update automatically so
 there is no need to open and close it.) Once a channel is chosen, click the 'Scan' button to scan the 
 chosen channel for clones. If any are found, they will be displayed in the list box. The other two buttons
 'Kick' and 'Kick Ban' will only be enabled if you have scanned a channel and are an op in it. Select the 
 clones you want to kick/ban and click the appropriate button. 
 Menu items:
 File	Options	      Help
 .Scan	.Configure      .Contents	
 -	                      .About
 .Save
 .Save As
 -
 .Exit
 This is a representation of the menu items (Creative eh? :)
 - The 'Scan' item does the same as the button in the main dialog
 - Save & Save As items save the output of the clone scan into a file. The default name for the
   Save As selection is clonescanMM/DD/YYYY.txt 
 - Exit does the same as the 'Done' button in the main dialog
 - The 'Configure' item brings up a dialog where you can configure your options.
 - Contents will bring up this help file 
 - About gives contact information about Clone Manager
Configuring your options
 The configuration dialog gives a number of options which you can easily change
  - To enable searching for clones on join, check the 'Join' checkbox at the top
  - If this is on, you can choose a reaction to finding any clones, which are kick/banning the clone, 
   warning them, or doing nothing. You can also enable checkbox to echo any clones found to the
   status/active window, whichever ones you prefer. 
  - To choose the scan type you want to use when scanning (if you dont know, just leave it blank) 
   use the drop down box to choose the mask type you want. 2 is the recommended type for finding
   the most clones, since its in the form of *!*@host - This is the default type in the add-on 
  - The warn message editbox allows you to put in the warn message you want to give when a clone 
   is found, which is also the kick message when a clone is kicked.
  - The last checkbox, labeled 'Allow Shift+F1 for clone scanning' allows the add-on to use the 
   Shift+F1 hotkey to bring up the scanning dialog and scan the active channel easily. 
    *Note: If used, this will over-write other Shift+F1 aliases. If you dont like popups, but dont want
     to over-write your Shift+F1 alias, you can use the alias /activescan for the same results
Nicklist
  There are nicklist popups which are enabled only if you are an op in a channel which allow you 
   to check certain nicks and take appropriate action without doing a full clone scan. 
Other
  If you prefer windows to dialogs, you can output results to a @custom window using the channel
  popups and going to the item 'Scan' -> 'Window' 

C) Uninstalling
 The add-on is extremely easy to unload, and requires very few variables to be unset due to use 
  of local variables and aliases. To uninstall the add-on, right click in the channel menu, go to 
  'Clone Scan', and Unload. A popup will come up to confirm the choice, and by pressing yes the
  script will unload itself completely.

D) FAQ
 This section includes common questions you may have with the clone manager.
Q:	"No clones are found and i know there are some in the channel" 
A:	This can be due to many reasons, try scanning again, make sure you have the right 
	channel, enabled your IAL, and try changing your options for the scan type (2 brings better results)
Q:	"The Save and Save As items are disabled even after i scanned the channel"
A:	They are only enabled if any results are found after the scan.

Q:	"This addon doesnt work!" (Not quite a question.. but *shrug*)
A:	Again, check your settings and IAL. If you think its a bug please contact me

Q:	"Where are all the features i see in other clone scanners?"
A:	There are many features being implemented into the next version, but for now this 
	scanner was meant for speed, quickness and efficiency opposed to 1000's of features
Q:	"In the nicklist, the persons address isnt showing"
A:	Try whois'ing the user or update your IAL with /who

E) Contact
 If you have any features, questions, suggestions, idea, comments, bugs, or even just want to say 
 hi, you can email me at Delta2k@mail.com or find me on DALnet with the nickname Delta2k. If 
 i'm not on feel free to memoserv me (if you're a registered user).
 This information can also be found in the about dialog.
____________________________
 
Clone Manager v1.02 
Thanks for using this addon :)
 