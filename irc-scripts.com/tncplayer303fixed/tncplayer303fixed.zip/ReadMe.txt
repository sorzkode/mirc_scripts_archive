;;;;;;;;;;;;;;;;;;;;;;
;;                  ;;
;;                  ;;
;; TNCr�w Mp3Player ;; 
;;                  ;;  
;;                  ;;
;;;;;;;;;;;;;;;;;;;;;;
--------------------------------------------------------
[Installing]
*This addon will only work with mIRC 5.6x*
Extract everything in the zip file to your mirc or script folder including
tncplayer.bmp, tncplayer2.mrc, tncdlg.mrc and tips.txt then type in any window /load -rs tncplayer.mrc
Then type /install in any mirc window
--------------------------------------------------------
[What's new on 3.03?]
1.New dialog interface in the main player
2.Lot's of bugs fixed
3.Added Tips!
--------------------------------------------------------
[Possible Problems]
1.Maybe loading the mp3 player u will 
see this * /dialog: 'mp3.player' error loading 'tncplayer.ico'
if that happend it's coz u didn't extract the tncplayer.ico
to your mirc or script folder, if this happen go to the
addon zip and extract tncplayer.ico to your mirc or script
folder any other problems mail me.
2.Playin an mp3 maybe u will se something like this
* /run: command disabled if this happen 
press alt+o then doble click on general click on lock and uncheck /run
--------------------------------------------------------
[Beta Testers]
GaTiLLeRo, P0is0nIvy
--------------------------------------------------------

[Bug Reports]
E-Mails:
kike26@hotmail.com
dark_kill@hotmail.com
Urls:
http://dfscript.irc-scripts.com
http://dfox.cjb.net
http://blackuniverse.com/darkside
http://taxhater.com/darkside
IRC Servers:
islaonline.chatpr.com Nick: DarkSide #Channel: #tropichat , #tripeochat , #chatboricua
webbernet.dal.net Nick: DaRk-KiLl Channel: #battle-room
surfzone.chatpr.net Nick: DarkSide Channel: #Tropichat