AwaySystem 3.02 Readme
http://www.geocities.com/mmircs
MmIRCS@bryansdomain.virtualave.net

Date released: 9/21/2000
--------------------------------------

Topics discussed in this file:

1 Changes to AwaySystem 3.02 from 3.01
2 Loading AwaySystem into mIRC
3 Disclaimer

--------------------------------------

1. Changes to AwaySystem 3.02 from 3.01

AwaySystem 3.02 has some new features than 3.01, which include:

AwayNick option for Presets... You can have a special nickname assigned
to a specific preset.

Fixed icons for mIRC 5.8 - mIRC 5.8 has a little trouble drawing bitmap
icons within a box.

Fixed bug for AwaySystem Theme creator - would return an error if you don't
already have an awaysysthemes.ini file.. *oops* heh

---------------------------------------

2. Loading AwaySystem into mIRC

Contents of the ZIP file:

1. awaysys.mrc - Core script file
2. awaysys.hlp - AwaySystem Winhelp file
3. mmircs.bmp - MmIRCS Logo icon
4. yield.ico - Error dialog icon

*--Upgrade Note-------------------------------------------------------------------------*
| To upgrade AwaySystem simply follow the directions below, making sure you overwrite	|
| your old awaysys.mrc file and be sure that mIRC is not running or type		|
| /reload -rs <path\>awaysys.mrc							|
| or even restart mIRC to make sure mIRC gets the new version of AwaySystem.. The only	| 
| difference between a clean install and upgrade is that AwaySystem will find your old	| 
| settings and ask if you want to import them.						|
*---------------------------------------------------------------------------------------*

Unzip the files to any folder. In mIRC type /load -rs <path\>awaysys.mrc
<path\> being the folder where you unzipped AwaySystem (such as C:\mirc\scripts\)
Note: if the folder name is a long name (contains spaces), you must enclose the entire
path in quotes (") like: /load -rs "C:\My Mirc\awaysys.mrc"

Click YES to the Remote Script warning.. If you don't, AwaySystem will not be properly
set up.

Access AwaySystem from the menubar, status and channel popup menus.. Be sure to read
the help for further information about AwaySystem's features.

-----------------------------------------

3. Disclaimer

AwaySystem is provided AS IS without warranty of any kind, either express or implied. In no 
event shall MmIRCS Scripts be liable for any damages whatsoever including direct, indirect, 
incidental, consequential, loss of business profits, or special damages even if MmIRCS Scripts 
has been advised of the possibility of such damages.

The term "MmIRCS Scripts" refers to it's scripters, scripts, and testers.

-----------------------------------------

Enjoy!

mudpuddle <MmIRCS@bryansdomain.virtualave.net>