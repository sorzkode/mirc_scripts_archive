Dict+ 
By fubar
For mirc5.61

Dict+ is not your normal dictionary addon, it uses the DICT protocol which 
allows advanced word searching options and several databases to choose from.
Sorry english only.
-------------------------
Instructions:
1. Unzip dict.zip to wherever.
2. Load dict.mrc. (example: type /load -rs c:\mirc\dict.mrc)
-------------------------
Usage:
/dict [word]
-------------------------
After that the rest is self-explanatory. No documentation needed.
-------------------------
Definitions of each database:
note: some definitions below were copied from various sources :)

Webster's Dictionary: normal dictionary
WordNet: A lexical database for english.
US Gazetteer: City information lookup.
Jargon File: hacker slang, folklore, and humor.
FOLDOC (Free On-Line Dictionary Of Computing): A searchable dictionary of acronyms, jargon, programming languages, tools, architecture, operating systems, networking, theory, conventions, standards, mathematics, telecoms, electronics, institutions, companies, projects, products, history, in fact anything to do with computing.
Elements: Definitions of the elements.
Easton's 1897 Bible Dictionary: Topics are from M.G. Easton M.A., D.D., Illustrated Bible Dictionary, Third Edition, published by Thomas Nelson, 1897
Hitchcock's Bible Names Dictionary: Contains more than 2,500 Bible and Bible-related proper names and their meanings