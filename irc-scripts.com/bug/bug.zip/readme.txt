      __
     / /__ ______
    /.  / � / . /
   /___/___/_  /
 .....!irc/___/.................. .. .
 :...:.....
 ....:....:........... .. .
 :  version: beta 1
 :  author: rockman
 :  release: 05/01/2000
 :.......................... .. .
   ....:.tkz.............. .. .
   : physi0n   NoBIOS   poot`z    
   : archon    shao`z   hempkiller
   : violent   vVv      dr_]{iller
   :.............................. ... . .
 ....:.others................ ... .. . . 
 : creditz to..
 : erawtic: (addon mp3.mrc) retired: id3 system and kbps system
 : physi0n: sockets (download themes) and retoX.thm 
 : NoBIOS and dr_]{iller: others...
 :.............................................. ... ...  .
    .....:.others.................................... ...  .. .
    : bug!irc is a beta version..
    : find a bug? send an e-mail to rockman@brasnet.org
    : home page: www.bug.cjb.net
    :.............................................. .. ... .
 