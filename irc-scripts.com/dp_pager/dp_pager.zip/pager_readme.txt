*************************************
*         DarkPaladin Pager         *
*           Version: 1.05           *
*        Visual Pager System        *
*************************************

Here's how to install:
1) Unzip the files to your mIRC directory and type
  /load -rs pager.mrc


-------------------------


This a simple pager system with a realistic look. This pager reacts based on ctcp pages:
/ctcp nick PAGE message goes here

Each page you recieve is stored in a database for later retreival. To view your pager if the
pager window click the Commands menu and select View Pager.

Just a note:
Due to the fact that you may recieve longer pages than the screen of the pager will allow for,
The "view" button will be enabled and you will see a "..." following end of the message.
Click this button to view the full message

If you have questions, comments, or suggestions please email the_psionic@hotmail.com or leave me
a memo on DALnet, nick Psionic.