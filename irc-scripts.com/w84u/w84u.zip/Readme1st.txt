W84U 1.0 ( Id�e de `KenjI` :) ) ( Compatible mIRC 5.7 )

D�zippez dans le r�pertoire de votre Mirc.
Lancer Mirc.
Tapez /load -rs W84U.mrc pour charger le fichier

Si vous trouvez des bugs �crivez moi � eViL_dEaD@thepentagon.com

Thx :)

     __         ___              _____       ____
     \ \       / / |           _|  ___|     |  _ \
     _\_\     / /| |         _| | |__   ____| | \ |
    / _ \\   / / | |        /   |  __| / _  | | | |     
   \  __/ \_/ /| | |__  ___ | o | |___< (_| | |_/ |   
    \___|\___/ |_|____||___|\___/_____ \_\__|____/ 