LOADING
--------
To load damn v1.0, unzip damn.zip to your mIRC directory or whatever,
Open mIRC, type /load -rs path/damn.mrc


USING
------
After loading the script,
Select 'damn v1.0' from the menubar
and click 'start'.


UNINSTALLING
-------------
Select 'damn v1.0' from the menubar
and click unload, this will unload the addon.


AUTHOR
-------
Nick name: kHz
Networks: DALnet ( irc.dal.net 6667-7000 )
Email: idansh@matav.net.il


EOF