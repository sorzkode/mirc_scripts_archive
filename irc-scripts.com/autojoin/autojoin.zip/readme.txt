
 Auto Channels Join
~~~~~~~~~~~~~~~~~~~~
 - Author: CarTMan
 - Description: Auto channels join - dialog based
 - File name: autojoin.mrc

 Installation
~~~~~~~~~~~~~~
 To install the Auto Join addon, copy the "autojoin.mrc" to a regular
 mIRC directory such as C:\mIRC\
 Run mIRC and type in the status window: /load -rs autojoin.mrc
 The a dialog will popup, Choose YES.

 Notes
~~~~~~~
 This addon has been tested alot of times, and I think its bug free.
 If you see any problems\bugs please report anything to desired@inter.net.il
 Or you can find me on DALnet - or Memo CarTMan.
 Comments\Suggestions\Insults will be appriciated :)

 -CarTMan
