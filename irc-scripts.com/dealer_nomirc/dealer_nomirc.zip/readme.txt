				------------------------------------
				------                       -------
				------     DEALER About      -------
				------                       -------
				------                       -------
				------                       -------
				------                       -------
				------      CoolMaster �     -------
				------                       -------
				------------------------------------



FIRST SORRY FOR MY ENGLISH, really sucks :]

*** Installation ***

* Full Version with mirc.exe *

Just unzip and them open script with dealer.exe


* Full Version without mirc.exe *

Need to put mirc.exe on script dir, you can get mirc on http://www.mirc.co.uk


* With patch *
Just download patch, unzip patch into script dir and them, type /installpatch on script
read docs\patch.txt for more help




*** About ***

This script works under many networks.
Script need mIRC 5.82+ to run correctly.
I wanna 10x to Spyon, nXistence, team #Script3rs. To kall for some topics and to all
ppl that help me and give ideas.
Don't forget to join to offical channels of Dealer: #Raptors && #your_way && #script3rs 
on PTnet 3 really cool channels!
If you find a bug please report to me.


				CoolMaster	<CoolMaster@pthelp.org>
				URL	 	<http://coolmaster.org>
				Copyright CoolMaster�


