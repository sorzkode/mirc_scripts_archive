..(chan probe) v.0 beta


..(install)

  load the sun-bitch up and type /probe
  if you don't know how, clue: /load -rs chanprobe.mrc


..(whats this all about)

  this addon scans a channel for the specified port
  using the /who command
  note: if the irc server your using maskes ip's
  and your not an op on the channel this addon won't work..
  and i think unmasking all the nicks would take to damn long 
  so i don't realy even wanna go ther.


..(contact info)

  ok this info is for people to bug me and harrass me
  about what i fucked up on.. or if your really board
  you can just harrass me.
  
  irc.msn.com #deftones&korn 
  ryun@planetarymotion.net
  69496033


..(realease info)

  i usualy never release my scripts
  i don't know why i'm releasin this one
  this is the first version "buggy code"
  i sat down and wrote it in like 20 min
  with an occasional bud break heh
  have fun and don't be ah dick in any way
  with this script.. cause that ain't cool
  and you wanna be cool don't you! heh yea right!