======================================
hMoNg-Fu's Bad Word Filter v0.75 Alpha
======================================
Scripters: hMoNg-Fu (From NewNet)
Created: September 8, 1999
Testers: Bozzman, Zaj`yaj, aQuAboY

Thanks for checking out my swear word filter script.

If you don't already know what it does, it modifies bad words
on your channels so you wont see any bad words.
You have 2 options, Text Censor and Self Censor. Text censor is 
censoring text of other chatters, and self censor is your text.

	To load this script:
		//load -rs censor.mrc

If it says "* /load: no such file ..." then make sure you include
the exact path of the censor.mrc where you exracted it or moved it to.

This is a early alpha(first) version of the script so there 'may'
be some errors/bugs so please let me know and I intend on working on
it and updating it frequently, make sure you check out future verions.

======================================================================
Cencor Script By hMoNg-Fu
Email: honkey_fu@hotmail.com

Please email me with comments, questions, bugs/errors, and so on!
Thanks!