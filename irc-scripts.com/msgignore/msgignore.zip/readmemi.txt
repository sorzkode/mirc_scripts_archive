
	Msg Ignore Version 1.2		May '99
		http://animedomain.com/ladydana/index.html

Description:
^~^~^~^~^~^~
   This script allows you intercept private messages and to choose to do with them as you wish. There are 
several options:

(1) Ignore the message (not show it anywhere)
(2) Show it in an active window
(3) Show it in a custom window

   It's also possible to choose to log all the messages in a *.txt file of your choice and to send a message 
of your choice to the person who msg'ed you. The script has a built in flood protection for those who would 
flood you in private. You may choose between a 'permanent' ignore or a temporary ignore (15 seconds).

   The script also has the ability of allowing you to set a list of nicknames that will not be affected by this 
script. Everything is easily accessable via dialogs (the menubar popups).


How to install this script:
^~^~^~^~^~^~^~^~^~^~^~^~^~^

	Your remotes has to be on for any scripts to work. Type:

		/remote on

	In any of your mIRC windows. It should say something like:

		*** Remote is ON (Ctcps,Events,Raw)


***
  If you downloaded this script from a webpage, then move the script to your mIRC directory. Type:

	/load -rs msgignore.mrc

  in your Status Window.

***
  If you got this script via DCC send from someone over IRC, then type:

	//load -rs $getdirmsgignore.mrc

***
  You can also load the script manually. Go to the TOOLS menu on the top and choose REMOTES. Once inside 
Remotes, choose LOAD SCRIPT from the FILE menu. Select msgignore.mrc and press on OKAY. The script should 
be loaded.


Comments:
^~^~^~^~^

   You may distribute this script anywhere you like. All I ask is that you'll always include this Text 
File (Unchanged please) if you do. It can help many a Newbie to install the script. Also, I worked very hard at 
this script and purposely didn't put any logos. Please keep it that way and don't claim it as your own.


Author:
^~^~^~^

   More common nicks: Danaria, LadyDana, Schala and Katlyria
   EMail: ladydana@animefan.org or dany@mindless.com
   ICQ: 5117508
   IRC Network: DALnet (http://www.dal.net/ - irc.dal.net 7000)
   Channels: Home channel: #RavenScar
             Help channels: #HelpDesk, #IRCHelp, #mIRC, etc ...
   Visit http://www.helpdesk.mircx.com/scripts/index.html! ;) 
		and http://www.irc-scripts.com/