-=-=-=-=-=-=-=-=-=-=-=-=-=-
-=- Basic System README -=-
-=-=-=-=-=-=-=-=-=-=-=-=-=-

Please, extract the bsys.mrc
to one path ( eg: c:\mirc\bsys\ )
And the .bmp files to \figuras 
( eg: c:\mirc\bsys\figuras )

10x Tentacle
irc.montreal.com.br 
#ScriptX