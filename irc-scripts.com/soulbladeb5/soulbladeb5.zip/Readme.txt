Thanks for choosing Soul Blade B5.

Soul Blade has passed a lot of excessive testing since it's first release in
September 2000, in order to deliver maximum effectiveness.

What is Soul Blade ?

Soul Blade is an advanced script for the mIRC IRC client, and it greatly expands
mIRC's built in options and capabilities. Soul Blade is easy to use for the novice,
and as equaly powerfull for the expert.

In order to check ALL Soul Blade features, please check Soul Blade's help file,
and read through the Versions topic.
There are listed all changes, updates, and additions.

How to install Soul Blade ?

When you download Soul Blade, simply unzip the file to any folder of your choice,
by using any kind of unzip utility (WinZip, Pkunzip etc ...).

Note : Soul Blade is NOT directory dependant, which means you can use long folder names,
and use spaces, BUT, the mIRC client still has some problems with space containing
folder names.

Once you've unzipped the file, copy the mirc32.exe and mlink32.exe files to the folder
where you unzipped Soul Blade. You could also copy the intro.hlp and mirc.hlp files,
which are not required for Soul Blade to fully function, but can be referenced
from within Soul Blade's help file.

Note : Soul Blade requires adleast mIRC 5.8 or newer to function properly.
Otherwise, some parts (i.e. Media Player) will not function at all. I strongly recomend
you download and use mIRC 5.81, since it involves some bug fixes that greatly
enhance Soul Blade itself.
You can download mIRC 5.81 at http://www.mirc.com/get.html

If you have any questions about Soul Blade, check the help file, by pressing F1 from
within Soul Blade. If your search fails, mail me and I'll help you.
You should also reconsider mailing me if you plan on using Soul Blade,
and I'll place you on my mailing list and promptly inform you on any updates.

INSIDES ( insides@soulbladescript.cjb.net)

P.S. Please note that the Update Manager, even though fully operational, will probably
stay down until I find quality web hosting to upload my update packets. So far,
I've been able to locate appropriate servers to upload the update packet listings.
All this means that you can still use the Update manager, but the amount of downloaded
files is limited due to web space limitations. Sorry.