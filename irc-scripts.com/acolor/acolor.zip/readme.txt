the auto-color add-on v1
by FalkO
------------------------


instructions...

copy the file acolor.mrc to your mirc directory, and the paste
'acbmps' put in your mirc script directory. example:

c:\your-script\acbmps\
c:\your-script\acolor.mrc


------------------------
if you have questions relative with 'scripting', go to #scriptX
at irc.brasnet.org or send me an email: falko@brasnet.org

my script url is: http://bf3.cjb.net  --  thankz!