              -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
              -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
              -=-=-=-=-=-     The DarkPaladin version 2.0.7     -=-=-=-=-=-
              -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
              -=-=-=-=-=- http://members.xoom.com/psionicscript -=-=-=-=-=-
              -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
              -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 


-----------------------------------------------
--  Contents                                 --
--    1) Introduction and Information        --
--    2) Modules and How to use this script  --
--    3) Contact Information                 --
-----------------------------------------------



How to load..
 
  Unzip to the C:\mirc\ directory, or whatever is your mIRC directory.
  Start up mIRC, and type this in the status window: 
    /load -rs install.psi
  The rest of the script loads itself.
  Your done!

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
-=-=-=-=-=-=-=-=-=-=-=-=-=-Section 1-=-=-=-=-=-=-=-=-=-=-=-=-=-
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

I began writing this script on April 23, 1999. This version was released on September 9th.
There is nothing violent, vengeful, or lamerish in this script. This script includes kick/ban
features using function keys, Clone scanning and sweeping, Bad word/nick kicker, Caps kicker, 
auto Ident, and many more features all included into several GUI Dialogs. If you are looking for
a war script, revenge script, "Cool" script, that you can abuse people with, this isn't the one. 
But if you are looking for good all around channel protection, very customizable script, ease 
of use, and more.. Then you've found the right script :)

If your one of those people who want to know what this script is putting on to your harddrive,
here is the list: 
utility.psi, nc.psi, utility2.psi, misccom.psi, miscoptions.psi, levels.psi, clonescan.psi, 
stopmsg.psi, instal.psi, kickban.psi, help.ini,and the script itself will create a paladin.ini 
file to store its settings. The script will also create an akicks.ini file for the channel akick
listings.
                -Psionic


  How To's on the upgrades.
  July 27th - 
     I have changed the way this script stores information from variables to ini files.
     Here's how to configure it for your channel(s):
     1) Hit F12
     2) In the dropbox type in the channel you want to add settings for
     3) Configure the settings, click OK
     
     Later on if you want to change those settings:
     You can do 1 of three things:
     1) In the channel hit F12, and it will load the settings into the dialog
     2) Hit F12, click the downarrow in the combobox, and select your channel.
     3) Type the channel name into the combobox, if it is a valid channel
         (one that has already been configured) it will load it into the dialog
      --Any of these will load your settings into the dialog for you to change
 
   August 6th -
      Beta of my MultiServ addon which allows multiple server connections.
      In the "Commands" menu, select "Multiple Server Connection" and enter the information
      that is requested.


  +++++++++++
  ++Updates++
  +++++++++++
   +2.0.7 --- September 9th
     -Many bugs fixed with the installation processes, special thanks to LadyDana for the review
        on www.IRC-Scripts.com which let me know about them.
     -Completely rewrote the clonescan.psi aliases: more efficient, easier to use/read.
     -New addition to the clone killing system. This addition allows the user to select, for
        each channel, whether they want to kick the ghost/old clone of the incomming nick, or
        kick both/all clones of the incomming nick.
     -Help system is still in the works, need to finish writing the file
     -New autokick addition: Kick banned users - This does what it says, kicks anyone banned 
        from the channel.
     -A few cosmetic upgrades were made to the
     -Added /autoghost and upgraded /autoid. /autoghost ghosts the nick you specify with the 
        stored password. /autoid can now use parameters, to identify as a different nick than
        you are using do this: /autoid psionic - This would send the identify command to nickserv
        with the valid password for that nick (/msg nickserv identify nick password)
     -Added special thanks area to the about box.
     -Fixed away response bug to word/phrase.
     -Too many cosmtic errors and bugs were fixed.
   +2.0.5 --- August 22nd
     -Almost 100% complete with the new help system.
     -More bugs fixed
     -Added /autoid command which sends identify to nickserv
     -Fixed the problem with setting the messageblocker autoreplies.
     -In the process of working on an idlekicker, lots of bugs to work on so I disabled the
        option in the channel settings window.
   +2.0.4 --- August 17th
     -New help system added, accessible by hitting F12 and clicking the 'help' button or from
        the Commands menu "Help with +The DarkPaladin+"
     -Nick flood kicker should be working again, I'll fix it if it doesn't
   +2.0.3 --- August 16th
     -New autokick added: Long line flood. Using this option, you can set it if someone uses
        too many characters in one line, it kicks them. No ban time is settable as of yet.
     -Less bugs.
     -Boo.
   +2.0.2 --- August 16th
     -New autoidentify system added. You can set passwords for each nick. Accessible in the
        feature configuration window. (Commands -> Configure �The DarkPaladin�)
     -More bugs squashed.
   +2.0.1 --- August 15th
     -Small upgrade
     -Bad Nick kicker works now
     -Multiple bug fixes also fixed.
     -Anti-Clone killing on join works too
   +2.0 --- August 14th
     -Not many bugs found, so not many bug fixes.
     -New configuration window, Commands menu -> Configure +The DarkPaladin+ or hit F12
        and click the 'Other Config' button down at the bottom.
     -Multi-IRC Addon is fully functional now. All that remains is cosmetic upgrades.
     -Repeat kicker fixed.            
   +1.9.4 --- August 12th
     -Multi-IRC Addon is almost complete.
     -Tweaked many of the autokicks to make them run faster
     -As usual, bug fixes :)
   +1.9.3 --- August 6th
     -New addition to the script, an addon I wrote which allows you to connect to another
        server and chat there in the same single mIRC application, its not complete yet
        but will be soon.
     -Many bug fixes and small upgrades
     -Fixed a bug with the F8 manual ignore key...
   +1.9.2 --- August 2nd
     -Fixed a few bugs in the installation processes, it should install correctly now
   +1.9.1 --- August 1st
     -Chanserv aKick works now. This option is designed to enforce akicks in certain
        channels and on many networks, the services go down or get lagged often, so 
        this option would kick-in and boot the user if their address matched the akick
        list.
     -Fixed the Revolving door kicker, it doesn't kick everyone now. Whoops.
   +1.9.0 --- July 31st
     -You can now change the badwords list easily via the F12 dialog. Its the editbox
        right next to the bad nick kick option.
     -You can now assign ban times to each different offence, these options can be set
        via the command menu: +The DarkPaladin+ Script >Set Autokick/other kick ban times
     -Fixed more bugs that I hadn't noticed before, quite a few, the interface should 
        clean itself up a bit.
     -Fixed a bug where the script wouldn't load if there was a space in the directory, 
        this should be fixed. Suggested by LagMonster - DALnet
   +1.8.1 --- July 27th
     -Fixed the bugs caused by the reconstruction of the script
     -Clone Killer option added, kills clones on join.
     -I killed the 'channel set' button, simply because its not needed anymore
     -Added a 'listen' level, so that you can allow users to message you
        permanently
   +1.8.0 --- July 27th
     -Holy shit update :)
     -Options now allow you to configure each option for each channel. 
        (see above for help on this)
     -Pager can now be turned off
     -Grouped a bunch of popups into the command menu, instead of cluttering 
        the channel menu.
     -Message blocker has been enhanced even more, whohoo!
   +1.7.1 --- July 26th
     -More bug fixes still.. As usual
     -Message Blocker system has been enhanced
     -New Option added to certain autokicks. A warn feature which warns the user 
        once, then if the user breaks the script's limit again, it does what it 
        normally would do, kick/ban.
   +1.7.0 --- July 26th
     -Mucho bug fixes everything should work correctly now.
     -The Nick completer was fixed. It would show a 'S' to 
        those people not using the FixedSys font.
   +1.6.7 --- July 25th
     -More bug fixes...
   +1.6.6 --- July 24th
     -A few minor bug fixes not worth mentioning
   +1.6.1 --- July 24th
     -Fixed more bugs that popped up in the repeat kicker.
     -Fixed a bug where $maxchar (used in excess character kicks) would count the
        wrong number. Fixed.
   +1.6  --- July 23rd
     -Overhauled the manual override system. This new override system allows you to
        choose which options you want to use manual on, and others you want to have
        automatic. Its your choice now :)
     -Fixed repeat kicker and flood kicker, few minor bugs in those.
     -Fixed the revolving door detection, doesn't kick everyone each time they join.
     -Adding in a new online help section. Expect it to be finished soon
     -The right side of the options dialog has the manual/auto checkbox. Unchecked
        means auto, checked means manual.
     -Hopefully most of the bugs in the past have been worked out, the manual system
        is as of yet not 100% bug free, unless I've fixed them all
     -Added a new level to the levels list, a 'badlist'. This list isn't a shitlist,
        although I might add one later on.
     -DCC blocking works now, F7 toggles DCC SEND ignore, and Shift F7 toggles DCC
        CHAT ignore
     -Added an akick protection thing. This is good if chanserv is lagged. If you want
        to grab the current channel's akick list, if you are an aop, rightclick on the
        channel and click "Update AKICK list" This will put all the akicks into a file
        called 'akicks.ini' This new addition uses the file to check if a person who is
        akicked enters the channel, so if chanserv is lagged, you can kick/ban them so
        that you can keep those akicked people ou.
     -This was a huge update, hope everyone likes it.
   +1.5.0 --- July 16th
     -Fixed a lot of bugs with the help of Commander-Apoc testing the installation
        and stuff
     -Added DCC blocking ability, accessible from the channel menu.
     -Repeat Kicker works now.
     -Added ctcp flood block/kicking. This is enabled when flood detection is enabled
     -Added a revolving door checker/kicker.
   +1.4.1 --- July 7th
     -Enhanced the Excess punctuation kicker to include all characters. Now if
        someone abuses any character, they are kicked.
     -Enhanced a few other things, just can't remember them, lol ;)
   +1.4  --- July 5th 
     -Enhanced the clone detection. Now checks if your channel is being clone
        attacked, and if so it bans *!*@host.domain to prevent any more clones
        from joining, and highlights the clones currently in the channel red for
        ease of cleanup.
     -Experimental Repeat Kicker is not in operation yet. Will be in the next 
        version.
     -Excess Puncuation checker is now implemented. Checks for periods, !'s
        and ?'s 
   +1.2.1 --- June 3rd 
     -Kick ass new manual override. This new override system still scans for
        everything you want it to scan for, but instead of autokicking, it 
        echo's telling you what the user has done, and tells you to hit F5 to
        kick/ban them, automatically using the correct kick msg.
     -I had to resize the main options dialog because of lack of more space. 
        This is a good thing :)
   +1.11  --- May 31st -- Small upgrade
     -Advanced Pager system...
        This pager works quite well, it allows the nick to send you a page
        only once every 10 minutes. But the neat thing is, that it opens up
        a window which tell you who paged you, the time, and the message.
   +1.1   --- May 31st
     -Enhanced Clone scanning: Scans for clones on the nick that joins
     -More custom user levels
     -Scanning for illegal channels when a nick joins       
   +1.03  --- May 16th
     -Nicklist menu for user level additions
     -Now can check for control code abuse, max codes setable via options                              +channel specific scanning for control code abuse.
   +1.02  --- April 28th
     -Complete unban protection added.
     -Custom channels for floodkick, baddwords, and capskick scanning.
     -Better Level editing.
     -Flood Kicker now checks for action floods aswell as text

   ********************Note***********************
   * Yes, the versions do tend to jump, but this *
   * is because I don't release some versions... *
   ***********************************************

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
-=-=-=-=-=-=-=-=-=-=-=-=-=-Section 2-=-=-=-=-=-=-=-=-=-=-=-=-=-
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

  The modules include the following:
  Levels.psi - *UPDATED 2.0.5*
      This is the Level editor. If you have set levels for nicks, hit F11, 
      and type in the level you wish to edit and hit enter. To remove someone, 
      click the line with the nick on it and hit the REMOVE button. To add 
      users, type /adduser <nick> <level>. To add users to preset levels, 
      rightclick on their nick in the channel, and select "Add user to level"
      and select a level.
  Clonescan.psi - *UPDATED 2.0.7* *BUG FIXES 2.0.7*
      This includes the clone scanning and sweeping protocol. F9 and shift+F9 
      are the keys to activate these commands. F9 simply scans for clones and 
      echoes them to the active window, but Shift+F9 Activates the clone 
      scanner which kicks all nonhost clones. Also scans for inbound nicks to 
      the channel.
  Misccom.psi - *UPDATED 2.0.5*
      This module contains miscellanous commands such as GetInfo, which gets 
      information on a specified nick/channel. This command can be accessed 
      by typing /getinfo <nick|channel> or in the nicklist or channel window, 
      it is listed as "Get info on..." Now contains DCC Blocking capability.
  Kickban.psi - *UPDATED 1.7.0*
      This module hosts the F2-F4 kick/bans commands. Read below for information on
      the function keys.
  Utility.psi - *UPDATED 2.0.7* *BUG FIXES 2.0.5*
      This module contains the main options dialog. It can be accessed by hitting
      F12. This module also contains the most vital of the components of this script.
  Utility2.psi - *UPDATED 2.0.7*
      Contains additions to utility.psi, like /me checking and channel notice checking.   
      Also contains other components vital to the script.
  Miscoptions.psi - *UPDATED 2.0.5* *BUG FIXES *
      This houses many of the small functions of the script, it's primary function is to
      run the Custom Config window.
  Stopmsg.psi - *UPDATED 1.8.1*
      This contains the message blocker system. If someone messages you, hit F8 in the
      query window, it will close it and ignore the user. DCC blocking is in here.
  tchan.psi - *UPDATED 1.6*
      This changes the boring normal output of joins and quits, to something more
      tasteful.
  nc.psi - 
      This is a cool addon I had for a while, and decided to add into this script,
      it has an option to be turned off or on. I added an option to add channels
      in which it will be colorless so you can still use it in channels that frown
      on colors. The menu which contains the command to disable or enable the Nick
      completor is in the channel or nicklist (right click on the channel window and 
      select "Turn Off NC" to disable, etc)


  +++++++++++++++
  +Function keys+
  +++++++++++++++
 
   F2 ============= Ban
   Shift + F2 ===== Reban last ban as permanent
   F3 ============= Kick /w random message
   Shift + F3 ===== Kick/Ban /w random message
   F4 ============= Kick /w prompted message
   Shift + F4 ===== Kick/Ban with Prompted message
   F5 ============= Manual Override kick.
   F7 ============= Toggles DCC CHAT ignore on/off
   Shift + F7 ===== Toggles DCC SEND ignore on/off
   F8 ============= Closes, ignores, and warns a nick in the current query window
   F9 ============= Clone Scanner
   Shift + F9 ===== Clone Sweeper (Scans and Kicks clones)
   F10 ============ Scans for Vulgar Nicks
   F11 ============ Level Editor (userlevels)
   F12 ============ Opens up the options window
   Shift + F12 ==== Open received DCC file (if possible)


   Check this website for information on what, in detail, this script can do. 
      http://psionic.irc-scripts.com
    -This site isn't up yet, don't expect that it work :)
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
-=-=-=-=-=-=-=-=-=-=-=-=-=-Section 3-=-=-=-=-=-=-=-=-=-=-=-=-=-
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

Contact Information and credits:
Author: Jordan Sissel - Psionic
Email: the_psionic@hotmail.com
ICQ: 13646189
AIM: PsiKronic  
Web Page: http://members.xoom.com/paladinart/
Updates: http://members.xoom.com/paladinart/darkpaladin.zip
       
Credits:
Many thanks to the helpers at #helpdesk on DALnet who got me into scripting...

Beta Testers/Bug Reporters:
DALnet:
  Commander-Apoc
  SweetandSassy == #Helpdesk
  Sassy4u^ == #IRChelp
  LunaMeow == #Help
  Ben-Dor == #Helpdesk
  If you havn't been mentioned but think you should have, let me know :)
  
If you've got questions, goto:
server: irc.dal.net
channel: #helpdesk
ask for Psionic

-Enjoy the script :)




