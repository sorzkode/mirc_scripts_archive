to load put multi-irc.mrc in your mIRC directory and type this:
/load -rs multi-irc.mrc

To use it to connect to another server, 
click the Commands menu and select "Multiple Server Connection"

-Psionic
