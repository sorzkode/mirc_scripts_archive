======================
ZeNeTh FileServer Explorer
======================

Description: Makes using of mIRC FileServers totally visual. This will automatically detect a FileServer session on an Incoming DCC Chat, and Get the information you need to Browse it (Rules, Credit Info, Directory Listings). An incredibly comprehensive addon.
Features: Automatic requesting of Rules, Visual Directory Listings, Double-Click Change Dir/Get File, Automatic Uploading. TOTAL GUI INTERFACE!
Author: Fant0m
Version: 5.02
e-Mail: bowler@iaccess.com.au
Installation Notes: Please extract to a directory named 'Zeneth' in your mirc directory.
Installation Command (Copy everyting after the colon): //load -rs $findfile($mircdir,Zen-Install.mrc,1)
Upgrading from versions 5.00+:Simply replace the existing files. No need to re-install.
Note on Upgrading from versions other than 5.00+: Uninstall, then re-install the new version
Help: Open Zeneth.hlp
Size Extracted: 662kb
mIRC: 5.71

///MerCury00\\\
