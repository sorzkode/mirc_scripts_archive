(C-Talk..) v5.8 By zud

mIRC v5.6 required!
Extract c-talk.mrc into your mIRC directory, if you are unsure what that is, type 
//echo -a $mircdir.  Once extracted, type /load -rs c-talk.mrc

-Whats New in v5.8!-------------------------------------------
- Dialog using /dialog and tossed out picture windows *sniff*
- Added underline and bold options
- Sped up algorithms
-------------------------------------------------------------
Usage:

	Right click on the channel and select C-Talk.

	Static: Same color(s) through out.
	Random Lines: Random colors selected for each input line.
	Random Letters: Random colors selected for each letter input.
	Random Words: Random colors selected for each word.

        Use /c whatever to 'say' using selected option.
	Use /cnotice whatever to notice someone or a channel using selected option.
	Use /cme whatever to display an 'action' using selected option.
	Use /came whatever to display an 'action' in all channels with selected option.
	Use /cmsg nickname whatever to msg someone with selected option.
	Use /camsg whatever to display your words in all channels with selected option.
 	