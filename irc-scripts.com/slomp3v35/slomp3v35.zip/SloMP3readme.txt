GAH! I hate these!

to load this script you need the two files:
SloMP31.mrc


then open mIRC and type: 
/load -rs SloMP31.mrc
if you have the files in a different directory than the mirc32.exe
add the path of the file.
EX: /load -rs C:\something\or\other\SloMP31.mrc

and click YES when it says if you want to run the functions.

uh, thanks.....
the first thing you want to do is configure the script:
right click in a channel window:
SloMP3>MP3 functions>display options

then, to play an MP3
SloMP3>MP3 functions>play MP3>whatever


like. enjoy.

ICQ #: 26436099
E-mail: pandrew1@twcny.rr.com
IRC: events.scifi.com 6667 in #BotTestLab and #DragonsDen I use the nick Sloloem
++++++++++++++++++++++++++++++++
<Spoon> Quotes are fun, and so is cheese
<Spoon> Go to hell ZC.
<Spoon> NEEEEEH!