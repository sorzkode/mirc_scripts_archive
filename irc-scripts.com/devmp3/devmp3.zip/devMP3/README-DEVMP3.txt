
devMP3! Search Engine v1.0 Beta
created by dephekt(dephekt@yahoo.com)
 --> ircdev scripting team - http://ircd4mirc.sourceforge.net

-------------------------------------------------------------

the devMP3! Search Engine is used to search for MP3s on the
many mp3 irc channels.  has a napster-style interface, all
you have to do is type in the artist, and title and click
search! it's really self-explanatory, so join run the script
and see what happens :-)

-------> still have problems?

  mp3 channels: these are the channels where the script will
                search for your mp3s.

  'Save Props.' button: save your properties (settings).
  'Get File(s)' button: select the mp3s in the search results
                        list (press shift + left-mouse button
                        to select more than one) and click
                        this button to begin the search.
  
