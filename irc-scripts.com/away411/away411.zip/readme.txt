                       ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                          the SMF Away Sys v4.11
                          for mIRC 5.7 or higher
                         ~~~~~~~~~~~~~~~~~~~~~~~~
����������������������������������������������������������������������������
Homepage : http://dgsoft.cjb.net
Away Sys : http://dgsoft.cjb.net/away/
����������������������������������������������������������������������������

-=<Install>=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

1) Put the files anywhere inside your mIRC directory (ie. C:\mirc)
2) Run mIRC, type /load -rs [path\]away.mrc*
3) Once finished with the setup, go to the "SMF Away Sys" section in
   your menubar and browse around :)

* if you put the script in a subdirectory, you should specify it's path
  like for example, if you put the script inside C:\mirc\addons\ then
  the command should be /load -rs addons\away.mrc

-=<What's New>=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

1) The away messages can now be costumized.
2) Fixed several bugs with the "del group" command in the log and page
   readers.

-=<Older Versions>=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

v4.0 : 1) Replaced the main away window with a dialog box (the away message
          is now included in the main away dialog).
       2) Replaced the pager window with a dialog box.
       3) The log and page titles now use a new time format: dd/mm/yy_HH:nn.
       4) Added a silent away option
       5) Updated the code for mIRC 5.6

v3.4 : 1) Both away and pager windows use the windows' color scheme and can
          be moved by clicking them
       2) Replaced the settings and viewer dialogs with new ones
       3) The WAV files can now be placed anywhere
       4) The script no longer uses perm variables (all settings are now
          being stored in away.ini)
       5) The script now fully supports spaces
       6) The script remembers 5 of your most recent away messages

v3.0 : 1) The script now remembers the options set on the main away window.
       2) Fixed a potential bug - from now on, when messaged/paged, the
          script only sends an away reply once to the person that has
          triggered the event.
       3) Auto away and auto quit options can now be turned off.
       4) The settings window now uses dialogs instead of listbox windows.
       5) When moved, the window remembers it's last location.
       6) The Away and Pager windows now have a popup titlebar.
       7) You can now configure the nick change in the settings window
          (change the whole nick/add an away sign/etc).
       8) All pages/logs are now being displayed in a Dialog GUI
       9) Rewrote some of the code to work faster and take less space

-=<Contact Me>=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

I am usually on DALnet's #startrek #startrekbots #startrekvoyager (see a
pattern yet?) #chronozone and #ircnews.com as SMFF_of_TS, on Undernet's
#Peace&Protection as SMFFofTS and you can always E-mail me at
rewt@dgsoft.cjb.net

GIMME FEEDBACK I DEMAND IT!

-=<Legal notes>=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

* Copyright � 2000 SMFF_of_TS and The magestic sockpuppet� Int.
* Ripping this script can and will get you killed.
* All models are 18 years of age and above.
* No animals were harmed during the making the script (not by me at least).
* SMFF_of_TS and The magestic sockpuppet� Int. do not take responcibility
  for any damage this script may cause to your computer.
* By reading this, you state that SMFF_of_TS is your god.
