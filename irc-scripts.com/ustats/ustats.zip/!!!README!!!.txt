Script: User Stats v1.0 
Author: Dark_Wolf
IRC Server: irc.relic.net
Channel: #relicscrpters , #mirc~scripting 

Install:
   type /load -rs dir/ustats.ini  

Description:
  This addon puts a channel(s) user stats into a dialog. It that simples.