****************************************************************************
* RCForge Encryption script for mIRC32                                     *
*                                                                          *
* Written by Matt (say-tan@IRC)                                            *
* Copryright (c) 2000 say-tan. All rights waived.                          *
*                                                                          *
* This script is provided AS IS, with no warranties explicit or implied!   *
* Use at YOUR OWN RISK!                                                    *
* WARNING: Export of this script is subject to federal strong encryption   *
* regulations.  If you have a question as to whether you are allowed to    *
* modify and distribute or redistribute this script and it's accompanying  *
* files, DO NOT EXPORT IT.  If you wish to refer a friend to the use of    *
* the script, send them to the download page at:                           *
*                  http://www.non-prophet.org/rcforge/                     *
****************************************************************************

Introduction:
-------------

RCForge is an encryption script for mIRC that uses 256-bit Strong encryption
over private and channel messages.  With a secure key, you are almost
totally secure in your conversations.

RCForge.zip includes the following files:

- Readme.txt       : This help file
- RCForge.ini      : The .ini file containing the mIRC script
- rc4toolkit.dll   : The .dll containing the ciphers and a few handy calls
- rc4toolkit.txt   : A detailed explaination of the interface between mIRC
                      and rc4toolkit.dll
- rc4toolkit.c     : The ANSI C source code for rc4toolkit.dll


Installation:
-------------

First, use winzip or a similar program to unzip all of the above-listed files
to your mIRC root directory.

note:  All files must be in your mIRC directory for the script to function
        correctly.

Next, open mIRC.  In your status window, type:  /load -rs RCForge.ini
This will begin the loading procedure for the RCForge script.  A dialog
box will pop up asking whether you wish to continue loading the script...
You MUST say 'yes' at this dialog for the script to load properly.

As the script initializes, you will be asked for a secret encryption key.
This key is your default key when entering new channels with encryption
on by default.

note:  A key is similar to a password.  It should only be known by you and
        anyone you wish to carry on an encrypted conversation with.  The
        key may contain up to 256 typeable characters (including spaces).
        See the section below on 'Cryptographic Weaknesses' for more info
        on choosing a safe key.

After you have entered your key, a confirmation dialog will pop up and ask you
to re-enter your key.  Type your key in in the same manner you did previously.

Once the script is loaded, you will notice new entries on several pop-up
menus from which you will be able to control the encryption properties.

At this point the script is finished installing/loading.  From here, you will
want to check a few setting in mIRC.

In order for the .dll file to be accessed, you need to enable the /dll command.

Go to:  General Options -> General -> Lock, then, under 'Disable Commands',
uncheck the box labeled '/dll'.


Tips:
-----

You can set several default values, which are used when you have not explicitly
set the value for a particular window, from the status pop-up menu and the
menubar menus.  There is also a 'Default Settings' option in the query and
channel pop-up menus.

Every query and channel window is able to have different option from the others.
Simply right-click in that window and Set up the options as you see fit.

If you log channel and/or private conversations and you don't wish to have your
encrypted information logged, you can use 'Encrypt to Window' to send all of
the sent and recieved encrypted text to another window, which prevents you from
having to turn logging on and off frequently.


Cryptographic Weaknesses:
-------------------------

256-bit RC4 is an extremely hard cipher to brute-force attack (attempt to discover
the message contents by trying every possible key).  It took several months for
several hundred-thousand computers working in their idle time to break even 64-bit
RC4.  However, there are a few ways that plaintext can be leaked by the RC4 cipher.
To avoid this problem, several measures have been added...namely, the CS1 and CS2
modifications.  It is recommended that you use CS1 or CS2 when seriously trying to
conduct an encrypted conversation.  Because very few people actually have the
crytographic backbround to break plain RC4, and because it is 'novel' to have it
listed, it is included in the list of algorithms.

Key size is a possible factor in the strength of RC4 encryption.  Crypto research
has found that the safest keys meet the following requirements:

-  Must be at least 15 characters long.
-  Should not be more than 54 characters long.
-  Should not consist of a plain phrase or word. (Ease of guessing)

For a more detailed cryptananlysis of the RC4, CS1 and CS2 ciphers, please visit:
    http://ciphersaber.gurus.com/cryptanalysis.html


Troubleshooting:
----------------

Q: This script doesn't look like it loaded...

A: 1) You put the RCForge files in tne wrong directory.
   2) You forgot to load the script.
   3) Your OS is broken.
   4) You are broken.

Q: I get blank lines when I send or recieve encryption...

A: The DLL is not being accessed correctly.
    1) The dll is not in the mIRC directory.
    2) You forgot to turn the /dll command on.
    3) Your OS is broken.
    4) You are broken.

Q: I get jibberish when someone types to me, and they get the same from me...

A:  1) You aren't using the same key.
    2) You aren't using the same encryption algorithm.
    3) Your and/or your friend's OS is broken.
    4) You and/or your friend is broken.

Q: I can't compile the DLL myself...

A: Neither can I.  I use MSVC++ 6.0 Pro, and the DLL is written for
    lcc-win32.  Yes, the dll can be modified to work in MSVC++ 6.0 Pro,
    but if you don't know how to do that, you don't need to be compiling
    or modifying the .dll.


Closing:
--------

No programmers were harmed in the creation of this script.  Well, actually
they were beat to bloody pulps and forced to do several hours of grueling
debugging, but most of them survived...

Thanks for your interest and be sure to visit http://www.non-prophet.org/
for other nifty things by say-tan.


-- say-tan
