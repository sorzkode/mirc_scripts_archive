TeenybopperKicker by EternalCaress

hello and thanx for downloading my add on i was bored and hated to see these mainstream kids come into these channels that are not for them and finding these tenybopper bands so i made this addon my first add on ever i never knew how hard it was making one 

just type /load -pn teenybopper.mrc and u will be set 

if u feel to email me my email is plaecbo4e@hotmail.com 