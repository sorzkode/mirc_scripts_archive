~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Acronyms � Danaria aka LadyDana
Found in #HelpDesk or #mIRC
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Description:
````````````

This script checks any text that you type into a channel or query window and if it matches
with the one of the acronyms that you have defined, then it will replace your text with 
the definition of the acronym (you have to define this one too).

All the data is stored in acronyms.txt

It's *very* important that the 2 files (acronyms.mrc and acronyms.txt) are in the
mIRC directory (same one as mirc.ini).


Instructions:
`````````````

You can load the script by typing

=> /load -rs acronyms.mrc 

	in your mIRC editbox. Make sure that you specify the directory of the file
if it's not in the directory that mIRC is in. Please also make sure that acronyms.txt is
in the same directory as the script.

You can also load the script manually by going into REMOTES (you can do this by pressing
ALT R in mIRC). Go into the FILE menu and choose LOAD - SCRIPT. Select acronyms.mrc and then
click on OK. You still have to make sure that acronyms.txt is in the same directory.

To use the script, just right click in a channel window, or go into your MenuBar popups.
You only need to enable the script, after that, it should work by itself.

Directions:
```````````

You can reach DALnet's #HelpDesk by connecting to any DALnet Server and joining the channel.

Server: /server irc.dal.net 7000
Channel: /join #HelpDesk

Danaria (the author of the script) can by contacted via email at dany@mindless.com
She can also be found in many channels, among them #HelpDesk, #IRCHelp or #mIRC.

The #HelpDesk website can be found at http://www.helpdesk.mircx.com/
Further Scripts can be found at http://www.helpdesk.mircx.com/documents/scripts.html
Various Scripting Help & Documentation: http://www.helpdesk.mircx.com/documents/scripting.html