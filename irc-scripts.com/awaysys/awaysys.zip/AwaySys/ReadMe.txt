________________________________________________________

*** The Ranger's Master Away System  by SixGun
________________________________________________________

*** Installation

*** Extract the Zip file to your mirc directory
         ( Folder with Mirc.exe in it )

*** Connect to IRC 

*** Type this command;

***  //Load -rs $mircdirAwaySys\Away.mrc

*** when prompted, "Run Initialization" Choose "Yes" 

*** Please Note the double // they are needed!
________________________________________________________

*** NOTES
  
   When you first install this script Make Sure that 
   you have NO OTHER AWAY files in your mirc folder!

   This Script Will Only work with mIRC 5.6 and Higher.

   The Ranger Away System has a built in Uninstall!

   Restricted the use of function keys and aliases. 
   In fact only 8 aliases are used. These aliases can
   be entered quickly and easily in the edit line.
   They are; /QA, /BRB, /IB, /Pager, /setting, 
   /Themes /Ark /clearArk. There are no function Keys 
   used at all.   

   One Known Problem exists when you use Large fonts.
   Using Windows Large fonts when set at 800 X 600 
   or Higher will not allow certain features to work.

________________________________________________________

*** Thanks for using this Away System. 
    I hope you enjoy it and have some fun.
    If you have any problems or comments,
    please drop me a line at
   
                SixGun@odsy.net
    
________________________________________________________

*** Shoutout for beta testers

*** KayK
*** `Pixie
*** `fish


                                 Thanks All
                                   
                                   SixGun