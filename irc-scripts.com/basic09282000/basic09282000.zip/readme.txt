- Basic 09272000 for mIRC 5.8

  I've added new stuff. Read changes.txt for the improvements.
  Also, if you're planning to write a theme, I've added two themes
  bx.thm and simple.thm. Study bx.thm carefully because there are
  a lot of changes that have been made. bx.thm is about the most
  detailed theme I made and there are a lot of comments and some
  explanation in it.

  There are only two themes because I have made quite a number of
  changes in the themes. I included simple.thm just so users who
  don't like to use black background will have something for them.

  For DALNet users, if anyone of you is familiar with /debug and
  the akick problem, please enable debug and send me the log file
  when the script tries to ban ChanServ. Hopefully, I have fixed
  this problem by now. I've added /ovn for the DALNet warriors.
  It's actually a /notice @+#. And I've changed the wallops so
  that it just sends a /notice @# etc.

  For those having troubles with their autojoin, you'll be happy
  to see the new autojoin feature which allows you to tell Basic
  what network a certain server is.

  If you are a new user of Basic, for crying out loud, PLEASE READ
  THE HELP SECTION. It took the longest time to write as compared
  to the actual script. IF YOU WANT TO CHANGE THE FONTS, USE THE
  /DISPLAY COMMAND AND CHECK OUT THE HELP FILE ON THIS. IF YOU WANT
  TO CHANGE HOW EVERYTHING LOOKS, BY ALL MEANS CHANGE IT VIA THE
  DISPLAY DIALOG. IT IS THERE FOR A REASON.

  This is still beta because there's still one more feature that
  I want to add. Thanks for your patience.

- Installation

  New installation:

  Extract the files to a clean directory. Place a copy of mirc32.exe or
  mirc16.exe in your main directory. When using Winzip, make sure the
  USE FOLDER NAMES option is CHECKED. I don't use pkunzip or any other
  archive program so I don't know the switches for that.

  UPGRADE NOT YET AVAILABLE. PLEASE REINSTALL AND USE THE IMPORT OPTION
  TO IMPORT YOUR OLD SETTINGS.

- Requirements
  
  mIRC version 5.8 only. Preferrably 32bit version. It should work with
  the 16bit version but some features will be disabled. Not tested in
  WinNT and Windows 2000 and WinME.

- Contact

  Email belf@usa.net for bug reports and other suggestions.

- Acknowledgements
  
  To all of you.  

  Peace. 

  blue-elf

- EOF

 


  