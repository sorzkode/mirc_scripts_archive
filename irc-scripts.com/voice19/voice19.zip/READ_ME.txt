*******************************************
AutoVoice v1.9 By JJ-Stud
*******************************************
1.)About Me
2.)About AutoVoice v1.9
3.)Install
*******************************************
1.) Im JJ-Stud you can find Me on DALnet in these channels:
#mp3forme, #mp3pub, #mp3`, #mp3swap-triviafun, and #mp3xtasy?

I have learned to script from someone who has been scripting for years
so my scripts are always dont to the fullest and best of my ability. I am usualy
in a chan so that you can find me for questions. And if you cant find me you 
can e-mail at puntang_pie169@hotmail.com. I am also a part of a lyrics
server Im a server for http://www.letssingit.com they have the best and most
lyrics on the Internet. If you want lyrics e-mail my staff at querklyric@hotmail.com.
They will help you find your lyric.
********************************************
2.)I  made this autovoice because I was always in need of one. The autovoice
voices people in a chan you are op in either if they send a LIST ad or a MP3 ad.
This script only will only work if your an OP. 
********************************************
3.)To install script use WinZip to UNZIP to your mIRC folder (i.e C:\mirc).
Then start up mIRC and go into a chan then type in /load -rs voice19.mrc
And then type     /remote on    so that your remote scripts will turn on and
the AutoVoice will be active.
********************************************
Thanks For Using My GREAT AutoVoice It Really Kicks Ass And Its TITS!