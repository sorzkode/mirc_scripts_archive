------------------------------------------------------
AnswerBook v1.2.10
By: Lee 'buzz' Liu (buzz@black-magic.net)

Copyright � 2000 Blackmagic New Media, Inc.
http://www.black-magic.net/answerbook/
October 2000
README.TXT


==========
WHAT'S NEW
==========


v1.2.10
- fixed US forecaster (this is starting to become a chore)
- added ebonics translator (?? en_eb text)

v1.2.9
- fixed stock quote lookup (again, sorry, silly mistake)
- added ICQ UIN lookup with online status (if enabled) and other info
- added webserver software/OS lookup

v1.2.8
- fixed quote lookup
- mirc5.8 will no longer be used (incompatibility with
  certain msg scripting functions causing problems with abook)

v1.2.7
- fixed US forecaster freezing abook
- fixed calc exploit that crashes abook
- added US & Canada residential phone number lookup

v1.2.6
- added currency converter between 62 countries/currencies
  (updates approx. once every 2 days)

v1.2.5
- fixed some words giving trash definitions
- fixed domain lookup not responding
- added a whole slew of metric/imperial conversions
  (eg: inch-cm, mile-km, ft-m, ga-l, lb-kg, etc)

v1.2.4
- added stock quote lookup for US and Canadian Exchanges,
  type ?? quote for usage information
- added support for more domain registrars other than NSI (not fully tested)
- added support for multi-word custom definitions using _ as space,
  add by using .adddef holy_cow text and use by ?? holy cow
- added ?? f-c and ?? c-f for conversion between Fahrenheit and Celcius
- the update notification is now built into the main program for more efficiency

v1.2.3
- added genie (magic 8ball type) with customizable responses using genie.txt
- fixed some more issues with US forecaster
- fixed using forecaster and spellchecker without parameters causing hang

v1.2.2
- added spellchecker, see Spellchecker section below
- fixed some issues with the US forecaster


============
INTRODUCTION
============

AnswerBook is a bot script written for mIRC, an Internet Relay
Chat (IRC) program. Some key features that separate AnswerBook
from the rest:

- dictionary word definition lookups
- language translator for 5 different languages
- Internic domain/whois lookup (supports Network Solutions and
  a few various registars)
- weather forecast for US, Canada and every major city on this
  planet
- spellchecker
- stock quote lookup for US & Canadian Exchanges
- added currency converter between 62 countries/currencies
  (updates approx. once every 2 days)
- US & Canada residential phone number lookup
- ICQ UIN lookup with online status and white pages info
- Webserver software/OS lookup
- Ebonics translator
- ability to add custom definitions

Other miscellaneous features include:
- simple math calculator
- virtual coin tosser
- random number generator
- genie (customizable 8ball)
- Fahrenheit to Celcius converter and vice versa
- More metric/imperial conversions: inch to centimetre, mile to
  kilometre, feet to metre, gallon to litre, pounds to kilogram,
  kilogram metre to pounds feet

AnswerBook has been tested on mIRC 5.6 and 5.7x and should work
with future versions.


============
INSTALLATION
============

If you downloaded the package that includes mirc32.exe, then
you're already set, just unzip the package into any directory
of your choice (eg. c:\mirc\answer).

If you downloaded the package without the mirc32.exe binaries,
simply unzip the package into any directory (eg. c:\mirc\answer)
then copy only the mirc32.exe into that directory.

File list for Full zip:
abook.ico       - icon file for mirc tray
abooksrv.exe    - AnswerBook server component (it does most of
                  the dirty work)
aliases.ini     - some aliases such as /j for /join
answerbook.dat  - main custom definitions library and variables
                  (all your custom definitions are stored here)
answerbook.ini  - primary AnswerBook script
answerbook2.ini - secondary AnswerBook script
genie.txt       - customizable responses for the genie
mirc.ini        - mIRC settings file
mirc32.exe      - mIRC32 executable (run this to start abook)
popups.ini      - popups file for mIRC
readme.txt      - some mystery file...
remote.ini      - userfile for mIRC

msinet.ocx      - Microsoft Internet Transfer ActiveX control
mswinsck.ocx    - Microsoft WinSock ActiveX control
msvbvm60.dll    - Microsoft Visual Basic Virtual Machine 6.0

The last 3 files above should be copied to c:\windows\system if
your using Win9x or c:\winnt\system32 if your using NT/2K.


===================
SUMMARY OF COMMANDS
===================

First-time run:
/msg AnswerBook owned

This sets you as the owner of the bot.  Type this command from
your regular IRC client.

Public/msg commands:
.adddef <keyword> <custom definition> - adds a custom definition
.deldef <keyword> - deletes a custom definition, if exists

.adddefuser <nick> - adds a Level 50 user to userlist
.adddefop <nick> - adds a Level 60 user to userlist
.deldefuser <nick> - deletes a user from userlist

.addignore <nick> - adds someone to ignore list
.delignore <nick> - removes someone from ignore list

.save - instead of waiting 5 minutes before save, saves now
.resetbook - in case something happens and it hangs, this resets
.diebook - quits bot

Lookup commands:
?? <word> - looks up a custom or dictionary word
?? <domain> - looks up a domain name
?? <translation type> <text> - translates to a different language
?? forecast <city>, <country> - weather forecast for non-US city
?? usforecast <city>, <state> - weather forecast for US city
?? spellcheck <word> - checks the spelling of a certain word

Misc lookups:
?? calc <expression> - performs math on the expression given
?? flip - flips a coin, displays either heads or tails
?? rand <starting number> <ending number> - random number
?? genie <yes/no question> - gives a magic 8ball type response


==============
FIRST-TIME RUN
==============

From the directory which you installed AnswerBook, load the
mirc32.exe as you would a normal mIRC client.  AnswerBook will
be loaded, by default, minimized into the system tray area with
a processor icon.  Double-click this icon and configure it so
that it joins your irc network and channel.

You may wish to add these lines to the mIRC perform section
(by pressing alt+o, click IRC, then click perform):

/server irc.yournetwork.net
/join #yourchannel

so that it auto-joins your channel on startup.


The first thing you should do after this is load your normal
irc client and identify yourself to AnswerBook as the owner.
You do this by typing:

/msg AnswerBook owned

where AnswerBook is the name of your AnswerBook bot.

The first person to do this becomes the owner and the command
can never be used again.  If you ever change isp's, you can
reset this by going on the bot and typing '/unset %owned'. Then
you can '/msg AnswerBook owned' again from your normal irc client.

Warning: This is important, if you don't do this, other people
might be able to set owner to themselves and that allow them to
add their own custom definitions without your consent.


Once done that, you may run the AnswerBook configuration by
double-clicking on the AnswerBook icon in the tray and under
the AnswerBook menu, click Settings.

Although this is not necessary since AnswerBook comes built-in
with a set of default settings and auto-detects other
settings, it's generally a good idea to set up AnswerBook,
depending on how your channel operates and the number of people
in it.  For more information on what each of the settings do,
look further down this file under SETTINGS.

And this brings us to...


------------------
Custom definitions
------------------

One of the features of AnswerBook is the ability to add custom
definitions.  These can range from funny descriptions of
people in your channel or definitions not normally included
in a dictionary.

For example, one of the preset custom definitions is 'mp3' and
it's definition as 'MPEG-1 Layer 3'. Ordinarily 'mp3' is not
a dictionary word but it's useful for those who may not know
what it stands for.

To add a custom definition, first make sure you're on a channel
that your AnswerBook bot is also on, then type this into the
channel:

.adddef lol laughing out loud

That will add the definition to the list of custom definitions.
You can add as many custom definitions as you want.  Definitions
are autosaved every 5 minutes.

NOTE: If you define a custom definition that's the same as a
dictionary word, your custom definition will take precedence
over the dictionary word and only your custom definition will
be shown.  To see the dictionary word definition again, simply
delete the definition:

.deldef llama

This will delete the custom definition 'llama', if you added
that and the dictionary definition will now be looked up instead.

In v1.2.4, multi-word definition support was added.  To add
a multi-word definition, use an underscore (_) instead of a space.
To use a multi-word definition, either a _ or a space will work.

For example,
.adddef holy_cow St. Cow

Can be requested in 2 ways,
?? holy cow
?? holy_cow


------------
Adding users
------------

Right now, only you, the owner can add custom definitions.  To
allow other people in your channel to add custom definitions,
they must first be recognized as a user of your AnswerBook bot.

There are 2 user levels to which you may add people, 50 and 60.
Level 50 allows the user to .adddef, .deldef.  Level 60 allows
the same as Level 50 except that Level 60 users are not bound
by limits of spam control or excessive lookups.  You, the owner
are also not limited by the spam control.

To add a level 50 user, type:

.adddefuser <nick>
(eg. .adddefuser Snoopy)

To add a level 60 user, type:
.adddefop <nick>
(eg. .adddefop cb)

Once you add, the user and you will receive a notice on the
update to the user list.

To delete users of either level, simply type:

.deldefuser <nick>
(eg. .deldefuser Downer)


=======
LOOKUPS
=======

You might be thinking, now that I've got this program, how
the heck do I use it?  It's fairly straight forward, read on...

---------------------------------------
Dictionary words and custom definitions
---------------------------------------

To lookup either a custom definition or a dictionary definition
is easy.  Depending on what settings you've set in AnswerBook
settings, certain people on your channel are allowed to request
definitions. (By default, everyone on your channel is allowed
to perform definition requests.)  To request a definition, type:

?? <definition>

That will display the definition of that word.  For example:

<You> ?? winamp
<AnswerBook> winamp: It really whips the llama's ass. Baaaaa!

Again, note that if a custom definition is the same as a
dictionary word, only the custom definition is displayed.

'winamp' just happens to be a custom definition that comes
preset with AnswerBook.  Here's what happens if you lookup
a dictionary word not included with AnswerBook:

<You> ?? royal flush
<AnswerBook> royal flush: n. 1. a straight flush having an ace
             as the highest card

It takes several seconds while it grabs the definition from the
server but eventually, it displays the definition of the word.
This feature is useful for doing homework or if someone doesn't
understand a word someone else uses.  There are hundreds of
thousands of dictionary words and this is one of the easiest
ways to perform a lookup.  In addition, you can also lookup
names of famous people, chemical compounds, geographical
locations with population and a whole slew of other stuff.

NOTE: The time it takes to lookup a definition depends on the
speed of your Internet access and also on the congestion of the
server.

ALSO NOTE: Sometimes the displayed definition may be a different
tense or different function of the word you're looking for, such
as: read, present tense and read, past tense or match, the verb
and match, the noun.  Unfortunately, there is nothing that I can
do to allow AnswerBook to differentiate between these types.
Currently, AnswerBook displays the definition given by the
server.  I have yet to find a way to display different functions
of words.


---------------------
Internic domain/whois
---------------------

This feature is useful for seeing if a domain is registered and
to whom.  To lookup a domain, type:

?? domainname.com

Currently, AnswerBook returns 3 conditions:

- If registered using Network Solutions, Register.com or certain
  registrars, it displays the registrant's name and location.
- If registered, but not using any of the above, it only displays
  that the domain is registered.
- If domain is available for registration, it returns a NO MATCH.

For example:

<You> ?? planetbuzz.net
<AnswerBook> planetbuzz.net: Lee Liu, PlanetBuzz Interactive.
             Toronto, ON, CA.

AnswerBook currently has support for .COM, .NET, .ORG, .EDU, .CA.


-------------------------
Multi-language translator
-------------------------

This feature allows translation among 5 different languages,
English to French, Spanish, German, Portuguese, Italian and
vice versa.  To translate something it requires 2 parameters:

?? <translation type> <sentence to translate>

The <translation type> can be any of these:
en_fr (French), en_sp (Spanish), en_ge (German),
en_pt (Portuguese), en_it (Italian)
and reverse translation back to English,
fr_en, ge_en, sp_en, it_en and pt_en.

For example, to translate 'i am smart' to French, type:

<You> ?? en_fr i am smart
<AnswerBook> en_fr: je suis fut�

To translate back to English:

<You> ?? fr_en je suis fut�
<AnswerBook> fr_en: I am smart

The same goes for the other languages.

Update in v1.2.10, an ebonics translator was added, use by:
?? en_eb <sentence to translate>
Note: This is not real ebonics, most of it is slang and what
most people think of, as ebonics.  I'm not trying to promote
ebonics but just as a means for entertainment purposes.


----------------
Weather forecast
----------------

This feature was built for the lazy.  Tired of switching to the
weather channel every morning and waiting for weather forecast
of the upcoming days?  Well, with this, you'd never have to do it
again.  There are two commands, one for US cities which report
in Fahrenheit and world cities using Celsius. To lookup a city,
type:

?? USforecast <city>, <state>
?? forecast <city>, <country>

For example, to lookup Tampa, Florida, type:

<You> ?? USforecast Tampa, FL
<AnswerBook> Tampa, FL: Current conditions - Plenty of sun and
warm. High 82F. Low 62F. Feels like 83F. Friday - Continued
warm with sunshine...(and so on for next 5 days)

To lookup Paris, France, type:

<You> ?? forecast Paris, France
<AnswerBook> Paris, FR, EU: Current conditions - Breezy, then a
            few showers. Low 12C. Friday - Overcast...(and so on)

Weather forecasts gives the forecast for 5 days from today.


------------
Spellchecker
------------

This feature was added in v1.2.2 due to popular demand.  It
checks the spelling of words and may suggest alternatives.
Certain IRC lingo and other non-common words will not be in
this. To check the spelling of a word, type:

?? spellcheck <word>

For example, to spellcheck "synonmim" which is really spelt
"synonym", type:

<You> ?? spellcheck synonim
<AnswerBook> spellcheck: "synonim" appears to have one or
more words misspelled. Suggestions: synonym, synonyms, synonymy,
synonymic, synonymies, synonymist, synonymity, synonymous,
symbolism, symposium, synonymical, symposiums, synergism, synod,
synodic

If you enter a sentence instead of a word, it will only suggest
alternatives for the first incorrectly spelled word in the
sentence.


------------
Stock quotes
------------

This feature was added in v1.2.4 also due to popular demand.
It returns stock symbol info on nearly all of the US & Canadian
Exchanges, including NASDAQ, DOW, NYSE, TSE, VSE to name a few.
The quote info updates every few minutes during a trading day.
To look up a quote, type:

?? quote <symbol>

For example, to check on nVidia Corporation, type:

<You> ?? quote nvda
<AnswerBook> nvda: NVIDIA CORPORATION (NASDAQ:NVDA) 74 15/16
Up +4 3/16 (+5.92%) High: 75 1/16 Low: 68 1/4 Volume: 1470600
Open: 69 11/16 Previous Close: 70 3/4 52-Week Range: 8.3750
- 88.0000 P/E Ratio: 87.24 (All data 20 minutes delayed.)

For Canadian Exchanges, you have to include the ticker symbol
and .ca as extension, eg. aty.ca or jds.ca.

To get info on the indexes themselves, use ?? quote $DJI will
get you info on the Dow Jones Industrial Average.  "$DJI" is
used for DOW AVG, "$DJU" for DOWUTIL, "COMP" for NASDAQ,
"SPX" for S&P500, "NYA" for NYSE.


------------------
Currency converter
------------------

This feature was added in v1.2.6.  It performs on-the-fly
currency conversions between 62 different countries/currencies.
The rate table automatically updates on first use, everyday.
Manual command for update is also available.  The syntax for
the currency converter works as follows:

?? exch <amount in home currency> <home country name or
currency shortform>-<visitor country name or shortform>

For example, to find out how much $100 US is in Canadian Dollars,
type:

<You> ?? exch 100 United States-Canada
<AnswerBook> United States-Canada: 100.00 United States Dollars
(USD) = 147.21 Canadian Dollars (CAD)

Note that each of the countries trails with a 3-letter shortform.
You can save yourself some typing if you use the shortform
rather than the full country name.  For example, to perform the
same conversion as above, except using shortforms, it would look
like this:

?? exch 100 USD-CAD

You can also mix shortforms and full names:
?? exch 150 CAD-Russia

For a list of countries and their shortforms, type:
?? exch list

To check for an update on the rates, type:
?? exch update

Note: Checking for an update does not necessarily mean that the
rates will be the most current.  The rates are updated from the
Bank of Montreal and they don't update their rate tables everyday.
Usually, the rates AnswerBook will provide will lag about 1-2 days
behind.  AnswerBook automatically updates the rate table on first
use, everyday. Periodically, AnswerBook will announce when the
rates were last updated at the Bank of Montreal when performing a
conversion.


---------------------------
Reverse phone number lookup
---------------------------

This feature was added in v1.2.7.  Although, it wasn't requested,
I thought it was fairly neat to have around.  It does a phone
number to name/address type of a lookup.  The directory only
contains listed residential numbers in the US and Canada.
Business numbers, cell phone or pager numbers and governmental
organizations will not be listed.  The syntax is as follows:

For US residential numbers, type:
?? usphone <area code><7-digit phone number>

For Canadian residential numbers, type:
?? caphone <area code><7-digit phone number>

For example,
<You> ?? caphone 4165551212
<AnswerBook> 4165551212: L Liu. 23 Somestreet St. E. Toronto,
ON, M5B3C9.

Note: The directory only lists residential numbers that have
been published in a local phone book for more than a year and
doesn't include all the small suburbs or small cities.  Some
numbers may be outdated or may not be found.


--------------
ICQ UIN lookup
--------------

This was requested long ago but I haven't had time to add it
in till now.  Basically it looks up a UIN in the ICQ White
Pages directory and returns info along with online status.
The syntax is as follows:

?? uin <ICQ UIN>

For example,
<You> ?? uin 1864791
<AnswerBook> 1864791: Nickname: buzz. Online Status: online.
Name: Lee Liu. Emails: buzz@black-magic.net, buzz@planetbuzz.net.
Location: Toronto, ON, Canada. Birth Date: 28-Sep-82. Age: 18.
Gender: Male. Language(s): English. Website: http://www.black-
magic.net.

Note: For some reason, the ICQ White Pages directory
experiences a lot of downtime.  It seems to be erratic and
seems to go down at will.  I can only assume heavy traffic to
be causing this problem.


--------------
Other features
--------------

To use calculator, type:
?? calc <expression>
(eg. '?? calc 1+1*3' will give 4)

To use coin tosser, type:
?? flip
It'll display either heads or tails.

To use the random number generator, type:
?? rand <starting number> <ending number>
(eg. '?? rand 1 6' will give a number between 1 and 6, inclusive)

To use the genie, type:
?? genie <yes/no question>
It'll return a random response from genie.txt.

To use the Fahrenheit to Celcius converter, type:
?? f-c <degrees in Fahrenheit>
(eg. '?? f-c 100'. Celcius to Fahrenheit is same except
use ?? c-f instead.)

The following are examples of other metric/imperial conversions:
?? inch-cm <number>
?? mile-km <number>
?? ft-m <number>
?? ga-l <number>
?? lb-kg <number>
?? kgm-lbsft <number>

also valid are the reverse lookups: cm-inch, km-mile, m-ft,
l-ga, kg-lb, lbsft-kgm.


========
SETTINGS
========

The settings for AnswerBook can be accessed by double clicking
on the AnswerBook processor icon, under the AnswerBook menu,
click on Settings.  This brings up the settings dialog.

By default, AnswerBook comes preset with certain spam control
settings that I feel work good.  You may leave them alone or
change to however you see fit.  AnswerBook will work fine
without any sort of configuration in the settings dialog since
it has the ability to auto-sense most of these settings by
itself.  But it's always a good idea to configure it properly
Here's what each of the settings do:

Nickname - self-explanatory, it determines the name of the bot.
Main channel - although AnswerBook will function on multiple
    channels, this is the main channel it will use for allowing
    DCC lookups.
Allow one lookup every X seconds for everyone - what this means
    is that no two person can use the ?? trigger within X seconds
    of another person using the trigger.  This discourage spam.
    Default is 3 seconds between lookups.
For each person, allow X lookups every Y seconds - this limits
    each person a maximum of X ?? lookups in Y seconds.
    Default is a max of 6 lookups in 30 seconds.
Allow lookup requests from (.) everyone, () voice & ops,
    () ops only - this is useful if you control a large channel.
    In large channels, you can limit requests to voices or ops.
    Default is that everyone has access to ??.
Allow DCC requests from (.) everyone, () voice & ops, () ops only
    This controls who has access to private DCC lookups.  The
    person must be on your Main channel to be allowed to use DCC.

If you have any questions about these settings or would like to
request an option, feel free to email me at the address at the
top of this file.


==============
FINAL COMMENTS
==============

I've developed AnswerBook months ago solely for my own channel.
However, after some great feedback from the users in my channel,
I've decided to tweak the code and release this publicly.  I
hope that you find it useful and entertaining.  Feel free to
email me on its success or failure in your own channel.  Also,
I am also accepting feature requests.  Although, I cannot
guarantee that I'll honor the request (feasibility or time wise),
I will consider all the suggestions that I receive. I'm not
accepting features for the script itself such as, kicking users
for spamming or gaining ops, etc.


=======
CREDITS
=======

Programmer: Lee 'buzz' Liu
Email: buzz@black-magic.net

Dictionary lookups provided by Merriam-Webster, Inc.
Translation lookups provided by Go.com
Weather forecast lookups provided by AccuWeather.com
Domain lookups provided by Network Solutions, Inc.
Spellcheck provided by spellcheck.net
Stock quote lookups provided by PCQuote.com
Currency rates provided by the Bank of Montreal.
Reverse phone number lookups provided by InfoSpace.
Ebonics translator provided by Da Ebonics Page

Flood control: Mike 'R2D2' Hu
Special thanks to: Fudd, rewobo, Putter, BakaGeima, Snoopy,
Downer, ViolentJ, Feesh, sh0ck, DV8, ^clumsy^, fiend, |Pulse|,
ChaoZ, K2rbka and countless others for the wonderful feedback.

Suggestors -------
Dictionary & Translator: Fudd
Spellchecker: Putter or |Pulse| (cant remember)
Multi-word definitions: Colin B.
Stock quotes: K2rbka & BakaGeima
Currency exchange: Stephane C. (Cookie)
ICQ UIN lookup: goku^
Ebonics translator: Putter


=====
LEGAL
=====

The author of this program will not be held liable for any
damages, data loss, time wasted, etc. which this program may
cause you.


=======
CONTACT
=======

WWW: http://www.black-magic.net/answerbook/
Email: buzz@black-magic.net
IRC: irc.gamesnet.net #blackmagic, look for 'buzz'
