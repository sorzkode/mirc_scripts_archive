Dialog Cd Player 2.0 by J_Saumer (saumer@northernnet.com)

There are 3 things required for this to work

1) Version 5.5 or greater mirc
2) A current version of Winamp
3) and cdplayer.exe

First time running procedure.
1) Set your drive letter through the channel, menubar, or channel popups that sey set cd drive.
2) run the cdplayer dialog through channel, menubar, or status popups.
3) Click on the button that says "Cd Setup" and the cd player will automatically find winamp.exe for you.
4) Hit "Cd Set" to make sure the cd information is set up. If it isn't hit Disc, then Edit Cd Playlist.
5) Hit "Cd Ident" to identify the cd and you should see the cd stats in the status window.
6) Hit "Track" to see a list of the cd tracks on the cd.
7) click on one of those tracks to select it for playing.  
8) Hit the play button
9) When not playing for the first time or just entering a cd, just start at step 5

TroubleShooting:

Q: My cd isn't identifying! What do I do?
A: There are a couple ways to get around this. I'll list them in an orderly fashion.
1) Simply take out the cd, put it back in and hit identify again. Sometimes it doesn't pick it up right away.
2) Check if you set up the all the cd credentials through cdplayer.exe but hitting Cd Set and then going to disk and then edit play list.
3) simply just hit identify again, sometimes that works.
4) if none of these work, please contact me.

Q: My cd is identifying but when I hit tracks, no tracks are listing.
A: Personally I have not run across this problem, but I do have one solution for it.
   Run cdplayer.exe by hitting cd setup and then hitting disk and then edit playlist and check what songs are in your playlist and even if the songs are named.

If you have any more probs or solutions to any existing problems,
e-mail me = saumer@northernnet.com
icq me = 2185189
irc me = J_Saumer on Dalnet