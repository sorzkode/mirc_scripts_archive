mCloneScan
   Author: swarm (turners@icehouse.net)
   Website: www.mIRCBoard.net
   ICQ UIN: 26564093
   Release: March 5, 2001
--------------------------------------
INDEX
 i     - Insallation
 ii    - Usage
 iii   - Features
 iiii  - Contact
-------------------------------------
i.    -INSTALLATION
  Installation is simple, use this method.
      Unzip the file to a directory of your choice.
      At the mIRC Command line, type /load -rs X:\path\to\cscan.mrc
      where X is the Drive it is installed on.
ii.   -USAGE
  There are 2 ways to access this addon,
      1. Channel Popup menu's
      2. The /clonescan alias
           * /clonescan [#channel]
iii.  -FEATURES
  This addon has many features, here is a list.
      * Progress bar while scanning
      * Easy dialog interface
      * Options on what to do when clones are found
      * The option to scan for clones when someone joins the channel
      * The ability to access the script either via command or popups
      * Options on what to do when clones are found joining a channel
iiii. -CONTACT
  To contact me, swarm, you can go on the DALnet IRC network (irc.dal.net)
  and join #mIRCBoard, or you can email me at Turners@icehouse.net

End of file