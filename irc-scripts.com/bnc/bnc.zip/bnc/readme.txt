                           BNC Manager/System 
                           ===================
                  Copyright (c) 1999 Tork's mIRC Projects

Project Info
============
Name........: BNC Manager/System
Script Size.: 12.7KB
Version.....: 1.0
Type........: Addon
Release Date: June 29th 1999
Project Num.: 1
Compressed..: No

Installing *Important*
==========
Step 1) UnZip file contents to mIRC *Root* folder.
-- Correct: c:\mirc\
-- Incorrect: c:\mirc\bob\
Step 2) load mIRC
Step 3) in mIRC type: /load -rs bnc\bnc.mrc
-- When it prompts you click 'Yes' *Very Important*
Step 4) Starting: click 'BNC Manager' under the menubar/status popups.

Script Help
===========
Script has a built in help system, click 'Help' button ;P

Credits
=======
FireWall  - Helped w/ Debugging
veno[m]   - Helped w/ Debugging
Conglomo  - Helped w/ Debugging
Davidian  - Helped w/ Debugging
Dark_Wolf - Got me started on Dialogs!

Contact Info
============
Author: Tork
E-Mail: tork@goth.net
ICQUIN: 1783165
IRC...: irc.relic.net / #TestChamber
WWW...: http://tork.cjb.net/irc/projects

Todo list (hopfully to be in next release)
=========
1) 'Get Vhost' button, retrives a list of every vhost on each account.
2) status window, will allow you to see every command sent to bounce.


v1.0 (First Release)
====
- No *known* bugs!


Send Questions/Comments/Suggestions/Ideas/Bug Reports to: tork@goth.net