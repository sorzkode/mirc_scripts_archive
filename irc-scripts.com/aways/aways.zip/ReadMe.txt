==============================
= Away System AddOn ver. 4.0 =
==============================

-= Away System AddOn ver. 4.0, CopyRight � 1999 LordViper and IRUV Crew �. =-

- Introduction
---------------

This addon is an Away System, that manage your away system with the options to log the incoming
messages and CTCP (Client-to-client-protocol) Pager, to send message with the reason to all the
channels or to do a quiet away with out any message, to choose if you want to use away-nickname
yes or no, to define a shortcut keys for the Away and for the Quiet Away and more useful things.
Everything is in a dialog, that makes the addon more simple.

- The Files
------------

 AwayS.mrc - The Script File
 ReadMe.txt - This File

- Loading
----------

Simply extract ALL the files to your mIRC dirctory, and then:
Type: /load -rs AwayS.mrc

- System Requirements
----------------------

 Computer (dahh)
 mIRC 5.6 (or higher) 32 Bits.

- Triggering
-------------

 Right click in a channel or select 'Away System' in the menubar.
 Typing: /Open.AwaySysDialog in any mIRC window.

- Known Bugs
-------------

 We don't know about any bugs! Please contact us if you find one. (or more... :)

- Contact Us
-------------

For Questions, FeedBack and Bug Report:

 ^InfraRed^
 + ICQ: 12430858
 + E-Mail: mbraun@sitcom.co.il
 + IRC: Server: DALnet , Nick: ^InfraRed^

 LordViper
 + E-mail: falconz@ductape.net
 + IRC: Server: DalNet, Channels: #kurilka, #script-files (My nick is LordViper :)

Home-Page:

 http://members.tripod.com/~IRUVCrew

=--==--==--==--==--==--==--==--==--==--==--==--==--==--==--==--==--==--==--==--==--==--==--==--=
Away System AddOn ver. 4.0, CopyRight � 1999 LordViper and IRUV Crew �.