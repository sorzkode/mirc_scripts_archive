dEfCoN oNe for mIRC 5.82
by fiRE_ANGEl (fiRE.ANGEl@gmx.net)
http://defcon-one.purespace.de

Version      : 0.70.57
Release Date : 27.12.00 (dd/mm/yy)

Installation:
-------------

1. Extract everything into a new folder.
   For example: c:\defcon
2. Rename the file 'mirc.bak' to 'mirc.ini'
3. Copy the mirc32.exe to the folder where you extracted those files.
   dEfCoN oNe is tested with mIRC version 5.82.

Upgrading:
----------

1. Exit mIRC
2. Extract everything to your defcon one directory
That's it

Function Keys :
---------------

F2         - join channel(s)
F4         - opens dEfCoN oNe setup
F6         - Opens Away Log
F8         - Set Away with reason
F9         - Opens dEfCoN oNe WebPage (German)
Ctrl + F9  - Opens dEfCoN oNe Webboard (German)
Shift + F9 - Download latest version of defcon one

Commands :
----------

/autojoin

To join your autojoin channels.


/j [#]chan1 [[#]chan2...]

/j is only alias for /join.
Differently than in the original # is not necessary.
Additionally several channels can be entered at the same time.


/seen nick

It operates exactly the same as !seen in the channel - with the difference that
the output only local takes place.

Commands to open Dialogs :
--------------------------

/about    About-Window
/nsetup   Network Setup
/ncsetup  Nick Completion Setup
/replace  Replacer Setup
/setup    General Setup
/seen     Opens Seen-Lookup

I think you know what this commands do ...