 ________________________________________________________
|  Script : Away System v1.1b                           |
|  Author : m0rbid                                      |
|  TEAM [ACIDCODE]                                      |
|========================================================|
|   CONTENTS                                            |
|      - Requirements                                    |
|      - Installation                                    |
|      - Features                                        |
|      - FKeys                                           |
|      - Disclaimer                                      |
|      - Contact                                         |
|========================================================|
|   REQUIREMENTS                                        |
|      -computer?!(err..)                                |
|      -mIRC v5.6+ 32 bit                                |
|========================================================|
|   INSTALLATION                                        |
|    unzip this file to your mIRC directory (eg:c\mirc), |
|      - run mIRC.exe                                    |
|      - type /remote on                                 |
|      - type /load -rs away11b.mrc                      |
|      - click yes if a small popup appears              |
|        to run the initialization commands              |
|      - put pager.wav in your mirc\sounds folder        |
|    NOTE : you need mIRC v5.6+ for this script,         |
|           failing which the script will unload itself  |
|           to know which version of mIRC you are        |
|           using,type //echo $version in any window     |
|           Get mIRC v5.6+ from http://mirc.co.uk        |
|========================================================|
|   FEATURES                                            |
|    Away nick Suffix                                    |
|      - the suffix you add to the list is added to      |
|        your nick when you set yourself away            |
|        you can add multiple away nick suffixes,        |
|        and select anyone you want when setting away    |
|    Away reason                                         |
|      - the away reason you type in is displayed        |
|        when you set yourself away                      |
|    Options                                             |
|      - pager [on/off]                                  |
|      - msg logging [on/off]                            |
|      - change nick when away [on/off]                  |
|      - silent away mode [on/off]                       |
|        (some channels kick/ban for public away mode,   |
|         hence,this option)                             |
|    Sends and Chats(DCC)                                |
|      - allow when away                                 |
|        sends [on/off]                                  |
|        chats [on/off]                                  |
|    Ignore Mode                                         |
|      - if this option is chosen,any user who msg's     |
|        you is ignored                                  |
|        default ignore time : 30 seconds(fixed)         |
|    Display Timer                                       |
|      - sets the time interval to tell channel          |
|        you are away (in minutes)                       |
|    Idle Away                                           |
|      - [on/off]                                        |
|        time (in minutes) before you idle away,         |
|        configurable through menubar popup              |
|    Auto ID to nickserv                                 |
|      - option to set your nick password                |
|        auto identifies to your nick when asked         |
|        for by nickserv                                 |
|========================================================|
|   FKEYS                                               |
|    F2  setup/away/back                                 |
|    F10 check messages                                  |
|    F11 check pages                                     |
|    F12 clear all msgs and pages                        |
|========================================================|
|   DISCLAIMER                                          |
|    I am not responsible for what may occur after you   |
|    download and use this script,I will also take no    |
|    responsibility for any damage or loss that may      |
|    occur to your system !                              |
|========================================================|
|   CONTACT                                             |
|    E-mail : info@acidcode.8m.com                       |
|    URL    : http://acidcode.8m.com                     |
|========================================================|
|   �1999 m0rbid                                         |
|   TEAM [ACIDCODE]                                      |
|________________________________________________________|

