This is a addon for Chanserv, Nickserv and Statserv DALnet services 
using dialogs.
For Memoserv, use the excellent memoexpress from |Legend| at 
irc-scripts.com or http://www.IRCworks.com/~memoexpress

dalservgui.mrc contains menus and dialogs definition
dalserv.mrc    contains startup code, events, dialogs code and alias

This script requires the use of mIRC 5.71

This script add 1 sub-menu in main and channel menu under the topic Services.
If one of the services is not available, the menu will not show the service name.

How to use :
  - copy the 2 .mrcs where you want
  - open your mIRC and type /load -rs FullpathTo\dalservgui.mrc 
    ( ex : /load -rs c:\mirc\addon\dalservgui.mrc )
  - then go to the main menu or channel menu.

For services and other DALnet help, have a look at http://help.dal.net/docs/
All comments and/or suggestions are welcome.

blaster^       
@mIRC DALnet irc
blasterb@wanadoo.fr