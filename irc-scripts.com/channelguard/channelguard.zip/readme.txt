PLEASE READ the channelguard.nfo before installing it

IT MUST BE INSTALLED IN YOUR MAIN MIRC DIRECTORY FOLDER IN THE
DIRECTORY \CHANNELRIDER.

OTHERWISE it WONT WORK  !!!!!!!!!



							Thanx, Scared