==============================================
|--------------------------------------------|
|----------------R.I.P. Mp3------------------|    
|--------------------------------------------|
==============================================


================Instalation===================
1) Extract RIPmp3.zip to /mIRC/ directory
2) Then start up mIRC
3) Press alt+r Go to File/ Load/Script
4) Select Show All Go to RIPmp3 directory
5) Select ripmp3.mrc then press Ok! when the 
box pops up
6) set up RIPmp3
7) After you close it and wish to reopen it 
Right-Click on the channel window and select 
R.I.P. Mp3
==============================================