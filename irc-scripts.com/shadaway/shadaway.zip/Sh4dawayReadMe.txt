Sh4d0w AwAy System v1.0
Email: shadowstorms@hotmail.com

1. How To Load

	A. Unzip files anywhere in your mIRC directory
	B. Open mIRC
	C. Type /load -rs shadaway.mrc

		Example: if you put the files somewhere else other than your main mIRC directory
                         for example you put them in a folder called "away" then type /load -rs away\awayshad.mrc

===============================================

2. Setting Options

You'll find the options in the channel drop down menu and the main drop down menu at the top of your mIRC program.
	
Away Dialog: This will open the main away dialog.

View Messages: This will open up your message window which will show messages that were sent to you while you were set away.

Current Settings: This will show your current away settings

Uninstall: This will unload the entire away addon if you feel this script isn't the one you want to use.

================================================

3. Using The Main Away Dialog

	Away Message: At the top in the "Away Message" box, you have to type a reason you are away.

	Message Logger: Click OFF if you don't want to log messages while you're away.

			Click ON if you would like to log messages while you're away.

	Open Log: Click on this button to view messages that have been logged during your time away.

	Display To Channel?: Click YES to display your away status to the all channels you are on while away.

			     Click NO if you don't want to display your away status to all channels you are on while away.
	
	Minutes: Choose the time (in minutes) you would like to display your away status to all channels while away.
                 Example: If you choose 10 from the drop down menu, your message will be displayed to the channel every 10 minutes.


	Away Button: Click to set yourself away

	Cancel Button: Click to close dialog

	Back Button: Sets you back (not away)

===========================================================

4. Unloading Away Addon

	A. Click on uninstall from the Away Menu to unload this addon script.

=============================================================

Hope you enjoy the addon script. It's my first dialog based addon. thankZ for trying it out and happy mIRCing........laterZ

Sh4d0w
irc.chatnet.org
#Mp3_Ultimate_Sounds
#JiGGa
http://shadowstorms.com
