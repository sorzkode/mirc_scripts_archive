Napster Search Engine v1.0
*------------------------*

Developed by: SvPir8
Special Thanks to: BurntAsh

Join [ #Warez-central ] on the UnderNet
*-------------------------------------*

[Installation]

1. Unzip all the files into your main mIRC directory
2. Type /load -rs Napster/napsrch.mrc
3. Enjoy It, and spread it around!
*--------------------------------*

[About Napster Search Engine]

This script is awsome (in my opinion) just type in 
what u want to search for and hit search and it will
open Napster and begin the Search
*-------------------------------*

[Shout Outs]

I'd like to thank everyone i know from #Warez-central
*---------------------------------------------------*