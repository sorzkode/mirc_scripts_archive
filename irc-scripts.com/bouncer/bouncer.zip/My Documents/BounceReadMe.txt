Welcome to [Axe-Bounce].
load the .mrc into your mirc file and load it into the mIRC.
this script is very self sufficiant and has a help button in it.
i hope you enjoy this, if you have any problems, comments, or questions, e-mail me. Mateox@juno.com
-Mateo-