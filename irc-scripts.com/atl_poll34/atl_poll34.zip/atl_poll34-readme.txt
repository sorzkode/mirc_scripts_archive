 -----====== Atl Poll v3.4 by CQAtlantis ======----
    
 Install:
 -------------
    
    To install put the file atl_poll34.mrc in your
  mirc directory. Then Type: 
    
               //load-rs atl_poll34.mrc
    
 --------------------------------------------------
    
 Use:
 ----
    
    To use this script type [ /appoll Toppic ] or
  tight click in the chat window or any window and
  goto At lPoll and click on [ Start ].
    
 --------------------------------------------------
    
 Credit:
 -------
    
    Thank you to the chatters of #WorldVillage on
  [ irc.villageirc.net ] for helping with the
  testing this script. Also big thanks to WeaZeL
  [ weazel@villageirc.net ] who fixed the change
  name cheat for me.
    
 --------------------------------------------------

 Contact:
 --------
    
    IRC: irc.villageirc.net [ 6667 ]
    Web: www.vi-p.net
    ICQ: 22561800
    AIM: CQAtlantis
    EMail: cq@vi-p.net
    
 -----====== Atl Poll v3.4 by CQAtlantis ======----