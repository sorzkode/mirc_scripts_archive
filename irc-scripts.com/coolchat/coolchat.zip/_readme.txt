- CoolChat mIRC Script by spunky <daftspunk@cyberdude.com>
--------------------------

Thank-You  for downloading  the CoolChat script for mIRC.
To  install  this  script,  uncompress  these  files into
your mIRC directory. After that, run mIRC and type in the
status  window, /load -rs coolchat.ini and click yes when
prompted  with  a message  to do the startup commands for
the script.

After you  have done  these commands a box  will popup to
ask for  your nickname.  Enter your nickname  and wait to
connect to  the irc server, Irc.MegaIRC.Net on port 6667.
