/-------------\
|DNS+ by Tarek|
\-------------/

What The Script Does:
When you do a /dns on someone, it brings up a @dns window which displays the nick, hostname and 
ip address of whoever you dns'd.

To Load Script:
Unzip in your mirc dir and type /load -rs dns.mrc

Questions or comments should be sent to n0fx@idirect.ca