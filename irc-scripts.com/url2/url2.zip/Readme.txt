               ____    _____   _   _   ____    _____ 
              /�___|  |�____|�|�\�|�| /�___|  |�____|�
              \___�\� |��_|   |��\|�| \___�\� |��_|   
            �  ___)�| |�|___  |�|\��|� ___)�| |�|__
              |____/  |_____| |_|�\_| |____/  |_____| 
           Copyright � 2000 The Sixth Sense Productions.

***************************
*Go To URL Dialog V2.0    *
***************************
*Created by SirNo3DfX 2000*
***************************

****Install this script.****

Instructions :
1. copy Url2.mrc to mIRC folder directory
2. Open mIRC.exe or any of your mIRC programme.
3. Type "/load -rs Url2.mrc" then press enter.
4. Now I'ts done and you can start using The Go To URL addon

Note: This scripts requires mIRC 5.71 and above.  To get the 
      latest version of mIRC, visit http://www.mirc.com.

You Will Find The Go To URl Addon On All Popups
You can also Press F3 anytime and the Dialog will show.

*****
v1.0*
*****
This was the first version of Go TO URL addon 
*****
v2.0*
*****
Go To URL addon is back with a lot of improvements..
I found out that not everybody uses Netscape or Explorer :P hehehe
I have added another feature to now the dialog saves your 10 last 
visits on the internet so that you don't have to type them again.

