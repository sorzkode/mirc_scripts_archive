#include "MemMenu.h"

//----------------------------------------------------------------------------
LPWORD MemMenu::offset() const
{
	if (!size) return pRes;
	LPWORD p = (LPWORD)((LPSTR)pRes + pRes[1]) + 2;
	int count = item;
	if (*pRes)
	{
		while (align(&p), (DWORD)((p - pRes) << 1) < size)
		{
			if (--count <= 0) return p;
			int popup = (p[6] & 1);
			p = ordinal(p + 7);
			if (popup)
			{
				align(&p);
				p += 2;
			}
		}
		return pRes;
	}
	while ((DWORD)((p - pRes) << 1) < size)
	{
		if (--count <= 0) return p;
		p += (*p & MF_POPUP ?  1 : 2);
		p = ordinal(p);
	}
	return pRes;
}

//----------------------------------------------------------------------------
int MemMenu::is_break() const
{
	return !caption().length();
}

//----------------------------------------------------------------------------
String MemMenu::caption() const
{
	LPWORD p = offset();
	return (LPCWSTR)(p + (*pRes ? 7 : (*p & MF_POPUP ? 1 : 2)));
}

//----------------------------------------------------------------------------
int MemMenu::is_popup() const
{
	LPWORD p = offset();
	return *pRes ? p[6] & 1 : *p & MF_POPUP;
}

//----------------------------------------------------------------------------
int MemMenu::is_final() const
{
	LPWORD p = offset();
	return *pRes ? p[6] & 0x80 : *p & MF_END;
}