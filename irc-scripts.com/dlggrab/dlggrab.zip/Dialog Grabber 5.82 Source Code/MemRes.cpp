#include "MemRes.h"
#include "String.h"

//----------------------------------------------------------------------------
MemRes::MemRes(HMODULE hModule,LPCSTR name,LPCSTR type)
{
	//find, load, lock, alloc and align resource
	HRSRC	hResInfo	= FindResource(hModule,name,type);
	size				= SizeofResource(hModule,hResInfo);
	HGLOBAL hResData	= LoadResource(hModule,hResInfo);
	LPWORD	hRes		= (LPWORD)LockResource(hResData);
	heapRes				= LocalAlloc(0,size + 256);
	pRes				= (LPWORD)(((DWORD)heapRes + 3) >> 2 << 2);
	CopyMemory(pRes,hRes,size);
}

//----------------------------------------------------------------------------
void MemRes::align(WORD **ptr)
{
	*ptr = (LPWORD)(((DWORD)*ptr + 3) >> 2 << 2);
}

//----------------------------------------------------------------------------
LPWORD MemRes::ordinal(LPWORD p)
{
	return p + (*p == 0xFFFF ? 2 : 1 + lstrlenW((LPCWSTR)p));
}