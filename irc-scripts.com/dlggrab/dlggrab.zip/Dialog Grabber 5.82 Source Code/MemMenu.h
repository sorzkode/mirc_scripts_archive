#ifndef MEMMENU_H_
#define MEMMENU_H_

#include <windows.h>
#include "MemRes.h"

#include "String.h"
#include <windows.h>


class MemMenu : public MemRes
{
	int item;

public:

	MemMenu::MemMenu(HMODULE hModule,LPCSTR name) : MemRes(hModule,name,RT_MENU)
	{}

	void set_item(int count) { item = count; }
	LPWORD offset() const;
	int is_break() const;
	int is_popup() const;
	int is_final() const;
	String caption() const;
};


#endif //#ifndef MEMMENU_H_