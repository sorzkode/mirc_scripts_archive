//----------------------------------------------------------------------------
//MAIN.h

#include "windows.h"
#include "String.h"
#include "MemDialog.h"
#include "MemMenu.h"
#include "resource.h"

//----------------------------------------------------------------------------
BOOL CALLBACK main_dlg_proc(HWND,UINT,WPARAM,LPARAM);
BOOL CALLBACK enum_dialogs(HMODULE,LPCTSTR,LPTSTR,LONG);
BOOL CALLBACK view_dialog(HMODULE,LPCTSTR,LPTSTR,LONG);
BOOL CALLBACK grab_dialog(HMODULE,LPCTSTR,LPTSTR,LONG);
BOOL CALLBACK view_dlg_proc(HWND,UINT,WPARAM,LPARAM);

//----------------------------------------------------------------------------
void	view();
void	browse();
void	grab();
void	show_last_error();
String	menuitems(MemMenu &pMenu,int parentid);

//----------------------------------------------------------------------------
HWND	hDialog;
HWND	hListBox		= (HWND)IDC_LIST_DLG;
HWND	hEditTable		= (HWND)IDC_EDIT_TABLE;
HWND	hButtonView		= (HWND)IDC_BUTTON_VIEW;
HWND	hButtonGrab		= (HWND)IDOK;
int		cur;
float	sX,sY;
RECT	dlg_rect;
char	dlg_file_name[MAX_PATH];
char	mrc_file_name[MAX_PATH];
char	dlg_file_title[MAX_PATH];
HMENU	hMenu;

//----------------------------------------------------------------------------
OPENFILENAME dlg = 
{
	sizeof(OPENFILENAME),
	0,0,
	"Executable modules (*.exe; *.dll)\0*.exe;*.dll\0All files (*.*)\0*.*\0",
	0,0,
	1,
	dlg_file_name,MAX_PATH,
	dlg_file_title,MAX_PATH,
	0,		//initial directory			
	"Select a file containing dialog resources",
	OFN_HIDEREADONLY | OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST,
};
OPENFILENAME mrc = 
{
	sizeof(OPENFILENAME),
	0,0,
	"mIRC 5.8x scripts (*.mrc)\0*.mrc\0All files (*.*)\0*.*\0",
	0,0,
	1,
	mrc_file_name,MAX_PATH,
	0,MAX_PATH,
	0,	//initial directory			
	"Select a file to append the output code to",
	OFN_HIDEREADONLY
	,0,0,
	"mrc"
};
//----------------------------------------------------------------------------
struct CONTROL_STYLES
{
	DWORD win;
	char *mirc;
};
String add_styles(DWORD style,CONTROL_STYLES *styles);

//editboxes
CONTROL_STYLES edit_styles[] =
{
	{ ES_RIGHT, "right" },	
	{ ES_CENTER, "center" },
	{ ES_MULTILINE, "multi" },
	{ ES_PASSWORD, "pass" },
	{ ES_READONLY, "read" },
	{ ES_WANTRETURN, "return" },
	{ ES_AUTOHSCROLL, "autohs" },
	{ ES_AUTOVSCROLL, "autovs" },
	{ 0,0 }
};

//combo boxes
CONTROL_STYLES combo_styles[] =
{
	{ CBS_SORT, "sort" },
	{ CBS_NOINTEGRALHEIGHT, "size" },
	{ 0,0 }
};

//text/icons
CONTROL_STYLES text_styles[] =
{
	{ SS_RIGHT, "right" },
	{ SS_CENTER, "center" },
	{ 0,0 }
};

//list boxes
CONTROL_STYLES list_styles[] =
{
	{ LBS_SORT, "sort" },
	{ LBS_EXTENDEDSEL, "extsel" },
	{ LBS_NOINTEGRALHEIGHT, "size" },
	{ 0,0 }
};

//windows
CONTROL_STYLES window_styles[] =
{
	{ WS_HSCROLL, "hsbar" },
	{ WS_VSCROLL, "vsbar" },
	{ WS_DISABLED, "disable" },
	{ WS_GROUP, "group" },
	{ 0,0 }
};

//buttons
CONTROL_STYLES button_styles[] =
{
	{ BS_LEFT, "left" },
	{ BS_PUSHLIKE, "push" },
	{ 0,0 }
};
