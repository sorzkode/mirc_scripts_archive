#include "MemDialog.h"

//----------------------------------------------------------------------------
MemDialog::MemDialog(HMODULE hModule,LPCSTR name) : MemRes(hModule,name,RT_DIALOG)
{}

//----------------------------------------------------------------------------
//offsets
LPWORD MemDialog::offset() const		{ return pRes + (ex() ? 4 : 0); }
LPWORD MemDialog::menu_offset()	const	{ return offset() + 9; }
LPWORD MemDialog::class_offset() const	{ return ordinal(menu_offset()); }
LPWORD MemDialog::title_offset() const	{ return ordinal(class_offset()); }
LPWORD MemDialog::font_offset()	const	{ return ordinal(title_offset()); }
DWORD &MemDialog::style() const			{ return ((LPDWORD)pRes)[ ex() ? 3 : 0]; }
LPWORD MemDialog::items_offset() const
{
	LPWORD pDlg = font_offset();
	if (style() & DS_SETFONT)
		pDlg += ex() ? 3 : 1;
	return ordinal(pDlg);
}

//----------------------------------------------------------------------------
//values
short MemDialog::x() const		{ return offset()[5]; }
short MemDialog::y() const		{ return offset()[6]; }
short MemDialog::w() const		{ return offset()[7]; }
short MemDialog::h() const		{ return offset()[8]; }
String MemDialog::title() const
{
	LPWORD pDlg = title_offset();
	return *pDlg == 0xFFFF ? String() : (LPCWSTR)pDlg;
}
int MemDialog::items() const	{ return offset()[4]; }

//----------------------------------------------------------------------------
//item_offsets
LPWORD MemDialog::item_offset() const
{
	LPWORD pDlg = items_offset();
	for (int i = 0;	align(&pDlg), ++i < item;) 
	{
		pDlg += ex() ? 12 : 9;	//wtf 12 instead of 11
		pDlg = ordinal(pDlg);	//skip type
		pDlg = ordinal(pDlg);	//skip text
		if (*pDlg)				//skip creation data
			pDlg = (LPWORD)((LPSTR)pDlg + *pDlg);
		else
			pDlg++;
	}
	return pDlg;
}
LPWORD MemDialog::item_class_offset() const
{
	return item_offset() + (ex() ? 12 : 9);
}

//----------------------------------------------------------------------------
//item_values
WORD MemDialog::item_type() const
{
	LPWORD pDlg = item_class_offset();
	return *pDlg == 0xFFFF ? pDlg[1] : 0;
}
short MemDialog::item_x() const		{ return item_offset()[ex() ? 6 : 4]; }
short MemDialog::item_y() const		{ return item_offset()[ex() ? 7 : 5]; }
short MemDialog::item_w() const		{ return item_offset()[ex() ? 8 : 6]; }
short MemDialog::item_h() const		{ return item_offset()[ex() ? 9 : 7]; }
short MemDialog::item_id() const	{ return item_offset()[ex() ? 10 : 8]; }
String MemDialog::item_title() const		{ return ordinal(item_class_offset()); }
DWORD &MemDialog::item_style() const
{
	return ((LPDWORD)item_offset())[ex() ? 2 : 0];
}

//----------------------------------------------------------------------------
void MemDialog::deletemenu()
{
	LPWORD ioff = items_offset(), item1off = ioff;
	if (items())
	{
		int i = item;
		set_item(1);
		item1off = item_offset();
		item = i;
	}

	//move memory
	LPWORD moff = menu_offset(),coff = class_offset();
	MoveMemory(moff + 1,coff,(ioff - coff) << 1);
	*moff = 0;

	//decrease padding before the 1st item
	if (items())
	{
		int padsize = item1off - items_offset(); //in WORDS
		int movedist = (padsize & ~1) << 1;		//in bytes
		MoveMemory(((LPSTR)item1off) - movedist,item1off,(size -= movedist));
	}
}