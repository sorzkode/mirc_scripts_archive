
	DALnet Services Popups Script v1.2		June 98

Description:
^~^~^~^~^~^~

  This script is a typical DALnet Services Popups Script. It allows you to easily use DALnet services without typing up the commands and remembering them all the time. The popups are easy to use and very practical.

  This version of the script will only work with mIRC Version 5.4 or higher. If you have an older version I strongly suggest for you to go to http://www.mirc.co.uk/get.html and to download the newest version. If not, you can go to http://members.tripod.com/~danaria/ and get a version of this script that's compatible with older mIRC Versions.

  The script will turn your mIRC's Notify on and add NickServ to your Notify the first time that it's run. Everytime that NickServ is detected on your Notify, the script will be turned on for easy use. However, if NickServ happens to leave the server or network (in a NetSplit for example), the script will be turned off.


How to install this script:
^~^~^~^~^~^~^~^~^~^~^~^~^~^

	Your remotes has to be on for any scripts to work. Type:

		/remote on

	In any of your mIRC windows. It should say something like:

		*** Remote is ON (Ctcps,Events,Raw)


***
  If you downloaded this script from a webpage, then move the script to your mIRC directory. Type:

	/load -rs services.mrc

  in your Status Window.

***
  If you got this script via DCC send from someone over IRC, then type:

	//load -rs $getdirservices.mrc

***
  You can also load the script manually. Go to the TOOLS menu on the top and choose REMOTES. Once inside Remotes, choose LOAD SCRIPT from the FILE menu. Select services54.mrc and press on OKAY. The script should be loaded.



Comments:
^~^~^~^~^

	You may distribute this script anywhere you like. All I ask is that you'll always include this Text File (Unchanged please) if you do. It can help many a Newbie to install the script.

	I included a copy of DALnet's helpfile (dalservs.hlp) in this package. If you have any questions about how services works, then please refer there. It should answer most of your questions. If you require any further assistance feel free to email me at dany@mindless.com

	Naturally, on DALnet, there are also the multitude of Help Channels that are at your services. You can go to any of them for further assistance. #DALnetHelp, #HelpDesk and #IRCHelp are a few of them.

	You can even change the messages in the script if you like. It doesn't really matter to me :)


Author:
^~^~^~^

	Well, I'm really too lazy to tell you about myself, so I just copy & pasted my email signature (a little modified) in here. If you need help, then just look for me. :)

^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^
 Danaria is dany@mindless.com * Call me Dana, aka Schala
 Danaria is on #HelpDesk #mIRC #IRCHelp #Help #Empire
 Danaria is on liberty.nj.us.dal.net
 Danaria is away: Life is short as it is ... enjoy it! :)
End of /WHOIS list.
^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^