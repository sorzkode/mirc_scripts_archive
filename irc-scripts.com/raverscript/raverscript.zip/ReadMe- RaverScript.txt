To Install - 

Close your open'd mIRC.  Unzip Raverzip file to that your mIRC root dir.. ie C:\mIRC\

then - start up mIRC and before connecting.  Type /load -rs Loadme.rvr
in the status box. 

That'll set ya up, and show two dialogs.. The first one is not necesary to fill out if you don't want to.  However- Do take the all of 15 secs to fill out the Away dialog.  Like - under Nicks tab.  Give an away name. :) 

if you leave AutoAway as 0, you will NOT autoaway. kapice?

-Any Questions?  M|ddae is usually on #mIRC on the undernet.  A help file is soon to come.. :) 

Version 2.7 RaverScript ColourFul Control.