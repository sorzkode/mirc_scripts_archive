			|=======================================================|
			|         	Currently Playing v2.3			|
			| 	             by KolNedra			|
			|=======================================================|
						(C) 2000

					����--------========--------����

Installation:
		After unzipping all the files to a directory (WINZIP will create the standard
		directory in the dir you installed it to, so if you install CP23 to 'c:\mirc\'
    		WINZIP will create the directory: 'c:\mirc\CurrentlyPlaying23\' and unzips all
		the files to that directory....)

		Just start mIRC32.exe or mIRC16.exe (Must be v5.6 or greater)
		Then type in any window (isn't necesary to be connected):
		/load -rs CurrentlyPlaying23\cp23.mrc
				or
		//load -rs $mircdirCurrentlyPlaying23\cp23.mrc

		That's all, the rest will be quite simple to install !

					����--------========--------����
Usage:
		When the installation has been succesfully completed, you've 4 options in the
		menubar: Setup - Load Infobar - Readme - Unload
		[The last two are pretty understandable, so I won't explain these]

	Setup:
		This loads a small DIALOG window with 4 buttons and 2 checkboxes
		Buttons: - Action
			 - Load
			 - Ok
			 - Cancel
		(Ok and Cancel are obvious)

		Action: This will pop up an action DIALOG, this is self explanatory !
		Load:	This loads the infobar !

 	Action?: (See Setup -> Action)

	Load Infobar: (See Setup -> Load) <- See for infobar help The InfoBar Section!

					����--------========--------����
Infobar:
		When the infobar is loaded you'll see a song that's currently playing in the
		grey bar!
		When you click on the left mouse button while the cursor is over "SAY!": The script 
		will perform it's action you assigned at 'Menubar -> Action?' [Shortcut: Right mouse button on "SAY!"]

                If you think that picture window is quite obnoxious, click on the right mouse button anywhere in the Infobar
		except on the "SAY!" button, and then click on the 'Close Window' option!

					����--------========--------����
Contact:
		Contact me @ KolNedraIRC@hotmail.com
				or on IRCnet @ #musicplanet

					����--------========--------����

						CYA SOON Citizen !