- CNICK Script v.14 for mIRC v5.71+ (Scripting by SyntheroS) -
==============
- Description
==============
This is a script which will allow you to create your own colorized version of your nick,
and share it with other CNICK Script users. When talking in channels it will then replace
their regular nick with the CNICK version they reported to you, if they have that feature.
=============
- Disclaimer
=============
-- Full scripts that DO NOT work with CNICK --
Polaris
Showdown
ircN
mIRC v5.7 or lower
-----------------------------------------
This script does not mix will with other scripts, it works fine by itself and anything
beyond that is not known. If you load this and you experience problems such as not seeing
colorized nicks, not being heard by others, or saying the same things twice, then this
script is probably not compatible with your current base script. Granted, it is meant as
an addon, but not to other scripts that make such heavy modifications so that it would
disrupt CNICK's operation.
==========
- Contact
==========
web: http://syntheros.2y.net/
email: syntheros@gxtreme.net
irc: irc.gxtreme.net:6667 #support