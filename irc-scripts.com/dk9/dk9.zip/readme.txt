#BOF
#  Dynamic K9 Popups by flipster <flipster@netegra.com>

#  Install
1. Unzip all files to any folder
2. Type /load -rs drive:\path\dk9.mrc
	eg. /load -rs c:\mirc\scripts\dk9.mrc
3. Or load it within the script editor

#  How to use
Simply authenticate (auth) with k9

#  Commands
/quickauth [$1] [$2] 
	1. $1 and $2 not required, either order password channel or channel 
	    password accepted.
	2. will auth in $1, $2, $active, or will ask.
	3. will use $1, $2, %k9password, or will ask for password to use.
/k9unload - will unload DKP.
/k9custom - will bring up Customize dialog
/k9help - will bring up Help dialog
/k9fix - will clear things up for auth
/qa - quickauth, just quicker (used by other scripts so be careful)

#  About
Dynamic K9 Popups, re-written, and only runs on mIRC 5.61. Built to help deal with K9, Chatnet's channel
	service bot. Just try it, any problems, look for flipster. Bugs, same thing
	Will run with i2, one thing, if you selected "display notices to dqwindow" in the misc. config 
	menu, all of k9's messages will still show up, even the ones meant to be hidden. Works with 
	VirusScript 2000, but is buggy, will not catch anything done using /msg k9 or /msg k9@k9.chatnet.org 
	so if you use VirusScript's popups to do your commands then it will not catch it, and hide K9's
	commands option will not avtivate this addon (all because they must have halted the /msg command 
	somewhere in there). Plus the same bug as in i2, if the channel bot window is open, it will display 
	the info there even the ones meant to be hidden. Will run on Basic, but Basic displays the incoming 
	notices from K9 no matter what, so be ready for screen flyby if you check access or banlist. Very
	buggy on Havok 2k. will not catch any /msg's or /raw's sent to k9 (will catch /raw -q though) and will
	not work using the script's built in k9 popups.

# Compatibility
Dyanimc K9 Popups work flawlessly with:
	Peace & Protection 4.00
	IrcN7.11
	ShowDown v10 Pro
	Leaopard Script 2000
	Elite Script 2000
	[AciD Script] 1.3
	7th SpaRRow 5.0
Dynamic K9 Popups has display problems with:
	I� 1.04
	Basic 3.0
Dynamic K9 Popups works, but is buggy:
	VirusScript 2��� - Will not respnd to /msg or use script's built in popups
	Havok 2k - Only responds to included popups, raw -q privmsg, and input to channel (eg k9 access)

#  New
Version 4.13 - 3.18.2000
1. Fixed access display bug
2. Added Addmask to access display, it will gather a list of nicks on that channel and let you choose who will be addmasked (must be on the chanel)
3. Added "Sorry master, I don't see that nick on the channel." to the echo list.

Version 4.12 - 3.17.2000
1. Changed banlist to comply with chatnet's new banlist format (now like access).
2. Added autoauth when k9 joins for autoauth channels.
3. Added k9fix to raw 401 (no suck user) in case k9's not online.
4. Changed nicklist popups to show 'op' on nonops, and 'deop' on ops.
5. Added "Thats funny i see a @ by his name" to the other echo list.
6. Changed nicklist popups to show 'voice' on nonvoices, and 'devoice' on voices.
7. Fixed homepage and email in dk9.ppa (peace & protection addon)

Version 4.11 - 3.13.2000
1. Introdueced new command /k9fix. This will fix the auth bug when k9 isnt there and it attempts to auth some time later.
2. Changed email to pgeurtz@email.com. (cuz im movin yall)
3. Fixed pnp addon loading bug

Version 4.1 - 3.11.2000
1. Now supports multichannel autoauths and will not flood k9
2. Fixed dialog bug when typing command in channel (ie k9 access)
3. Changed filenames to dk9.mrc and dk9_dialog.mrc

Version 4.0 - 1.29.2000
1. Redesigned script completely. Moved Popups to seperate optional file. Put all Dialogs in one tabbed dialog
2. Brought back Upgrade via the web feature (not for public release yet, still in alpha testing)
3. Changed Addon help to picture help. Added K9 help dialog to main dialog
4. Added option to display all K9 msgs to dialogs
5. Redesigned Banlist and Access dialogs. Unban check, now can do multiline. Added Suspend and level, remuser
 moduser and level, and remmask to access dialog
6. Added about dialog (all for me =)
7. Changed ctcp from ($findtok(blah,$1,0,46)) to ($istok(blah,$1,46))
8. Removed support for Add-On Organizer and Dialog Progress indicator

Version 3.11 - 10.10.1999
1. Fixed $k9.password
2. Fixed /quickauth bug.

Version 3.1 - 10.4.1999
1. Made Access dialog, similar to Banlist, can be turned off/on the same way.

Version 3.01 - 9.26.1999
1. Added "Unban" check on banlist dialog, will unban the seleceted line when
 close is pressed. Only will show check if you are level 75 or higher in that
 channel.
2. Made P&P4.00 addon file, if you're using this file with Peace & 
 Protwection 4.00, load it in the Addons dialog. (Use the Unload button in
 the Customize dialog to unload the script, not P&P's Uninstall command)
3. Renamed the Level... to its unofficial rank, and right aligned the
 commands level in the popup.

Version 3.0 - 9.25.1999
1. Put all the variables in an ini file.
2. Added a banlist dialog. Displays all bans listed with K9, including who
 set the ban, dat, time, expiration date and time, and reason. Can be turned
 off and displayed as usual. (5.5up)

Version 2.4 - 9.20.1999
1. Removed upgradeability function.
2. Changed the dialog event, to work for only k9.* instead of *.
3. Added if $isalias(qa) to /qa, so it wont even try and use it if its 
 already used.

Version 2.34 - 6.10.1999
1. Merged nicklist and channel menus into one, and used $menu for different
 commands.
2. Merged similar events (dialog, notice) into their own events, and used
 $dname to tell them apart.
3. Changed groups to variable switches.
4. Removed upgradeability function, no new updates are planned until K9 gets
 some new commands. Look for a new version when K9 gets new commands.

Version 2.33 - 6.1.1999
1. Changed check sockread, it will automatically download if %k9upgrade or if
 $dialog(k9.custom) and $did(k9.custom,15). The 'yes' switch for auto upgrade.
 Added the alias k9.down and k9.look to do this.

Version 2.32 - 5.26.1999
1. Simplified the sockopen event, it now only has the nessecary sockwrites. Saved
 1.2K.
2. Moved the version number and homepage to the top of the script, to find
 easier.
3. Changed the did flags in the help dialog from -o to -ra.
4. Added alias k9.uload, provides fix for Add-On Organizer's dialog screwup

Version 2.31 - 5.23.1999
1. Bug in the k9.catcher, guess i stripped out a few things out that i needed.
2. Changed load and unload procs to use 
 dk92. $+ $remove($k9.version,$chr(46)) $+ .mrc instead of whatever the file's
 name really is. (Saves me a bit of typing when new versions come out).

Version 2.30 - 5.22.1999
1. Added Dialog Progress Indicator (DPI) by Sting support to upgrade procedure
 (5.5up).
2. Cut a few bytes from the $netserv custom identifier, and renamed it $chatserv.
3. Added Help section (5.5up). 
4. Added /k9.check to make upgrading easier.
5. Added -u0 to a few /set %k9tmp to unset them when done.
6. Changed ctcp from ($1 isin blah) to ($findtok(blah,$1,0,46))
7. Added timer to dialog call in load event, because Add-On Organizer sometimes
 threw a fit when loading.
8. Changed dialog's titles from %variables to dialog -t during init dialog event.
9. Made txt file alot easier to read.

Version 2.23 - 5.16.1999
1. Changed all the echos, now info2 color not info.
2. Added small dialog if not gonna self update, but there is a new version (5.5up).
3. Updated txt file.
4. Dropped some if/else code from the dialogs it sets to state now.
5. Added Check version button (5.5up) so u can manually check for a new DKP 
 version, Auto switch must be set to automatically upgrade if needed.
6. Changed level for level 1 events from 1 to *
7. chaged alot of if/else code to $iif .
	eg. if (blah) do this is now do $$iif((blah),this)

Version 2.22 - 5.13.1999
1. Fixed display bug for the load dialog.
2. Organized the customize dialog id's.
3. Added $k9.on for future usage (doesn't do anything right now).
4. Changed email address its now flipster@netegra.com.
5. Fixed download bug found in 2.21 $read dont like $scriptdir $+ %variable. 
 Sorry for 2.21 i had such high hopes.

Version 2.21 - 5.11.1999
1. Dropped some unnessacary code, events do their own commands instead of 
 calling aliases.
2. Renamed all the variables from %ak9 to %k9 (saved a few bytes).
3. Took the number outta the read file after download it just now deletes the 1st 
 line if it aint equal to whatever.
4. Fixed the $left($1) == # bug it is now $left($1,1) == #.

Version 2.2 - 5.6.1999
1. New feature. DKP is now self updating, It will check the DKP webpage if there 
 is a new version, and if you have it set it will automatically download the upgrade 
 patch which will upgrade to the next version. Or it will just tell you theres a new 
 version available so you can download it yourself (if you d/l it yourself it will not 
 be a patch, you will have to unload the old version just like any script).

Version 2.1 - 5.5.1999
1. Bug in Access $snick (atually asked for $me).
2. Added password support for popup auths.
3. Added ( ) to all the if's.
4. Got rid of returns and added elseif's.
5. Tightened up the code, looks alot nicer.
6. Changed /qa to /quickauth (to work with p&p, a popular full script). kept /qa 
 but it might not work with some full scripts.
7. Changed variable from words to 0 and 1 so it'll be easier to switch.

Version 2.0 - 5.2.1999
1. Whoa can you say 'change'?
2. Took out all pre 5.4 support.
3. Flushed the timer down the toilet.
4. Kicked the level check to the curb.
5. Instead of each popup being a variable, its now an $iif(), Basically, $iif(level on 
 # >= number,Popup):command or $iif(check is status(or menu),Popup):command.
6. Added $scriptdir to call for k9.hlp file.
7. Fixed $scriptdir in load and unload of second file.
8. Changed script filenames to dk91.20.mrc and dk92.20.mrc.

Version 1.5 - 5.2.1999
1. Was able to remake the script for above 5.4 alot simpler, and so got rid of all
 the above 5.4 stuff and made this script a bit smaller. But this pre 5.4 script will
 no longer be updated, and will have little support. If you want to take advantage
 of all the benifits of Dynamic K9 Popups and its continued improvements and
 support, upgrade to mIRC 5.4 at least, then upgrade to Dynamic K9 Popups v2.0.
2. Changed script filenames to dk91.15.mrc and dk92.15.mrc.

Version 1.36 - 4.28.1999
1. Added silence stop '.' to a missing disable command making it not display it.
2. Fixed Unload bug.
3. Changed dailog titles to variables to include script version.
4. Added on Start commands to tell when you've upgraded your mirc version.

Version 1.32
1. Renamed variable to match others.
2. Made k9.echo only change the popup variable if under version 5.51 (cuz its 
 dialog now).

Version 1.30
1. Added version.
2. Minor fixes for backward compatible, works back to 5.1.

No Version
1. Added toggle switch for $netowrk identifier(some networks, which will remain
 un-named, do not return the correct value for $netowrk) you can now choose to
 have it read the $server and return it from there.
2. Made somethings required in the commands section
	eg. topic # $?="Topic" is now $$?="Topic".
3. Added & to all variables, hot keys for the popups, for those people that use the
 keyboard more.
4. Added unload command.
5. Added Add-On Organizer 1.0 (iNFO Compatible).
6. Upgraded load and customize for 5.51 and up mIRC's, now uses dialogs for
 input.

EOF