;;;;;;;;;;;;
;
;
;      ...........
;      .         .
;      .      |��.������|
;      .      |  .      |
;      .......|...      |
;             |_________|
;
;
;      Pseudo physic engine,
;      by visionz (g_baril@sympatico.ca)
;
;
;
;
;                                              ;
;                                              ;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


Installation
-------------------------------------------
Load PseudoPhysic.mrc into your mirc remote
section and open with Statut menu, command
menu or channel menu