-----------------------------------\
Away System 3.0 by LordViper.        \  
First, some info:                             \
Contact:                                        \ 
1.IRC.DAL.NET:7000, #script-files.      /
2. Falconz@Ductape.net                  /
-----------------------------------/
~1.0: Installing the away system.
First of all, unzip all of the files into a directory.
Then, come into mIRC, and type /load -rs �location�\aways.mrc
(�location� is where you put the unzipped file, I.E. C:\Unzipped or something like that.)
If you'll see a little square prompt, click yes.
The away system is loaded and ready to use.
~1.1: Using the away system.
You can define Function keys to handle the aliases, becuase you don't feel like typing or using the popups, do ya? :-)
All of the options can be configured throughout the popups.
Some nice features that the script has:
*No /ame flaw, e.g. It's won't result in an error, trying to /ame when you're not on any channel.
*Away nick - You can define an away nick, so that ppl that join the chan you're on will see that you're away.
Example: Say your nick is John. You set away, with away nick enabled and defined. Your nick now changes to the nick you specified, i.e. John[A], or John{A}, or John-Gone..You get the point.
*Quiet away option - Do I need to explain?
* Also, a message logger + CTCP pager are included in the script.
* Auto-Away - If you idle more than the time you specify, it sets you away automatically, if it's enabled.
Please, if you find any bugs, email me or find me on IRC - The server and email addies are at the top.
------------------------------------------------------------------------------------------------------
**mIRC scripting resources:
So you don't come into mIRC Scripting help chans, ask for scripts and get banned, try these sites first:
1. www.pairc.com
2. www.mirc.net
3. www.mircscripts.com
4. www.hawkee.com
5. www.irc-scripts.com
--------------------------------
Enjoy.




