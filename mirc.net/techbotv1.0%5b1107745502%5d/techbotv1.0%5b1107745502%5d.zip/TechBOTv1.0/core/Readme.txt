This is an Seen Script , Copyright� by Vir2k from UnderNet`s Servers . Please don`t ReCopyright this script or you`ll damage it.
For any questions mail me at Vir2k_us@yahoo.com.


                           Regards Vir2k







To load the script please copy the seenscript.ini file in your mIRC directory , then please type /load -rs seenscript.ini in your mIRC program