(((((( Information ))))))
Welcome to TEchBOTv1.0. I decided to make a simple channel bot for channels and the END PRODUCT is TEchBOT!

(((((( Running ))))))
To run TechBOT v1.0, run:
1. Unzip contents of the techBOT.zip to a folder.
2.Copy mirc.exe v6.16 to this folder.
3.Simple open mirc.exe

(((((( Configuring ))))))
If you are running for the first time, a dialog box will open and you will have to fill all info to get the BOT working.
If you want to change the settings again then from TechBot menu select setup and same dialog box will appear again.
Example setup setup is as shown below.
After setup is done the bot could be configured remotely by utilizing its all services.
Please refer core/services.txt document for this.
Next time when Bot is online, it will detect you and give you a message.
To get help from him type /msg <BOT's Nickname> help me

((((( Example Configuration )))))
When you run TechBOT for first time a dialog box opens and you are then required to fill following fields :
BOT Nickname : Broken_Arrow ==> Enter the Nickname that BOT will be using...
BOT Password : jhjksdkfj    ==> Password for the BOT if he needs to auth with nickserv...
BOT Main channel : #NiteCafe==> Enter the main channel of the BOT where he will be staying...
BOT Server : coins.dal.net  ==> Server that BOT will join.......
BOT SERVER PORT : 6667      ==> Default port for that server ( Default value for DalNet is 6667 )
BOT Owner Nick Name : Kick_Master ==> This is important. Enter your nick name which you use for login....

Okay, now that I filled in all that information. I hit OK. Then, Close. The mIRC then lower's itself and I open up my client and
await TechBOT to join the channel I specified on the server I specified. When it joins, he will give you welcome message. I then type help me in private window with BOT
That's about it.

((((( Upgrading ))))))
Yet i am not done with website but soon it will be launched. Until then you can send me bug reports and queries to siddharth.god@gmail.com

(((((( Features )))))))
TechBOT v1.0 has several features such as:
Firstly only BAD thing is it is BEST with DALnet and GOOD with allothers !!!
It supports Autojoin on connect,Auto voice,Auto op, Auto kick features....
It has got 7 Different protections and auto greet also!
It supports our all normal commands like op,deop,kick,ban.... and also /say /me /describe etc.
It has 6 fun commands like !hug,!kiss,!romance,!beer,!wine etc...
It is very simple to configure and once configured it can be totally handled remotely...
It supports multiple MODERATORS which only owner can add and delete means FULL SECURITY....
It has got some amount of Artificial Intelligence also.....!!!
I hope you will enjoy the TchBOT v1.0 very much ...

(((((( Contact ))))))
IRC: coins.dal.net #kolhapur,#NiteCafe 
My IRC DALNET nick is Kick_Master
E-MAIL: siddharth.god@gmail.com
WEBSITE: Under construction
