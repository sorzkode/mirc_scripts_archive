Script Merger 1.00 Readme

================
Contact
================

Email: 	jeremy@mirc.net
IRC:	LemonButt on UnderNet

================
Installation
================

To install Script Merger:
	1. Extract files to mIRC directory or subdirectory.
	2. Type //.Load -rs $Shortfn($Findfile($Mircdir,scriptmerger.mrc,1)) in any mIRC window
	3. Type /SM in any window.

================
Usage
================

This addon will merge multiple remote and alias files into one remote file.  Alias files will be searched for aliases and prefixed with "Alias" so they function properly in alias files.  You can edit the prefix to localize alias files (Alias -l) or any other prefix by editing the SM.Prefix alias at the top of the script file.  Commenting code will insert begin/end comment lines for files.  Here is an example of a merged file using commented code:

;#################### Begin: file1.mrc ####################

----remotes----

;#################### End: file1.mrc ####################
;#################### Begin: file2.mrc ####################

----aliases----

;#################### End: file2.mrc ####################