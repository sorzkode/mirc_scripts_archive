 -----------------------------
|                             |
| Lusitania Theme by PuffGirl |
|                             |
|       1st Version           |
|                             |
 -----------------------------

-
Introduction
This MTS Theme is the second and final that i make. 
It comes after a very reasonable acceptance for my first theme (Carbon). And i'll, most likely, be updating both of them.
Lusitania consists in a default theme, called MiddleAge, and 6 more schemes: Sphere, Invision, Moonlight, Cold, Static and Fabrics.
-
How to use mIRC Theme Standards.

If you like your script to be kept organized, you should create a folder within it, called, say, "Themes". But it can be anything else.
After downloading a MTS theme, extract it to that folder. Usually, themes are released with it's own folder, but if they don't, you MUST create one single folder for one MTS theme (along with the *.MRC file that most themes have).

It's really important, that you NEVER keep multiple MTS Themes within the same folder. That will conflict with most theme engines. Will give you /* UNKNOWN COMMANDS, will Lag you for that, and you'll flame the author. :|

Now you have the theme, within it's folder, and you will need a theme engine. One good theme engine can be found, by following the link bellow:

KTE MTS Engine by Kamek:
http://mircscripts.org/download.php?id=1194&type=2

The link is broken? Just go to mircscripts.org and use the search feature.
-
Using KTE:

-Step 1 -> Loading the addon:

After downloading the addon, extract it into your mirc folder, or you can create a sub-folder.

In case you have the addon on mirc's main folder, just type /load -rs kte.mrc 
For a sub-folder, within mirc's main folder type /load -rs sub_folder_name/kte.mrc

Well, now you have the Theme Engine loaded on your script.

-Step 2 -> Loading an MTS Theme:

You can type /theme.load or you can click on your popup menubar -> "Load Theme". Then, a dialog will give you some options, so you can deal with it.

KTE will automatically search for mts themes available on mirc's folder. If it doesn't find the theme you want, you can click on the top button "..." and search for it yourself. Select the theme you want, on the left, and load it, by clicking the bottom button "Load".

This litle explanation applys to all mts themes. That's why i didn't even mention mine.
-
Thanks to,

 mirc.net
 mircscripts.org
 scriptsdb.org

For hosting my themes.

And special thanks to diabu for helping me with some tests.

-
Bug Reports,

I'll be very grateful if you can give me any ideas or bug reports for my themes.

You can find me at:

PTnet irc network (#PT-Scripters)
BRASnet irc network (#scripts)

Nicknames: PuffGirl, Napoleonika, Natasha, ... and some more (weird ones) that i don't dare to mention here. x)

Or mail me to: Napoleonika@gmail.com

-
PuffGirl Scripts 2005
-

Have fun.