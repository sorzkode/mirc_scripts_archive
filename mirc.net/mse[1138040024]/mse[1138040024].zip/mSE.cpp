/*
 * mIRC Scripts Editor DLL 
 * v1.0
 * by da^hype
 * www.codedb.org
 * _HUGE_ thanks to codemastr_ for helping with the hooks
 */
 
#include <windows.h>
#include <Winuser.h>
#define f(x) int __stdcall x(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)
 
HWND mEditor;

//some globals and structs
typedef struct tagLOADINFO
{
    DWORD  mVersion;
    HWND   mHwnd;
    BOOL   mKeep;
}LOADINFO,*LPLOADINFO;
HINSTANCE hInst		= 0; //the handle to our dll
HWND hMirc			= 0;
 
f(Editor)
{
	return 0;
}
 
LRESULT CALLBACK CBTHookProc(int iCode, WPARAM wParam, LPARAM lParam)
{
	//BOOL WHICH WILL LET THE CODE TO MODIFY RICHEDITBOX KNOW IF THE EDITOR IS OPEN

	if (iCode == HCBT_CREATEWND) 
	{ 
		mEditor = FindWindow(NULL,"mIRC Scripts Editor");
 
		if (IsWindow(mEditor)) 
		{
			// CODE TO MODIFY THE REMOTE EDITOR WINDOW
			UINT uStyles = (UINT)GetWindowLong(mEditor,GWL_STYLE);
			SetWindowLong(mEditor,GWL_STYLE,uStyles | WS_MINIMIZEBOX | WS_MAXIMIZEBOX);
			SetWindowPos(mEditor,NULL,0,0,0,0,SWP_FRAMECHANGED | SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
			 
		} 
	}
	return 0;
}
 
//truns hook on. It will then spy on irc, and deteck when a window is opened.
HHOOK hHook = SetWindowsHookEx(WH_CBT, CBTHookProc, GetModuleHandle(NULL), GetCurrentThreadId());
 
 
//just having this function and exporting will make mIRC keep the dll loaded
void __stdcall LoadDll(LPLOADINFO li)
{
	hMirc = li->mHwnd;
}
 
typedef struct tagENUMSTRUCT
{
	char szClass[256];
	HWND *hWnd;	
}ENUMSTRUCT,*LPENUMSTRUCT;
 
 
 
int __stdcall UnloadDll(int timeout)
{
	if (!timeout) 
	{ 
		UnhookWindowsHookEx(hHook); // kill the hook, so it doesn't crash mirc.
		return 1; 
	}
	return 0;
}

/*
 * Dll Info dialog
 * $dll(mSE.dll,DllInfo,.)
 *
 */
int WINAPI DllInfo(HWND,HWND,char *data,char*,BOOL,BOOL)
{
	MessageBox(NULL, "Made by da^hype (Shahir Reza Ali). www.codedb.org", "mSE.dll 1.0. Malaysian Made", MB_OK);
	return 0;
}