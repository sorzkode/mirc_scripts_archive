�_____�      �____�  �_____� �____�  __�����__
|�____|      /�___|� |�____| |��_�\  \�\���/�/
|��_|� _____�\___�\� |��_|   |�|_)�| �\�\�/�/�
|�|���|_____|�___)�| |�|___� |��_�<� ��\�'�/�
|_|���       |____/� |_____| |_|�\_\ ���\_/�� EXPLORER 2.1b
                                             

Thanx for using F-SERV EXPLORER :o)
I dedicate this script to ICFT (Internationale Confederation of Free Trader)       
If you think you can write that more clearer and whithout mistakes (I am sure you can) connatct me please
Please read this readme before you use F-Serv Explorer

This Files are in the trader.zip
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
trader.mrc
readme.txt
The script will create a fserv.ini file(setup is saved there) in scriptdir and temporary a fserv.dat (when you are on fileservers)

What It Is!
~~~~~~~~~~~ 
This is a simple little script that allows you to point and click your way through Fservers.
Change Directories, Download files, Send Files, check your Stats. All with a click of the mouse.
Couldn't be easier.

What you need.
~~~~~~~~~~~~~~
Internet Connection 
This Script 
mIRC 5.6 or greater
Windows 95/98/NT


How you install it.
~~~~~~~~~~~~~~~~~~~
When you got a earlier F-serv explorer version pls delete all files and unzip than this one in your directory
Type in any Mirc window "/load -rs (unzip directory) +trader.mrc"
(eg If you unzipped trader.mrc and readme.txt in "C:\script\trader\"
you have to type "/load -rs C:\script\trader\trader.mrc" )
Now a mirc script warning box appears click the Yes button to go on.
New poups are addes to the Commands popups in menu line (under the blue bar at the top "Files" "Tools" "DCC "Commands"..)
The setup dialog will appear now with own help text in listbox (you can find this text too at the end of this file)

Commands popups:
~~~~~~~~~~~~~~~~
F-Serv Explorer (move mous on it and popups with "." will appear
.Auto start @Filez window on Dcc fileserver seasson? (move mouse on it and popups with ".." will appear 
..Yes (Enable auto start)
..No (Disable auto start)
.Show percent while downloading in @Filez window? (move mouse on it and popups with ".." will appear 
..Yes (Enable percent viewing)
..No (Disable percent viewing)
.Auto tile window? (move mouse on it and popups with ".." will appear
..Yes (Enable Auto arrange of windows when @filez window appear)
..No (Disable Auto arrange of windows when @filez window appear)
.Setup F-Serv Explorer (Setup dialog)
.Script Info (hmm scriptinfos maybe *G*)
.Readme (Shows readme.txt)

@Filez window popups (appears when you right click in @Filez window)
~~~~~~~~~~~~~~~~~~~~
F-Serv Explorer works on ... F-serv (Some infos about your filelist and computer)
Check for double files (Compares your filelist with filenames in window and when it find one filename in window and filelist it will deled it in @filez window
Get selected file (Start download for selected file)
Get and view selected file (Downloads slected file and view/execute file, beware of executing .exe .com files you do not know maybe its an virus 
Send file (Open send dialog)
Setup (Open setup dialog)
Refresh @Filez window (all files will be showed again)

Popups on supported Fileserver (Panzer,Hawkee and Sphooserver)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
??? extension (??? = name of suported fileserver)
.check credit (checks credit and show it too you)
.current Ratio (shows current ratio)
.enough credit (you have select a file then F-serv Explorer tells you if you got enough credit for that file)
.View only files you can download with your current credit (Just view files you can download with your current credit)

F-Serv Filelist generator 1.0 (FSFG)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
This is a basic filelist generator
YOu can generate fielist of your files ;o) so that F-Serv Explorer knows your files and can delete them in @Filez window
when you Check for double files
First you have to change a start directory its auto set to C:\ (eg its C:\ then FSFG will search all directorys in c:\
eg its C:\Files\ it will search all directories in C:\files )
in the edit box you can specify which file extensions you want add to your filelist (eg if you type ".jpg.gif.bmp" only those
three filetypes will be added to you filelist, because i think when a trader just trade with pictures you wont need
.exe.bat.dll in your filelist) so you can maybe make one filelist for mp3 one for pictures one for movies...
you can fats chnage them in setup so its no porblem 
and if you really need eg .??? in your "eg picture filelist" just enter the filename in filename box and choose the direcory
where the file is and the .??? filesnames will be added to your picture filelist... 

What can it do?
~~~~~~~~~~~~~~~
It checks for double files
It can show you which files you can downlod with your current credit (on supported servers)
It shows your current ratio and credit (on supported servers)
It says you if you have enough credits to download the files you want (on supported servers)
It shows you download process in @filez window so you have not to open all the dcc get windows
It regets a files if the download stoped or anything happened
It shows you all private messages of fileserver automaticly
It can show only files with the extension you want
It creates filelists for you
and more option included soon :o)

Known Bugs:
~~~~~~~~~~~
[Files with spaces in fileservers]
when you want to download a file with spaces(like "sex with me.jpg) in Panzer or Hawkee
they think you want download multiple files like (sex.??? with.??? me.jpg) so this fileservers 
cannot send you files with spaces in filename

when you download a file in sphooserver sometimes there will be a proplem with deleting of
the filename line in @Filez window beacause its shows you in fileserver files with spaces and "_" character
(like "sex_with you.jpg") but send you "sex_with_you.jpg" so i have to replace the
"_" character (now our example looks "sex with you.jpg" but right one should be "sex_with you.jpg")
and now F-serv searches for the false text and wont find anything and replay this error "* /dline: insufficient parameters"
and F-serv explorer will save a wrong filename in your filelist same problem as above 
sorry but i found no way around it in sphooserver

[Changing directory while geting a file or other operations]
sometimes you will get error message in status screen but thats not so important 
and cannot crasch anything

Notes
~~~~~
Never Download and view a executable file (eg .exe.bat.com...) you don t know maybe its a virus or another crap 
Please give me a short message when you find a bug (james.james@maiclity.com) so i can fix it
When you want to help me or think you got some got ideas for the script please contact me 
When you script a fileserver and want to me to support it just msg me 

Thanx to:
~~~~~~~~~
Doctor P.C. scripter of the Offline Server script (saves many money for me beacuse i tested most offline on Panzer, Hawkee and Sphooserver fileserver)

Connatct:
~~~~~~~~~
Undernet as James-- in #almdudler #austria (often)
Dalnet as ORK1 in several trader channels with fileservers (sometimes)
E-Mail: James.James@mailcity.com
URL: http://sliver.hypermart.net/script/index.html
Newestversion: http://sliver.hypermart.net/script/trader.zip or 
               http://sliver.hypermart.net/script/trader.exe (for those who has no winzip)


First time starting message:
~~~~~~~~~~~~~~~~~~~~~~~~~~~
   Welcome to F-serv Explorer 2.1b
   -
   You started F-Serv Explorer the first time 
   this text wont be shown again
   (this notes are in readme.txt too)  
   Please read readme.txt and this notes
   - 
   Very important:
   Please check if you allow /run commands 
   You find that when click the icon next to the flash or press alt+o.
   Now doubleclick on "General" then click on "Look". Now you
   see a box named "Disable commands" when the box before
   /run is empty its ok, when not click on the box
   so that the box is empty
   (or the view file wont work)
   -
   Filelist:
   When you have no filelist you can generate one with
   F-serv Explorer or use a filelist from  Panzer,
   Hawkee,Sphoserver or from any other filelist generator 
   wich save the filenames as plain text in the list file (must not 
   be a .txt file). When its your first time trading and got no files
   just use F-Serv Explorers auto setted list or generate any .txt file
   and set it as filelist
   -
   Download Directory:
   The download directory you see on the button is the currently
   download directory you use. When you want to set another one,
   you can choose a directory by clicking the button but than you
   have to restart Mirc. After that restart mirc now your new directory 
   -
   Now enjoy the script :o)) James Shagall 
   James Shagall 
   �Sliver Productions 1999 
   E-mail James.James@mailcity.com