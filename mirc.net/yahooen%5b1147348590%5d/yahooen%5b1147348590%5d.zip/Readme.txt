/*
Loading:

/load -rs $shortfn(directory\ysc.mrc)

For example: /load -rs $shortfn(C:\myaddons\ysc.mrc) 
*/

Thanx!