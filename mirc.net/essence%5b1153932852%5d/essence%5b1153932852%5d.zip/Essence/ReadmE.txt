======== Essence DLL v.:2.2.6.0 ==========
==========================================
======= Essentialy addon for mIRC ========

1) Unpack folder to mIRC folder; ex.: C:\Program Files\mIRC\Essence\

2) Open mIRC and type /load -rs Essence\Essence.mrc

3) Type /eset and set G3, Game directory, etc...

4) Commands: 
             /g3 - G3 Torrent
             /g3.t - G3 Total (speed)
             /utor - uTorrent
             /utor.t - uTorrent Total
             /eabc - ABC Torrent (v3 protocol)
             /eabc.t - ABC Total (speed)
             /esong - WinAmp song info
             /esong+ - WinAmp simple song info
             /esong.autoon - if new song then call "esong"
             /esong.autooff - disable new song checking
             /edcc - DCC Get/Send file
             /edir - List of selected dir (optional 1st parameter is dir Ex: /edir c:\movies\)
             /ewins - Show open windows
             /ecpu - CPU Info
             /emem - Memory Info*
             /ehdd - HDD Space
             /epower - Power status
             /eoff - Monoitor Off
             /evideo - Video Adapter
             /eos - Windows version
             /euptime - Windows UpTime
             /euptimemirc - mIRC UpTime
             /enod - NOD32 Signatures version
             /eset - Essence Settings
             /etheme - Themes
             /essence - About Essence
             /echeck - Check latest version
             /enet - Network Adapters
             /enet.spd [index] - adapters speed (index = adapter index, if nothing then calc all)
             /enet.bts - all adapters IN/OUT
  AW Machine: 
             /awon - enable AM default (afk)
             /awon [reason] - enable AM with "reason"
             /awoff - disable AM
              other users can use "Nick:gong" and "Nick:beep"
             /beepstop - beeping stop :)

             /disablebeep - disable beeping
             /disablegong - disable gong

             /reloadessence - use after update process

--------------------------------------------------------------
Hint: (c) replacing "color char" and (b) replacing "bold char"
/edir command supported wildcards Ex: /edir c:\movies\the*
-----
"Save" button saving only selected part of theme
if save don't check NTFS settings (in NTFS drives)
-----
* garanted only on XP/2k maybe NET
(getting from windows registers)
-----
for showing G3/ABC info, must enable Web Interface and set pass/ID
in Essence, type /eset and set host (port only for ABC) and password or ID
-----
if using G3 Torrent ver 0.999 download this:
http://area-71.net/essence/g3FIX.zip
or update to 1.01 or newest
-----
###  If change headers of "file list"; modify "datalist" section in Essence.ini (order by (right click to headers))
###  example: http://area-71.net/essence/utor.PNG
-----
Always tested on latest mIRC version
--------------------------------------------------------------

Web: http://area-71.net/essence/ | E-mail: v2@area-71.net