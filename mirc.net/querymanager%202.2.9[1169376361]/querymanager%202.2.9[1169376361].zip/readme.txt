/************************************************
*						*
*	QueryManager 				*
*	Version: 2.2.8				*
*	Created by: Salz`			*
*	Email: salzig@gmail.com			*
*	Web: http://www.mircboard.de		*
*	IRC: quakenet.org #mirc-scripting	*
*	2006-03-27				*
*						*
************************************************/

 -----------------------------
 	INFORMATION
 -----------------------------

   Sorry for my bad english in the following.

 -----------------------------
	REQUIREMENTS
 -----------------------------
 
   I create that script on mIRC v6.17, so mIRC v6.17 is required.
   <v6.17 is untested.

 -----------------------------
	HOW TO INSTALL
 -----------------------------
   Unzip QueryManager.mrc into the mIRC Basedir, or 
   anyplace you like.

   Open mIRC.

   *   Then load the QueryManager.mrc with:
            /load -rs path_to/QueryManager.mrc

       Note: path_to can be relative to your mIRC.exe

   *   Open the Scripts Editor (Tools->Scripts Editor)
       Click at File->Load and locate your QueryManager.mrc
   

 -----------------------------
	HOW TO USE
 -----------------------------

   After you load the QueryManager.mrc file to your mIRC, 
   is all done. So, now you can wait for Query's, or you 
   write a query to your self with:
	//msg $me test

   To configure the Addon you can use the 
   menubar entry "QueryManger [/QM]" or you
   just type /qm into the Editbox and press [RETURN].

 -----------------------------
	CONFIGURE
 -----------------------------
  
   What can i change?
	- "Block all incoming messeges"
		Will block any messeges you got. If 
		whitelist is aktiveted those querys 
		will not blocked

	- "accept all incoming messeges"
		All incoming messeges will be accepted

	- "use Blacklist"
		activate's the blacklist usage.

	- "use Whitelist
		activate's the whitelist.

	- "auto block messeges after: N sec"
		Here you can configure the how long you 
		see the Information Dialog. The Value 0 
		deactivat's this feature.

	- "edit text" Area
		Here can you select with the small 
		dropdown which text you whant to change.
		By clicking the "change" button the 
		change is be down. "Reset" will go back 
		to default.


 -----------------------------
	HOW TO UNINSTALL
 -----------------------------

   Just click in the Configuration Dialog the menu Item
   File->Unload or File->Remove 

   Note: Remove will also delete your Configuration and 
         the QueryManager.mrc

 -----------------------------
	CREDITS
 -----------------------------

	-To WH|Teutonilo for beta testing
	-To Morph1512 for bug reports