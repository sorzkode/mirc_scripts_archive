/*
UltraDock DLL v0.1
by ClickHeRe
panodude@videotron.ca

This DLL lets the user dock dialogs around the mIRC interface

*/

#include "UltraDock.h"
#include "token.h"

// ##################################################################################################


void Signal(char *data) {	
  wsprintf(mData,"//.signal -n UltraDock %s",data);
  SendMessage(mIRC_hwnd, WM_USER + 200,0,0);
}

// Removes window style to a window
void RemStyles(HWND hwnd,int parm,long RemStyles)
{
  LONG Styles = GetWindowLong(hwnd, parm);
  Styles &= ~RemStyles;
  SetWindowLong(hwnd, parm, Styles);
}

//	Adds window styles to a window
void AddStyles(HWND hwnd,int parm,long AddStyles)
{
  LONG Styles = GetWindowLong(hwnd, parm);
  Styles |= AddStyles;
  SetWindowLong(hwnd, parm, Styles);
}

// ##################################################################################################
// mIRC Procedure Callback

Proc(mIRCProc) {

  switch(uMsg) {

    case WM_SIZE: 
      {
        mIRC_size();
        //SwitchbarPos();
        return 0L;
      }
      break;

    case WM_CAPTURECHANGED: 
      {
        //Signal("WM_CAPTURECHANGED");
        CallWindowProc(mOldProc,hwnd,uMsg,wParam,lParam);
        swb_pos = SwitchbarPos();
        mIRC_size();
        return 0L;
      }
      break;

    case WM_EXITSIZEMOVE:
      {
        Signal("SIZEEND");
      }
      break;

    case WM_ENABLE:
      {
        if (wParam) {
          CallWindowProc(mOldProc,hwnd,uMsg,wParam,lParam);
          swb_pos = SwitchbarPos();
          mIRC_size();
          return 0L;
        }
      }
      break;

      /*
      case WM_ACTIVATEAPP: 
      {
      if (wParam) {
      CallWindowProc(mOldProc,hwnd,uMsg,wParam,lParam);
      SetFocus(hwnd);
      return 0L;
      }
      }
      break;
      */
    case WM_COMMAND:
      {
        int wID = LOWORD(wParam);
        if (wID == 112 || wID == 111) {
          CallWindowProc(mOldProc,hwnd,uMsg,wParam,lParam);
          //Signal("WM_COMMAND");
          swb_pos = SwitchbarPos();
          mIRC_size();
          return 0L;
        }
      }
      break;

    case WM_CLOSE: 
      {
        SetWindowLong(mIRC_hwnd,GWL_WNDPROC,(LONG) mOldProc);
        PostMessage(hwnd, uMsg,0,0);
        return 0L;
      }
      break;

    default:
      break;
  }
  return CallWindowProc(mOldProc,hwnd,uMsg,wParam,lParam);
}

// ##################################################################################################
// Load DLL command
void WINAPI LoadDll(LOADINFO* load)
{
  hFileMap = CreateFileMapping(INVALID_HANDLE_VALUE,0,PAGE_READWRITE,0,4096,"mIRC");     
  mData = (LPSTR)MapViewOfFile(hFileMap,FILE_MAP_ALL_ACCESS,0,0,0);
  mIRC_hwnd = load->mHwnd;
  load->mKeep = TRUE;

  //Subclass mIRC
  mOldProc = (WNDPROC)SetWindowLong(mIRC_hwnd,GWL_WNDPROC,(LONG)mIRCProc);

  tb_hwnd = FindWindowEx(mIRC_hwnd,NULL,"mIRC_Toolbar",NULL);
  mdi_hwnd = FindWindowEx(mIRC_hwnd,NULL,"MDIClient",NULL);
  sb_hwnd = FindWindowEx(mIRC_hwnd,NULL,"mIRC_SwitchBar",NULL);

  swb_pos = SwitchbarPos();

  // Listbox opration creation
  lb_hwnd = CreateWindowEx(
    NULL,
    "ListBox",
    NULL,
    WS_CHILD,
    100,
    100,
    200,
    200,
    mIRC_hwnd,
    NULL,
    GetModuleHandle(NULL),
    NULL);
}

// Unload DLL command
int WINAPI UnloadDll(int timeout)
{
  if (!timeout)
  { 

    SetWindowLong(mIRC_hwnd,GWL_WNDPROC,(LONG) mOldProc);

    UnmapViewOfFile(mData);
    CloseHandle(hFileMap);
    return 1;
  }
  else return 0;
}

// ##################################################################################################
// External DLL Commands
mIRC(Version) 
{
  ret("UltraDock DLL v0.12 by ClickHeRe �2004 - http://scriptsdb.org");
}

// ##################################################################################################
// Docking Commands

// Dock N HWND POS NAME
mIRC(Dock) {

  if (numtok(data," ") > 3) {

    int pos = (int) atoi(gettok(data,1," "));
    HWND dhwnd = (HWND) atol(gettok(data,2," "));
    if (IsWindow(dhwnd) && AlreadyWindow(dhwnd) == -1) {

      if (!lstrcmp("left",gettok(data,3," ")) || !lstrcmp("right",gettok(data,3," ")) || !lstrcmp("top",gettok(data,3," ")) || !lstrcmp("bottom",gettok(data,3," "))) {
        AttachWindow(dhwnd);
        char text[256];
        lstrcpy(text,gettok(data,2," ",1));
        ListBox_InsertString(lb_hwnd, pos, text);

        mIRC_size();
        ret("U_OK");
      }
    }
  }
  ret("U_ERROR");
}

// UnDock N
mIRC(UnDock) {

  int pos = (int) atoi(gettok(data,1," "));
  int nItem = ListBox_GetCount(lb_hwnd);

  // valid position
  if (pos >= 0 && pos < nItem) {

    char text[256];
    if (ListBox_GetText(lb_hwnd, pos, text) != 0) {

      HWND dhwnd = (HWND) atol(gettok(text,1," "));
      if (IsWindow(dhwnd)) {
        EjectWindow(dhwnd);
        ListBox_DeleteString(lb_hwnd, pos);

        mIRC_size();
        ret("U_OK");
      }
    }
  }
  ret("U_ERROR");
}

// DockPos NAME
mIRC(DockPos) {

  if (numtok(data," ") > 0) {

    char text[256];
    int nItem = ListBox_GetCount(lb_hwnd);

    int i = 0;
    while (i < nItem) {

      ListBox_GetText(lb_hwnd, i, text);

      if (!lstrcmp(gettok(data,1," "),gettok(text,3," "))) {
        wsprintf(data,"%d",i);
        return 3;
      }
      i++;
    }
  }
  ret("-1");
}

// DockSide NAME
mIRC(DockSide) {

  if (numtok(data," ") > 0) {

    char text[256];
    int nItem = ListBox_GetCount(lb_hwnd);

    int i = 0;
    while (i < nItem) {

      ListBox_GetText(lb_hwnd, i, text);

      if (!lstrcmp(gettok(data,1," "),gettok(text,3," "))) {
        lstrcpy(data,gettok(text,2," "));
        return 3;
      }
      i++;
    }
  }
  ret("-1");
}

mIRC(DockRefresh) {

  mIRC_size();
  ret("U_OK");
}

mIRC(SBSize) {
  RECT rc;
  GetWindowRect(sb_hwnd, &rc);
  wsprintf(data,"%d %d", rc.right-rc.left, rc.bottom-rc.top);
  return 3;
}

mIRC(TBSize) {
  RECT rc;
  GetWindowRect(tb_hwnd, &rc);
  wsprintf(data,"%d %d", rc.right-rc.left, rc.bottom-rc.top);
  return 3;
}

mIRC(SBPos) {
  wsprintf(data,"%d",swb_pos);
  return 3;
}

// #####################################################################################
// mIRC hide/show Commands

// ShowMenubar 1|0
mIRC(ShowMenubar) {

  if (numtok(data," ") > 0) {
    int show = (int) atoi(gettok(data,1," "));

    if (show && !GetMenu(mIRC_hwnd))
      SendMessage(mIRC_hwnd, WM_COMMAND, (WPARAM) MAKEWPARAM(110,0), 0);
    else if(!show && GetMenu(mIRC_hwnd))
      SendMessage(mIRC_hwnd, WM_COMMAND, (WPARAM) MAKEWPARAM(110,0), 0);

    ret("U_OK");
  }
  ret("U_ERROR");
}

// ShowSwitchbar 1|0
mIRC(ShowSwitchbar) {

  if (numtok(data," ") > 0) {
    int show = (int) atoi(gettok(data,1," "));

    if (show && !IsWindowVisible(sb_hwnd))
      SendMessage(mIRC_hwnd, WM_COMMAND, (WPARAM) MAKEWPARAM(112,0), 0);
    else if(!show && IsWindowVisible(sb_hwnd))
      SendMessage(mIRC_hwnd, WM_COMMAND, (WPARAM) MAKEWPARAM(112,0), 0);

    ret("U_OK");
  }
  ret("U_ERROR");
}

// ShowToolbar 1|0
mIRC(ShowToolbar) {

  if (numtok(data," ") > 0) {
    int show = (int) atoi(gettok(data,1," "));

    if (show && !IsWindowVisible(tb_hwnd))
      SendMessage(mIRC_hwnd, WM_COMMAND, (WPARAM) MAKEWPARAM(111,0), 0);
    else if(!show && IsWindowVisible(tb_hwnd))
      SendMessage(mIRC_hwnd, WM_COMMAND, (WPARAM) MAKEWPARAM(111,0), 0);

    ret("U_OK");
  }
  ret("U_ERROR");
}

// IsSwitchbar
mIRC(IsSwitchbar) {

  if (IsWindowVisible(sb_hwnd)) {
    ret("$true");
  }
  else {
    ret("$false");
  }
}

// IsToolbar
mIRC(IsToolbar) {

  if (IsWindowVisible(tb_hwnd)) {
    ret("$true");
  }
  else {
    ret("$false");
  }
}

// IsMenubar
mIRC(IsMenubar) {

  if (GetMenu(mIRC_hwnd)) {
    ret("$true");
  }
  else {
    ret("$false");
  }
}

// #####################################################################################
// 0 == no swb, 1 == Left, 2 == Right, 3 == Top, 4 == Bottom
int SwitchbarPos(void) {

  RECT rc, rsb, rtb;
  POINT sbp;

  GetClientRect(mIRC_hwnd, &rc);
  GetClientRect(tb_hwnd, &rtb);
  GetWindowRect(sb_hwnd, &rsb);

  if (IsWindowVisible(sb_hwnd)) {

    sbp.x = rsb.left;
    sbp.y = rsb.top;
    ScreenToClient(mIRC_hwnd, &sbp);
    int rsbw = rsb.right - rsb.left;
    int rsbh = rsb.bottom - rsb.top;

    if (IsWindowVisible(tb_hwnd)) {

      // toolbar height added
      rc.top += rtb.bottom - rtb.top;

      int rch = rc.bottom - rc.top;
      if (sbp.x == 0 && sbp.y == rtb.bottom - rtb.top) {
        if (rsbh > rch - 5 && rsbh < rch + 5) {
          //Signal("SWB_LEFT");
          return SWB_LEFT;
        }
        else {
          //Signal("SWB_TOP");
          return SWB_TOP;
        }
      }
      else {
        if (rsbh > rch - 5 && rsbh < rch + 5) {
          //Signal("SWB_RIGHT");
          return SWB_RIGHT;
        }
        else {
          //Signal("SWB_BOTTOM");
          return SWB_BOTTOM;
        }
      }
    }
    else {

      int rch = rc.bottom - rc.top;
      if (sbp.x == 0 && sbp.y == 0) {
        if (rsbh > rch - 5 && rsbh < rch + 5) {
          //Signal("SWB_LEFT");
          return SWB_LEFT;
        }
        else {
          //Signal("SWB_TOP");
          return SWB_TOP;
        }
      }
      else {
        if (rsbh > rch - 5 && rsbh < rch + 5) {
          //Signal("SWB_RIGHT");
          return SWB_RIGHT;
        }
        else {
          //Signal("SWB_BOTTOM");
          return SWB_BOTTOM;
        }
      }
    }
  }
  //Signal("SWB_NONE");
  return SWB_NONE;
}

void mIRC_size(void) {

  RECT rmdi, rsb, rtb;

  // mdi size starts at client size
  GetClientRect(mIRC_hwnd, &rmdi);
  GetClientRect(tb_hwnd, &rtb);
  GetClientRect(sb_hwnd, &rsb);

  // MDI is always there
  int nWin = 1;

  if (IsWindowVisible(tb_hwnd) && IsWindow(tb_hwnd))
    nWin++;
  if (IsWindowVisible(sb_hwnd) && IsWindow(sb_hwnd))
    nWin++;

  int nItem = ListBox_GetCount(lb_hwnd);
  nWin = nWin + nItem;

  // DeferWindowPos Multiple Handle
  HDWP hdwp = BeginDeferWindowPos(nWin);

  // reajust top
  if (IsWindowVisible(tb_hwnd)) {
    DeferWindowPos(hdwp, tb_hwnd, NULL, 0, 0, rmdi.right - rmdi.left, rtb.bottom - rtb.top, SWP_NOZORDER);
    //MoveWindow(tb_hwnd, 0, 0, rmdi.right - rmdi.left, rtb.bottom - rtb.top, false);
    rmdi.top += rtb.bottom - rtb.top;
  }

  // parse switchbar position on mdi square
  switch (swb_pos) {

    case SWB_LEFT:
      DeferWindowPos(hdwp, sb_hwnd, NULL ,rmdi.left, rmdi.top, rsb.right - rsb.left, rmdi.bottom-rmdi.top, SWP_NOZORDER);
      //MoveWindow(sb_hwnd, rmdi.left, rmdi.top, rsb.right - rsb.left, rmdi.bottom-rmdi.top, false);
      rmdi.left += rsb.right - rsb.left;
      break;

    case SWB_RIGHT:
      DeferWindowPos(hdwp, sb_hwnd, NULL, rmdi.right - (rsb.right-rsb.left), rmdi.top, rsb.right-rsb.left, rmdi.bottom-rmdi.top, SWP_NOZORDER);
      //MoveWindow(sb_hwnd, rmdi.right - (rsb.right - rsb.left), rmdi.top, rsb.right - rsb.left, rmdi.bottom-rmdi.top, false);
      rmdi.right -= rsb.right - rsb.left;
      break;

    case SWB_TOP:
      DeferWindowPos(hdwp, sb_hwnd, NULL, rmdi.left, rmdi.top, rmdi.right - rmdi.left, rsb.bottom-rsb.top, SWP_NOZORDER);
      //MoveWindow(sb_hwnd, rmdi.left, rmdi.top, rmdi.right - rmdi.left, rsb.bottom-rsb.top, false);
      rmdi.top += rsb.bottom - rsb.top;
      break;

    case SWB_BOTTOM:
      DeferWindowPos(hdwp, sb_hwnd, NULL, rmdi.left, rmdi.bottom - (rsb.bottom-rsb.top), rmdi.right - rmdi.left, rsb.bottom-rsb.top, SWP_NOZORDER);
      //MoveWindow(sb_hwnd, rmdi.left, rmdi.bottom - (rsb.bottom-rsb.top), rmdi.right - rmdi.left, rsb.bottom-rsb.top, false);
      rmdi.bottom -= rsb.bottom - rsb.top;
      break;

    case SWB_NONE:
    default:
      break;
  }

  HWND dhwnd;
  RECT drc;
  char text[256];

  int i = 0;
  while (i < nItem) {

    ListBox_GetText(lb_hwnd, i, text);
    //Signal(text);

    dhwnd = (HWND) atol(gettok(text,1," "));

    if (IsWindow(dhwnd)) {

      GetWindowRect(dhwnd, &drc);

      if (!lstrcmp("left",gettok(text,2," "))) {
        DeferWindowPos(hdwp, dhwnd, NULL, rmdi.left, rmdi.top, drc.right - drc.left, rmdi.bottom - rmdi.top, SWP_NOZORDER);
        //MoveWindow(dhwnd, rmdi.left, rmdi.top, drc.right - drc.left, rmdi.bottom - rmdi.top, false);
        rmdi.left += drc.right - drc.left;
      }
      else if (!lstrcmp("right",gettok(text,2," "))) {
        DeferWindowPos(hdwp, dhwnd, NULL, rmdi.right - (drc.right - drc.left), rmdi.top, drc.right - drc.left, rmdi.bottom - rmdi.top, SWP_NOZORDER);
        //MoveWindow(dhwnd, rmdi.right - (drc.right - drc.left), rmdi.top, drc.right - drc.left, rmdi.bottom - rmdi.top, false);
        rmdi.right -= drc.right - drc.left;
      }
      else if (!lstrcmp("top",gettok(text,2," "))) {
        DeferWindowPos(hdwp, dhwnd, NULL, rmdi.left, rmdi.top, rmdi.right - rmdi.left, drc.bottom - drc.top, SWP_NOZORDER);
        //MoveWindow(dhwnd, rmdi.left, rmdi.top, rmdi.right - rmdi.left, drc.bottom - drc.top, false);
        rmdi.top += drc.bottom - drc.top;
      }
      else if (!lstrcmp("bottom",gettok(text,2," "))) {
        DeferWindowPos(hdwp, dhwnd, NULL, rmdi.left, rmdi.bottom -(drc.bottom - drc.top) , rmdi.right - rmdi.left, drc.bottom - drc.top, SWP_NOZORDER);
        //MoveWindow(dhwnd, rmdi.left, rmdi.bottom -(drc.bottom - drc.top) , rmdi.right - rmdi.left, drc.bottom - drc.top, false);
        rmdi.bottom -= drc.bottom - drc.top;
      }
    }
    i++;
  }

  DeferWindowPos(hdwp, mdi_hwnd, NULL, rmdi.left, rmdi.top+1, rmdi.right - rmdi.left, rmdi.bottom - rmdi.top - 1, SWP_NOZORDER);
  //MoveWindow(mdi_hwnd, rmdi.left, rmdi.top+1, rmdi.right - rmdi.left, rmdi.bottom - rmdi.top - 1, true);

  EndDeferWindowPos(hdwp);
  //RedrawWindow(mIRC_hwnd, NULL, NULL, RDW_INTERNALPAINT|RDW_ALLCHILDREN|RDW_INVALIDATE|RDW_ERASE);
}

void AttachWindow(HWND dhwnd) {

  RECT rcClient;
  // Window Struct to memorise Dialog size
  LPMYDCXWINDOW lpdcx = new MYDCXWINDOW;
  GetWindowRect(dhwnd,&lpdcx->rc);
  GetClientRect(dhwnd,&rcClient);
  SetWindowLong(dhwnd, GWL_USERDATA, (LONG) lpdcx);

  // Remove Style for docking purpose
  RemStyles(dhwnd,GWL_STYLE,WS_CAPTION | DS_FIXEDSYS | DS_SETFONT | DS_MODALFRAME | WS_POPUP | WS_OVERLAPPED);	
  RemStyles(dhwnd,GWL_EXSTYLE,WS_EX_CONTROLPARENT | WS_EX_CLIENTEDGE | WS_EX_DLGMODALFRAME | WS_EX_WINDOWEDGE | WS_EX_STATICEDGE);
  AddStyles(dhwnd,GWL_STYLE,WS_CHILDWINDOW);

  // save parent window
  SetParent(dhwnd, mIRC_hwnd);
  SetWindowPos(dhwnd, NULL, 0, 0, rcClient.right-rcClient.left, rcClient.bottom-rcClient.top, SWP_NOZORDER | SWP_NOMOVE);
}

void EjectWindow(HWND dhwnd) {

  LPMYDCXWINDOW lpdcx = (LPMYDCXWINDOW) GetWindowLong(dhwnd, GWL_USERDATA);

  // Remove Style for undocking purpose
  RemStyles(dhwnd,GWL_STYLE,WS_BORDER);
  //WS_CHILDWINDOW |
  RemStyles(dhwnd,GWL_EXSTYLE,WS_EX_CLIENTEDGE | WS_EX_DLGMODALFRAME | WS_EX_WINDOWEDGE | WS_EX_STATICEDGE);
  // Add Styles input by user
  AddStyles(dhwnd,GWL_STYLE,WS_CAPTION | DS_FIXEDSYS | DS_SETFONT | DS_MODALFRAME | WS_POPUP | WS_OVERLAPPED);	
  AddStyles(dhwnd,GWL_EXSTYLE,WS_EX_CONTROLPARENT | WS_EX_DLGMODALFRAME | WS_EX_WINDOWEDGE);
  RemStyles(dhwnd,GWL_STYLE,WS_CHILDWINDOW);

  //SetParent(dhwnd, lpdcx->hParent);
  SetParent(dhwnd, NULL);
  SetWindowPos(dhwnd, NULL, lpdcx->rc.left, lpdcx->rc.top, lpdcx->rc.right - lpdcx->rc.left, lpdcx->rc.bottom - lpdcx->rc.top, SWP_NOZORDER);

  delete lpdcx;
  SetWindowLong(dhwnd, GWL_USERDATA, NULL);
}

int AlreadyWindow(HWND dhwnd) {

  HWND dchwnd;
  char text[256];
  int nItem = ListBox_GetCount(lb_hwnd);

  int i = 0;
  while (i < nItem) {

    ListBox_GetText(lb_hwnd, i, text);

    dchwnd = (HWND) atol(gettok(text,1," "));
    if (dchwnd == dhwnd) return i;
    i++;
  }
  return -1;
}