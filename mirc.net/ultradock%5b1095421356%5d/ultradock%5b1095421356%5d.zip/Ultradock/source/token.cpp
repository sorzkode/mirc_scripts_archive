#include "token.h"

char* gettok(char *data, int pos, char *C, int all)
{
    char*  Token;
    int    i;
    char data2[1024];
    lstrcpy(data2,data);
    Token = strtok(data2,C);
    for (i = 1; Token && (i < pos); i++) {

      if (i == (pos-1) && all) return strtok(NULL,"");
      else Token = strtok(NULL,C);
    }
    if (all) return strtok(data,"");
    //if (!Token)
    //  lstrcpy(Token,"\0");
    return Token;
}

int numtok(char *data, char *C)
{
    char* Token;
    char data2[1024];
    int i = 0;
    lstrcpy(data2,data);
    Token = strtok(data2,C);
    while (Token) {
      Token = strtok(NULL,C);
      i++;
    }
    return i;
}

