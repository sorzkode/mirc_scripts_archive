//#pragma check_stack(off)
//#pragma comment(linker,"/OPT:NOWIN98")

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>
#include <stdlib.h>

// alias to define an External DLL Command
#define mIRC(x) int __stdcall WINAPI x(HWND mWnd,HWND aWnd,char *data,char*,BOOL,BOOL)
// alias to define a WNDPROC function
#define Proc(x) LRESULT CALLBACK x(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
#define ret(x) { lstrcpy(data,x); lstrcat(data,"\0"); return 3; }

#define SWB_NONE    0
#define SWB_LEFT    1
#define SWB_RIGHT   2
#define SWB_TOP     3
#define SWB_BOTTOM  4

// ##################################################################################################

// Global Vars
HANDLE hFileMap;
LPSTR mData;
// mIRC components HWND
HWND mIRC_hwnd, sb_hwnd, tb_hwnd, mdi_hwnd, lb_hwnd;
WNDPROC mOldProc;
// switchbar position
int swb_pos;
// indicate if MDI is maxed out
BOOL MDIismax;

// ##################################################################################################

// default Load DLL structure
typedef struct {
    DWORD  mVersion;
    HWND   mHwnd;
    BOOL   mKeep;
} LOADINFO;

// Dialog info structure
typedef struct tagMYDCXWINDOW {

  RECT rc;

} MYDCXWINDOW,*LPMYDCXWINDOW;

void Signal(char *data);

// Removes window style to a window
void RemStyles(HWND hwnd,int parm,long RemStyles);
//	Adds window styles to a window
void AddStyles(HWND hwnd,int parm,long AddStyles);

int SwitchbarPos(void);
void mIRC_size(void);
void AttachWindow(HWND dhwnd);
void EjectWindow(HWND dhwnd);
int AlreadyWindow(HWND dhwnd);