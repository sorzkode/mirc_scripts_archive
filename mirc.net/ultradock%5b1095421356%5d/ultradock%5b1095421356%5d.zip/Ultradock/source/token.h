#include <windows.h>

char* gettok(char *data, int pos, char *C, int all = 0);
int numtok(char *data, char *C);
