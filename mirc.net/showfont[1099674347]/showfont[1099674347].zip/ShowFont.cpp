/******************************************************************
 *
 *
 * FileName:		ShowFont.dll
 * 
 * Author:			Shredplayer
 * 
 * Version:			v2.0
 *
 *
 *******************************************************************/

#pragma check_stack(off)
#pragma comment(linker,"/OPT:NOWIN98")
#include <windows.h>
#include "resource.h"

HINSTANCE g_hInst;
char *color;
char *szRgb;
int rgb;


char *delchr(char *token)
{
	char *p = token + lstrlen(token) -1,*o = token;
	while (p[0] == ' ')
	{
		p[0] = 0;
		p--;
	}
	while (o[0] == ' ')
	{
		o[0] = 0;
		o++;
	}
	return o;
}

char *isin(int c , char *p)

	{

			while (*p && *p != c)

					p++;

				 if (*p == c) 
			
			return p;

        return NULL;
}

 UINT CALLBACK CFHookProc(HWND hdlg,UINT uiMsg,WPARAM wParam,LPARAM lParam)

	{
		HWND hWnd;

		switch(uiMsg)

		{

			case WM_INITDIALOG:

				hWnd = GetDlgItem(hdlg,1139);
				SendMessage(hWnd,CB_RESETCONTENT,0,0);
				char *num = strtok(" 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15",",");
				int o = 0;
				while (num != NULL) {
				SendMessage(hWnd,CB_ADDSTRING,o,(LPARAM) num);

					num = strtok(NULL,",");
					o++;

				} 

			    char *string = strtok(szRgb,",");
				int g = 0;
				while (string != NULL) {
                SendMessage(hWnd,CB_SETITEMDATA,g, (LPARAM) atoi(string));

					string = strtok(NULL,",");
					g++;

				} 

				int y = 0;
				while (y != 16) {
					if (SendMessage(hWnd,CB_GETITEMDATA,y,0) == rgb) {
						SendMessage(hWnd,CB_SETCURSEL,y,0);
					break;

					}
					y++;
				}

			 break;
		}

	return 0;

}



int __stdcall ShowFont(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)

	{


		CHOOSEFONT cf;
        static LOGFONT lf;	
        static DWORD rgbCurrent;	
        HFONT hfont;
		HDC hDC = GetDC(mWnd);
		char szSwitch[] = {0};

		ZeroMemory(&cf, sizeof(cf));
		cf.lStructSize = sizeof (cf);
		cf.lpLogFont = &lf;
		cf.nSizeMin = 8;
		cf.nSizeMax = 72;
		cf.Flags = CF_SCREENFONTS | CF_INITTOLOGFONTSTRUCT | CF_FORCEFONTEXIST | CF_LIMITSIZE;

		int i = 0;

	 	char *szToken;

	 	szToken = strtok(data,">");

		HWND hwnd = (HWND)atol(data);

				if (IsWindow(hwnd)) cf.hwndOwner = hwnd;

					if (!isin('>', data)) szToken = strtok(NULL,">");
			
					if (szToken != NULL) lstrcpy(lf.lfFaceName,delchr(szToken));

						szToken = strtok(NULL,">");

							if (szToken != NULL) lf.lfHeight = -(atoi(delchr(szToken)) * GetDeviceCaps(hDC, LOGPIXELSY) / 72);

								szToken = strtok(NULL,">");
								
								if (szToken != NULL) {

								if (isin('u',szToken)) lf.lfUnderline = TRUE;

								if (isin('s',szToken)) lf.lfStrikeOut = TRUE;

								if (isin('b',szToken)) lf.lfWeight = FW_BOLD;

								if (isin('i',szToken)) lf.lfItalic = TRUE;

								if (isin('T',szToken)) cf.Flags |= CF_TTONLY;

								if (isin('F',szToken)) cf.Flags |= CF_FIXEDPITCHONLY;
									
								if (isin('V',szToken)) cf.Flags |= CF_NOVECTORFONTS;
																	
								if (isin('P',szToken)) cf.Flags |= CF_PRINTERFONTS;

								if (isin('N',szToken)) cf.Flags |= CF_NOSCRIPTSEL;

								if (isin('C',szToken)) cf.Flags |= CF_SCALABLEONLY;

								if (isin('L',szToken)) cf.Flags |= CF_NOFACESEL;

								if (isin('Y',szToken)) cf.Flags |= CF_NOSTYLESEL;

								if (isin('Z',szToken)) cf.Flags |= CF_NOSIZESEL;

								if (isin('E',szToken)) {

								cf.Flags |= CF_EFFECTS;
								i = 1;

						}
							if (isin('D',szToken)) {

								cf.lpfnHook = CFHookProc;
								cf.Flags |= CF_ENABLETEMPLATE | CF_ENABLEHOOK;
								cf.nSizeMin = 5;
								cf.nSizeMax = 30;

								cf.lpTemplateName = MAKEINTRESOURCE(IDD_FONT);
								cf.hInstance = g_hInst;

								}

								if (!IsWindow(hwnd) && isin('A',szToken)) cf.hwndOwner = aWnd;
								if (!IsWindow(hwnd) && isin('M',szToken)) cf.hwndOwner = mWnd;

				}

								szToken = strtok(NULL,">");

								if (szToken != NULL)
			
					{

								color = delchr(szToken);
								rgb = atoi(color);
								if (!lstrcmpi(color,"Black") || rgb == 0) cf.rgbColors = 0;
								if (!lstrcmpi(color,"Maroon") || rgb == 128) cf.rgbColors = 128;
								if (!lstrcmpi(color,"Green") || rgb == 32768) cf.rgbColors = 32768;
								if (!lstrcmpi(color,"Olive") || rgb == 32896) cf.rgbColors = 32896;
								if (!lstrcmpi(color,"Navy") || rgb == 8388608) cf.rgbColors = 8388608;
								if (!lstrcmpi(color,"Purple") || rgb == 8388736) cf.rgbColors = 8388736;
								if (!lstrcmpi(color,"Teal") || rgb == 8421376) cf.rgbColors = 8421376;
								if (!lstrcmpi(color,"Gray") || rgb == 8421504) cf.rgbColors = 8421504;
								if (!lstrcmpi(color,"Silver") || rgb == 12632256) cf.rgbColors = 12632256;
								if (!lstrcmpi(color,"Red") || rgb == 255) cf.rgbColors = 255;
								if (!lstrcmpi(color,"Lime") || rgb == 65280) cf.rgbColors = 65280;
								if (!lstrcmpi(color,"Yellow") || rgb == 65535) cf.rgbColors = 65535;
								if (!lstrcmpi(color,"Blue") || rgb == 16711680) cf.rgbColors = 16711680;
								if (!lstrcmpi(color,"Fuchsia") || rgb == 128) cf.rgbColors = 16711935;
								if (!lstrcmpi(color,"Aqua") || rgb == 16711935) cf.rgbColors = 16776960;
								if (!lstrcmpi(color,"White") || rgb == 16777215) cf.rgbColors = 16777215;


						}
								szToken = strtok(NULL,">");
								if (szToken != NULL) szRgb = szToken;
								else szRgb = "16777215,0,8323072,37632,255,127,10223772,32764,65535,64512,9671424,16776960,16515072,16711935,8355711,13816530";
		
					ReleaseDC(mWnd,hDC);

					if (ChooseFont(&cf)) 
	 
		{
					hfont = CreateFontIndirect(&lf);
					if (lf.lfWeight > 699) lstrcat(szSwitch,"b");
					if (lf.lfItalic) lstrcat(szSwitch,"i");
					else if (lf.lfWeight != 700) lstrcat(szSwitch,"r");
					if (lf.lfUnderline) lstrcat(szSwitch,"u");
					if (lf.lfStrikeOut) lstrcat(szSwitch,"s");

					if (i == 0) wsprintf(data,"%s,%d,%s",lf.lfFaceName,cf.iPointSize / 10,szSwitch);

					else wsprintf(data,"%s,%d,%s,%d",lf.lfFaceName,cf.iPointSize / 10,szSwitch,cf.rgbColors);

				return 3;

		}

		else {

			lstrcpy(data,"$false");

			 return 3;

		}
}


// returns the Dll Info

int __stdcall DllInfo(HWND, HWND, char *data, char*, BOOL, BOOL)

	{
		  lstrcpy(data,"ShowFont.dll v2.0 by Shredplayer - shredplayer@email.com");
	     return 3;

}