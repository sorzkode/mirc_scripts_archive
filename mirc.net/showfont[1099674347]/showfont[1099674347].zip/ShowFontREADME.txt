ShowFont
Nick: Shredplayer
Email: shredplayer@email.com



ShowFont - Brings the Font dialog box and returns the selected values
	   in the format of FontName,FontSize,Styles,FontColor delimited by $chr(44).

ex:  Times New Roman,18,bius,65535

if "b" or "i" isn't specified "r" is return  (Regular).

NOTE:
 some people are requesting that S_CANCEL be changed to $false in the tradition of mIRC
 so here it is , $false is returned if the dialog is cancelled.


ShowFont
  
Arguments:

	Handle		Can be any window or dialog handle.
	FontName	Can be any installed font.
	FontSize		Ranges from 8 to 72, if "D" is used 5 to 30.
	Switch & Styles	u - Underline.
			s - Strikeout.
			b - Bold.
			i - Italic.
			E - enable underline, strikeout and color effects.
			T - only enumerate and allow the selection of TrueType fonts.
			V - not allow vector font selections.
			P - causes the dialog box to also list the fonts supported by the printer.
			N - disables the Script combo box.
			S - allow only the selection of scalable fonts.
			Z - prevent the dialog box from displaying an initial selection for the "FONT SIZE" combo box.
			Y - prevent the dialog box from displaying an initial selection for the  "FONT STYLE"  combo box.
			L -  prevent the dialog box from displaying an initial selection for the  "FONT NAME"  combo box.
			D - This will clone mIRC Font dialog box and can also use effects.
			X - if "D" is used the font sizes will range from 8 to 72.
			A - If the specified handle is omitted or null, the active window will be the parent window.
			M - If the specified handle is omitted or null, the main mIRC window will be the parent window.

			If the handle is omitted or null and both switch isn't specified, the parent window wil be null and the dialog
			will show on desktop.

			note: some switch may override others.

	FontColor		
 		                  RGB values
			  0, 128, 32768, 32896, 8388608, 8388736, 8421376, 8421504,12632256,
			  255, 65280, 65535, 16711680, 16711935, 16776960, 16777215.

	Color Array	up to 16 custom color, valid only if "D" and "E" is used.
			0,535535,255,127.....etc..
			since i use chr(44) as a delimeter internally i suggest to use a variable
			or identifier for the parameter. 



syntax: $dll(ShowFont.dll,ShowFont,[Handle]>[FontName]>[FontSize]>[Styles]>[FontColor]> [Color Arrays])

Color arrays is only valid when mIRC Font dialog layout "D" and "E" is used.

ex:  //echo $dll(ShowFont.dll,ShowFont,$dialog($dname).hwnd > Verdana > 12 > biE > 65535)

uses the Font dialog layout of mIRC.

ex:  //echo $dll(ShowFont.dll,ShowFont, > Verdana > 12 > MD)

or 
      supply it with custom 16 color array.
       var %i = 65535,127,255, etc.........
ex:  //echo $dll(ShowFont.dll,ShowFont, > Verdana > 12 > ED > 65535 > %i)

ex:  //echo $dll(ShowFont.dll,ShowFont, > Verdana > 12 > ED > 65535 > $readini(mirc.ini,palettes,n1))


The idea behind the extra space is for you to able to pass variables or identifiers as parameters.
but if you use only plain text extra space is not needed except for the handle.

all arguments are optional and if you want to omit parameters just leave it empty.
ex: //echo $dll(ShowFont.dll,ShowFont, >  >  > E > 65535)


DllInfo - returns the DLL Info.

ex: //echo $dll(ShowFont.dll,DllInfo,.)


for more suggestions PMSG me.