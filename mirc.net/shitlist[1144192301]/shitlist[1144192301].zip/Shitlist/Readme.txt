
=============================================================================
Puff_Shitlist Read me file.
=============================================================================

Loading the addon: Just put his folder on your mirc main folder and type /load -rs Shitlist/shitlist.mrc

Unloading the addon: Type /unload -rs shitlist.mrc

How it works:
In this shitlist, each user has it's own setup, such as channels, punishment, kick reason, ban type.
After loading the addon, type /shit and the setup dialog will come up. Then you start adding hostmasks that will be detected by this code. Then you select a hostmask that you added and configure it's options on the right. For removing a hostmask, just select it on the list and click "-".
Those hostmasks you add, aren't necessarily the ban type that you will apply. You can set it up to detect those masks, and ban them using another ban type. You do that by chosing it on the combo box bellow "Ban type/kick reason". You can set this to "Default" for banning the mask you added, as is. After configuring the options you want for the selected user, click "Apply", and those settings will be saved for that user.
This shitlist will punish any addresss that matches those you defined on the shitlist. You're not allowed to add hostmasks like *!*@* ou *, and the code wont ban your own address.

Note: By loading this addon, it creates a sub-folder and a file where hash table data will be stored. When you unload it, everything the code generated, will be deleted, and it will not leave any useless files/values on your mirc.

=============================================================================

Bugs, suggestions?

Networks: none
Nick: PuffGirl
E-Mail: Napoleonika@gmail.com

=============================================================================
  

