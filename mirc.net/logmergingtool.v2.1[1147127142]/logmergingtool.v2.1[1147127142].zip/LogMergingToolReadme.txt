; Log Merging Tool v2.1
; by ch1zra
; ch1zra@gmail.com
; http://uptheirons.co.sr/
; #Scripters @ irc.krstarica.com
; Copyright � Up The Irons ! inc. Scripting Team

; <----------------------- $Instalation ------------------->

	Step 1. Unzip .zip file into your mIRC directory.
	Step 2. Type :
   //load -rs " $+ $findfile($mircdir,LogMergingTool.mrc,1) $+ "
	Step 3. Answer "Yes" if a popup box comes up.
	Step 4. You are ready to use Log Merging Tool

	After instalation, check your popups, or type /merge

; <----------------------- $Usage ------------------------->

	Log Merging Tool provides some basic features for 
	merging more log files into single log. It scans given
	logs for sessions within it, and then sorts them by 
	time and date.

; <----------------------- $ChangeLog --------------------->

	v2.1
	- Replaced Help custom @window with another pretty
	  nice organized dialog.
	- Corrected some typos.

	v2.0
	- Unload $qt() bug.
	- Space in filename error
	- Some variables staying after $script execution
	- Added keyboard shortcuts.
	- Listbox double entry check
	- Improved file existance check, and added error msg 
	  if non-existent file is given for merging.
	- Total new write method, using far less resources 
	  than the old one, and much, much more faster and 
	  precise :)
	- Stopped using tmp files for execution of $script 
	- Also added on:dialog:close event to close all custom
	  windows and unset all variables, just in case of 
	  something has missed.
	- Removed picwin progressbar.
	- Replaced status output /echo with /aline custom 
	  @window. This one has a custom popup with "Close" 
	  item to close it (:P).

	
	Somethings for next versions (if needed) :
	- Maybe a dialog using mdx.dll    
	- Option to enter your own "Session Start:" and "Session
	  Close:" words, in case you've modified the way your 
	  mIRC describes session start and end in log.

   ; <----------------------- $Credits -------------------->

	- Khaled Mardam-Bey for making mIRC.
	- My girlfriend for giving me the idea
	- Heavy metal for clearing my thoughts during scripting.
	- Fast, the sweet nicotine :D
	- Pepsi and Ness ;]
	- All the others...

; <----------------------- $Disclaimer -------------------->

	I will under no circumstances be held responsible for
	any damage resulting from the use of this addon, 
	whether emotional, physical, loss of data, health, 
	wealth, religious beliefs, or whatever other type of 
	damage. By using this script and reading this document 
	you agree not to hold Log Merging Tool v2.1 or the author 
	of this addon responsible for (including but not 
	limited to) above mentioned damages. If you do not 
	agree with the above disclaimer, you should remove 
	this script from your computer immediately.

	Thank you for using this addon, I've worked hard to 
	make this as useful, practical and safe as I could!


; <----------------------- $Contact ----------------------->

	Mail :	ch1zra@gmail.com
	IRC :	#Scripters @ irc.krstarica.com
	ICQ :	177462935 (ICQ is gay)
	www: 	http://uptheirons.co.sr/
	bye, $me
						� 2006 Up The Irons ! inc.