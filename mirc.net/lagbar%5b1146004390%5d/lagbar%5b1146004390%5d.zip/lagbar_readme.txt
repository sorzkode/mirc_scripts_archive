LagBar 1.01 Readme

================
Contact
================

Email: 	jeremy@mirc.net
IRC:	LemonButt on UnderNet

================
Installation
================

To install LagBar:
	1. Extract files to mIRC directory or subdirectory.
	2. Type //.Load -rs $Shortfn($Findfile($Mircdir,lagbar.mrc,1)) in any mIRC window
	3. LagBar will automatically load in the top right-hand corner of your mIRC.

Additional install directions for MTS users:
	4. Press Alt+R
	5. Goto File>Order
	6. Select lagbar.mrc (should be the last one in the list)
	7. Press the "Move Up" button until lagbar.mrc is BEFORE your MTS loader (mts.mrc or similar)

================
Usage
================

Right-click the LagBar for options menu.  The options dialog is pretty much self explainatory.  You can change colors by clicking on the colored boxes and test the new colors/settings in the test area.  Nothing will be set until you press the OK button.

The "XP Theme" option will bump the controls down 2 pixels to even the dialog out.  I have not tested this myself, but I am told that users using XP Theme need the controls dropped down slightly to align properly with their toolbar due to the larger titlebars in XP Theme mode.

You can add custom events/echos/etc by using the ON SIGNAL event at the top of the script file.  Lag time is sent through $$1 and is in milliseconds.

================
Versions
================

Version 1.01 (Released 04/25/06)
   -Fixed destroy menu bug destroying a nonexistant menu.
   -Fixed timer being halted bug.  Timer is now set every time you connect instead of on start.
   -Added disconnect support to change lag to n/a when disconnected.

Version 1.00 (Released 03/11/06)
   -First version of LagBar.