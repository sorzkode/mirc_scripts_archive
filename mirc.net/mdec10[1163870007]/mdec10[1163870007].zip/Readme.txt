=========================
Msn Delete Checker v1.0 Readme.txt
=========================

============
     Description
============
This addon shows the people who are on your list who haven't added you to  their 

own list and the people who have deleted you from their list. 

Due to the change in the source website the addon started working later 

than usual. Thats why there has been an update.

===============
Updating Informations:
===============

===============
       Version 1.0
===============
*Removed security code box


==============
        Version 0.2
==============
*The dialog showing warnings about the addon has been removed.

The warnings are now shown in the main dialog.

*Added security code box.

*Removed unnecessary icons on listview.


============
     Installation
============
Unzip all files and then

/load -rs $shortfn(folder\mdec10.mrc)

For exam: /load -rs $shortfn(c:\pro direct\mdec10.mrc)


============
     Contact me
============
E-mail and Msn : serdarnone@hotmail.com

Thanks for using this addon ;)

Sorry my english...

SeRDaR406
