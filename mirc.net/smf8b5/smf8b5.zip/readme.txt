                      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                           SMF Script 8 beta 5
                         for mIRC 5.6 and higher
                      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
����������������������������������������������������������������������������
Homepage   : http://dgsoft.cjb.net
SMF Script : http://dgsoft.cjb.net/SMF8/
����������������������������������������������������������������������������

-=<Install>=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

1) Unzip the files into a CLEAN directory of your choise.
2) Copy mirc32.exe into the directory.
3) Run mIRC.

-=<What's New>=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

 1) Fixed bugs in the SPAM Blocker.
 2) Fixed the "add to channels" and "add to autojoin" bugs (now fully
    supports spaces).
 3) Fixed various issues bugs and quirks in the massmode commands.
 4) Added a caps kicker
 5) Added an option to customize the F keys
 6) Added a kick/kill counter
 7) Added a new version of the SMF Away Sys (4.0)
 8) Fixed an error in the country codes dialog.
    now, when you type a code with a dot you'll no longer get a $read error.
 9) The settings dialog now remembers it's last location.
10) The address for the userlists can now be chosen manually.
11) Fixed a bug in the autojoin list - now won't return errors if only one
    channel is chosen.
12) Added "safety" triggers for the IRC operator commands - now the oper
    dialogs will not open unless you are set to specific modes.
13) Added a textflood kicker.
14) Added a table window for /stats l.
15) Fully integrated the SMF Op Assistant with the script.
16) Fixed bugs in the remote banlist console.
17) Rewrote the nick manager to work with INI files instead of variables.
18) The quick menu, away sys, the autojoin list and the mediaplayer now
    use settings.ini to store their configurations settings.
19) Completely rewrote the autojoin list, now supports different networks.
20) Added an option to customize the script's sounds.
21) Rewrote the kick message parts of all kickers, now use one (editable)
    database in settings.ini.

-=<Older Versions>=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

SMF8 b4 :  1) Added a new version of the Quick Menu - fully customizable +
              skin support.
           2) All important variables are now being kept inside INI files
              (no more /unsetall == crash).
           3) Added an "update address" feature on the userlist dialog.
           4) Added mass comands on the nicklist.
           5) Fixed the ping reply bug.
           6) Added the Op Assistant v2.0.
           7) Added two more Fkey commands - shift-f1 for 'kick selected'
              and shift-f2 for 'bankick selected'.
           8) Added a "Did you know" tips dialog
           9) The titlebar now shows the server you are on and your
              usermodes
          10) Added an option to automatically set channel modes when opped
              in a channel.
          11) Fixed quirks with the userlist's bankick level
          12) Fixed compatibility issues with the SMF Mediaplayer
          13) Added an IRC Operator scanner
          14) Added a clone scanner
          15) Fixed bugs in the alarm clock

SMF8 b3 :  1) Fixed a few userhost-related issues.
           2) Fixed bugs in the lagbar.
           3) Made a new feature - average lag calculator on #channel ping.
           4) Added a small text editor (Textpad 1.0).
           5) Rewrote the quick menu to use the windows' color scheme +
              roll up when inactive.
           6) Started rewriting the script to work with mIRC 5.6.
           7) Removed the DCC Filter.
           8) Added a few minor improvemets to the SPAM Block code.
           9) Merged the Userlist main dialog with the settings window .
          10) Added new version of the SMF Server cuts (1.2).
          11) Added mass aliases.

SMF8 b2 :  1) Added support for the server notices (@Server window).
           2) Added the SMF Lag Bar (1.0).
           3) Added support for colour schemes.
           4) All script colours are now customizable (fit the currently
              selected colour scheme).
           5) Added a new version of the Mediaplayer
           6) Added a new version of the Away Sys
           7) Rewrote all userlists (support channels and various access
              levels)
           8) Canceled the multilanguage support.
           9) Added a ban dialog console

SMF8 b1 :  1) Added the SMF Server cuts (v1.0)
           2) Got rid of useless wavs, bmps, popups and messages.
           3) Rewrote the SPAM Block and DCC Filter for configurability.
           4) Started rewriting the settings window to dialogs.
           5) All script files are now being stored in the system folder.
           6) The quick menu can now be turned off.
           7) Rewrote the script's code to work with mIRC 5.5.
           8) Replaced the Channels Folder's listbox with a dialog box,
              improved the code and added new options.
           9) Replaced the Autojoin List's listbox with a dialog box.
          10) Replaced the Remote Banlist's listbox with a dialog box,
              improved the code and added more options.
          11) Added a new "Country Codes" dialog
          12) Replaced the kick section of the nicklist popups with a dialog
              kick console. 
          13) Startred rewriting popups to be smaller and easier.
          14) Added full IRCop support (popups, dialogs and events support).
          15) The notice, ctcp, whois and DNS commands now have a
              configurable output (default, active or special windows).
          16) Shrunk the channel op commands into mere 4 commands.

SMF99 b2:  1) Rewrote all services features.
           2) Added the Quick Menu (v1.5).
           3) Removed the Shortcut bar.
           4) Added a remote banlist features.
           5) Added an auto-join feature.
           6) Added an alternative to mIRC's default channel list.
           7) All configurable features are now located inside the Personal
              Settings Window.
           8) Added two info windows.
           9) Adjusted the button bar so it'll fit the mIRC v5.5 buttons. 
          10) Rewrote the alarm clock.
          11) Moved 99% of the script's MRC's and INI's into the system
              folder.
          12) Added the new versions of the Away Sys and the Mediaplayer.
          13) Added the Op Assistant (v1.0)
          14) Rewrote all popups

-=<Thanks To>=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Nukem : Tips, suggestions, bug reports, testing and, of course, making me
        a socket cloner so i could test my mass actions.
Plaza : Tips, suggestions and neverending critisizm.

Queen, Brian May, Andrew Lloyd Webber, Twisted Sister, Kiss, Ozzy Osbourne,
Rainbow, Deep Purple, Jethro Tull, Yngwie J. Malmsteen, Marty Friedman,
ABBA, Megadeth, Iron Maiden, Cacophony, Weird Al Yankovic, AC/DC, Ronnie
James Dio, Cinderella, Black Sabbath, Dream Theater, Skid Row, Gary Moore,
Sheryl Crow, The Bangles, The Eagles, Nazareth, Def Leppard, Metallica,
Guns'n'Roses, Body Count, Motley Crue, Nirvana and the Coca Cola Co. for
keeping me sane and awake during the preparation of the script.

-=<Contact Me>=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

I am usually on DALnet's #startrek #startrekbots and #startrekvoyager
(as you may have noticed, i like star trek :) as SMFF_of_TS and you can
always E-mail me at rewt@dgsoft.cjb.net

-=<Legal notes>=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

I made this script, therefore i own it. you rip it - i kick your ass,
the end :>