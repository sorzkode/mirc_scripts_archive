Purple television - 2004 - (updated in 2005)

All graphics, musics and scripting by StanZ
mIRC dlls by Str3iber & captainEO
________________________________________________________


Install:
Just unzip in your mirc root then type
/load -rs "television/television.mrc"
(press the righ mouse eyes for a popup menu)

Exit the demo with [ESC] (nice way for a thumb down :))

* * *

Pas besoin de fichier d'aide pour cet addon. Sinon qu'une simple commande pour
charger la demo dans mIRC:

en ligne de commande.
Tapez /load -rs "television/television.mrc"

Ensuite utilisez les popups pour lancer la demo. (Click droit sur le "status" par exemple.)

Pour quitter la demo, touche [ESC]