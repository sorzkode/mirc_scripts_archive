Intro:

This is Wang MTS theme version 2.1 dedicated to WangScript, written by OryNider.

It contains 21 schemes whith most used fonts and TimeStamp or NoTimeStamp.

You'll need an mts engine that supports MTS format version 1.2 but 1.3 is recomdated.

How to install:

It depends of what engine you use. The most widespread MTS theme engine out there, is KTE (Kameks Theme Engine).

I will explain how to load it on MTS loader v1.71, which is the MTS engine that I used while writting this theme:

 1 - Open up MTS loader main dialog. You can use the /mts command to do this;
 2 - Select menu "File > Add";
 3 - Go all the way to this theme path and select wang.mts file. It will appear at the themes list on the main dialog;
 4 - Select this theme from the list and click "load".

If you are using any other engine thats not MTS loader, check out its documentation to know how to load a theme; if you 
don't know what an MTS theme or MTS engine is, you might not understand what these files are all about, and its beyond
of this readme.txt file to explain in detail what all of this crap means. Check out http://www.mircscripts.org/mts.php
if you want more information about MTS themes for mIRC or want to know what that is.

Contact:

mail: orynider@rdslink.ro
www: http://pubory.uv.ro/
