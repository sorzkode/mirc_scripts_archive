mIRC Theme Standard - file icon (mts file icon)
-----------------------------------------------

Filename: mtstheme.ico

An icon file I made for MTS files (*.mts). 

Its come in .ico frames.

 DEVELOPMENT TOOLS:     

 - ArtIcons Pro v5.2
 - Image2Ico v2.7

How to set the icon for .mts files step by step in Windows 98 and 98 SE:

1) Go to Start Menu -> Settings.
2) Click Folder Options.
3) Go to the file types tab and wait for your file types to load.
4) Press the New button.
5) Type your extension into the edit box, we will use MTS File but you can use anything, then press Ok.
6) Click on one of the lines in the list, then type your extension, mts, to scroll down to it.
7) Click the Change Icon button.
8) Click the browse button then find your icon (mtstheme.ico) and press Ok, then press Close.


How to set the icon for .mts files step by step in Windows Xp:

Note: In Windows Xp you must be an administrator to do this!
1) Open My Computer (Windows Explorer).
2) Go to the Tools menu and click Folder Options.
3) Go to the file types tab and wait for your file types to load.
4) Press the New button.
5) Type your extension into the edit box, we will use MTS File but you can use anything, then press Ok.
6) Click on one of the lines in the list, then type your extension, mts, to scroll down to it.
7) Click the Change Icon button.
8) Click the browse button then find your icon (mtstheme.ico) and press Ok, then press Close.

You can asociate an editor (Windows 9x/Xp):
1) Go back to the Folder Options -> File Types -> MTS File -> Edit 
2) Press New, the type on Action: Edit
3) Click the Browse button
4) Find the program you will use, I will use Notepad or Notepad++
5) Click Set Default 
6) Click OK and then press Close.


 Contact Information:
-------------------------------------------------------

 OryNider
   www:   http://pubory.uv.ro/ ex. http://pubory.lx.ro/
   yahoo: ory_001
   mail: orynider@rdslink.ro