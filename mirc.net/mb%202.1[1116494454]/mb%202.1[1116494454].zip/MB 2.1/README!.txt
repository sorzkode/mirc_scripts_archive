// =====================
// Readme version 2.1
// ---------------------
// Topics:
// Intro;
// Installing;
// Upgrade;
// Credits;
// HELP;
// ---------------------
// contact: black-mage@sapo.pt / nowprevailsdarknesswhereoncerevealedlove@hotmail.com / black-mage @ irc.ptnet.org

// Topic 1 - Intro
-> Wellcome! thank you for downloading my mIRC Bot, this roBot is functional and not very hard to configure. has you login it would be (very) esclarecing to you if you read /help. 
once again, thank you - and have a nice mIRC Chatting!!

// Topic 2 - Installing
-> If you downloaded the version without mIRC you should take this steps in order to install MB correctly.
First you have to download the mIRC from mIRC website (www.mirc.com).
After install mIRC to another folder than MB, copy mirc.exe (ONLY) and place it in MB Folder.
Run mIRC.exe and bot should be installed correctly.

Advertise: if you copy more than just mirc.exe you wont be able to run MB correctly!

// Topic 3 - Upgrade
-> MB Is equiped with a upgrade command (/check.upd) but you can also view upgrades and stuff in mirc.net, scriptingX.com and in MB Homepage www.mahoutsukaibot.com.sapo.pt - there you can find plus that just the Bot, such as game, etc..

// Topic 4 - Credits
-> Credits go to people/mIRC users that made the first (and many others) version possible, those are:
black-mage: without me, anything of this was possible :P
ScRaMbLe: a PTnet user, who as supported me every sence i was a newbie in mIRC Scripting
Voz: this fellow gave me the website to read Sockets Tutorial =))
My Parents: They pay-up the bill at the end of the month :P
 
beta-testers: thank you fellows and friends, who caught many bugs and errors!
// Topic 5 - HELP
-> you'll have a fully dysplay of the help file inside the RoBot and if you want to know what fucntions have been addade, you can take a look at version.txt