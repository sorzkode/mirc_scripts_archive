Readme
----------------------------
XKAntiSpam is an addon from mIRC which fight spam in IRC Channels.
It has 2 level of defence. Normal and high. (You can choose which level by right clicking on mIRC windows)
Normal mode will block any spam message (private message) which is found on the spam database of XKAntiSpam.
High mode will also block priovate message which contains HTTP, www.,porn,XXX

After blocking the spam it adds the spammed to the ignore list for 1 hour.

XKAntiSpam check for updates on Start and every 24 hours and updates the antispam database if needed.



Installation:
-------------
Extract anywhere (most suggested to extract in mIRC directory), then load:
/load -rs "X:\path\xkantispam.mrc"

If you choose to extract the files on mIRC directory then just write:
/load -rs xkantispam.mrc


When the initialization warning pops, please choose yes.