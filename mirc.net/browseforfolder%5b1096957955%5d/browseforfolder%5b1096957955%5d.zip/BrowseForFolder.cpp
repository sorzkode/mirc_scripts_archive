/******************************************************************
 *
 *
 * FileName:		BrowseForFolder.dll
 * 
 * Author:			Shredplayer
 * 
 *
 ******************************************************************/

#include <windows.h>
#include <shlobj.h>


#ifndef BIF_NEWDIALOGSTYLE
#define BIF_NEWDIALOGSTYLE	0x0040
#endif
#ifndef BIF_UAHINT
#define BIF_UAHINT	0x0100
#endif
#ifndef BIF_NONEWFOLDERBUTTON
#define BIF_NONEWFOLDERBUTTON	0x0200
#endif
#ifndef BIF_USENEWUI
#define BIF_USENEWUI	0x0050
#endif



char *delchr(char *token, int c)

	{
			char *o = token ,*p = strlen(o) + o -1;

				while (*p == c)

						*p = 0;
						p--;

				while (*o == c)

						*o = 0;
						o++;

		return o;
}


char *isin(int c, char *token)

	{

			char *p = token;

			while (*p && *p != c)

					p++;

				 if (*p == c) 
			
			return p;

        return NULL;
}


 INT CALLBACK BrowseCallbackProc(HWND hwnd, 
				UINT uMsg,
				LPARAM lParam, 
				LPARAM pData) 
{
		TCHAR szPath[MAX_PATH];

		switch(uMsg) 

   {

				case BFFM_INITIALIZED:
						if (GetCurrentDirectory(sizeof(szPath)/sizeof(TCHAR),szPath))

		{

				SendMessage(hwnd, BFFM_SETSELECTION, TRUE, (LPARAM) szPath);
	

			}

		break;
				case BFFM_SELCHANGED: 

						if (SHGetPathFromIDList((LPITEMIDLIST) lParam ,szPath))

			{
								SendMessage(hwnd, BFFM_ENABLEOK, TRUE, 1);
								SendMessage(hwnd,BFFM_SETSTATUSTEXT,0,(LPARAM) szPath);

				}

			 else {

								SendMessage(hwnd, BFFM_ENABLEOK, TRUE, 0);
								SendMessage(hwnd,BFFM_SETSTATUSTEXT,0,NULL);

					 }

		break;

			case BFFM_VALIDATEFAILED:
			return 1;

	}

   return 0;

}



int __stdcall BrowseForFolder(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)

	{

	    	TCHAR szPath[MAX_PATH];
			LPITEMIDLIST pidl;

		BROWSEINFO bi;
		ZeroMemory(&bi,sizeof(bi));
		bi.ulFlags = BIF_RETURNONLYFSDIRS;
		bi.pidlRoot = 0;
		bi.lParam = 0;
		bi.lpfn = BrowseCallbackProc;
											
			char *szToken;

				szToken = strtok(data,">");

				HWND hwnd = (HWND)atol(data);

					if (IsWindow(hwnd)) bi.hwndOwner = hwnd;

						if (!isin('>', data)) szToken = strtok(NULL,">");

							if (szToken != NULL) SetCurrentDirectory(delchr(szToken,' '));

								szToken = strtok(NULL,">");

											if (szToken != NULL)

								{

											if (isin('d',szToken)) bi.ulFlags |= BIF_NEWDIALOGSTYLE;
											if (isin('e',szToken)) bi.ulFlags |= BIF_EDITBOX;
											if (isin('u',szToken)) bi.ulFlags |= BIF_USENEWUI;
											if (isin('h',szToken)) bi.ulFlags |= BIF_UAHINT;
											if (isin('n',szToken)) bi.ulFlags |= BIF_NONEWFOLDERBUTTON;
											if (isin('s',szToken)) bi.ulFlags |= BIF_STATUSTEXT;
											if (isin('f',szToken)) bi.ulFlags |= BIF_BROWSEINCLUDEFILES;
											if (isin('v',szToken)) bi.ulFlags |= BIF_VALIDATE;
											if (!IsWindow(hwnd) && isin('A',szToken)) bi.hwndOwner = aWnd;
											else if (!IsWindow(hwnd) && isin('M',szToken)) bi.hwndOwner = mWnd;

						}
									szToken = strtok(NULL,">");

									if (szToken != NULL && strcmp(szToken," ")) bi.lpszTitle = szToken;
									else bi.lpszTitle = "Choose a Directory:";

							
							pidl = SHBrowseForFolder(&bi);


			if (pidl != NULL)

				{

					SHGetPathFromIDList(pidl, szPath);
			
						wsprintf(data,"%s",szPath);
				
						IMalloc * imalloc = 0;

       						 if (SUCCEEDED(SHGetMalloc (&imalloc)))

       				{
           				 imalloc->Free (pidl);
            				imalloc->Release ();
       		 }

			return 3;

	  }

		else {
			
			strcpy(data,"S_CANCEL");
		   
			return 3;
		}

} 

// returns the dll version

int __stdcall DllInfo(HWND, HWND, char *data, char*, BOOL, BOOL)

	{
		  strcpy(data,"BrowseForFolder.dll 1.0 by Shredplayer - shredplayer@email.com");
	     return 3;

}
