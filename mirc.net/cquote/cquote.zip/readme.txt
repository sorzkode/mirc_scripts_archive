cQuote For mIRC 5.Whatever :)
(c)1998 By CitizenC

Installation
~~~~~~~~~~~~
Simply extract CQUOTE.MRC to your mIRC exe's directory
(Usually C:\mIRC -- Unless You're Using A Script) And
Type:
	/load -rs cquote.mrc

If you didn't extract cquote.mrc to your mIRC dir, thats
ok too -- just type this instead:

	/load -rs (Full Path To CQuote.mrc)

Command Reference
~~~~~~~~~~~~~~~~~
 /sayquote [n]
 Says Either A Random Quote (If You Dont Specify
 a Number) Or Says Quote Number [n] To The Active
 Channel/Query/Chat.

 /findquote <words>
 Searches your quote database for quotes that contain
 <words>. If any are found, the quote number is indicated
 so you can then say the quote with /sayquote. (See Above.)

 /addquote <quote>
 Adds A Quote To Your Database.

Please not that there are also many many options available to you..
check the channel popups for details!

-- CitizenC - March 24/99