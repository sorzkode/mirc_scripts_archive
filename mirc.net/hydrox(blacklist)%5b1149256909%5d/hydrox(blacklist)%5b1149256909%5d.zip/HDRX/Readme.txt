>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>HyDroX<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
>>>>>>>>>>>>>>>>Blacklist 2.5 
>>>>>>>>>>>>>>>>By HyDraGeN
>>>>>>>>>>>>>>>>Thank you for downloading this addon :)
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>HyDroX<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

>> Introduction:
what is this?
well nothing much to say, this is a program, that is written in a language, which is 
supported by mIRC, and only mIRC can run it...
furthermore, this addon is called blacklist, a blacklist does the following:
1.Records all your enemies :), and lets you punish them or keep them away from you
2.Blocks spamming, and lets you punish those damn spammers :P

>> Installation:
How to install?
well unzip this pack, into your mIRC directory (Recommended)
and type:
/load -rs HDRX\blacklist.HDX
and it should work.., else if you put this in a different directory
you must specify the directory while loading ex:
if you unzipped this into this directory: C:/Addons/
you should type:
/load -rs C:/Addons/HDRX/Blacklist.HDX

if you have any comments or bug reports please send them to:
HyDraGeN@Hotmail.com
Up_to_the_limits@Yahoo.com

E N D - O F - F I L E