clock.mrc by hellish@efnet

To get started, just unzip all these files to any directory (having their own directory is good, but not required, so the skins don't clutter up your addons directory or whatever).

then type
   /load -rs <path>\clock-v2.mrc
Be sure to click "yes" when it asks you if you want to perform the commands

The clock should load right up. To turn off the clock, just type /clock off or hit the "close" popup of the clock window. To start the clock again, type /clock

By default the clock is docked in the lower left hand corner of the mirc mdi. to select other positions, they are located under "dock clock to..." You can also set the clock on top of all other windows (this will make it a desktop window). However, the window will not show in the taskbar. After you drag the clock around, you can restore it to its docked position by double clicking.

Choosing skins is very simple. Just click "choose a skin" to open the skin browser. The default directory to browse is the directory the script is in, but if you have the skins in another directory you can click the "?" button to change the directory. Clicking the ">" button will return you to the script directory. Single click a skin to preview it. Double click to select it. Click "cancel" when you are finished.

Making your own skins is also simple. You can either alter the colors of the more simpler skins (digital, argon, hydro) or you can select your own fonts. the dimensions for each number are 12x17 pixels. the colon (or whatever you want it to be) is 7x17 pixels. Look at a skin to see how these dimensions are layed out on the bitmap.

New in version 2:

0. Hey this really doesn't deserve a new version number but oh well.
1. Fixed bug requiring you to have a black background
2. Fixed spaces in filenames bug (I should have known better)
3. If the clock is docked against the right edge and is showing seconds and you remove the show seconds toggle the window will be realigned with the right edge (because it is now shorter in length)
4. Added ability to place the clock ontop

Version 2a:

1. Fixed bug leaving background white when clicking show seconds, making the window larger

-hellish