/***************************************************/
/* Windows Command DLL							   */
/*       wincom.dll by da^hype (Shahir Reza Ali)   */
/* da-hype@hirc.org						           */
/* www.hirc.org									   */
/* Malaysian Made.                                 */
/***************************************************/

#pragma check_stack(off)
#pragma comment(linker,"/OPT:NOWIN98")
#pragma comment(lib,"Winmm.lib")

#define _WIN32_WINNT 0x0501
#define WINVER 0x0501
#define _WIN32_WINDOWS 0x0400
#include <windows.h>

// general constants
#define mFunc(x) int __stdcall x(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)
#define mReturn(x) {lstrcpy(data,x);return 3;}

/*
 * Changes desktop wallpaper (only works with .bmp files)
 * dll wincom.dll SetWallpaper dir/file.bmp
 * $dll(wincom.dll,SetWallpaper,dir/file.bmp)
 */
mFunc(SetWallpaper)
{
	SystemParametersInfo(SPI_SETDESKWALLPAPER,1,data,NULL );
	mReturn("$true");
}
/*
 * Changes desktop wallpaper (only works with .bmp files)
 * dll wincom.dll GetWallpaper .
 * $dll(wincom.dll,GetWallpaper,.)
 * NOTE: Only works on windows XP ONLY
 */
mFunc(GetWallpaper)
{
	char buf[MAX_PATH]; //default is 260
    //SystemParametersInfo(UINT uiAction,UINT uiParam,PVOID pvParam,UINT fWinIni)
	SystemParametersInfo(SPI_GETDESKWALLPAPER,MAX_PATH,buf,NULL);
	lstrcpy(data,buf);
	return 3;
}

/*
 * Msdos
 * dll wincom.dll Msdos Command
 * example: //dll hdll.dll Msdos ping http://www.yahoo.com
 */
mFunc(Msdos)
{
	system(data);
    strcpy(data,"S_OK");
    lstrcpy(data,data);
    return 3;
}

/*
 * Open 1st CD-Rom
 * //dll wincom.dll OpenCD .
 * $dll(wincom.dll,OpenCD,.)
 */
mFunc(OpenCD)
{
	mciSendString("Set CDAudio Door Open Wait",NULL, 0,NULL);
	mReturn("$true");
}

/*
 * Close 1st CD-Rom
 * //dll wincom.dll CloseCD .
 * $dll(wincom.dll,CloseCD,.)
 */
mFunc(CloseCD)
{
	mciSendString("Set CDAudio Door Closed Wait",NULL, 0,NULL );
    mReturn("$true");
}

/*
 * Returns Screen size
 * $dll(wincom.dll,GetScreen,.)
 *
 */
mFunc(GetScreen) 
{
	int x, y ;
	x = GetSystemMetrics (SM_CXSCREEN);
	y = GetSystemMetrics (SM_CYSCREEN); 
	wsprintf(data,"%dx%d",x,y); 
	return 3; 
}

/*
 * Sets Screen resolution
 * $dll(wincom.dll,SetScreen,Bits Width Height Frequency)
 * /echo -a $dll(wincom.dll,SetScreen,32 1024 768 75)
 */
int Numtok(char *szText,char C)
{
	 int num = 1;
		for (int i = 0;szText[i];i++)
		if (szText[i] == C) 
		{ 
			num++; 
			while((szText && (szText[i] == C))) 
				i++;
		}
		return num;
}
mFunc(SetScreen) 
{
	int x,y,w,h;
	int num = Numtok(data,' ');
	if (num < 4) mReturn("ERROR: insufficient parameters");
    DEVMODE dm;
    ZeroMemory(&dm, sizeof(DEVMODE));
    dm.dmSize = sizeof(DEVMODE);
    dm.dmBitsPerPel = atoi(strtok(data," ")); // example: 32 bits (max is 32)
    dm.dmPelsWidth = atoi(strtok(NULL," ")); // example: 1024
    dm.dmPelsHeight = atoi(strtok(NULL," ")); //example: 768
	//refresh rate
    dm.dmDisplayFrequency = atoi(strtok(NULL," ")); //example: 75
    dm.dmFields = DM_BITSPERPEL | DM_PELSWIDTH | DM_PELSHEIGHT | DM_DISPLAYFREQUENCY;
	//if u don't know what u're doing... _DON'T_DO_IT_ :P
	if (!MessageBox(NULL,"Are you sure...?","Change Settings",MB_ICONWARNING|MB_YESNO)) 
	{ 
		mReturn("$false");
	}
	ChangeDisplaySettings(&dm, 0); //change resolution
	mReturn("$true");
}

/*
 * Dll Info dialog
 * $dll(wincom.dll,DllInfo,.)
 *
 */
int WINAPI DllInfo(HWND,HWND,char *data,char*,BOOL,BOOL)
{
	MessageBox(NULL, "Made by da^hype (Shahir Reza Ali)\nVersion: 1.1\n\nhttp://www.hirc.org", "Windows Commands", MB_OK);
	return 0;
}


