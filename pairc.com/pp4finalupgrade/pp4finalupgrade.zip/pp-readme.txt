
PnP 4.00
Final Beta
mIRC 5.7


This is the last BETA release of PnP 4.00.
This requires and is designed for mIRC 5.7, not included.
The last release said it would be the last beta release, but I
decided to take the time to fix some bugs and update it for mIRC
5.7. So enjoy.

If I ever get time, I may finish up a few more things and do
some documentation, but don't count on anything. I would not
be surprised if I never touched PnP again.

This does not necessarily mean I won't ever script again, but
I make no promises.


** IF THIS IS AN UPDATE PACKAGE **
Just install over a previous beta, and answer 'yes' to any
file overwrites.


** IF THIS IS A FULL INSTALL **
If you are installing this for the first time, just unzip to a
directory. *Make sure you use/retain directories* in the zip.
Then simply copy mirc32.exe (version 5.7) into the directory.
(just the .exe- no .inis or anything.)

If you already have a previous beta configured the way you like,
you then copy your old mirc.ini and CONFIG dir to the new beta.
You can also use /profile to import settings from 4.00 or plain mIRC.
(3.20-specific settings not imported YET)


NOTE: Bug reporting and feedback features have been disabled. I
don't read the stuff anymore anyways, sorry. Please don't expect
any replies to any e-mails regarding scripting either. I don't
mean to be rude- I simply do not have the time or interest anymore.


IMPORTANT NOTE: Although I try to make this as bug free and usable
as possible, there will definately be bugs, and many features
either aren't complete, aren't in, or are in but undocumented.

For a detailed list of changes from beta to beta, see whatsnew.txt.



** Slowly increasing commands list **

/spawn [server [port]]
/aidle (extras)
/ezping (extras)
/colorwin (extras)
/ns (nickserv)
/kickstat [on|off|quiet|clear|nickname]
/defld
/atopic
/rtopic
/about
/bug
/feedback
/update
/strict [#chan]
/count [#chan]
/black [-r|*|#chan] nick|addr [=nick] [reason]
/blackedit
/repjoin
/protedit [#chan]
/prot
/config
/unban [-s] nick|addr
/serverlist [+|- network] ...
/theme
  /fontfix
  /nickcol [on|off]
  /nickcol edit
  /display
  /linesep
  /msgs
  /sounds
  /text [file.ext|on|off|mirc]
  /text edit
  /text cfg
/fav [params]
/tome
/addon
/clones [#chan] [mask]
/scan [#chan] [flags]
/notif [nick]
/ign [[-r] nick|addr]
/userlist [#chan|*]
/user [-r|-v] nick|addr [editing stuff...]
/xw command (x/w)
/cs (chanserv)
/away
/back
/awaylog
/pager
/awaycfg
/fontfix
/umode
/profile
/authlist
/auth
/scfg (sound)
/sopt (sound)
/playlist (sound)
/loc (sound)
/squeue (sound)
/spanel (sound)
/scont (sound)
/inv [#chan] [nick]
/rec [v|n [d|f]]
/mtn
/forcecs (chanserv)
/ame/amsg/aame/aamsg/acme/acmsg
/rn/urn (extras)
/lagbar (extras)
/saycolor/showcolor (extras)
/rle/sle/rlm/slm/rln/sln (extras)
/country/usa (extras)
/xdcc (xdcc)
/op/fop/dop/deop/fdop/fdeop/kick/ban/unban (etc)
/onotice/ovnotice/o/ov/wall/allbut/fnotice/peon/rnotice/nnotice
/popups
